Hi,

Thank you for downloading and using Serenity. For information on how to configure
Serenity please refer to the Wiki at http://wiki.hudson-ci.org/display/HUDSON/Serenity+Plugin.

Have a nice day,
Michael Couck