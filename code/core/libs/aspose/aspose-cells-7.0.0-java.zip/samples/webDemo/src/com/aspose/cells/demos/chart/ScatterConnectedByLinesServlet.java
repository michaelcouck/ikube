package com.aspose.cells.demos.chart;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Axis;
import com.aspose.cells.Chart;
import com.aspose.cells.ChartCollection;
import com.aspose.cells.ChartType;
import com.aspose.cells.Color;
import com.aspose.cells.FileFormatType;
import com.aspose.cells.Font;
import com.aspose.cells.Legend;
import com.aspose.cells.LegendPositionType;
import com.aspose.cells.SeriesCollection;
import com.aspose.cells.Title;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class ScatterConnectedByLinesServlet extends DemoBaseServlet
{
    private static final String TEMPLATE_FILE_PATH_PART = "/WEB-INF/Designer/Chart/ScatterTemplate.xls";

    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        int fileFormatType = FileFormatType.EXCEL_97_TO_2003;
        resultFile = "ScatterConnected.xls";

        Workbook wb = new Workbook(getServletContext().getRealPath(TEMPLATE_FILE_PATH_PART));
        int chartType = ChartType.SCATTER_CONNECTED_BY_CURVES_WITH_DATA_MARKER;
        switch (Integer.parseInt(request.getParameter("ChartTypeList")))
        {
            case 1:
            {
                chartType = ChartType.SCATTER_CONNECTED_BY_CURVES_WITHOUT_DATA_MARKER;
                break;
            }
            case 2:
            {
                chartType = ChartType.SCATTER_CONNECTED_BY_LINES_WITH_DATA_MARKER;
                break;
            }
            case 3:
            {
                chartType = ChartType.SCATTER_CONNECTED_BY_LINES_WITHOUT_DATA_MARKER;
                break;
            }
        }
        createStaticReport(wb, chartType);
        return wb;
    }

    private void createStaticReport(Workbook workbook, int chartType) throws Exception
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet dataSheet = worksheets.get(0);
        Worksheet worksheet = worksheets.get(worksheets.add());
        //Set the name of worksheet
        dataSheet.setName("Data");
        worksheet.setName("Chart");

        //Create chart
        ChartCollection charts = worksheet.getCharts();
        Chart chart = charts.get(charts.add(chartType, 1, 1, 25, 10));

        //Set properties of nseries
        SeriesCollection nSeries = chart.getNSeries();
        nSeries.add("Data!A2:B10", true);
        for(int i = 0; i < nSeries.getCount(); i++)
        {
            nSeries.get(i).setName("Particulate");
        }

        //Set properties of chart title
        Title title = chart.getTitle();
        Font font1 = title.getTextFont();
        font1.setBold(true);
        font1.setColor(Color.getBlack());
        font1.setSize(12);

        //Set properties of categoryaxis title
        Axis categoryAxis = chart.getCategoryAxis();
        title = categoryAxis.getTitle();
        title.setText("Daily Rainfall");
        Font font2 = title.getTextFont();
        font2.setBold(true);
        font2.setColor(Color.getBlack());
        font2.setSize(10);

        //Set properties of valueaxis title
        Axis valueAxis = chart.getValueAxis();
        title = valueAxis.getTitle();
        title.setText("Particulate");
        Font font3 = title.getTextFont();
        font3.setBold(true);
        font3.setColor(Color.getBlack());
        font3.setSize(10);
        title.setRotationAngle(90);

        //Set the legend position type
        Legend legend = chart.getLegend();
        legend.setPosition(LegendPositionType.TOP);
    }
}
