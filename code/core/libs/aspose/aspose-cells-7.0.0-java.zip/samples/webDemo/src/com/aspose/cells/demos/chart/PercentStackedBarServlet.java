package com.aspose.cells.demos.chart;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Axis;
import com.aspose.cells.Cells;
import com.aspose.cells.Chart;
import com.aspose.cells.ChartCollection;
import com.aspose.cells.ChartType;
import com.aspose.cells.Color;
import com.aspose.cells.FileFormatType;
import com.aspose.cells.Font;
import com.aspose.cells.SeriesCollection;
import com.aspose.cells.SheetType;
import com.aspose.cells.Title;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class PercentStackedBarServlet extends DemoBaseServlet
{
    private static final String TEMPLATE_FILE_PATH_PART = "/WEB-INF/Designer/Chart/PercentStacked.xls";

    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        int fileFormatType = FileFormatType.EXCEL_97_TO_2003;
        resultFile = "PercentStackedBar.xls";

        Workbook wb = new Workbook(getServletContext().getRealPath(TEMPLATE_FILE_PATH_PART));
        int chartType = ChartType.BAR_100_PERCENT_STACKED;
        if(request.getParameter("CheckBoxShow3D") != null)
        {
            chartType = ChartType.BAR_3_D_100_PERCENT_STACKED;
        }
        createStaticReport(wb, chartType);
        return wb;
    }

    private void createStaticReport(Workbook workbook, int chartType) throws Exception
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet worksheet = worksheets.get(worksheets.add(SheetType.CHART));
        Worksheet dataSheet = worksheets.get(0);
        //Set the name of worksheet
        dataSheet.setName("Data");
        worksheet.setName("Chart");

        //Create Chart
        ChartCollection charts = worksheet.getCharts();
        Chart chart = charts.get(charts.add(chartType, 0, 0, 0, 0));

        //Set properties of nseries
        SeriesCollection nSeries = chart.getNSeries();
        nSeries.add("Data!B2:E4", false);
        nSeries.setCategoryData("Data!B1:E1");

        Cells cells = dataSheet.getCells();
        String temp = "";
        for(int i = 0; i < nSeries.getCount(); i++)
        {
            temp = cells.get(i + 1, 0).getStringValue();
            nSeries.get(i).setName(temp);
        }

        //Set properties of chart title
        Title title = chart.getTitle();
        title.setText("Product contribution to total sales");
        Font font1 = title.getTextFont();
        font1.setBold(true);
        font1.setColor(Color.getBlack());
        font1.setSize(12);

        //Set properties of valueaxis title
        Axis valueAxis = chart.getValueAxis();
        title = valueAxis.getTitle();
        title.setText("% of total sales");
        Font font2 = title.getTextFont();
        font2.setColor(Color.getBlack());
        font2.setBold(true);
        font2.setSize(10);
    }
}
