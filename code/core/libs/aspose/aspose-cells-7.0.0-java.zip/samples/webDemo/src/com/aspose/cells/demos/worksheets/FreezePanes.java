package com.aspose.cells.demos.worksheets;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class FreezePanes extends DemoBaseServlet
{
    @Override
    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        resultFile = "FreezePanes.xls";
        Workbook workbook = new Workbook();
        createStaticReport(workbook);
        return workbook;
    }

    private void createStaticReport(Workbook workbook) throws Exception
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet worksheet = worksheets.get(0);

        worksheet.freezePanes(3, 2, 3, 2);
    }
}
