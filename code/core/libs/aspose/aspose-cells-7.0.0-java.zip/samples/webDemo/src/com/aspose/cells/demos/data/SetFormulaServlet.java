package com.aspose.cells.demos.data;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Cell;
import com.aspose.cells.Cells;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class SetFormulaServlet extends DemoBaseServlet
{
    private static final String TEMPLATE_FILE_PATH_PART = "/WEB-INF/Designer/Workbooks/Formula.xls";

    @Override
    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        resultFile = "Formula.xls";
        ServletContext sc = getServletContext();
        String template_file_path = sc.getRealPath(TEMPLATE_FILE_PATH_PART);
        Workbook workbook = new Workbook(template_file_path);
        createStaticReport(workbook);
        return workbook;
    }

    private void createStaticReport(Workbook workbook)
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet worksheet = worksheets.get(0);

        Cells cells = worksheet.getCells();
        Cell cell;

        String strFormula = "";
        for(int i = 18; i <= 133; i++)
        {
            strFormula = cells.get(i, 2).getStringValue();
            cell = cells.get(i, 3);
            //Set a formula of the Cell
            cell.setFormula(strFormula);
        }
    }
}
