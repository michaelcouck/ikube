package com.aspose.cells.demos.pagesetup;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import com.aspose.cells.PageSetup;
import com.aspose.cells.PrintCommentsType;
import com.aspose.cells.PrintOrderType;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class SettingPrintOptions extends DemoBaseServlet
{
    private static final String TEMPLATE_FILE_PATH_PART = "/WEB-INF/Designer/book1.xls";

    @Override
    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        resultFile = "SettingPrintOptions.xls";
        ServletContext sc = getServletContext();
        String template_file_path = sc.getRealPath(TEMPLATE_FILE_PATH_PART);
        Workbook workbook = new Workbook(template_file_path);
        createStaticReport(workbook);
        return workbook;
    }

    private void createStaticReport(Workbook wb) throws Exception
    {
        WorksheetCollection worksheets = wb.getWorksheets();
        Worksheet worksheet = worksheets.get(0);

        PageSetup pageSetup = worksheet.getPageSetup();
        pageSetup.setPrintArea("A1:G5");
        pageSetup.setPrintTitleColumns("$A:$B");
        pageSetup.setPrintTitleRows("$1:$2");
        //Allow to print gridlines
        pageSetup.setPrintGridlines(true);
        //Allow to print row/column headings
        pageSetup.setPrintHeadings(true);
        //Allow to print worksheet in black & white mode
        pageSetup.setBlackAndWhite(true);
        //Allow to print comments as displayed on worksheet
        pageSetup.setPrintComments(PrintCommentsType.PRINT_IN_PLACE);
        //Allow to print worksheet with draft quality
        pageSetup.setPrintDraft(true);
        //Allow to print cell errors
        pageSetup.setOrder(PrintOrderType.DOWN_THEN_OVER);
    }
}
