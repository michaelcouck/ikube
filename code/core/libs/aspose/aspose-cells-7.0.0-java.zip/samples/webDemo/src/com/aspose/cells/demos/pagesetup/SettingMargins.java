package com.aspose.cells.demos.pagesetup;

import javax.servlet.*;
import javax.servlet.http.*;

import com.aspose.cells.*;
import com.aspose.cells.demos.DemoBaseServlet;

public class SettingMargins extends DemoBaseServlet
{ 
	private static final String TEMPLATE_FILE_PATH_PART = "/WEB-INF/Designer/book1.xls";
  
	@Override
	protected Workbook createReport(HttpServletRequest request) throws Exception {
	    resultFile = "SettingMargins.xls"; 
	    ServletContext sc = getServletContext();
	    String template_file_path = sc.getRealPath(TEMPLATE_FILE_PATH_PART);
	    Workbook workbook = new Workbook(template_file_path);
	
	    WorksheetCollection worksheets = workbook.getWorksheets();
	    Worksheet worksheet = worksheets.get(0);
	
	    PageSetup pageSetup = worksheet.getPageSetup();
	    pageSetup.setBottomMargin(5);
	    pageSetup.setFooterMargin(5);
	    pageSetup.setHeaderMargin(5);
	    pageSetup.setLeftMargin(5);
	    pageSetup.setRightMargin(5);
	    pageSetup.setTopMargin(5);
		return workbook;
	} 
}
