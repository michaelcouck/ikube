package com.aspose.cells.demos.chart;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Cells;
import com.aspose.cells.Chart;
import com.aspose.cells.ChartCollection;
import com.aspose.cells.ChartType;
import com.aspose.cells.Color;
import com.aspose.cells.FileFormatType;
import com.aspose.cells.Font;
import com.aspose.cells.SeriesCollection;
import com.aspose.cells.SheetType;
import com.aspose.cells.Title;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class PyramidPercentStackedServlet extends DemoBaseServlet
{
    private static final String TEMPLATE_FILE_PATH_PART = "/WEB-INF/Designer/Chart/PercentStacked.xls";

    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        int fileFormatType = FileFormatType.EXCEL_97_TO_2003;
        resultFile = "PyramidPercentStacked.xls";

        Workbook wb = new Workbook(getServletContext().getRealPath(TEMPLATE_FILE_PATH_PART));
        int chartType = ChartType.PYRAMID_100_PERCENT_STACKED;
        switch (Integer.parseInt(request.getParameter("ChartTypeList")))
        {
            case 1:
            {
                chartType = ChartType.PYRAMID_BAR_100_PERCENT_STACKED;
                break;
            }
        }
        createStaticReport(wb, chartType);
        return wb;
    }

    private void createStaticReport(Workbook workbook, int chartType) throws Exception
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet dataSheet = worksheets.get(0);
        Worksheet worksheet = worksheets.get(worksheets.add(SheetType.CHART));
        //Set the name of worksheet
        dataSheet.setName("Data");
        worksheet.setName("Chart");

        //Create chart
        ChartCollection charts = worksheet.getCharts();
        Chart chart = charts.get(charts.add(chartType, 0, 0, 0, 0));

        //Add the nseries collection to a chart
        SeriesCollection nSeries = chart.getNSeries();
        nSeries.add("Data!B2:E4", false);
        //Get or set the range of category Axis values
        nSeries.setCategoryData("Data!B1:E1");

        Cells cells = dataSheet.getCells();
        String temp = "";
        for(int i = 0; i < nSeries.getCount(); i++)
        {
            temp = cells.get(i + 1, 0).getStringValue();
            nSeries.get(i).setName(temp);
        }

        //Set properies to title
        Title title = chart.getTitle();
        title.setText("Product contribution to total sales");
        Font font = title.getTextFont();
        font.setBold(true);
        font.setColor(Color.getBlack());
        font.setSize(12);
    }
}
