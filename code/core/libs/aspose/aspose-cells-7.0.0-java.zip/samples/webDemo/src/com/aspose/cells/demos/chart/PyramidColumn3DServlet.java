package com.aspose.cells.demos.chart;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Chart;
import com.aspose.cells.ChartCollection;
import com.aspose.cells.ChartType;
import com.aspose.cells.Color;
import com.aspose.cells.FileFormatType;
import com.aspose.cells.Font;
import com.aspose.cells.SeriesCollection;
import com.aspose.cells.Title;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class PyramidColumn3DServlet extends DemoBaseServlet
{
    private static final String TEMPLATE_FILE_PATH_PART = "/WEB-INF/Designer/Chart/Template2.xls";

    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        int fileFormatType = FileFormatType.EXCEL_97_TO_2003;
        resultFile = "PyramidColumn3D.xls";

        Workbook wb = new Workbook(getServletContext().getRealPath(TEMPLATE_FILE_PATH_PART));
        createStaticReport(wb);
        return wb;
    }

    private void createStaticReport(Workbook workbook) throws Exception
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet worksheet = worksheets.get(0);
        //Set the name of worksheet
        worksheet.setName("Pyramid Column3D");

        //Create chart
        ChartCollection charts = worksheet.getCharts();
        Chart chart = charts.get(charts.add(ChartType.PYRAMID_COLUMN_3_D, 1, 3, 25, 12));

        //Set properties of nseries
        SeriesCollection nSeries = chart.getNSeries();
        nSeries.add("B2:C12", true);
        nSeries.setCategoryData("A2:A12");

        //Set properties of chart
        chart.setElevation(15);
        chart.setRotationAngle(20);
        chart.setShowLegend(false);
        chart.setGapWidth(10);
        chart.setDepthPercent(280);

        //Set properties of chart title
        Title title = chart.getTitle();
        title.setText("Number of Employees");
        Font font = title.getTextFont();
        font.setBold(true);
        font.setColor(Color.getBlack());
        font.setSize(12);
    }

}
