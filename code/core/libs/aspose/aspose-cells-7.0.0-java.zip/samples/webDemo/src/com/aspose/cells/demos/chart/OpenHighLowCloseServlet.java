package com.aspose.cells.demos.chart;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Axis;
import com.aspose.cells.Cells;
import com.aspose.cells.Chart;
import com.aspose.cells.ChartCollection;
import com.aspose.cells.ChartType;
import com.aspose.cells.Color;
import com.aspose.cells.FileFormatType;
import com.aspose.cells.Font;
import com.aspose.cells.SeriesCollection;
import com.aspose.cells.Title;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class OpenHighLowCloseServlet extends DemoBaseServlet
{
    private static final String TEMPLATE_FILE_PATH_PART = "/WEB-INF/Designer/Chart/StockTemplate2.xls";

    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        int fileFormatType = FileFormatType.EXCEL_97_TO_2003;
        resultFile = "OpenHighLowClose.xls";

        Workbook wb = new Workbook(getServletContext().getRealPath(TEMPLATE_FILE_PATH_PART));
        createStaticReport(wb);
        return wb;
    }

    private void createStaticReport(Workbook workbook) throws Exception
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet dataSheet = worksheets.get(0);
        Worksheet worksheet = worksheets.get(worksheets.add());
        //Set the name of worksheet
        dataSheet.setName("Data");
        worksheet.setName("Chart");

        //Create chart
        ChartCollection charts = worksheet.getCharts();
        Chart chart = charts.get(charts.add(ChartType.STOCK_OPEN_HIGH_LOW_CLOSE, 1, 1, 25, 10));

        //Set pproperties of nseries
        SeriesCollection nSeries = chart.getNSeries();
        nSeries.add("Data!B2:E4", true);
        nSeries.setCategoryData("Data!A2:A4");

        Cells cells = dataSheet.getCells();
        String temp = "";
        for(int i = 0; i < nSeries.getCount(); i++)
        {
            temp = cells.get(0, i + 1).getStringValue();
            nSeries.get(i).setName(temp);
        }

        //Set properties of chart title
        Title title = chart.getTitle();
        title.setText("Stock chart");
        Font font1 = title.getTextFont();
        font1.setBold(true);
        font1.setColor(Color.getBlack());
        font1.setSize(12);

        //Set Properties of categoryaxis title
        Axis categoryAxis = chart.getCategoryAxis();
        title = categoryAxis.getTitle();
        title.setText("Scock Names");
        Font font2 = title.getTextFont();
        font2.setBold(true);
        font2.setColor(Color.getBlack());
        font2.setSize(10);

        //Set properties of valueaxis title
        Axis valueAxis = chart.getValueAxis();
        title = valueAxis.getTitle();
        title.setText("Stock Price");
        Font font3 = title.getTextFont();
        font3.setBold(true);
        font3.setColor(Color.getBlack());
        font3.setSize(10);
        title.setRotationAngle(90);
    }
}
