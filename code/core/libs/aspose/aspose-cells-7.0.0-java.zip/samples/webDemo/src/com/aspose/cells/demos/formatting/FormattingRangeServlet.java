package com.aspose.cells.demos.formatting;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Border;
import com.aspose.cells.BorderCollection;
import com.aspose.cells.BorderType;
import com.aspose.cells.Cell;
import com.aspose.cells.CellBorderType;
import com.aspose.cells.Cells;
import com.aspose.cells.Color;
import com.aspose.cells.Column;
import com.aspose.cells.Font;
import com.aspose.cells.Row;
import com.aspose.cells.Style;
import com.aspose.cells.StyleFlag;
import com.aspose.cells.TextAlignmentType;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class FormattingRangeServlet extends DemoBaseServlet
{
    @Override
    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        resultFile = "FormattingRange.xls";
        Workbook workbook = new Workbook();
        createStaticReport(workbook);
        return workbook;
    }

    private void createStaticReport(Workbook workbook)
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet worksheet = worksheets.get(0);

        Cells cells = worksheet.getCells();
        Cell cell;
        Style style = workbook.createStyle();
        style.setVerticalAlignment(TextAlignmentType.CENTER);
        style.setHorizontalAlignment(TextAlignmentType.CENTER);
        Font font = style.getFont();
        font.setColor(Color.getGreen());
        style.setShrinkToFit(true);

        BorderCollection borders = style.getBorders();
        Border border = borders.getByBorderType(BorderType.BOTTOM_BORDER);
        border.setColor(Color.getRed());
        border.setLineStyle(CellBorderType.DOTTED);

        //Access a row from the Rows collection
        Row row = cells.getRows().get(0);
        StyleFlag flag = new StyleFlag();
        flag.setAll(true);
        row.applyStyle(style, flag);

        //Access a column from the Columns collection
        Column column = cells.getColumns().get(0);
        column.applyStyle(style, flag);
    }
}
