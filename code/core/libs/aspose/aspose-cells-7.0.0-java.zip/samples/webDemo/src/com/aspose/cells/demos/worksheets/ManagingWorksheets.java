package com.aspose.cells.demos.worksheets;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class ManagingWorksheets extends DemoBaseServlet
{
    private static final String TEMPLATE_FILE_PATH_PART = "/WEB-INF/Designer/Workbooks/ManagingWorksheets.xls";

    @Override
    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        resultFile = "ManagingWorksheets.xls";
        ServletContext sc = getServletContext();
        String template_file_path = sc.getRealPath(TEMPLATE_FILE_PATH_PART);
        Workbook workbook = new Workbook(template_file_path);
        if("Add".equals(request.getParameter("_command")))
        {
            addWorksheets(workbook);
        }
        else
        {
            removeWorksheets(workbook);
        }
        return workbook;
    }

    private void addWorksheets(Workbook workbook)
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet worksheet = worksheets.get(0);
        //Set the name of worksheet
        worksheet.setName("My Worksheet1");

        worksheets.get(worksheets.add());
        worksheet = worksheets.get(1);
        //Set the name of worksheet
        worksheet.setName("My Worksheet2");

        worksheets.get(worksheets.add());
        worksheet = worksheets.get(2);
        //Set the name of worksheet
        worksheet.setName("My Worksheet3");
    }

    private void removeWorksheets(Workbook workbook)
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        //Remove the worksheet
        worksheets.removeAt(1);
    }
}
