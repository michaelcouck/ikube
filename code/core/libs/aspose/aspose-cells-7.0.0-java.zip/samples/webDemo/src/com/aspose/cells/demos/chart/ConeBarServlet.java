package com.aspose.cells.demos.chart;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Chart;
import com.aspose.cells.ChartCollection;
import com.aspose.cells.ChartType;
import com.aspose.cells.Color;
import com.aspose.cells.FileFormatType;
import com.aspose.cells.Font;
import com.aspose.cells.SeriesCollection;
import com.aspose.cells.Title;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class ConeBarServlet extends DemoBaseServlet
{
    private static final String TEMPLATE_FILE_PATH_PART = "/WEB-INF/Designer/Chart/Template2.xls";

    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        int fileFormatType = FileFormatType.EXCEL_97_TO_2003;
        resultFile = "ConeBar.xls";

        Workbook wb = new Workbook(getServletContext().getRealPath(TEMPLATE_FILE_PATH_PART));
        int chartType = ChartType.CONICAL_BAR;
        switch (Integer.parseInt(request.getParameter("ChartTypeList")))
        {
            case 0:
                chartType = ChartType.CONICAL_BAR;
                break;
            case 1:
                chartType = ChartType.CONICAL_BAR_STACKED;
                break;
        }
        createStaticReport(wb, chartType);
        return wb;
    }

    private void createStaticReport(Workbook workbook, int chartType) throws Exception
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet dataSheet = worksheets.get(0);
        Worksheet worksheet = worksheets.get(worksheets.add());
        //Set the name of worksheet
        dataSheet.setName("Data");
        worksheet.setName("Chart");

        //Create chart
        ChartCollection charts = worksheet.getCharts();
        Chart chart = charts.get(charts.add(chartType, 1, 1, 25, 10));

        //Set properties of nseries
        SeriesCollection nSeries = chart.getNSeries();
        nSeries.add("Data!B2:C12", true);
        nSeries.setCategoryData("Data!A2:A12");

        //Set properties of chart
        chart.setElevation(15);
        chart.setRotationAngle(20);
        chart.setShowLegend(false);
        chart.setGapWidth(10);
        chart.setDepthPercent(280);

        //Set properties of chart title
        Title title = chart.getTitle();
        title.setText("Number of Employees");
        Font font = title.getTextFont();
        font.setBold(true);
        font.setColor(Color.getBlack());
        font.setSize(12);
    }
}
