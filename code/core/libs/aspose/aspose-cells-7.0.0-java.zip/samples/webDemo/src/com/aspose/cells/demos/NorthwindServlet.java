package com.aspose.cells.demos;

//
// Copyright 2002-2004 Aspose Pty Ltd. All Rights Reserved.
//
// This file is part of Aspose.Cells. The source code in this file
// is only intended as a supplement to the documentation, and is provided
// "as is", without warranty of any kind, either expressed or implied.
//

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.FileFormatType;
import com.aspose.cells.Workbook;

public class NorthwindServlet extends DemoBaseServlet
{
    private static final long serialVersionUID = 3689633583941628976L;

    private static final String DB_URL_P1 = "jdbc:odbc:driver={Microsoft Access Driver (*.mdb)};DBQ=";
    private static final String DB_URL_P2 = "/WEB-INF/Database/Northwind.mdb";

    private static final String TEMPLATE_FILE_PATH_PART = "/WEB-INF/Designer/Northwind.xls";

    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        String command = request.getParameter("_command");
        int fileFormatType = FileFormatType.EXCEL_97_TO_2003;
        resultFile = command + ".xls";

        ServletContext sc = getServletContext();

        String db_url = DB_URL_P1 + sc.getRealPath(DB_URL_P2);
        String template_file_path = sc.getRealPath(TEMPLATE_FILE_PATH_PART);
        Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
        Workbook wb = new Workbook(template_file_path);

        if("ProductsList".equals(command))
        {
            DemoNorthwind.createProductsList(db_url, wb);
        }
        else if("Catalog".equals(command))
        {
            DemoNorthwind.createCatalog(db_url, wb);
        }
        else if("CatalogSubreport".equals(command))
        {
            DemoNorthwind.createCatalogSubreport(db_url, wb);
        }
        else if("CustomerLabels".equals(command))
        {
            DemoNorthwind.createCustomerLabels(db_url, wb);
        }
        else if("EmployeeSales".equals(command))
        {
            DemoNorthwind.createEmployeeSales(db_url, wb);
        }
        else if("Invoice".equals(command))
        {
            DemoNorthwind.createInvoice(db_url, wb);
        }
        else if("ProductsByCategory".equals(command))
        {
            DemoNorthwind.createProductsByCategory(db_url, wb);
        }
        else if("SalesByCategorySubreport".equals(command))
        {
            DemoNorthwind.createSalesByCategorySubreport(db_url, wb);
        }
        else if("SalesByYear".equals(command))
        {
            DemoNorthwind.createSalesByYear(db_url, wb);
        }
        else if("SalesByYearSubreport".equals(command))
        {
            DemoNorthwind.createSalesByYearSubreport(db_url, wb);
        }
        else if("SalesTotals".equals(command))
        {
            DemoNorthwind.createSalesTotals(db_url, wb);
        }
        else if("SummaryByQuarter".equals(command))
        {
            DemoNorthwind.createSummaryByQuarter(db_url, wb);
        }
        else
        {
            // Unrecognized command. We simply throw an exception.
            throw new IllegalArgumentException("Unrecognized command: " + command);
        }
        return wb;
    }

}
