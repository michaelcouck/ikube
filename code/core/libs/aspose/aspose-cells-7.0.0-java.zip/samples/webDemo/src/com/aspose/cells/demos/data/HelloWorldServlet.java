package com.aspose.cells.demos.data;

import java.util.Calendar;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Cell;
import com.aspose.cells.CellValueType;
import com.aspose.cells.Cells;
import com.aspose.cells.DateTime;
import com.aspose.cells.Style;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class HelloWorldServlet extends DemoBaseServlet
{
    private static final String TEMPLATE_FILE_PATH_PART = "/WEB-INF/Designer/Workbooks/HelloWorld.xls";

    @Override
    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        resultFile = "HelloWorld.xls";
        ServletContext sc = getServletContext();
        String template_file_path = sc.getRealPath(TEMPLATE_FILE_PATH_PART);
        Workbook workbook = new Workbook(template_file_path);
        createStaticReport(workbook);
        return workbook;
    }

    private void createStaticReport(Workbook workbook)
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet worksheet = worksheets.get(0);
        Cells cells = worksheet.getCells();
        Cell cell;

        //Put a string value into the cell using its name
        cell = cells.get("A1");
        cell.setValue("Cell Value");

        //put a string value into the cell using its name
        cell = cells.get("A2");
        cell.setValue("Hello World");

        //Put an boolean value into the cell using its name
        cell = cells.get("A3");
        cell.setValue(true);

        //Put an int value into the cell using its name
        cell = cells.get("A4");
        cell.setValue(100);

        //Put an double value into the cell using its name
        cell = cells.get("A5");
        cell.setValue(2856.5);

        //Put an object value into the cell using its name
        Object obj = "Aspose";
        cell = cells.get("A6");
        cell.setValue(obj);

        //Put an datetime value into the cell
        Calendar calendar = Calendar.getInstance();
        cell = cells.get("A7");
        cell.setValue(new DateTime(calendar));
        Style style = cell.getStyle();
        style.setNumber(14);
        cell.setStyle(style);

        //Put a string value into the cell using its row and column
        cell = cells.get(0, 1);
        cell.setValue("Cell Value Type");
        int temp;
        for(int i = 1; i < 7; i++)
        {
            temp = cells.get(i, 0)./* getValueType */getType();
            cell = cells.get(i, 1);
            switch (temp)
            {
                case CellValueType.IS_NULL:
                    cell.setValue("Null");
                    break;
                case CellValueType.IS_BOOL:
                    cell.setValue("Boolean");
                    break;
                case CellValueType.IS_DATE_TIME:
                    cell.setValue("Calendar");
                    break;
                case CellValueType.IS_STRING:
                    cell.setValue("String");
                    break;
                case CellValueType.IS_NUMERIC:
                    cell.setValue("Double");
                    break;
                default:
                    cell.setValue("String");
                    break;
            }
        }
    }
}
