package com.aspose.cells.demos.pivottable;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Cell;
import com.aspose.cells.Cells;
import com.aspose.cells.PivotFieldType;
import com.aspose.cells.PivotTable;
import com.aspose.cells.PivotTableCollection;
import com.aspose.cells.Style;
import com.aspose.cells.StyleFlag;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class PivotTableServlet extends DemoBaseServlet
{
    @Override
    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        resultFile = "PivotTable.xls";
        Workbook workbook = new Workbook();
        createStaticData(workbook);
        createStaticReport(workbook);
        return workbook;
    }

    private void createStaticData(Workbook workbook)
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet worksheet = worksheets.get(0);

        Cells cells = worksheet.getCells();
        //Setting the value to the cells
        Cell cell = cells.get("A1");
        cell.setValue("Sport");
        cell = cells.get("B1");
        cell.setValue("Quarter");
        cell = cells.get("C1");
        cell.setValue("Sales");

        cell = cells.get("A2");
        cell.setValue("Golf");
        cell = cells.get("A3");
        cell.setValue("1Golf");
        cell = cells.get("A4");
        cell.setValue("Tennis");
        cell = cells.get("A5");
        cell.setValue("Tennis");
        cell = cells.get("A6");
        cell.setValue("Tennis");
        cell = cells.get("A7");
        cell.setValue("Tennis");
        cell = cells.get("A8");
        cell.setValue("Golf");

        cell = cells.get("B2");
        cell.setValue("Qtr3");
        cell = cells.get("B3");
        cell.setValue("Qtr4");
        cell = cells.get("B4");
        cell.setValue("Qtr3");
        cell = cells.get("B5");
        cell.setValue("Qtr4");
        cell = cells.get("B6");
        cell.setValue("Qtr3");
        cell = cells.get("B7");
        cell.setValue("Qtr4");
        cell = cells.get("B8");
        cell.setValue("Qtr3");

        cell = cells.get("C2");
        cell.setValue(1500);
        cell = cells.get("C3");
        cell.setValue(2000);
        cell = cells.get("C4");
        cell.setValue(600);
        cell = cells.get("C5");
        cell.setValue(1500);
        cell = cells.get("C6");
        cell.setValue(4070);
        cell = cells.get("C7");
        cell.setValue(5000);
        cell = cells.get("C8");
        cell.setValue(6430);
    }

    private void createStaticReport(Workbook workbook)
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet worksheet = worksheets.get(0);

        PivotTableCollection pivotTables = worksheet.getPivotTables();

        //Adding a PivotTable to the worksheet
        int index = pivotTables.add("=A1:C8", "E3", "PivotTable2");

        //Accessing the instance of the newly added PivotTable
        PivotTable pivotTable = pivotTables.get(index);

        //Unshowing grand totals for rows.
        pivotTable.setRowGrand(false);

        //Draging the first field to the row area.
        pivotTable.addFieldToArea(PivotFieldType.ROW, 0);

        //Draging the second field to the column area.
        pivotTable.addFieldToArea(PivotFieldType.COLUMN, 1);

        //Draging the third field to the data area.
        pivotTable.addFieldToArea(PivotFieldType.DATA, 2);
    }
}
