package com.aspose.cells.demos.chart;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Axis;
import com.aspose.cells.Chart;
import com.aspose.cells.ChartCollection;
import com.aspose.cells.ChartType;
import com.aspose.cells.Color;
import com.aspose.cells.FileFormatType;
import com.aspose.cells.Font;
import com.aspose.cells.Legend;
import com.aspose.cells.LegendPositionType;
import com.aspose.cells.SeriesCollection;
import com.aspose.cells.Title;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class ClusteredColumnServlet extends DemoBaseServlet
{
    private static final String TEMPLATE_FILE_PATH_PART = "/WEB-INF/Designer/Chart/Template.xls";

    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        int fileFormatType = FileFormatType.EXCEL_97_TO_2003;
        resultFile = "ClusteredColumn.xls";

        Workbook wb = new Workbook(getServletContext().getRealPath(TEMPLATE_FILE_PATH_PART));
        int gapWidth = Integer.parseInt(request.getParameter("GapWidth"));
        String categoryAxisTitle = request.getParameter("CategoryAxisTitle");
        String valueAxisTitle = request.getParameter("ValueAxisTitle");
        double maxValue = Double.parseDouble(request.getParameter("ValueMaxValue"));
        double minValue = Double.parseDouble(request.getParameter("ValueMinValue"));
        double majorUnit = Double.parseDouble(request.getParameter("ValueMajorUnit"));
        double minorUnit = Double.parseDouble(request.getParameter("ValueMinorUnit"));
        createColumnChart(wb, gapWidth, categoryAxisTitle, valueAxisTitle, majorUnit, maxValue,
                minorUnit, minValue);

        return wb;
    }

    private void createColumnChart(Workbook workbook, int gapWidth, String categoryAxisTitle,
            String valueAxisTitle, Double majorUnit, Double maxValue, Double minorUnit,
            Double minValue) throws Exception
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet worksheet = worksheets.get(0);
        //Set the name of the worksheet
        worksheet.setName("Clustered Column");

        //Create chart
        ChartCollection charts = worksheet.getCharts();
        Chart chart = charts.get(charts.add(ChartType.COLUMN, 5, 1, 29, 10));

        SeriesCollection nSeries = chart.getNSeries();

        //Add the nseries collection to a chart
        nSeries.add("B2:B4", true);
        //Set the range of category axis values
        nSeries.setCategoryData("A2:A4");

        for(int i = 0; i < nSeries.getCount(); i++)
        {
            nSeries.get(i).getDataLabels().setShowValue(true);
            nSeries.get(i).setColorVaried(true);
        }

        Legend legend = chart.getLegend();
        //Set the legend position type
        legend.setPosition(LegendPositionType.TOP);
        chart.setGapWidth(gapWidth);

        //Set properties of chart title
        Title title = chart.getTitle();
        title.setText("Marketing Costs by Region");
        Font font1 = title.getTextFont();
        font1.setBold(true);
        font1.setColor(Color.getBlack());
        font1.setSize(12);

        //Set properties of categoryaxis title
        Axis categoryAxis = chart.getCategoryAxis();
        title = categoryAxis.getTitle();
        title.setText(categoryAxisTitle);
        Font font2 = title.getTextFont();
        font2.setName("Arial");
        font2.setBold(true);
        font2.setColor(Color.getBlack());
        font2.setSize(10);

        //Set properties of valueaxis title
        Axis valueAxis = chart.getValueAxis();
        title = valueAxis.getTitle();
        title.setText(valueAxisTitle);
        title.setRotationAngle(90);
        valueAxis.setMajorUnit(majorUnit);
        valueAxis.setMaxValue(maxValue);
        valueAxis.setMinorUnit(minorUnit);
        valueAxis.setMinValue(minValue);
        valueAxis.getMajorGridLines().setVisible(false);
    }
}
