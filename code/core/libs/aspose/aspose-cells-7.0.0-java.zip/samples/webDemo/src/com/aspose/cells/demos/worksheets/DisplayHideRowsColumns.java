package com.aspose.cells.demos.worksheets;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class DisplayHideRowsColumns extends DemoBaseServlet
{
    @Override
    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        resultFile = "DisplayHideRowsColumns.xls";
        Workbook workbook = new Workbook();
        createStaticReport(workbook, "Display".equals(request.getParameter("_command")));
        return workbook;
    }

    private void createStaticReport(Workbook workbook, boolean display) throws Exception
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet worksheet = worksheets.get(0);
        worksheet.setRowColumnHeadersVisible(display);
    }
}
