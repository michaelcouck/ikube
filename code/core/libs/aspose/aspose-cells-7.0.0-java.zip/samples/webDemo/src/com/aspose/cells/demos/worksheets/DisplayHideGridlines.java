package com.aspose.cells.demos.worksheets;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.FileFormatType;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class DisplayHideGridlines extends DemoBaseServlet
{
    private void createStaticReport(Workbook wb, boolean display) throws Exception
    {
        WorksheetCollection worksheets = wb.getWorksheets();
        Worksheet worksheet = worksheets.get(0);
        worksheet.setGridlinesVisible(display);
    }

    @Override
    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        int fileFormatType = FileFormatType.EXCEL_97_TO_2003;
        resultFile = "DisplayHideGridlines.xls";

        Workbook wb = new Workbook(fileFormatType);
        boolean display = "Display".equals(request.getParameter("_command"));
        createStaticReport(wb, display);
        return wb;
    }

}
