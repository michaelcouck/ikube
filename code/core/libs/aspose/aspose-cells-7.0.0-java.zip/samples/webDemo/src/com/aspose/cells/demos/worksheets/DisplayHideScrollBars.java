package com.aspose.cells.demos.worksheets;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.FileFormatType;
import com.aspose.cells.Workbook;
import com.aspose.cells.WorkbookSettings;
import com.aspose.cells.demos.DemoBaseServlet;

public class DisplayHideScrollBars extends DemoBaseServlet
{
    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        int fileFormatType = FileFormatType.EXCEL_97_TO_2003;
        resultFile = "DisplayHideScrollBars.xls";

        Workbook wb = new Workbook(fileFormatType);
        boolean display = "Display".equals(request.getParameter("_command"));
        createStaticReport(wb, display);
        return wb;
    }

    private void createStaticReport(Workbook wb, boolean display) throws IOException
    {
        WorkbookSettings settings = wb.getSettings();
        settings.setHScrollBarVisible(display);
        settings.setVScrollBarVisible(display);
    }

}
