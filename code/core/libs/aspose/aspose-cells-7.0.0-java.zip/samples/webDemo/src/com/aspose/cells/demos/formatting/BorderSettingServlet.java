package com.aspose.cells.demos.formatting;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.BorderCollection;
import com.aspose.cells.Cell;
import com.aspose.cells.CellBorderType;
import com.aspose.cells.Cells;
import com.aspose.cells.Color;
import com.aspose.cells.Style;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class BorderSettingServlet extends DemoBaseServlet
{
    @Override
    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        resultFile = "BorderSetting.xls";
        Workbook workbook = new Workbook();
        createStaticReport(workbook);
        return workbook;
    }

    private void createStaticReport(Workbook workbook)
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet worksheet = worksheets.get(0);

        Cells cells = worksheet.getCells();
        Cell cell;
        Style style;

        cell = cells.get("B2");
        style = cell.getStyle();
        BorderCollection borders = style.getBorders();
        borders.setStyle(CellBorderType.DASHED);
        borders.setColor(Color.getBlue());
        cell.setStyle(style);
    }
}
