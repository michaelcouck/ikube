package com.aspose.cells.demos.chart;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Axis;
import com.aspose.cells.Chart;
import com.aspose.cells.ChartCollection;
import com.aspose.cells.ChartType;
import com.aspose.cells.Color;
import com.aspose.cells.FileFormatType;
import com.aspose.cells.Font;
import com.aspose.cells.SeriesCollection;
import com.aspose.cells.Title;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class ScatterServlet extends DemoBaseServlet
{
    private static final String TEMPLATE_FILE_PATH_PART = "/WEB-INF/Designer/Chart/ScatterTemplate.xls";

    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        int fileFormatType = FileFormatType.EXCEL_97_TO_2003;
        resultFile = "Scatter.xls";

        Workbook wb = new Workbook(getServletContext().getRealPath(TEMPLATE_FILE_PATH_PART));
        createStaticReport(wb);
        return wb;
    }

    private void createStaticReport(Workbook workbook) throws Exception
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet worksheet = worksheets.get(0);
        //Set the name of worksheet
        worksheet.setName("Scatter");

        //Create chart
        ChartCollection charts = worksheet.getCharts();
        Chart chart = charts.get(charts.add(ChartType.SCATTER, 1, 3, 25, 12));

        //Set properties of nseries
        SeriesCollection nSeries = chart.getNSeries();
        nSeries.add("A2:B10", true);
        for(int i = 0; i < nSeries.getCount(); i++)
        {
            nSeries.get(i).setName("Particulate");
        }

        //Set properties of chart title
        Title title = chart.getTitle();
        title.setText("Scatter Chart : Particulate Levels in Rainfall");
        Font font1 = title.getTextFont();
        font1.setBold(true);
        font1.setColor(Color.getBlack());
        font1.setSize(12);

        //Set properties of categoryaxis title
        Axis categoryAxis = chart.getCategoryAxis();
        title = categoryAxis.getTitle();
        title.setText("Daily Rainfall");
        Font font2 = title.getTextFont();
        font2.setBold(true);
        font2.setColor(Color.getBlack());
        font2.setSize(10);

        //Set properties of valueaxis title
        Axis valueAxis = chart.getValueAxis();
        title = valueAxis.getTitle();
        title.setText("Particulate");
        Font font3 = title.getTextFont();
        font3.setBold(true);
        font3.setColor(Color.getBlack());
        font3.setSize(10);
        title.setRotationAngle(90);
    }
}
