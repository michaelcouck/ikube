package com.aspose.cells.demos.chart;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Axis;
import com.aspose.cells.Cells;
import com.aspose.cells.Chart;
import com.aspose.cells.ChartCollection;
import com.aspose.cells.ChartMarkerType;
import com.aspose.cells.ChartType;
import com.aspose.cells.Color;
import com.aspose.cells.FileFormatType;
import com.aspose.cells.Font;
import com.aspose.cells.Legend;
import com.aspose.cells.LegendPositionType;
import com.aspose.cells.SeriesCollection;
import com.aspose.cells.Title;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class LineServlet extends DemoBaseServlet
{
    private static final String TEMPLATE_FILE_PATH_PART = "/WEB-INF/Designer/Chart/AreaTemplate.xls";

    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        int fileFormatType = FileFormatType.EXCEL_97_TO_2003;
        resultFile = "Line.xls";

        Workbook wb = new Workbook(getServletContext().getRealPath(TEMPLATE_FILE_PATH_PART));
        int chartType = ChartType.LINE;
        switch (Integer.parseInt(request.getParameter("ChartTypeList")))
        {
            case 1:
            {
                chartType = ChartType.LINE_WITH_DATA_MARKERS;
                break;
            }
        }
        int nseriesMarkerStyle = Integer.parseInt(request.getParameter("NSeriesMarkerStyle"));
        int nMarkBackColor = Integer.parseInt(request.getParameter("NMarkBackColor"));
        int nMarkForeColor = Integer.parseInt(request.getParameter("NMarkForeColor"));
        int nseriesMarkSize = Integer.parseInt(request.getParameter("NSeriesMarkSize"));
        createStaticReport(wb, chartType, nseriesMarkerStyle, nMarkBackColor, nMarkForeColor,
                nseriesMarkSize);
        return wb;
    }

    private void createStaticReport(Workbook workbook, int chartType, int nseriesMarkerStyle,
            int nMarkBackColor, int nMarkForeColor, int nseriesMarkSize) throws Exception
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet worksheet = worksheets.get(0);
        //Set the name of worksheet
        worksheet.setName("Line");

        //Create chart
        ChartCollection charts = worksheet.getCharts();
        Chart chart = charts.get(charts.add(chartType, 5, 1, 29, 10));

        //Set Properties of nseries
        SeriesCollection nSeries = chart.getNSeries();
        nSeries.add("B2:F4", false);
        nSeries.setCategoryData("B1:F1");

        Cells cells = worksheet.getCells();
        String temp = "";
        for(int i = 0; i < nSeries.getCount(); i++)
        {
            temp = cells.get(i + 1, 0).getStringValue();
            nSeries.get(i).setName(temp);

            switch (nseriesMarkerStyle)
            {
                case 0:
                    nSeries.get(i).setMarkerStyle(ChartMarkerType.CIRCLE);
                    break;
                case 1:
                    nSeries.get(i).setMarkerStyle(ChartMarkerType.SQUARE_STAR);
                    break;
                case 2:
                    nSeries.get(i).setMarkerStyle(ChartMarkerType.SQUARE_X);
                    break;
            }
            nSeries.get(i).setMarkerBackgroundColor(getColor(nMarkBackColor));
            nSeries.get(i).setMarkerForegroundColor(getColor(nMarkBackColor));
        }

        //Set Properties of chart title
        Title title = chart.getTitle();
        title.setText("Sales By Region For Years");
        Font font1 = title.getTextFont();
        font1.setBold(true);
        font1.setColor(Color.getBlack());
        font1.setSize(12);

        //Set Properties of categoryaxis title
        Axis categoryAxis = chart.getCategoryAxis();
        title = categoryAxis.getTitle();
        title.setText("Year(2002-2006)");
        Font font2 = title.getTextFont();
        font2.setBold(true);
        font2.setColor(Color.getBlack());
        font2.setSize(10);

        //Set the legend position type
        Legend legend = chart.getLegend();
        legend.setPosition(LegendPositionType.TOP);
    }

    private Color getColor(int index)
    {
        switch (index)
        {
            case 0:
                return Color.getRed();
            case 1:
                return Color.getTeal();
            case 2:
                return Color.getGray();
        }
        return Color.getYellow();
    }
}
