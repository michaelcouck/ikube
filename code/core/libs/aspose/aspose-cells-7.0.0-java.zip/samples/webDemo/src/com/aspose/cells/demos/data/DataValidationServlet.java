package com.aspose.cells.demos.data;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Cell;
import com.aspose.cells.CellArea;
import com.aspose.cells.Cells;
import com.aspose.cells.OperatorType;
import com.aspose.cells.Validation;
import com.aspose.cells.ValidationAlertType;
import com.aspose.cells.ValidationCollection;
import com.aspose.cells.ValidationType;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class DataValidationServlet extends DemoBaseServlet
{
    @Override
    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        resultFile = "DataValidation.xls";
        Workbook workbook = new Workbook();

        //Data Validation for Numbers
        validationForNumbers(workbook);
        return workbook;
    }

    private void validationForNumbers(Workbook wb)
    {
        WorksheetCollection worksheets = wb.getWorksheets();
        Worksheet worksheet = worksheets.get(0);
        Cells cells = worksheet.getCells();
        ValidationCollection validations = worksheet.getValidations();

        Cell cell;
        cell = cells.get("A1");
        cell.setValue("Enter Number:");
        cell = cells.get("B1");
        cell.setValue(100);
        //Create a validation object
        int index = validations.add();
        Validation validation = validations.get(index);
        //Set the validation type to whole number
        validation.setType(ValidationType.WHOLE_NUMBER);
        //Set the operator for validation to between
        validation.setOperator(OperatorType.BETWEEN);
        //Set the minimum value for the validation
        validation.setFormula1("0");
        //Set the maximum value for the validation
        validation.setFormula2("10");
        validation.setShowError(true);
        validation./* setAlertType */setAlertStyle(ValidationAlertType.INFORMATION);
        validation.setErrorTitle("Error");
        validation.setErrorMessage("Enter value between 0 to 10");
        validation.setInputMessage("Data Validation using Condition for Numbers");
        validation.setIgnoreBlank(true);
        validation.setShowInput(true);
        validation.setShowError(true);

        //Apply the validation to a range of cells from B1 to B1 using the CellArea structure
        CellArea cellArea = CellArea.createCellArea(0, 1, 0, 1);

        //Add the cell area to Validation
        validation.addArea(cellArea);
    }
}
