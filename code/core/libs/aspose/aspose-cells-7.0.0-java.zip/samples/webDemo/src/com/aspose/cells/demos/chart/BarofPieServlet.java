package com.aspose.cells.demos.chart;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Chart;
import com.aspose.cells.ChartCollection;
import com.aspose.cells.ChartType;
import com.aspose.cells.Color;
import com.aspose.cells.FileFormatType;
import com.aspose.cells.Font;
import com.aspose.cells.LabelPositionType;
import com.aspose.cells.SeriesCollection;
import com.aspose.cells.Style;
import com.aspose.cells.Title;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class BarofPieServlet extends DemoBaseServlet
{
    private static final String TEMPLATE_FILE_PATH_PART = "/WEB-INF/Designer/Chart/PieTemplate.xls";

    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        int fileFormatType = FileFormatType.EXCEL_97_TO_2003;
        resultFile = "BarofPie.xls";

        Workbook wb = new Workbook(getServletContext().getRealPath(TEMPLATE_FILE_PATH_PART));
        createPieChart(wb);
        return wb;
    }

    private void createPieChart(Workbook workbook) throws Exception
    {
        Style style = workbook.getDefaultStyle();
        Font font = style.getFont();
        font.setName("Tahoma");

        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet worksheet = worksheets.get(0);
        //Set the name of worksheet
        worksheet.setName("BarofPie");

        //Create chart
        ChartCollection charts = worksheet.getCharts();
        Chart chart = charts.get(charts.add(ChartType.PIE_BAR, 1, 3, 25, 13));

        //Set properties of nseries
        SeriesCollection nSeries = chart.getNSeries();
        nSeries.add("B2:B8", true);
        nSeries.setCategoryData("A2:A8");
        for(int i = 0; i < nSeries.getCount(); i++)
        {
            nSeries.get(i).setColorVaried(true);
            nSeries.get(i).getDataLabels().setShowValue(true);
            nSeries.get(i).getDataLabels().setPosition(LabelPositionType.OUTSIDE_END);
        }

        //Set properties of chart title
        Title title = chart.getTitle();
        title.setText("Sales By Region");
        font = title.getTextFont();
        font.setColor(Color.getBlack());
        font.setBold(true);
        font.setSize(12);
    }
}
