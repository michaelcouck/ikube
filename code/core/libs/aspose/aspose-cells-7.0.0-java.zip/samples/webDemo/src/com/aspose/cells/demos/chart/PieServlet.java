package com.aspose.cells.demos.chart;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Chart;
import com.aspose.cells.ChartCollection;
import com.aspose.cells.ChartType;
import com.aspose.cells.Color;
import com.aspose.cells.FileFormatType;
import com.aspose.cells.Font;
import com.aspose.cells.LabelPositionType;
import com.aspose.cells.Legend;
import com.aspose.cells.LegendPositionType;
import com.aspose.cells.SeriesCollection;
import com.aspose.cells.Title;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class PieServlet extends DemoBaseServlet
{
    private static final String TEMPLATE_FILE_PATH_PART = "/WEB-INF/Designer/Chart/PieTemplate.xls";

    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        int fileFormatType = FileFormatType.EXCEL_97_TO_2003;
        resultFile = "Pie.xls";

        Workbook wb = new Workbook(getServletContext().getRealPath(TEMPLATE_FILE_PATH_PART));
        int chartType = ChartType.PIE;
        if(request.getParameter("CheckBoxShow3D") != null)
        {
            chartType = ChartType.PIE_3_D;
        }
        int firstSliceAngle = Integer.parseInt(request.getParameter("FirstSliceAngle"));
        int labelsPostion = Integer.parseInt(request.getParameter("LabelsPostionList"));
        createStaticReport(wb, chartType, firstSliceAngle, labelsPostion);
        return wb;
    }

    private void createStaticReport(Workbook workbook, int chartType, int firstSliceAngle,
            int labelsPostion) throws Exception
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet worksheet = worksheets.get(0);
        //Set the name of worksheet
        worksheet.setName("Pie");

        //Create chart
        ChartCollection charts = worksheet.getCharts();
        Chart chart = charts.get(charts.add(chartType, 1, 3, 25, 12));

        //Set properties of chart
        chart.setFirstSliceAngle(firstSliceAngle);

        //Set properties of nseries
        SeriesCollection nSeries = chart.getNSeries();
        nSeries.add("B2:B8", true);
        nSeries.setCategoryData("A2:A8");

        for(int i = 0; i < nSeries.getCount(); i++)
        {
            nSeries.get(i).setColorVaried(true);
            nSeries.get(i).getDataLabels().setShowValue(true);

            switch (labelsPostion)
            {
                case 0://Center
                    nSeries.get(i).getDataLabels().setPosition(LabelPositionType.CENTER);
                    break;
                case 1://InsideBase
                    nSeries.get(i).getDataLabels().setPosition(LabelPositionType.INSIDE_BASE);
                    break;
                case 2://InsideEnd
                    nSeries.get(i).getDataLabels().setPosition(LabelPositionType.INSIDE_END);
                    break;
                case 3://OutsideEnd
                    nSeries.get(i).getDataLabels().setPosition(LabelPositionType.OUTSIDE_END);
                    break;
            }
        }

        //Set properties of chart title
        Title title = chart.getTitle();
        title.setText("Sales By Region");
        Font font = title.getTextFont();
        font.setBold(true);
        font.setColor(Color.getBlack());
        font.setSize(12);

        //Set the legend position type
        Legend legend = chart.getLegend();
        legend.setPosition(LegendPositionType.RIGHT);
    }
}
