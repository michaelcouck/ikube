package com.aspose.cells.demos.security;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.FileFormatType;
import com.aspose.cells.Protection;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class AdvancedProtection extends DemoBaseServlet
{
    private static final String TEMPLATE_FILE_PATH_PART = "/WEB-INF/Designer/book1.xls";

    protected Workbook createReport(HttpServletRequest request) throws Exception
    { 
        resultFile = "AdvancedProtection.xls";

        Workbook wb = new Workbook(getServletContext().getRealPath(TEMPLATE_FILE_PATH_PART));
        createStaticReport(wb);
        return wb;
    }

    private void createStaticReport(Workbook wb) throws IOException
    {
        WorksheetCollection worksheets = wb.getWorksheets();
        Worksheet worksheet = worksheets.get(0);

        Protection protection = /* new Protection(); */worksheet.getProtection();

        //Restricting users to delete columns of the worksheet
        protection.setAllowDeletingColumn(false);

        //Restricting users to delete row of the worksheet
        protection.setAllowDeletingRow(false);

        //Allowing users to edit contents of the worksheet
        protection.setAllowEditingContent(false);

        //Allowing users to edit objects of the worksheet
        protection.setAllowEditingObject(true);

        //Allowing users to edit scenarios of the worksheet
        protection.setAllowEditingScenario(true);

        //Restricting users to filter
        protection.setAllowFiltering(false);

        //Allowing users to format cells of the worksheet
        protection.setAllowFormattingCell(true);

        //Allowing users to format rows of the worksheet
        protection.setAllowFormattingRow(true);

        //Allowing users to insert columns in the worksheet
        protection.setAllowInsertingColumn(true);

        //Allowing users to insert hyperlinks in the worksheet
        protection.setAllowInsertingHyperlink(true);

        //Allowing users to insert rows in the worksheet
        protection.setAllowInsertingRow(true);

        //Allowing users to select locked cells of the worksheet
        protection.setAllowSelectingLockedCell(true);

        //Allowing users to select unlocked cells of the worksheet
        protection.setAllowSelectingUnlockedCell(true);
        //Allowing users to sort
        protection.setAllowSorting(true);

        //Allowing users to use pivot tables in the worksheet
        protection.setAllowUsingPivotTable(true);
    }
}
