/*
 * Copyright (c) 2001-2011 Aspose Pty Ltd. All Rights Reserved.
 */

package com.aspose.cells.demos;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.aspose.cells.Workbook;

public abstract class DemoBaseServlet extends HttpServlet
{
    protected String resultFile;
    protected String resultFormatSuffix;
    
    protected abstract Workbook createReport(HttpServletRequest request) throws Exception;
    
    protected void sendReport(HttpServletRequest request, HttpServletResponse response, Workbook wb) throws Exception
    {
        wb.save(response.getOutputStream(), wb.getFileFormat());
    }
    
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException,
            ServletException
    {
        try
        {
            Workbook wb = createReport(request);
            setResponseHeader(response, resultFile, resultFormatSuffix == null ? resultFile : resultFormatSuffix);
            sendReport(request, response, wb);
        }
        catch(Exception e)
        {
            writeError(e, response);
            return;
        }
    }
    
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException
    {
        doGet(request, response);
    }
    
    protected void setResponseHeader(HttpServletResponse response, String fileName, String formatSuffix)
    {
        String contentType = "application/vnd.ms-excel";
        formatSuffix = formatSuffix.toLowerCase();
        if(formatSuffix.endsWith(".xlsx")
                || formatSuffix.endsWith(".xlsb")
                || formatSuffix.endsWith(".xlsm")
                || formatSuffix.endsWith(".xltm")
                || formatSuffix.endsWith(".xltx"))
        {
            contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        }
        response.setContentType(contentType);
        response.addHeader("content-disposition", "inline;filename=" + fileName);
    }
    
    
    private void writeError(Throwable e, HttpServletResponse response) throws IOException
    {
        response.setContentType("text/html");
        PrintWriter writer = new PrintWriter(response.getOutputStream());

        writer.println("<html>");
        writer.println("<head>");
        writer.println("<title>sorry</title>");
        writer.println("</head>");
        writer.println("<body>");
        writer.println("<h1>Sorry, the demo programme failed for some reason.</h1>");
        e.printStackTrace(writer);
        writer.println("</body>");
        writer.println("</html>");
        writer.close();
    }
}
