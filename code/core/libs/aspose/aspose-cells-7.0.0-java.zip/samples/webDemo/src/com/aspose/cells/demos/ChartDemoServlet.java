package com.aspose.cells.demos;

import java.io.IOException;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Random;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Axis;
import com.aspose.cells.CategoryType;
import com.aspose.cells.Cell;
import com.aspose.cells.Cells;
import com.aspose.cells.Chart;
import com.aspose.cells.ChartCollection;
import com.aspose.cells.ChartFrame;
import com.aspose.cells.ChartType;
import com.aspose.cells.DateTime;
import com.aspose.cells.FileFormatType;
import com.aspose.cells.Font;
import com.aspose.cells.PivotFieldType;
import com.aspose.cells.PivotTable;
import com.aspose.cells.PivotTableCollection;
import com.aspose.cells.Series;
import com.aspose.cells.SeriesCollection;
import com.aspose.cells.ShapeCollection;
import com.aspose.cells.SheetType;
import com.aspose.cells.Style;
import com.aspose.cells.StyleFlag;
import com.aspose.cells.TextAlignmentType;
import com.aspose.cells.TextBox;
import com.aspose.cells.Title;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;

public class ChartDemoServlet extends DemoBaseServlet
{
    private static final long serialVersionUID = 3257562889065082933L;

    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        String command = request.getParameter("_command");
        int fileFormatType = FileFormatType.EXCEL_97_TO_2003;
        resultFile = command + ".xls";
        if(command.equals("ColumnChart"))
        {
            return createColumnChart(fileFormatType);
        }
        else if(command.equals("LineChart"))
        {
            return createLineChart(fileFormatType);
        }
        else if(command.equals("StockChart"))
        {
            return createStockChart(fileFormatType);
        }
        else if(command.equals("PivotTable"))
        {
            return createPivotTable(fileFormatType);
        }
        else
        {
            throw new IllegalArgumentException("Unrecognized command: " + command);
        }
    }

    private static Workbook createColumnChart(int fileFormatType) throws Exception
    {
        Workbook workbook = new Workbook(fileFormatType);
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet sheet = worksheets.get(0);
        Cells cells = sheet.getCells();
        Cell cell = cells.get("B4");
        cell.setValue("January");
        cell = cells.get("C4");
        cell.setValue("February");
        //soure data
        cell = cells.get("B5");
        cell.setValue(9300);
        cell = cells.get("C5");
        cell.setValue(1280);
        cell = cells.get("B6");
        cell.setValue(11300);
        cell = cells.get("C6");
        cell.setValue(21000);
        cell = cells.get("B7");
        cell.setValue(13200);
        cell = cells.get("C7");
        cell.setValue(11000);
        Style style = workbook.createStyle();
        style.setNumber(5);
        StyleFlag styleFlag = new StyleFlag();
        styleFlag.setAll(true);
        cells.createRange("B5", "C7").applyStyle(style, styleFlag);
        //catergory
        cell = cells.get("A5");
        cell.setValue("Chicago");
        cell = cells.get("A6");
        cell.setValue("Dallas");
        cell = cells.get("A7");
        cell.setValue("Boston");

        ChartCollection charts = sheet.getCharts();

        //Adding a chart to the worksheet
        Chart chart = charts.get(charts.add(ChartType.COLUMN, 10, 5, 22, 12));
        //Adding NSeries (chart data source) to the chart ranging from "B5" cell to "C7"
        SeriesCollection nSeries = chart.getNSeries();
        nSeries.add("B5:C7", true);

        //Setting the data source for the category data of NSeries
        nSeries.setCategoryData("A5:A7");
        //setting sereis name
        Series aSeries = nSeries.get(0);
        aSeries.setName("=B4");
        aSeries = nSeries.get(1);
        aSeries.setName("=C4");
        return workbook;
    }

    private static Workbook createStockChart(int fileFormatType) throws Exception
    {
        Workbook workbook = new Workbook(fileFormatType);
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet sheet = worksheets.get(0);
        Cells cells = sheet.getCells();
        Cell cell = cells.get("B1");
        cell.setValue("Volumne");
        cell = cells.get("C1");
        cell.setValue("High");
        cell = cells.get("D1");
        cell.setValue("Low");
        cell = cells.get("E1");
        cell.setValue("Close");
        //soure data
        cell = cells.get("B2");
        cell.setValue(41000);
        cell = cells.get("C2");
        cell.setValue(27.20);
        cell = cells.get("D2");
        cell.setValue(23.49);
        cell = cells.get("E2");
        cell.setValue(25.45);
        cell = cells.get("B3");
        cell.setValue(35000);
        cell = cells.get("C3");
        cell.setValue(25.03);
        cell = cells.get("D3");
        cell.setValue(19.55);
        cell = cells.get("E3");
        cell.setValue(23.05);
        cell = cells.get("B4");
        cell.setValue(30000);
        cell = cells.get("C4");
        cell.setValue(19.05);
        cell = cells.get("D4");
        cell.setValue(15.12);
        cell = cells.get("E4");
        cell.setValue(17.32);
        Style style = workbook.createStyle();
        style.setNumber(7);
        StyleFlag styleFlag = new StyleFlag();
        styleFlag.setAll(true);
        cells.createRange("B2", "E4").applyStyle(style, styleFlag);
        //catergory
        cell = cells.get("A2");
        cell.setValue("Aspose");
        cell = cells.get("A3");
        cell.setValue("Aspose.Cells");
        cell = cells.get("A4");
        cell.setValue("Aspose.Words");

        //
        ChartCollection charts = sheet.getCharts();

        //Adding a chart to the worksheet
        Chart chart = charts.get(charts.add(ChartType.STOCK_VOLUME_HIGH_LOW_CLOSE, 10, 5, 22, 15));
        //Adding NSeries (chart data source) to the chart ranging from "B5" cell to "C7"
        SeriesCollection nSeries = chart.getNSeries();
        nSeries.add("B2:E4", true);

        //Setting the data source for the category data of NSeries
        nSeries.setCategoryData("A2:A4");
        //setting sereis name
        Series aSeries = nSeries.get(0);
        aSeries.setName("=B1");
        aSeries = nSeries.get(1);
        aSeries.setName("=C1");
        aSeries = nSeries.get(2);
        aSeries.setName("=D1");
        aSeries = nSeries.get(3);
        aSeries.setName("=E1");
        return workbook;
    }

    private static Workbook createLineChart(int fileFormatType) throws Exception
    {
        Workbook workbook = new Workbook(fileFormatType);
        WorksheetCollection worksheets = workbook.getWorksheets();
        int iNewSheets = 0;
        // Get rid of all sheets except first one
        for(int i = worksheets.getCount() - 1; i > 0; --i)
        {
            worksheets.removeAt(i);
        }
        /*
         * Workbook has a 32000 data point limit on 2D charts and a 4000 data
         * point on 3D charts
         */
        int iMaxRows = 32000;

        Worksheet linechart = worksheets.get(worksheets.add(SheetType.CHART));
        linechart.setName("CPUUtil");
        iNewSheets++;
        Worksheet sheet = worksheets.add("CPUData");
        //setColumnWidth(sheet);
        iNewSheets++;
        Cells cells = sheet.getCells();
        Cell cell = cells.get("B4");
        cell.setValue("saturn");
        cell = cells.get("C4");
        cell.setValue("clsol1");
        cell = cells.get("D4");
        cell.setValue("clsol2");
        cell = cells.get("E4");
        cell.setValue("clsol3");
        cell = cells.get("F4");
        cell.setValue("clsol4");
        cell = cells.get("G4");
        cell.setValue("tqclss1");
        //source data
        //category
        Calendar calendar;
        double iChicago;
        double iDallas;
        double iBoston;
        double iLA;
        double iSeattle;
        double iCL;
        int iNumDays = 7;
        int iNumHours = 24;
        int iTotRows = iNumDays * iNumHours;
        Random generator = new Random();

        for(int i = 1; i < iNumDays + 1; i++)
        {
            for(int j = 0; j < iNumHours; j++)
            {
                // Set date
                calendar = new GregorianCalendar(1990, 0, i, j, 0, 0);
                calendar.setTimeZone(TimeZone.getTimeZone("GMT"));
                cell = cells.get(((i - 1) * iNumHours) + j + 4, 0);
                cell.setValue(new DateTime(calendar));

                // Set Chicago numbers
                iChicago = generator.nextInt(2000) / 10000.0;
                iChicago += .80; // Never lower than 80%
                cell = cells.get(((i - 1) * iNumHours) + j + 4, 1);
                cell.setValue(iChicago);

                // Set Dallas numbers
                iDallas = generator.nextInt(2000) / 10000.0;
                iDallas += .60; // Never lower than 60% or higher than 80
                cell = cells.get(((i - 1) * iNumHours) + j + 4, 2);
                cell.setValue(iDallas);

                // Set Boston numbers
                iBoston = generator.nextInt(500) / 10000.0;
                iBoston += .65; // Never lower than 65% or higher than 70
                cell = cells.get(((i - 1) * iNumHours) + j + 4, 3);
                cell.setValue(iBoston);

                // Set LA numbers
                iLA = generator.nextInt(1000) / 10000.0;
                iLA += .30; // Never lower than 30% or higher than 40
                cell = cells.get(((i - 1) * iNumHours) + j + 4, 4);
                cell.setValue(iLA);

                // Set Seattle numbers
                iSeattle = generator.nextInt(700) / 10000.0;
                iSeattle += .72; // Never lower than 72% or higher than 79
                cell = cells.get(((i - 1) * iNumHours) + j + 4, 5);
                cell.setValue(iSeattle);

                // Set CL numbers
                iCL = generator.nextInt(300) / 10000.0;
                iCL += .94; // Never lower than 94% or higher than 97
                cell = cells.get(((i - 1) * iNumHours) + j + 4, 6);
                cell.setValue(iCL);
            }
        }
        // Set Date format
        StyleFlag styleFlag = new StyleFlag();
        styleFlag.setAll(true);
        Style dateStyle = workbook.createStyle();
        dateStyle.setNumber(22);
        cells.createRange(4, 0, iTotRows, 1).applyStyle(dateStyle, styleFlag);
        // Set Data format
        Style style = workbook.createStyle();
        style.setNumber(10);
        cells.createRange(4, 1, iTotRows, 6).applyStyle(style, styleFlag);

        /*
         * 
         * Setup the chart
         */
        ChartCollection charts = linechart.getCharts();

        //Adding a chart to the worksheet
        Chart chart = charts.get(charts.add(ChartType.LINE_WITH_DATA_MARKERS, 0, 0, 42, 20));

        //Set the title
        Title title = chart.getTitle();
        title.setText("Work Server %busy");

        //Adding NSeries (chart data source) to the chart ranging from "B5" cell to "C7"

        StringBuffer builder = new StringBuffer("CPUData!B5:G");

        // Reset total number of rows to chart for now
        if(iTotRows > iMaxRows)
            iTotRows = iMaxRows;

        builder.append(iTotRows + 4);
        SeriesCollection nSeries = chart.getNSeries();
        nSeries.add(builder.toString(), true);

        //Setting the data source for the category data of NSeries
        StringBuffer builder2 = new StringBuffer("CPUData!A5:A");
        builder2.append(iTotRows + 4);

        nSeries.setCategoryData(builder2.toString());

        Axis catAxis = chart.getCategoryAxis();
        catAxis.setCategoryType(CategoryType.CATEGORY_SCALE);
        catAxis.getTickLabels().setNumber(22);

        //Set the Value Axis title
        Title cTitle = catAxis.getTitle();
        cTitle.setText("Time");
        cTitle.setTextHorizontalAlignment(TextAlignmentType.CENTER);
        catAxis.getMajorGridLines().setVisible(true);
        catAxis.setTickLabelSpacing(12);

        Axis valAxis = chart.getValueAxis();
        valAxis.setMaxValue(1.0);

        //Set the Value Axis title
        Title vTitle = valAxis.getTitle();
        vTitle.setText("%busy");
        vTitle.setRotationAngle(90);

        //setting series name
        Series aSeries = nSeries.get(0);
        aSeries.setName("=CPUData!B4");

        aSeries = nSeries.get(1);
        aSeries.setName("=CPUData!C4");

        aSeries = nSeries.get(2);
        aSeries.setName("=CPUData!D4");

        aSeries = nSeries.get(3);
        aSeries.setName("=CPUData!E4");

        aSeries = nSeries.get(4);
        aSeries.setName("=CPUData!F4");

        aSeries = nSeries.get(5);
        aSeries.setName("=CPUData!G4");

        // Remove any leading sheets before the ones we created.
        for(int i = worksheets.getCount() - (iNewSheets + 1); i >= 0; --i)
        {
            worksheets.removeAt(i);
        }

        // Add text box
        ChartFrame plotArea = chart.getPlotArea();
        int iPlotX = plotArea.getX();
        int iPlotY = plotArea.getY();
        int iPlotWidth = plotArea.getWidth();
        int iPlotHeight = plotArea.getHeight();
        ShapeCollection shapes = chart.getShapes();

        TextBox textBox = shapes.addTextBoxInChart(iPlotX + (iPlotWidth / 4), iPlotY
                + (iPlotHeight / 4), iPlotWidth / 2, iPlotHeight / 2);
        textBox.getFillFormat().setVisible(false);

        textBox.setText("Line chart demo!!");
        Font boxFont = textBox.getFont();
        boxFont.setSize(18);
        boxFont.setName("Arial");

        textBox.getLineFormat().setVisible(false);

        textBox.setTextHorizontalAlignment(TextAlignmentType.CENTER);
        textBox.setTextVerticalAlignment(TextAlignmentType.CENTER);
        return workbook;
    }

    private static Workbook createPivotTable(int fileFormatType) throws IOException
    {
        Workbook workbook = new Workbook(fileFormatType);
        Worksheet sheet = workbook.getWorksheets().get(0);
        Cells cells = sheet.getCells();
        Cell cell = cells.get("A1");
        cell.setValue("Sport");
        cell = cells.get("B1");
        cell.setValue("Quarter");
        cell = cells.get("C1");
        cell.setValue("Sales");

        cell = cells.get("A2");
        cell.setValue("Golf");
        cell = cells.get("A3");
        cell.setValue("Golf");
        cell = cells.get("A4");
        cell.setValue("Tennis");
        cell = cells.get("A5");
        cell.setValue("Tennis");
        cell = cells.get("A6");
        cell.setValue("Tennis");
        cell = cells.get("A7");
        cell.setValue("Tennis");
        cell = cells.get("A8");
        cell.setValue("Golf");

        cell = cells.get("B2");
        cell.setValue("Qtr3");
        cell = cells.get("B3");
        cell.setValue("Qtr4");
        cell = cells.get("B4");
        cell.setValue("Qtr3");
        cell = cells.get("B5");
        cell.setValue("Qtr4");
        cell = cells.get("B6");
        cell.setValue("Qtr3");
        cell = cells.get("B7");
        cell.setValue("Qtr4");
        cell = cells.get("B8");
        cell.setValue("Qtr3");

        cell = cells.get("C2");
        cell.setValue(1500);
        cell = cells.get("C3");
        cell.setValue(2000);
        cell = cells.get("C4");
        cell.setValue(600);
        cell = cells.get("C5");
        cell.setValue(1500);
        cell = cells.get("C6");
        cell.setValue(4070);
        cell = cells.get("C7");
        cell.setValue(5000);
        cell = cells.get("C8");
        cell.setValue(6430);

        PivotTableCollection pivotTables = sheet.getPivotTables();
        int index = pivotTables.add("=A1:C8", "E3", "PivotTable1");
        PivotTable pivotTable = pivotTables.get(index);
        pivotTable.addFieldToArea(PivotFieldType.ROW, 0);
        pivotTable.addFieldToArea(PivotFieldType.COLUMN, 1);
        pivotTable.addFieldToArea(PivotFieldType.DATA, 2);
        pivotTable.setSaveData(true);
        return workbook;
    }
}
