package com.aspose.cells.demos.cells;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.FileFormatType;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.demos.DemoBaseServlet;

public class HidingRowsAndColumns extends DemoBaseServlet
{
    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        String command = request.getParameter("_command");
        int fileFormatType = FileFormatType.EXCEL_97_TO_2003;
        resultFile = command + "RowsAndColumns.xls";

        Workbook wb = new Workbook(fileFormatType);
        if(command.equals("Display"))
        {
            displayingRowsAndColumns(wb.getWorksheets().get(0));
        }
        else
        {
            hidingRowsAndColumns(wb.getWorksheets().get(0));
        }
        return wb;
    }

    private void displayingRowsAndColumns(Worksheet worksheet)
    {
        //Hide the 3rd row of the worksheet
        worksheet.getCells().unhideRow(2, 13.5);
        //Hide the 2nd column of the worksheet
        worksheet.getCells().unhideColumn(1, 15);
    }

    private void hidingRowsAndColumns(Worksheet worksheet)
    {
        //Hide the 3rd row of the worksheet
        worksheet.getCells().hideRow(2);

        //Hide the 2nd column of the worksheet
        worksheet.getCells().hideColumn(1);
    }
}
