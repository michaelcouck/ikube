package com.aspose.cells.demos.pagesetup;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.PageSetup;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class HeadersAndFooters extends DemoBaseServlet
{
    private static final String TEMPLATE_FILE_PATH_PART = "/WEB-INF/Designer/book1.xls";

    protected Workbook createReport(HttpServletRequest request) throws Exception
    {  
        resultFile = "HeadersAndFooters.xls"; 
        Workbook wb = new Workbook(getServletContext().getRealPath(TEMPLATE_FILE_PATH_PART));
        createStaticReport(wb);
        return wb;
    }

    private void createStaticReport(Workbook wb) throws IOException
    {
        WorksheetCollection worksheets = wb.getWorksheets();
        Worksheet worksheet = worksheets.get(0);

        PageSetup pageSetup = worksheet.getPageSetup();
        pageSetup.setFooter(0, "&P");
        pageSetup.setHeader(1, "&D");
    }
}
