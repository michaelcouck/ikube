package com.aspose.cells.demos.pagesetup;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.PageOrientationType;
import com.aspose.cells.PageSetup;
import com.aspose.cells.PaperSizeType;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class SettingPageOption extends DemoBaseServlet
{
    private static final String TEMPLATE_FILE_PATH_PART = "/WEB-INF/Designer/book1.xls";

    @Override
    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        resultFile = "SettingPage.xls";
        ServletContext sc = getServletContext();
        String template_file_path = sc.getRealPath(TEMPLATE_FILE_PATH_PART);
        Workbook workbook = new Workbook(template_file_path);
        createStaticReport(workbook);
        return workbook;
    }

    private void createStaticReport(Workbook wb) throws Exception
    {
        WorksheetCollection worksheets = wb.getWorksheets();
        Worksheet worksheet = worksheets.get(0);

        PageSetup pageSetup = worksheet.getPageSetup();
        //Set the orientation
        pageSetup.setOrientation(PageOrientationType.LANDSCAPE);
        //You can either choose FitToPages or Zoom property but not both at the same time
        pageSetup.setZoom(80);
        //Set the paper size
        pageSetup.setPaperSize(PaperSizeType.PAPER_A_4);
        //Set the print quality of the worksheet
        pageSetup.setPrintQuality(200);
        //Set the first page number of the worksheet pages
        pageSetup.setFirstPageNumber(1);
    }
}
