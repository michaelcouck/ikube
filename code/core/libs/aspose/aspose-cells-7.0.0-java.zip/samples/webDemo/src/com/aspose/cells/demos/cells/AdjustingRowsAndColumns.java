package com.aspose.cells.demos.cells;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Cells;
import com.aspose.cells.FileFormatType;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class AdjustingRowsAndColumns extends DemoBaseServlet {

    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        String command = request.getParameter("_command");
        int fileFormatType = FileFormatType.EXCEL_97_TO_2003;
        resultFile = "AdjustingRowsAndColumns.xls";
        
        Workbook workbook = new Workbook(fileFormatType);
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet worksheet = worksheets.get(0);

        Cells cells = worksheet.getCells();

        //Set the height of all row in the worksheet
        cells.setStandardHeight(20);
        //Set the width of all columns in the worksheet
        cells.setStandardWidth(20);

        //Set the width of the first column
        cells.setColumnWidth(0, 12);
        cells.setColumnWidth(1, 40);
        //Setting the height of row
        cells.setRowHeight(1, 8);
        return workbook;
    }
}
