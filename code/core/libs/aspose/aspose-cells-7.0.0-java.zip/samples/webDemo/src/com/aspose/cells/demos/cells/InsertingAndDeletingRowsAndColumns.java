package com.aspose.cells.demos.cells;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Cell;
import com.aspose.cells.Cells;
import com.aspose.cells.FileFormatType;
import com.aspose.cells.Workbook;
import com.aspose.cells.demos.DemoBaseServlet;

public class InsertingAndDeletingRowsAndColumns extends DemoBaseServlet
{
    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        String command = request.getParameter("_command");
        int fileFormatType = FileFormatType.EXCEL_97_TO_2003;
        resultFile = command + "RowsAndColumns.xls";

        Workbook wb = new Workbook(fileFormatType);
        if(command.equals("Insert"))
        {
            insertRowsAndColumns(wb.getWorksheets().get(0).getCells());
        }
        else
        {
            deleteRowsAndColumns(wb.getWorksheets().get(0).getCells());
        }
        return wb;
    }

    private void insertRowsAndColumns(Cells cells)
    {
        createStaticReport(cells);

        //Insert a row or column into the worksheet
        cells.insertRows(2, 10);
        cells.insertColumns(1, 1);
    }

    private void deleteRowsAndColumns(Cells cells)
    {
        createStaticReport(cells);

        //Delete a row or column into the worksheet
        cells.deleteRows(2, 2, false);
        cells.deleteColumns(1, 1, false);
    }

    private void createStaticReport(Cells cells)
    {
        Cell cell;

        //Put a value into a cell
        cell = cells.get("A1");
        cell.setValue("Aspose");
        cell = cells.get("A2");
        cell.setValue(123);
        cell = cells.get("A3");
        cell.setValue("Hello World");
        cell = cells.get("B1");
        cell.setValue(120);
    }
}
