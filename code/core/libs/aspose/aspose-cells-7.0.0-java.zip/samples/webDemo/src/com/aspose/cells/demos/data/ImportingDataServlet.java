package com.aspose.cells.demos.data;

import javax.servlet.http.*;

import com.aspose.cells.*;
import com.aspose.cells.demos.DemoBaseServlet;

public class ImportingDataServlet extends DemoBaseServlet
{
    @Override
    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        resultFile = "ImportingData.xls";
        Workbook workbook = new Workbook();
        createHelloWorld(workbook);
        return workbook;
    }

    private void createHelloWorld(Workbook workbook) throws Exception
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet worksheet = worksheets.get(0);
        Cells cells = worksheet.getCells();

        importArray(cells);
    }

    private void importArray(Cells cells)
    {
        String[] names = new String[]
        {
                "Tom", "John", "kelly"
        };
        cells.importArray(names, 0, 0, true);
    }
}
