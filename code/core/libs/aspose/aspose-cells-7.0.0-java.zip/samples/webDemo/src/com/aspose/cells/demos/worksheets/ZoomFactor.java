package com.aspose.cells.demos.worksheets;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class ZoomFactor extends DemoBaseServlet
{
    @Override
    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        resultFile = "ZoomFactor.xls";
        Workbook workbook = new Workbook();
        createStaticReport(workbook, Integer.parseInt(request.getParameter("Zoom")));
        return workbook;
    }

    private void createStaticReport(Workbook workbook, int zoom) throws Exception
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet worksheet = worksheets.get(0);

        worksheet.setZoom(zoom);
    }
}
