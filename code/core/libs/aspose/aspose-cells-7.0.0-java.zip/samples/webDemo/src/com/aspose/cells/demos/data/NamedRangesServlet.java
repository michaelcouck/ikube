package com.aspose.cells.demos.data;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Cell;
import com.aspose.cells.Cells;
import com.aspose.cells.Range;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class NamedRangesServlet extends DemoBaseServlet
{
    @Override
    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        resultFile = "NamedRanges.xls";
        Workbook workbook = new Workbook();
        createStaticReport(workbook);
        return workbook;
    }

    private void createStaticReport(Workbook workbook)
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet worksheet = worksheets.get(0);

        Cells cells = worksheet.getCells();
        Cell cell;

        //Create a named range and Set the name of the named range
        Range nameRange = cells.createRange("B1", "E5");
        nameRange.setName("TestRange");
        //Accessing a specific Named Range

        Range mynameRange = worksheets.getRangeByName("TestRange");
        cell = mynameRange.get(0, 0);
        cell.setValue("First");

        //Accessing All Named Ranges in a Worksheet
        Range[] nameRangeList = worksheets.getNamedRanges();
        Range testNameRange;
        for(int i = 0; i < nameRangeList.length; i++)
        {
            testNameRange = nameRangeList[i];
            cell = testNameRange.get(1, 0);
            cell.setValue("Second");
        }
        //Use cells.CreateRange method to extend it
        nameRange = cells.createRange(0, 0, 6, 6);
        //access the address (row and column) of the range
        mynameRange = worksheets.getRangeByName("TestRange");
    }
}
