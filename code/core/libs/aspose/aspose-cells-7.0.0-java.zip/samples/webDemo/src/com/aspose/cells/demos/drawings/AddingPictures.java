package com.aspose.cells.demos.drawings;

import java.io.FileInputStream;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Picture;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class AddingPictures extends DemoBaseServlet
{
    private static final String TEMPLATE_IMAGE_PATH_PART = "/Images/school.JPG";

    protected Workbook createReport(HttpServletRequest request) throws Exception
    { 
        resultFile = "AddingPictures.xls";

        Workbook wb = new Workbook();
        createStaticReport(wb, this.getServletContext().getRealPath(TEMPLATE_IMAGE_PATH_PART));
        return wb;
    }

    private void createStaticReport(Workbook workbook, String imageFile) throws Exception
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet worksheet = worksheets.get(0);

        //Insert a picture into a cell
        FileInputStream fis = new FileInputStream(imageFile);
        Picture picture = worksheet.getShapes().addPicture(1, 1, fis, 100, 100);
        fis.close();
    }
}
