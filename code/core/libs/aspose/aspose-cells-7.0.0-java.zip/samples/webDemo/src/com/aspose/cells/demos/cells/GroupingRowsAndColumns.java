package com.aspose.cells.demos.cells;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Cells;
import com.aspose.cells.FileFormatType;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.demos.DemoBaseServlet;

public class GroupingRowsAndColumns extends DemoBaseServlet
{
    private static final String TEMPLATE_FILE_PATH_PART1 = "/WEB-INF/Designer/Workbooks/GroupingRowsAndColumns.xls";
    private static final String TEMPLATE_FILE_PATH_PART2 = "/WEB-INF/Designer/Workbooks/UnGroupingRowsAndColumns.xls";

    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        String command = request.getParameter("_command");
        int fileFormatType = FileFormatType.EXCEL_97_TO_2003;
        resultFile = command + ".xls";

        ServletContext sc = getServletContext();
        Workbook wb;
        if(command.equals("Group"))
        {
            resultFile = "GroupingRowsAndColumns.xls";
            wb = new Workbook(sc.getRealPath(TEMPLATE_FILE_PATH_PART1));
            groupingRowsAndColumns(wb.getWorksheets().get(0));
        }
        else
        {
            resultFile = "UnGroupingRowsAndColumns.xls";
            wb = new Workbook(sc.getRealPath(TEMPLATE_FILE_PATH_PART2));
            unGroupingRowsAndColumns(wb.getWorksheets().get(0));
        }
        return wb;
    }

    private void groupingRowsAndColumns(Worksheet worksheet)
    {
        Cells cells = worksheet.getCells();
        cells.groupRows(0, 9, false);
        cells.groupColumns(0, 1, false);

        //Set SummaryRowBelow property
        worksheet.getOutline().SummaryRowBelow = true;
        //Set SummaryColumnRight property
        worksheet.getOutline().SummaryColumnRight = true;
    }

    private void unGroupingRowsAndColumns(Worksheet worksheet)
    {
        Cells cells = worksheet.getCells();
        cells.ungroupRows(0, 9);
        cells.ungroupColumns(0, 1);
    }
}
