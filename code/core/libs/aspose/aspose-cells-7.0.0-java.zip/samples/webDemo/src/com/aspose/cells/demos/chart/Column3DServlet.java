package com.aspose.cells.demos.chart;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Axis;
import com.aspose.cells.Cells;
import com.aspose.cells.Chart;
import com.aspose.cells.ChartCollection;
import com.aspose.cells.ChartType;
import com.aspose.cells.Color;
import com.aspose.cells.FileFormatType;
import com.aspose.cells.Floor;
import com.aspose.cells.Font;
import com.aspose.cells.LegendPositionType;
import com.aspose.cells.SeriesCollection;
import com.aspose.cells.Title;
import com.aspose.cells.Walls;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class Column3DServlet extends DemoBaseServlet
{
    private static final String TEMPLATE_FILE_PATH_PART = "/WEB-INF/Designer/Chart/Template.xls";

    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        int fileFormatType = FileFormatType.EXCEL_97_TO_2003;
        resultFile = "Column3D.xls";

        Workbook wb = new Workbook(getServletContext().getRealPath(TEMPLATE_FILE_PATH_PART));
        String columnType = request.getParameter("ColumnType");
        int type;
        if(columnType.equals("Column3D"))
        {
            type = ChartType.COLUMN_3_D;
        }
        else if(columnType.equals("Column3DClustered"))
        {
            type = ChartType.COLUMN_3_D_CLUSTERED;
        }
        else if(columnType.equals("Column3DStacked"))
        {
            type = ChartType.COLUMN_3_D_STACKED;
        }
        else
        {
            throw new IllegalArgumentException("Unknown column type: " + columnType);
        }

        int wallsColor = Integer.parseInt(request.getParameter("WallsColor"));
        int floorColor = Integer.parseInt(request.getParameter("FloorColor"));
        int rotation = Integer.parseInt(request.getParameter("Rotation"));
        int elevation = Integer.parseInt(request.getParameter("Elevation"));
        int depthPercent = Integer.parseInt(request.getParameter("DepthPercent"));

        createStaticReport(wb, type, wallsColor, floorColor, rotation, elevation, depthPercent);

        return wb;
    }

    private void createStaticReport(Workbook workbook, int type, int wallsColor, int floorColor,
            int rotation, int elevation, int depthPercent) throws Exception
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet worksheet = worksheets.get(0);
        //Set the name of the worksheet
        worksheet.setName("3D Column");

        //Create chart
        ChartCollection charts = worksheet.getCharts();

        Chart chart = charts.get(charts.add(type, 5, 1, 29, 10));

        //Set properties of chart
        SeriesCollection nSeries = chart.getNSeries();
        nSeries.add("B2:B4", true);
        nSeries.setCategoryData("A2:A4");

        Cells cells = worksheet.getCells();
        String temp = "";
        for(int i = 0; i < nSeries.getCount(); i++)
        {
            temp = cells.get(i + 1, 0).getStringValue();
            nSeries.get(i).setName(temp);
            nSeries.get(i).setColorVaried(true);
        }

        //Set properies to title
        Title title = chart.getTitle();
        title.setText("Marketing Costs by Region");
        Font font1 = title.getTextFont();
        font1.setBold(true);
        font1.setColor(Color.getBlack());
        font1.setSize(12);

        //Set properties of categoryaxis title
        Axis categoryAxis = chart.getCategoryAxis();
        title = categoryAxis.getTitle();
        title.setText("Region");
        Font font2 = title.getTextFont();
        font2.setBold(true);
        font2.setColor(Color.getBlack());
        font2.setSize(10);

        //Set properties of valueaxis title
        Axis valueAxis = chart.getValueAxis();
        title = valueAxis.getTitle();
        title.setText("In Thousands");
        title.setRotationAngle(90);

        //Set the legend position type
        chart.getLegend().setPosition(LegendPositionType.TOP);
        chart.getPlotArea().getBorder().setVisible(false);

        //Set properties of chart
        Walls walls = chart.getWalls();
        walls.setForegroundColor(getColor(wallsColor));
        Floor floor = chart.getFloor();
        floor.setForegroundColor(getColor(floorColor));
        chart.setRotationAngle(rotation);
        chart.setElevation(elevation);
        chart.setDepthPercent(depthPercent);
    }

    private Color getColor(int index)
    {
        switch (index)
        {
            case 0:
                return Color.getWhite();
            case 1:
                return Color.getRed();
            case 2:
                return Color.getBlue();
            case 3:
                return Color.getSilver();
            case 4:
                return Color.getGray();
        }
        return Color.getYellow();
    }
}
