package com.aspose.cells.demos.data;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Cell;
import com.aspose.cells.Cells;
import com.aspose.cells.Color;
import com.aspose.cells.Font;
import com.aspose.cells.FontUnderlineType;
import com.aspose.cells.Style;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class AddingHyperlinksServlet extends DemoBaseServlet
{
    @Override
    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        resultFile = "AddingHyperlinks.xls";
        Workbook workbook = new Workbook();
        createStaticReport(workbook);
        return workbook;
    }
    
    private void createStaticReport(Workbook workbook)
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet worksheet = worksheets.get(0);

        Cells cells = worksheet.getCells();
        Cell cell;
        /* Adding link to a URL */
        //Put a value into a cell
        cell = cells.get("A1");
        cell.setValue("Visit Aspose");
        Style style = cell.getStyle();
        Font font = style.getFont();
        font.setColor(Color.getBlue());
        font.setUnderline(FontUnderlineType.SINGLE);
        cell.setStyle(style);

        //Add a hyperlink to a URL at "A1" cell
        worksheet.getHyperlinks().add("A1", "B1", "http://www.aspose.com", "Hello Aspose", "1");

        /* Adding a link to an external file */
        //Put a value into a cell
        cell = cells.get("A5");
        cell.setValue("SmartMarkerDesigner.xls");

        String FILE_PATH_PART = "/WEB-INF/Designer/SmartMarkerDesigner.xls";
        ServletContext sc = getServletContext();
        String template_file_path = sc.getRealPath(FILE_PATH_PART);

        //Add a hyperlink to a URL at "B2" cell
        worksheet.getHyperlinks().add("A5", "B5", template_file_path, "Excel File", "1");
    }
}
