package com.aspose.cells.demos.data;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Cell;
import com.aspose.cells.Cells;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class DataFilterServlet extends DemoBaseServlet
{
    @Override
    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        resultFile = "DataFilter.xls";
        Workbook workbook = new Workbook();
        CreateStaticReport(workbook);
        return workbook;
    }

    private void CreateStaticReport(Workbook workbook)
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet worksheet = worksheets.get(0);

        Cells cells = worksheet.getCells();
        Cell cell;
        //Put a value into a cell
        cell = cells.get("A1");
        cell.setValue("Fruit");
        cell = cells.get("B1");
        cell.setValue("Total");
        cell = cells.get("A2");
        cell.setValue("Apple");
        cell = cells.get("B2");
        cell.setValue(1000);
        cell = cells.get("A3");
        cell.setValue("Orange");
        cell = cells.get("B3");
        cell.setValue(2500);
        cell = cells.get("A4");
        cell.setValue("Bananas");
        cell = cells.get("B4");
        cell.setValue(2500);
        cell = cells.get("A5");
        cell.setValue("Pear");
        cell = cells.get("B5");
        cell.setValue(1000);
        cell = cells.get("A6");
        cell.setValue("Grape");
        cell = cells.get("B6");
        cell.setValue(2000);

        cell = cells.get("D1");
        cell.setValue("Count:");
        cell = cells.get("E1");
        cell.setFormula("=SUBTOTAL(2, B1:B6)");

        worksheet.getAutoFilter().setRange("A1:B6");
    }
}
