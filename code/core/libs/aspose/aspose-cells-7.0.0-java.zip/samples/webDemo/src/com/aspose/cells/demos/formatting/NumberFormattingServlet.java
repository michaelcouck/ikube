package com.aspose.cells.demos.formatting;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Cell;
import com.aspose.cells.CellValueType;
import com.aspose.cells.Cells;
import com.aspose.cells.Style;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class NumberFormattingServlet extends DemoBaseServlet
{
    private static final String TEMPLATE_FILE_PATH_PART = "/WEB-INF/Designer/Workbooks/NumberFormatting.xls";

    @Override
    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        resultFile = "NumberFormatting.xls";
        ServletContext sc = getServletContext();
        String template_file_path = sc.getRealPath(TEMPLATE_FILE_PATH_PART);
        Workbook workbook = new Workbook(template_file_path);
        createStaticReport(workbook);
        return workbook;
    }

    private void createStaticReport(Workbook workbook)
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet worksheet = worksheets.get(0);

        Cell cell;
        Cells cells = worksheet.getCells();
        Style style;
        int number = 0;
        String temp = "";
        Double d;

        for(int i = 1; i <= 36; i++)
        {
            cell = cells.get(i, 0);
            temp = cell.getStringValue();

            switch (cell.getType())
            {
                case CellValueType.IS_NUMERIC:
                    number = cell.getIntValue();
                    break;
            }

            //Set the display format of numbers and dates
            cell = cells.get(i, 1);
            cell.setValue(123.5);
            style = cell.getStyle();
            style.setNumber(number);
            cell.setStyle(style);
        }
    }
}
