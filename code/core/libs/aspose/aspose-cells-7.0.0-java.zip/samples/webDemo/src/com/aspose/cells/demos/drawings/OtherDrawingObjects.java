package com.aspose.cells.demos.drawings;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.MsoDrawingType;
import com.aspose.cells.TextBox;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class OtherDrawingObjects extends DemoBaseServlet
{
    protected Workbook createReport(HttpServletRequest request) throws Exception
    { 
        resultFile = "OtherDrawingObjects.xls";

        Workbook wb = new Workbook();
        createStaticReport(wb);
        return wb;
    }

    private void createStaticReport(Workbook wb) throws Exception
    {
        WorksheetCollection worksheets = wb.getWorksheets();
        Worksheet worksheet = worksheets.get(0);

        TextBox textbox = (TextBox)worksheet.getShapes().addShape(MsoDrawingType.TEXT_BOX, 1, 0, 1,
                0, 40, 40);
        textbox.setText("aaa");
        textbox.setHeight(80);
        textbox.setWidth(80);
    }
}
