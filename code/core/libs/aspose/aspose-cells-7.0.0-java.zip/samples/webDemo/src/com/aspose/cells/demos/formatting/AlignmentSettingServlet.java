package com.aspose.cells.demos.formatting;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Cell;
import com.aspose.cells.Cells;
import com.aspose.cells.Style;
import com.aspose.cells.TextAlignmentType;
import com.aspose.cells.TextDirectionType;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class AlignmentSettingServlet extends DemoBaseServlet
{
    private static final String TEMPLATE_FILE_PATH_PART = "/WEB-INF/Designer/Workbooks/AlignmentSetting.xls";

    @Override
    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        resultFile = "AlignmentSetting.xls";
        ServletContext sc = getServletContext();
        String template_file_path = sc.getRealPath(TEMPLATE_FILE_PATH_PART);
        Workbook workbook = new Workbook(template_file_path);
        createStaticReport(workbook);
        return workbook;
    }

    private void createStaticReport(Workbook workbook)
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet worksheet = worksheets.get(0);

        Cells cells = worksheet.getCells();
        Cell cell;
        Style style;

        //Set style to A1
        cell = cells.get("A1");
        style = cell.getStyle();
        style.setHorizontalAlignment(TextAlignmentType.CENTER);
        style.setVerticalAlignment(TextAlignmentType.CENTER);
        cell.setStyle(style);

        //Set style to A2
        cell = cells.get("A2");
        style = cell.getStyle();
        style.setRotationAngle(45);
        cell.setStyle(style);

        //Set style to C3
        cell = cells.get("C3");
        style = cell.getStyle();
        style.setShrinkToFit(true);
        cell.setStyle(style);

        //Set style to A4
        cell = cells.get("A4");
        style = cell.getStyle();
        style.setIndentLevel(5);
        cell.setStyle(style);

        //Set style to A5
        cell = cells.get("A5");
        style = cell.getStyle();
        style.setTextDirection(TextDirectionType.CONTEXT);
        cell.setStyle(style);

        //Set style to A6
        cell = cells.get("A6");
        style = cell.getStyle();
        style.setTextWrapped(true);
        cell.setStyle(style);
    }
}
