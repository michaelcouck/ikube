package com.aspose.cells.demos.drawings;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Cell;
import com.aspose.cells.Cells;
import com.aspose.cells.Comment;
import com.aspose.cells.CommentCollection;
import com.aspose.cells.Font;
import com.aspose.cells.Shape;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class AddingComments extends DemoBaseServlet
{
    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        resultFile = "AddingComments.xls";

        Workbook wb = new Workbook();
        createStaticReport(wb);
        return wb;
    }

    private void createStaticReport(Workbook workbook) throws Exception
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet worksheet = worksheets.get(0);

        Cells cells = worksheet.getCells();
        Cell cell;
        cell = cells.get("B5");
        //Put a value into a cell
        cell.setValue("Hello");

        //Add comment to cell B1
        CommentCollection comments = worksheet.getComments();
        Comment comment = comments.get(comments.add(4, 1));
        //Set the comment note
        comment.setNote("Aspose.Cells");

        //Set the font of a comment
        Font font = comment.getFont();
        font.setSize(12);
        font.setBold(true);
        Shape shape = comment.getCommentShape();
        shape.setHeight(200);
        shape.setWidth(200);
    }

}
