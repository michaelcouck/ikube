package com.aspose.cells.demos.formatting;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.BackgroundType;
import com.aspose.cells.Cell;
import com.aspose.cells.Cells;
import com.aspose.cells.Color;
import com.aspose.cells.Style;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class PatternSettingServlet extends DemoBaseServlet
{
    protected Workbook createReport(HttpServletRequest request) throws Exception
    { 
        resultFile = "PatternSetting.xls";

        Workbook wb = new Workbook();
        createStaticReport(wb);
        return wb;
    }

    private void createStaticReport(Workbook workbook)
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet worksheet = worksheets.get(0);

        Cells cells = worksheet.getCells();
        Cell cell;
        Style style;

        cell = cells.get("B2");
        style = cell.getStyle();
        style.setPattern(BackgroundType.DIAGONAL_CROSSHATCH);
        style.setBackgroundColor(Color.getBlue());
        cell.setStyle(style);
    }
}
