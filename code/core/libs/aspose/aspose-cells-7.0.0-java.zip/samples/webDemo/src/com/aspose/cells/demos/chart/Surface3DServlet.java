package com.aspose.cells.demos.chart;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Axis;
import com.aspose.cells.Cells;
import com.aspose.cells.Chart;
import com.aspose.cells.ChartCollection;
import com.aspose.cells.ChartType;
import com.aspose.cells.Color;
import com.aspose.cells.FileFormatType;
import com.aspose.cells.Font;
import com.aspose.cells.SeriesCollection;
import com.aspose.cells.Title;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class Surface3DServlet extends DemoBaseServlet
{
    private static final String TEMPLATE_FILE_PATH_PART = "/WEB-INF/Designer/Chart/SurfaceTemplate.xls";

    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        int fileFormatType = FileFormatType.EXCEL_97_TO_2003;
        resultFile = "3DSurface.xls";

        Workbook wb = new Workbook(getServletContext().getRealPath(TEMPLATE_FILE_PATH_PART));
        int chartType = ChartType.SURFACE_3_D;
        switch (Integer.parseInt(request.getParameter("ChartTypeList")))
        {
            case 1:
            {
                chartType = ChartType.SURFACE_WIREFRAME_3_D;
                break;
            }
        }
        createStaticReport(wb, chartType);
        return wb;
    }

    private void createStaticReport(Workbook workbook, int chartType) throws Exception
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet worksheet = worksheets.get(0);
        //Set the name of worksheet
        worksheet.setName("3D Surface");

        //Create chart
        ChartCollection charts = worksheet.getCharts();
        Chart chart = charts.get(charts.add(chartType, 1, 7, 25, 16));

        //Set properties of nseries
        SeriesCollection nSeries = chart.getNSeries();
        nSeries.add("B3:F11", true);
        nSeries.setCategoryData("A3:A11");

        Cells cells = worksheet.getCells();
        String temp = "";
        for(int i = 0; i < nSeries.getCount(); i++)
        {
            temp = cells.get(0, i + 1).getStringValue();
            nSeries.get(i).setName(temp);
        }

        //Set properties of chart title
        Title title = chart.getTitle();
        title.setText("Tensile strenth Measurements");
        Font font1 = title.getTextFont();
        font1.setBold(true);
        font1.setColor(Color.getBlack());
        font1.setSize(12);

        //Set properties of categoryaxis title
        Axis categoryAxis = chart.getCategoryAxis();
        title = categoryAxis.getTitle();
        title.setText("Seconds");
        Font font2 = title.getTextFont();
        font2.setBold(true);
        font2.setColor(Color.getBlack());
        font2.setSize(10);

        //Set properties of valueaxis title
        Axis valueAxis = chart.getValueAxis();
        valueAxis.setVisible(false);
        title = valueAxis.getTitle();
        title.setText("Tensile Strength");
        Font font3 = title.getTextFont();
        font3.setBold(true);
        font3.setColor(Color.getBlack());
        font3.setSize(10);
        title.setRotationAngle(90);
    }
}
