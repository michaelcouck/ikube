package com.aspose.cells.demos.security;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.FileFormatType;
import com.aspose.cells.Protection;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class ProtectingWorksheet extends DemoBaseServlet
{
    private static final String TEMPLATE_FILE_PATH_PART = "/WEB-INF/Designer/book1.xls";

    protected Workbook createReport(HttpServletRequest request) throws Exception
    { 
        resultFile = "ProtectingWorksheet.xls";

        Workbook wb = new Workbook(getServletContext().getRealPath(TEMPLATE_FILE_PATH_PART));
        createStaticReport(wb);
        return wb;
    }

    private void createStaticReport(Workbook wb) throws Exception
    {
        WorksheetCollection worksheets = wb.getWorksheets();
        Worksheet worksheet = worksheets.get(0);

        Protection protection = /* new Protection() */worksheet.getProtection();
        String password = "123";
        protection.setPassword(password);
    }
}
