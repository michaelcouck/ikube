package com.aspose.cells.demos.smartmarker;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.AsposeDataTable;
import com.aspose.cells.Workbook;
import com.aspose.cells.WorkbookDesigner;
import com.aspose.cells.demos.DemoBaseServlet;

public class SmartMarkerServlet extends DemoBaseServlet
{
    private static final long serialVersionUID = 3257562897738708533L;

    private static final String DB_URL_P1 = "jdbc:odbc:driver={Microsoft Access Driver (*.mdb)};DBQ=";

    private static final String DB_URL_P2 = "/WEB-INF/Database/Northwind.mdb";

    private static final String TEMPLATE_FILE_PATH_PART = "/WEB-INF/Designer/SmartMarkerDesigner.xls";

    @Override
    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        String command = request.getParameter("_command");
        ServletContext sc = getServletContext();
        String template_file_path = sc.getRealPath(TEMPLATE_FILE_PATH_PART);
        Workbook wb = new Workbook(template_file_path);
        if(command.equals("SmartResult"))
        {
            resultFile = "SmartMarker.xls";
            String db_url = DB_URL_P1 + sc.getRealPath(DB_URL_P2);
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            createSmart(db_url, wb);
        }
        else
        {
            resultFile = "SmartMarkerDesigner.xls";
        }
        
        return wb;
    }

    private static void createSmart(String db_url, Workbook wb) throws Exception
    {
        WorkbookDesigner designer = new WorkbookDesigner();
        designer.setWorkbook(wb);
        designer.setDataSource("Variable", "Single Variable");
        designer.setDataSource("MultiVariable", new String[]
        {
                "Variable 1", "Variable 2", "Variable 3"
        });
        designer.setDataSource("MultiVariable2", new String[]
        {
                "Skip 1", "Skip 2", "Skip 3"
        });
        designer.setDataSource("Array1Dim", new String[]
        {
                "A1", "A2", "A3"
        });
        designer.setDataSource("Array2Dim", new String[][]
        {
                {
                        "A11", "A12", "A13"
                },
                {
                        "A21", "A22", "A23", "A24"
                },
                {
                        "A31", "A32",
                },
        });
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try
        {
            conn = DriverManager.getConnection(db_url);
            stmt = conn
                    .createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            rs = stmt
                    .executeQuery("SELECT Address, City, CompanyName, ContactName, ContactTitle, Country, CustomerID, Fax, Phone, PostalCode, Region"
                            + " FROM Customers");
            designer.setDataSource("Customers", rs);

            conn = DriverManager.getConnection(db_url);
            stmt = conn
                    .createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            ResultSet rs_order = stmt.executeQuery("SELECT DISTINCTROW Invoices.* FROM Invoices");
            designer.setDataSource("Order Details", rs_order);
            AsposeDataTable dataTable = new DataTable();
            designer.setDataSource("Employee", dataTable);
            Person person = new Person("0", "Aspose");
            designer.setDataSource("Person", person);
        }
        catch (java.sql.SQLException sqlEx)
        {
            sqlEx.printStackTrace();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        designer.process(false);

        try
        {
            if(stmt != null)
            {
                stmt.close();
            }
            if(conn != null)
            {
                conn.close();
            }
        }
        catch (SQLException sqlEx)
        {
        }
    }
}
