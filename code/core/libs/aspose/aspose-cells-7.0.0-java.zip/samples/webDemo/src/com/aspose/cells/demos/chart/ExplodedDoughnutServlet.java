package com.aspose.cells.demos.chart;

import javax.servlet.http.HttpServletRequest;

import com.aspose.cells.Axis;
import com.aspose.cells.Chart;
import com.aspose.cells.ChartCollection;
import com.aspose.cells.ChartType;
import com.aspose.cells.Color;
import com.aspose.cells.FileFormatType;
import com.aspose.cells.Font;
import com.aspose.cells.Legend;
import com.aspose.cells.LegendPositionType;
import com.aspose.cells.SeriesCollection;
import com.aspose.cells.Title;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.cells.demos.DemoBaseServlet;

public class ExplodedDoughnutServlet extends DemoBaseServlet
{
    private static final String TEMPLATE_FILE_PATH_PART = "/WEB-INF/Designer/Chart/DoughnutTemplate.xls";

    protected Workbook createReport(HttpServletRequest request) throws Exception
    {
        int fileFormatType = FileFormatType.EXCEL_97_TO_2003;
        resultFile = "ExplodedDoughnut.xls";

        Workbook wb = new Workbook(getServletContext().getRealPath(TEMPLATE_FILE_PATH_PART));
        createStaticReport(wb);
        return wb;
    }

    private void createStaticReport(Workbook workbook) throws Exception
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet dataSheet = worksheets.get(0);
        Worksheet worksheet = worksheets.get(worksheets.add());
        //Set the name of worksheet
        dataSheet.setName("Data");
        worksheet.setName("Chart");

        //Create chart
        ChartCollection charts = worksheet.getCharts();
        Chart chart = charts.get(charts.add(ChartType.DOUGHNUT_EXPLODED, 1, 1, 27, 10));

        //Set the properties of nseries
        SeriesCollection nSeries = chart.getNSeries();
        nSeries.add("Data!B2:B3", true);
        nSeries.setCategoryData("Data!A2:A3");

        //Set the properties of chart title
        Title title = chart.getTitle();
        title.setText("Fruit Sales by Region For 2005");
        Font font1 = title.getTextFont();
        font1.setBold(true);
        font1.setColor(Color.getBlack());
        font1.setSize(12);

        //Set the properties of categoryaxis title
        Axis categoryAxis = chart.getCategoryAxis();
        title = categoryAxis.getTitle();
        title.setText("Region");
        Font font2 = title.getTextFont();
        font2.setBold(true);
        font2.setColor(Color.getBlack());
        font2.setSize(10);

        //Set the properties of valueaxis title
        Axis valueAxis = chart.getValueAxis();
        title = valueAxis.getTitle();
        Font font3 = title.getTextFont();
        font3.setColor(Color.getBlack());
        font3.setBold(true);
        font3.setSize(10);

        //Set the properties of legend
        Legend legend = chart.getLegend();
        legend.setPosition(LegendPositionType.TOP);
    }
}
