

import com.aspose.cells.*;
import java.util.ArrayList;

public class DataTable implements AsposeDataTable
{
   private ArrayList<Person> list = null;
   private int index;
   public DataTable()
   {
      list = new ArrayList<Person>();
      for(int i = 0 ; i < 10 ; i++)
      {
         Person person = new Person("" + i ,"Person" + i);
         list.add(person);
      }
      index = -1;
   }
   
   public String[] getColumns()
   {
//     String[] columns = new String[4];
//     columns[0] = "startColumn";
//     columns[1] = "startRow";
//     columns[2] = "endColumn";
//     columns[3] = "endRow";
     return null;
   }

   public int size()
   {
      
      return this.list.size();
   }

   public void beforeFirst()
   {
      index = -1;
   }

   public Object get(int columnIndex)
   {
      if(index < 0 || index >= this.size())
      {
         return false;
      }
      Person person = this.list.get(index);
      switch(columnIndex)
      {
      case 1:
         return person.getId();
      case 2:
         return person.getName();
         default:
            return null;
      }
   }

   public boolean next()
   {
      index += 1;
      if(index >= this.list.size())
      {
         return false;
      }
      return true;
   }
   
   /**
    * Returns the value of the designated column in the current row.
    * @param columnName the property name of the POJO. 
    * @return the value of the designated column in the current row.
    */
   public Object get(String columnName)
   {
      Person person = this.list.get(index);
      if(columnName.equals("id"))
      {
         return person.getId();
      }
      if(columnName.equals("name"))
      {
         return person.getName();
      }
            
      return null;
   }  
  
   

}
