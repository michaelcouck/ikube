/*
 * Copyright (c) 2001-2011 Aspose Pty Ltd. All Rights Reserved.
 */
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

import com.aspose.cells.BackgroundType;
import com.aspose.cells.Border;
import com.aspose.cells.BorderCollection;
import com.aspose.cells.BorderType;
import com.aspose.cells.Cell;
import com.aspose.cells.CellBorderType;
import com.aspose.cells.Cells;
import com.aspose.cells.Color;
import com.aspose.cells.Font;
import com.aspose.cells.Row;
import com.aspose.cells.Style;
import com.aspose.cells.StyleCollection;
import com.aspose.cells.StyleFlag;
import com.aspose.cells.TextAlignmentType;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;

public class DemoNorthwind
{
    ////////////////////////// BEGIN OF Alphabetical List of Products  ///////////////////////
    public static void createProductsList(String db_url, Workbook workbook) throws SQLException,
            IOException
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        for(int i = worksheets.getCount() - 1; i > 0; --i)
        {
            worksheets.removeAt(i);
        }
        Worksheet sheet = worksheets.get(0);
        sheet.setName("Product List");
        Cells cells = sheet.getCells();
        // open from database
        Connection conn = null;
        ResultSet rs = null;
        Statement stmt = null;
        try
        {
            conn = DriverManager.getConnection(db_url);
            stmt = conn.createStatement();
            rs = stmt
                    .executeQuery("SELECT DISTINCTROW Products.ProductName, Categories.CategoryName, "
                            + " Products.QuantityPerUnit, Products.UnitsInStock "
                            + " FROM Categories INNER JOIN Products "
                            + " ON Categories.CategoryID = Products.CategoryID "
                            + " WHERE (((Products.Discontinued) = No)) "
                            + " Order by Products.ProductName");

            int rowIndex = 5;
            while (rs.next())
            {
                cells.get(rowIndex, 1).setValue(rs.getString(1));
                cells.get(rowIndex, 2).setValue(rs.getString(2));
                cells.get(rowIndex, 3).setValue(rs.getString(3));
                cells.get(rowIndex, 4).setValue(rs.getInt(4));
                ++rowIndex;
            }
        }
        finally
        {
            if(rs != null)
                rs.close();
            if(stmt != null)
                stmt.close();
            if(conn != null)
                conn.close();
        }

    }

    //////////////////////////// END OF Alphabetical List of Products  //////////////////////

    //////////////////////////// BEGIN OF CATALOG ///////////////////////////////////////////
    public static void createCatalog(String db_url, Workbook workbook) throws SQLException,
            Exception
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet sheet = worksheets.get("Sheet2");
        sheet.setName("Catalog");
        Cells cells = sheet.getCells();
        // remove unuseful sheets
        for(int i = worksheets.getCount() - 1; i >= 0; --i)
        {
            if(worksheets.get(i) != sheet)
                worksheets.removeAt(i);
        }

        // customize colors, fonts, and styles
        Style styleOfCategoryName, styleOfDescription, styleOfProductName, styleOfTitle, styleOfNumber;
        workbook.changePalette(Color.getLightGray(), 55); // light gray

        styleOfCategoryName = workbook.createStyle();
        Font font = styleOfCategoryName.getFont();
        font.setName("Times New Roman");
        font.setColor(Color.getBlue());
        font.setSize(14);
        font.setBold(true);

        styleOfDescription = workbook.createStyle();
        font = styleOfDescription.getFont();
        font.setName("Times New Roman");
        font.setColor(Color.getBlue());
        font.setItalic(true);

        styleOfProductName = workbook.createStyle();
        font = styleOfProductName.getFont();
        font.setBold(true);

        styleOfTitle = workbook.createStyle();
        font = styleOfTitle.getFont();
        font.setBold(true);
        font.setItalic(true);
        styleOfTitle.setPattern(BackgroundType.SOLID);
        styleOfTitle.setForegroundColor(Color.getLightGray());

        styleOfNumber = workbook.createStyle();
        styleOfNumber.setNumber(8);
        font = styleOfNumber.getFont();
        font.setName("Times New Roman");

        Connection conn = null;
        Statement stmt = null;
        PreparedStatement pstmt = null;
        ResultSet rs_cata = null;
        ResultSet rs_prod = null;
        StyleFlag styleFlag = new StyleFlag();
        styleFlag.setAll(true);
        try
        {
            conn = DriverManager.getConnection(db_url);
            stmt = conn.createStatement();
            rs_cata = stmt
                    .executeQuery("SELECT CategoryID, CategoryName, Description FROM Categories");
            pstmt = conn
                    .prepareStatement("SELECT ProductName, ProductID, QuantityPerUnit, UnitPrice "
                            + " FROM Products" + " WHERE categoryid = ?");

            int rowIndex = 55;
            while (rs_cata.next())
            {
                rowIndex += 2;
                Row row;
                Cell cell;

                // category name
                row = cells.getRows().get(rowIndex);
                row.setHeight(20);
                cell = row.get(1);
                cell.setStyle(styleOfCategoryName);
                cell.setValue(rs_cata.getString(2));

                // description
                row = cells.getRows().get(++rowIndex);
                cell = row.get(1);
                cell.setStyle(styleOfDescription);
                cell.setValue(rs_cata.getString(3));

                // query product
                pstmt.setInt(1, rs_cata.getInt(1));
                rs_prod = pstmt.executeQuery();

                rowIndex += 2;
                row = cells.getRows().get(rowIndex);
                cells.createRange(rowIndex, 1, 1, 4).applyStyle(styleOfTitle, styleFlag);

                int rowNum = cells.importResultSet(rs_prod, rowIndex, 1, -1, -1, true);
                cells.createRange(rowIndex + 1, 1, rowNum, 1).applyStyle(styleOfProductName,
                        styleFlag);
                cells.createRange(rowIndex + 1, 4, rowNum, 1).applyStyle(styleOfNumber, styleFlag);

                rowIndex += rowNum;
                rs_prod.close();
                rs_prod = null;
            }
        }
        finally
        {
            if(rs_cata != null)
                rs_cata.close();
            if(rs_prod != null)
                rs_prod.close();
            if(pstmt != null)
                pstmt.close();
            if(stmt != null)
                stmt.close();
            if(conn != null)
                conn.close();
        }

    }

    /////////////////////////// END OF CATALOG //////////////////////////////////////////

    ////////////////////////// BEGIN OF Catalog Subreport ///////////////////////////////
    public static void createCatalogSubreport(String db_url, Workbook workbook)
            throws SQLException, Exception
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet sheet = worksheets.get("Sheet3");
        sheet.setName("Catalog Subreport");
        Cells cells = sheet.getCells();
        // remove unuseful sheets
        for(int i = worksheets.getCount() - 1; i >= 0; --i)
        {
            if(worksheets.get(i) != sheet)
                worksheets.removeAt(i);
        }

        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try
        {
            conn = DriverManager.getConnection(db_url);
            stmt = conn.createStatement();
            rs = stmt.executeQuery("SELECT ProductName, ProductID, QuantityPerUnit, UnitPrice"
                    + " FROM Products" + " ORDER BY ProductName");
            cells.importResultSet(rs, 0, 1, -1, -1, false);
        }
        finally
        {
            if(rs != null)
                rs.close();
            if(stmt != null)
                stmt.close();
            if(conn != null)
                conn.close();
        }

    }

    //////////////////////////// END OF Catalog Subreport ///////////////////////////////

    //////////////////////////// BEGIN OF CUSTOMER LABELS ///////////////////////////////
    public static void createCustomerLabels(String db_url, Workbook workbook) throws IOException,
            SQLException
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet sheet = worksheets.get("Sheet4");
        sheet.setName("Customer Labels");
        Cells cells = sheet.getCells();
        // remove unuseful sheets
        for(int i = worksheets.getCount() - 1; i >= 0; --i)
        {
            if(worksheets.get(i) != sheet)
                worksheets.removeAt(i);
        }

        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try
        {
            conn = DriverManager.getConnection(db_url);
            stmt = conn.createStatement();
            rs = stmt.executeQuery("SELECT CompanyName, Address, City, Region, PostalCode, Country"
                    + " FROM Customers" + "" + " ORDER BY Country, Region");

            int sign = 0, rowIndex = 0;
            while (rs.next())
            {
                int columnIndex = sign * 3;

                cells.get(rowIndex, columnIndex).setValue(rs.getString(1));
                cells.get(rowIndex + 1, columnIndex).setValue(rs.getString(2));

                //StringBuilder builder = new StringBuilder();
                String tmp_string;
                //builder.append(rs.getString(3));
                // builder.append(rs.getString(4));
                //builder.append(rs.getString(5));
                String v = rs.getString(3) + rs.getString(4) + rs.getString(5);
                cells.get(rowIndex + 2, columnIndex).setValue(v);

                cells.get(rowIndex + 3, columnIndex).setValue(rs.getString(6));

                if(++sign == 3)
                {
                    sign = 0;
                    rowIndex += 5;
                }
            }
        }
        finally
        {
            if(rs != null)
                rs.close();
            if(stmt != null)
                stmt.close();
            if(conn != null)
                conn.close();
        }

    }

    ///////////////////////////// END OF CUSTOMER LABELS ////////////////////////////////

    //////////////////////////// BEGIN OF Employee Sales by Country /////////////////////
    public static void createEmployeeSales(String db_url, Workbook workbook) throws SQLException,
            Exception
    {
        StyleFlag styleFlag = new StyleFlag();
        styleFlag.setAll(true);
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet sheet_uk = worksheets.get("Sheet5");
        sheet_uk.setName("Employee Sales UK");

        Worksheet sheet_us = worksheets.get("Sheet6");
        sheet_us.setName("Employee Sales USA");

        // remove unuseful sheets
        for(int i = worksheets.getCount() - 1; i >= 0; --i)
        {
            Worksheet tmp = worksheets.get(i);
            if((tmp != sheet_uk) && (tmp != sheet_us))
                worksheets.removeAt(i);
        }

        Connection conn = null;
        Statement stmt = null;
        PreparedStatement pstmt = null;
        ResultSet rs_employee = null;
        ResultSet rs_order = null;

        ArrayList params_uk = new ArrayList();
        ArrayList params_us = new ArrayList();
        try
        {
            conn = DriverManager.getConnection(db_url);
            stmt = conn.createStatement();
            rs_employee = stmt
                    .executeQuery("SELECT Country, EmployeeID, FirstName, LastName FROM Employees "
                            + " ORDER BY Country, LastName, FirstName");
            pstmt = conn
                    .prepareStatement("SELECT Orders.OrderID, [Order Subtotals].Subtotal as SaleAmount"
                            + " FROM Employees INNER "
                            + " JOIN (Orders INNER JOIN [Order Subtotals] ON Orders.OrderID = "
                            + " [Order Subtotals].OrderID) "
                            + " ON Employees.EmployeeID = Orders.EmployeeID"
                            + " where Employees.EmployeeID = ?");

            int ukRowIndex = 6, usRowIndex = 6;
            Style style;

            // create a style for the header
            style = workbook.createStyle();
            style.setName("HeaderStyle");
            BorderCollection borders = style.getBorders();
            borders.getByBorderType(BorderType.BOTTOM_BORDER).setLineStyle(CellBorderType.DOUBLE);
            borders.getByBorderType(BorderType.TOP_BORDER).setLineStyle(CellBorderType.DOUBLE);
            Font font = style.getFont();
            font.setSize(12);
            font.setBold(true);
            style.setTextWrapped(true);
            style.setHorizontalAlignment(TextAlignmentType.CENTER);

            while (rs_employee.next())
            {
                String country = rs_employee.getString(1);
                int employee_id = rs_employee.getInt(2);
                String employee_name = rs_employee.getString(4) + ", " + rs_employee.getString(3);

                Worksheet sheet;
                ArrayList params_xx;
                Cell cell;
                Row row;
                int rowIndex;
                if(country.equals("UK"))
                {
                    sheet = sheet_uk;
                    rowIndex = ukRowIndex;
                    params_xx = params_uk;
                }
                else if(country.equals("USA"))
                {
                    sheet = sheet_us;
                    rowIndex = usRowIndex;
                    params_xx = params_us;
                }
                else
                    continue;
                Cells cells = sheet.getCells();
                cell = cells.get(rowIndex - 2, 0);
                cell.setValue("SalePerson: " + employee_name);
                style = workbook.createStyle();
                font = style.getFont();
                font.setBold(true);
                font.setSize(12);
                cell.setStyle(style);

                cells.getRows().get(rowIndex - 2).setHeight(19);
                cells.getRows().get(rowIndex - 1).setHeight(4);
                cells.getRows().get(rowIndex).setHeight(48);

                style = workbook.getStyles().get("HeaderStyle");
                row = cells.getRows().get(rowIndex);
                cells.createRange(rowIndex, 1, 1, 4).applyStyle(style, styleFlag);
                row.get(1).setValue("Order ID:");
                row.get(2).setValue("Sales Amount:");
                row.get(3).setValue("Percent of Salesperson's Total:");
                row.get(4).setValue("Percent of Country Total:");
                ++rowIndex;

                pstmt.setInt(1, employee_id);
                rs_order = pstmt.executeQuery();
                int rowNum = cells.importResultSet(rs_order, rowIndex, 1, false);

                // stores the start row index and the row count
                int[] rowAndRowNum = new int[2];
                rowAndRowNum[0] = rowIndex;
                rowAndRowNum[1] = rowNum;
                params_xx.add(rowAndRowNum);

                rowIndex += rowNum;
                rowIndex += 4;
                rs_order.close();
                rs_order = null;

                if(country.equals("UK"))
                {
                    ukRowIndex = rowIndex;
                }
                else if(country.equals("USA"))
                {
                    usRowIndex = rowIndex;
                }
            }
        }
        finally
        {
            if(rs_employee != null)
                rs_employee.close();
            if(rs_order != null)
                rs_order.close();
            if(pstmt != null)
                pstmt.close();
            if(stmt != null)
                stmt.close();
            if(conn != null)
                conn.close();
        }

        // Prepare the style for the "Exceeded Goal"
        Style styleOfExceededGoal = workbook.createStyle();
        Font font = styleOfExceededGoal.getFont();
        font.setBold(true);
        font.setItalic(true);
        font.setSize(12);
        font.setColor(Color.getRed());

        // Calculates sales percentages
        for(int i = 0; i < worksheets.getCount(); ++i)
        {
            Worksheet sheet = worksheets.get(i);
            Cells cells = sheet.getCells();
            ArrayList params = sheet.getName().endsWith("UK") ? params_uk : params_us;

            double country_total = 0;
            double person_total = 0;
            for(int j = 0; j < params.size(); ++j)
            {
                int[] rowIndexAndCount = (int[])params.get(j);
                int startRowIndex = rowIndexAndCount[0];
                int rowCount = rowIndexAndCount[1];

                person_total = 0;
                for(int m = startRowIndex; m < startRowIndex + rowCount; ++m)
                {
                    person_total += ((Double)(cells.get(m, 2).getValue())).doubleValue();
                }
                if(person_total > 5000)
                {
                    Cell cell = cells.get(startRowIndex - 3, 3);
                    cell.setValue("Exceeded Goal!");
                    cell.setStyle(styleOfExceededGoal);
                }
                cells.get(startRowIndex + rowCount, 2).setValue(person_total);
                country_total += person_total;
            }

            for(int j = 0; j < params.size(); ++j)
            {
                int[] rowIndexAndCount = (int[])params.get(j);
                int startRowIndex = rowIndexAndCount[0];
                int rowCount = rowIndexAndCount[1];

                person_total = ((Double)(cells.get(startRowIndex + rowCount, 2).getValue()))
                        .doubleValue();
                for(int m = startRowIndex; m < startRowIndex + rowCount; ++m)
                {
                    // person percentage
                    double single_sale = ((Double)(cells.get(m, 2).getValue())).doubleValue();
                    cells.get(m, 3).setValue(single_sale / person_total);
                    cells.get(m, 4).setValue(single_sale / country_total);
                }
                cells.get(startRowIndex + rowCount, 4).setValue(person_total / country_total);
            }

        }

    }

    ///////////////////////////// END OF Employee Sales by Country //////////////////////

    //////////////////////////// BEGIN OF Create Invoice /////////////////////////////////
    public static void createInvoice(String db_url, Workbook workbook) throws IOException,
            SQLException
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet sheet = worksheets.get(0);
        sheet.setName("Invoice");
        Cells cells = sheet.getCells();
        setColumnWidth(sheet);
        createInvoiceStyles(workbook);
        StyleCollection styles = workbook.getStyles();

        Connection conn = null;
        Statement stmt = null;
        PreparedStatement pstmt = null;
        ResultSet rs_order = null;
        ResultSet rs_invoice = null;

        try
        {
            conn = DriverManager.getConnection(db_url);
            stmt = conn.createStatement();
            rs_order = stmt.executeQuery("SELECT OrderID FROM Orders ORDER BY OrderID DESC");
            pstmt = conn.prepareStatement(
                    "SELECT DISTINCTROW Invoices.* FROM Invoices WHERE Invoices.OrderID = ?",
                    ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);

            int rowIndex = 0;
            while (rs_order.next())
            {
                // query invoices
                int orderID = rs_order.getInt(1);
                pstmt.setInt(1, orderID);
                rs_invoice = pstmt.executeQuery();

                if(!rs_invoice.next())
                    continue;

                createInvoiceHeader(styles, sheet, rs_invoice, rowIndex);
                rowIndex += 11;
                createOrder(styles, sheet, rowIndex, orderID, rs_invoice);
                rowIndex += 4;
                rowIndex += createOrderDetail(styles, sheet, rowIndex, rs_invoice) + 1;

                rs_invoice.close();
                rs_invoice = null;
            }
        }
        finally
        {
            if(rs_invoice != null)
                rs_invoice.close();
            if(rs_order != null)
                rs_order.close();
            if(pstmt != null)
                pstmt.close();
            if(stmt != null)
                stmt.close();
            if(conn != null)
                conn.close();
        }
    }

    /* Part of createInvoice() */
    private static final void createInvoiceStyles(Workbook workbook)
    {
        Color lightBlue = Color.getLightBlue();
        Color darkBlue = Color.getDarkBlue();
        workbook.changePalette(darkBlue, 55);
        workbook.changePalette(lightBlue, 54);

        Style style;
        Font font;

        style = workbook.createStyle();
        font = style.getFont();
        font.setSize(12);
        font.setBold(true);
        font.setColor(Color.getWhite());

        style.setPattern(BackgroundType.SOLID);
        style.setForegroundColor(lightBlue);
        style.setHorizontalAlignment(TextAlignmentType.CENTER);
        style.setName("Font12Center");

        Style styleN = workbook.createStyle();
        styleN.copy(style);
        style = styleN;
        style.setHorizontalAlignment(TextAlignmentType.LEFT);
        style.setName("Font12Left");

        styleN = workbook.createStyle();
        styleN.copy(style);
        style = styleN;
        style.setHorizontalAlignment(TextAlignmentType.RIGHT);
        style.setName("Font12Right");

        style = workbook.createStyle();
        style.setNumber(7);
        style.setName("Number7");

        style = workbook.createStyle();
        style.setNumber(9);
        style.setName("Number9");

        style = workbook.createStyle();
        style.setHorizontalAlignment(TextAlignmentType.CENTER);
        style.setName("Center");

        style = workbook.createStyle();
        font = style.getFont();
        font.setSize(16);
        font.setBold(true);
        font.setColor(darkBlue);
        style.setName("Darkblue");

        style = workbook.createStyle();
        font = style.getFont();
        font.setSize(12);
        font.setBold(true);
        font.setColor(darkBlue);
        style.setName("Darkblue12");

        style = workbook.createStyle();
        font = style.getFont();
        font.setItalic(true);
        font.setColor(darkBlue);
        style.setName("DarkblueItalic");

        style = workbook.createStyle();
        Border border = style.getBorders().getByBorderType(BorderType.BOTTOM_BORDER);
        border.setLineStyle(CellBorderType.MEDIUM);
        border.setColor(Color.getBlack());
        style.setName("BlackMedium");
    }

    /* Part of createInvoice() */
    private static final void setColumnWidth(Worksheet sheet)
    {
        Cells cells = sheet.getCells();
        cells.setColumnWidth(0, 12);
        cells.setColumnWidth(1, 16);
        cells.setColumnWidth(2, 16);
        cells.setColumnWidth(3, 16);
        cells.setColumnWidth(4, 16);
        cells.setColumnWidth(5, 16);
        cells.setColumnWidth(6, 18);
    }

    /* Part of createInvoice() */
    private static final void createInvoiceHeader(StyleCollection styles, Worksheet sheet,
            ResultSet rs_invoice, int rowIndex) throws SQLException
    {
        Row row;
        Cell cell;
        Style style;
        String string;
        Cells cells = sheet.getCells();
        cells.getRows().get(rowIndex).setHeight(24);

        cell = cells.get(rowIndex, 5);
        cell.setValue("INVOICE");
        cell.setStyle(styles.get("Darkblue"));

        style = styles.get("BlackMedium");
        for(int i = 0; i <= 255; ++i)
            cells.get(rowIndex + 2, i).setStyle(style);

        style = styles.get("DarkblueItalic");
        cell = cells.get(rowIndex + 3, 0);
        cell.setValue("One Portals Way, Twin Points WA 98156");
        cell.setStyle(style);
        cell = cells.get(rowIndex + 4, 0);
        cell.setValue("Phone:1-206-555-1417 Fax:1-206");
        cell.setStyle(style);

        style = styles.get("Darkblue12");
        cell = cells.get(rowIndex + 3, 5);
        cell.setValue("Date:");
        cell.setStyle(style);

        Calendar calendar = new GregorianCalendar();
        //StringBuilder timeDisplay = new StringBuilder();
        String timeDisplay = "";
        timeDisplay += (calendar.get(Calendar.DAY_OF_MONTH)) + "/";
        timeDisplay += (calendar.get(Calendar.MONTH)) + "/";
        timeDisplay += (calendar.get(Calendar.YEAR));

        cells.get(rowIndex + 3, 6).setValue(timeDisplay.toString());

        cells.getRows().get(rowIndex + 6).setHeight(16);
        cell = cells.get(rowIndex + 6, 0);
        cell.setValue("Ship To:");
        cell.setStyle(style);

        cell = cells.get(rowIndex + 6, 4);
        cell.setValue("Bill To:");
        cell.setStyle(style);

        String tmp_str = rs_invoice.getString(1);
        cells.get(rowIndex + 6, 1).setValue(tmp_str);
        cells.get(rowIndex + 6, 5).setValue(tmp_str);

        tmp_str = rs_invoice.getString(2);
        cells.get(rowIndex + 7, 1).setValue(tmp_str);
        cells.get(rowIndex + 7, 5).setValue(tmp_str);

        tmp_str = "";
        tmp_str += rs_invoice.getString(3);
        tmp_str += rs_invoice.getString(4);
        tmp_str += rs_invoice.getString(5);
        tmp_str.trim();
        cells.get(rowIndex + 8, 1).setValue(tmp_str);
        cells.get(rowIndex + 8, 5).setValue(tmp_str);

        tmp_str = rs_invoice.getString(6);
        cells.get(rowIndex + 9, 1).setValue(tmp_str);
        cells.get(rowIndex + 9, 5).setValue(tmp_str);
    }

    /* Part of createInvoice() */
    private static final void createOrder(StyleCollection styles, Worksheet sheet, int rowIndex,
            int orderID, ResultSet rs_invoice) throws SQLException
    {
        Style style;
        String str;
        Row row;
        Cells cells = sheet.getCells();
        cells.getRows().get(rowIndex).setHeight(14);
        cells.getRows().get(rowIndex + 3).setHeight(14);

        style = styles.get("Font12Center");
        for(int i = 0; i < 7; ++i)
        {
            cells.get(rowIndex, i).setStyle(style);
            cells.get(rowIndex + 3, i).setStyle(style);
        }

        cells.get(rowIndex, 0).setValue("Order ID:");
        cells.get(rowIndex + 1, 0).setValue(orderID);

        cells.get(rowIndex, 1).setValue("Customer ID:");
        cells.get(rowIndex + 1, 1).setValue(rs_invoice.getString("CustomerID"));

        cells.get(rowIndex, 2).setValue("Salesperson:");
        cells.get(rowIndex + 1, 2).setValue(rs_invoice.getString("Salesperson"));

        cells.get(rowIndex, 3).setValue("Order Date:");
        cells.get(rowIndex + 1, 3).setValue(rs_invoice.getString("OrderDate"));

        cells.get(rowIndex, 4).setValue("Required Date:");
        cells.get(rowIndex + 1, 4).setValue(rs_invoice.getString("RequiredDate"));

        cells.get(rowIndex, 5).setValue("Shipped Date:");
        str = rs_invoice.getString("ShippedDate");
        if(str != null)
            cells.get(rowIndex + 1, 5).setValue(str);

        cells.get(rowIndex, 6).setValue("Ship Via");
        cells.get(rowIndex + 1, 6).setValue(rs_invoice.getString(19));

        row = cells.getRows().get(rowIndex + 3);
        row.get(0).setValue("Product ID:");
        row.get(1).setValue("Product");
        row.get(2).setValue("Name:");
        row.get(3).setValue("Quantity:");
        row.get(4).setValue("Unit Price:");
        row.get(5).setValue("Discount:");
        row.get(6).setValue("Extended Price:");

        row.get(1).setStyle(styles.get("Font12Right"));
        row.get(2).setStyle(styles.get("Font12Left"));
    }

    /**
     * Part of createInvoice().
     * 
     * @return how many rows written.
     */
    private static final int createOrderDetail(StyleCollection styles, Worksheet sheet,
            int rowIndex, ResultSet rs_invoice) throws SQLException
    {
        int rowIndexBackup = rowIndex;
        Style style_number7 = styles.get("Number7");
        Style style_number9 = styles.get("Number9");
        Style style_center = styles.get("Center");

        rs_invoice.beforeFirst();
        Cells cells = sheet.getCells();
        while (rs_invoice.next())
        {
            Row row = cells.getRows().get(rowIndex);
            row.get(0).setValue(rs_invoice.getInt("ProductID"));
            row.get(0).setStyle(style_center);

            row.get(1).setValue(rs_invoice.getString("ProductName"));

            row.get(3).setValue(rs_invoice.getInt("Quantity"));

            row.get(4).setValue(rs_invoice.getDouble("UnitPrice"));
            row.get(4).setStyle(style_number7);

            row.get(5).setValue(rs_invoice.getDouble("Discount"));
            row.get(5).setStyle(style_number9);

            row.get(6).setValue(rs_invoice.getDouble("ExtendedPrice"));
            row.get(6).setStyle(style_number7);

            ++rowIndex;
        }

        return rowIndex - rowIndexBackup + 1;
    }

    //////////////////////////// END OF Create Invoice ///////////////////////////////////

    //////////////////////////// BEGIN OF Products by Category ///////////////////////////
    public static void createProductsByCategory(String db_url, Workbook workbook)
            throws IOException, SQLException
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet sheet = worksheets.get("Sheet7");
        sheet.setName("Products By Category");
        Cells cells = sheet.getCells();
        StyleCollection styles = workbook.getStyles();
        // remove useless sheets
        for(int i = worksheets.getCount() - 1; i >= 0; --i)
        {
            if(worksheets.get(i) != sheet)
                worksheets.removeAt(i);
        }

        setProductsByCategoryStyles(workbook, sheet);
        int rowIndex = 4;
        int columnIndex = 0;
        int productsCount = 0;
        String lastCategory = "";
        String thisCategory, nextCagegory;

        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        Cell cell;

        try
        {
            conn = DriverManager.getConnection(db_url);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
            rs = stmt
                    .executeQuery("SELECT Categories.CategoryName, Products.ProductName, Products.QuantityPerUnit, "
                            + "       Products.UnitsInStock, Products.Discontinued, Categories.CategoryID, "
                            + "       Products.ProductID "
                            + " FROM Categories INNER JOIN Products ON Categories.CategoryID = Products.CategoryID"
                            + " WHERE (Products.Discontinued <> Yes) "
                            + " ORDER BY Categories.CategoryName, Products.ProductName");

            while (rs.next())
            {
                thisCategory = rs.getString("CategoryName");
                if(!thisCategory.equals(lastCategory))
                {
                    rowIndex = 4;
                    if(!rs.isFirst())
                        columnIndex += 4;

                    cell = cells.get(rowIndex, columnIndex);
                    cell.setValue("Category:");
                    cell.setStyle(styles.get("Category"));

                    cell = cells.get(rowIndex, columnIndex + 1);
                    cell.setValue(thisCategory);
                    cell.setStyle(styles.get("CategoryName"));

                    cell = cells.get(rowIndex + 1, columnIndex);
                    cell.setValue("Product Name");
                    cell.setStyle(styles.get("ProductName"));

                    cell = cells.get(rowIndex + 1, columnIndex + 1);
                    cell.setValue("Units In Stock:");
                    cell.setStyle(styles.get("UnitsInStock"));

                    lastCategory = thisCategory;
                    rowIndex += 2;
                }
                cells.get(rowIndex, columnIndex).setValue(rs.getString("ProductName"));
                cells.get(rowIndex, columnIndex + 1).setValue(rs.getInt("UnitsInStock"));

                if(!rs.isLast())
                {
                    rs.next();
                    nextCagegory = rs.getString("CategoryName");
                    if(!thisCategory.equals(nextCagegory))
                    {
                        cell = cells.get(rowIndex + 1, columnIndex);
                        cell.setValue("Number of Products:");
                        cell.setStyle(styles.get("ProductsCount"));

                        cell = cells.get(rowIndex + 1, columnIndex + 1);
                        cell.setValue(productsCount + 1);
                        cell.setStyle(styles.get("CountNumber"));

                        ++rowIndex;
                        productsCount = 0;
                    }
                    else
                        ++productsCount;
                    rs.previous();
                }
                else
                {
                    cell = cells.get(rowIndex + 1, columnIndex);
                    cell.setValue("Number of Products:");
                    cell.setStyle(styles.get("ProductsCount"));

                    cell = cells.get(rowIndex + 1, columnIndex + 1);
                    cell.setValue(productsCount + 1);
                    cell.setStyle(styles.get("CountNumber"));
                }
                ++rowIndex;
            }
        }
        finally
        {
            if(rs != null)
                rs.close();
            if(stmt != null)
                stmt.close();
            if(conn != null)
                conn.close();
        }

    }

    /* Part of createProductsByCategory */
    private static final void setProductsByCategoryStyles(Workbook workbook, Worksheet sheet)
    {
        Cells cells = sheet.getCells();
        cells.getRows().get(4).setHeight(20.25f);
        cells.getRows().get(5).setHeight(18.75f);

        Style style;
        Font font;
        BorderCollection borders;

        style = workbook.createStyle();
        font = style.getFont();
        font.setItalic(true);
        font.setBold(true);
        font.setSize(16);
        style.setHorizontalAlignment(TextAlignmentType.RIGHT);
        style.setName("Category");

        style = workbook.createStyle();
        font = style.getFont();
        font.setSize(16);
        font.setBold(true);
        style.setHorizontalAlignment(TextAlignmentType.LEFT);
        style.setName("CategoryName");

        style = workbook.createStyle();
        font = style.getFont();
        font.setSize(14);
        font.setBold(true);
        font.setItalic(true);
        style.setHorizontalAlignment(TextAlignmentType.LEFT);
        borders = style.getBorders();
        borders.getByBorderType(BorderType.TOP_BORDER).setLineStyle(CellBorderType.MEDIUM);
        borders.getByBorderType(BorderType.BOTTOM_BORDER).setLineStyle(CellBorderType.MEDIUM);
        style.setName("ProductName");

        style = workbook.createStyle();
        font = style.getFont();
        font.setSize(14);
        font.setBold(true);
        font.setItalic(true);
        style.setHorizontalAlignment(TextAlignmentType.RIGHT);
        borders = style.getBorders();
        borders.getByBorderType(BorderType.TOP_BORDER).setLineStyle(CellBorderType.MEDIUM);
        borders.getByBorderType(BorderType.BOTTOM_BORDER).setLineStyle(CellBorderType.MEDIUM);
        style.setName("UnitsInStock");

        style = workbook.createStyle();
        font = style.getFont();
        font.setBold(true);
        font.setItalic(true);
        borders = style.getBorders();
        borders.getByBorderType(BorderType.TOP_BORDER).setLineStyle(CellBorderType.THIN);
        style.setName("ProductsCount");

        style = workbook.createStyle();
        style.setHorizontalAlignment(TextAlignmentType.LEFT);
        borders = style.getBorders();
        borders.getByBorderType(BorderType.TOP_BORDER).setLineStyle(CellBorderType.THIN);
        style.setName("CountNumber");
    }

    //////////////////////////// END OF Products by Category /////////////////////////////

    /////////////////////////// BEGIN OF Sales by Category Subreport /////////////////////
    public static void createSalesByCategorySubreport(String db_url, Workbook workbook)
            throws SQLException, Exception
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet sheet = worksheets.get("Sheet9");
        sheet.setName("Sales By Category Subreport");
        Cells cells = sheet.getCells();
        // remove unuseful sheets
        for(int i = worksheets.getCount() - 1; i >= 0; --i)
        {
            if(worksheets.get(i) != sheet)
                worksheets.removeAt(i);
        }

        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try
        {
            conn = DriverManager.getConnection(db_url);
            stmt = conn.createStatement();
            rs = stmt
                    .executeQuery("SELECT DISTINCTROW Products.ProductName, "
                            + "       Sum([Order Details Extended].ExtendedPrice) AS ProductSales "
                            + " FROM Categories INNER JOIN (Products INNER JOIN "
                            + "     (Orders INNER JOIN [Order Details Extended] ON "
                            + "     Orders.OrderID = [Order Details Extended].OrderID) "
                            + "     ON Products.ProductID = [Order Details Extended].ProductID)"
                            + "     ON Categories.CategoryID = Products.CategoryID "
                            + " WHERE (((Orders.OrderDate) Between #1/1/1995# And #12/31/1995#)) "
                            + " GROUP BY Categories.CategoryID, Categories.CategoryName, Products.ProductName "
                            + " ORDER BY Products.ProductName");

            cells.importResultSet(rs, 0, 0, false);
        }
        finally
        {
            if(rs != null)
                rs.close();
            if(stmt != null)
                stmt.close();
            if(conn != null)
                conn.close();
        }

    }

    /////////////////////////// END OF Sales by Category Subreport ///////////////////////

    /////////////////////////// BEGIN OF Sales by Year ///////////////////////////////////
    public static void createSalesByYear(String db_url, Workbook workbook) throws IOException,
            SQLException
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet sheet = worksheets.get("Sheet10");
        sheet.setName("Sales By Year");
        Cells cells = sheet.getCells();
        // remove unuseful sheets
        for(int i = worksheets.getCount() - 1; i >= 0; --i)
        {
            if(worksheets.get(i) != sheet)
                worksheets.removeAt(i);
        }

        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try
        {
            conn = DriverManager.getConnection(db_url);
            stmt = conn.createStatement();
            rs = stmt.executeQuery("SELECT DISTINCTROW ShippedDate, "
                    + "        Orders.OrderID, [Order Subtotals].Subtotal as Subtotal "
                    + " FROM Orders INNER JOIN [Order Subtotals] "
                    + "      ON Orders.OrderID = [Order Subtotals].OrderID "
                    + " WHERE( (Orders.ShippedDate) Is Not Null)");

            int rowIndex = 6;
            int row_num = 1;
            while (rs.next())
            {
                cells.get(rowIndex, 1).setValue(row_num++);
                String str = rs.getString(1);
                str = str.substring(0, str.indexOf('\40'));
                cells.get(rowIndex, 2).setValue(str);
                cells.get(rowIndex, 3).setValue(rs.getInt(2));
                cells.get(rowIndex, 4).setValue(rs.getDouble(3));
                ++rowIndex;
            }
        }
        finally
        {
            if(rs != null)
                rs.close();
            if(stmt != null)
                stmt.close();
            if(conn != null)
                conn.close();
        }

    }

    /////////////////////////// END OF Sales By Year //////////////////////////////////////

    /////////////////////////// BEGIN OF Sales by Year ///////////////////////////////////
    public static void createSalesByYearSubreport(String db_url, Workbook workbook)
            throws IOException, SQLException
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet sheet = worksheets.get("Sheet11");
        sheet.setName("Sales By Year Subreport");
        Cells cells = sheet.getCells();
        StyleCollection styles = workbook.getStyles();
        // remove unuseful sheets
        for(int i = worksheets.getCount() - 1; i >= 0; --i)
        {
            if(worksheets.get(i) != sheet)
                worksheets.removeAt(i);
        }

        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        Cell cell;

        try
        {
            conn = DriverManager.getConnection(db_url);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
            rs = stmt.executeQuery("SELECT DISTINCTROW COUNT(*) AS Orders, "
                    + "  SUM([Order Subtotals].Subtotal) AS Sales, "
                    + "  FORMAT(ORDERS.SHIPPEDDATE, 'yyyy/Q') AS Quarter "
                    + " FROM Orders INNER JOIN [Order Subtotals] "
                    + "    ON Orders.OrderID = [Order Subtotals].OrderID "
                    + " WHERE (orders.shippeddate IS NOT NULL) "
                    + " GROUP BY FORMAT(ORDERS.SHIPPEDDATE ,  'yyyy/Q')");

            int rowIndex = 0;
            int totalOrders = 0;
            double totalSales = 0;
            String thisYear = "";

            Style style;
            style = workbook.createStyle();
            Font font = style.getFont();
            font.setBold(true);
            style.setName("Bold");

            int loopCount = 0;
            while (rs.next())
            {
                String quarter = rs.getString("Quarter");
                int orders = rs.getInt("Orders");
                double sales = rs.getDouble("Sales");

                if(loopCount == 0)
                {
                    thisYear = quarter.substring(0, 4);
                    createSalesByYearSubreportHeader(styles, sheet, 0, thisYear);
                    createSalesByYearSubreportData(sheet, 2, 0, quarter, orders, sales);
                    totalOrders += orders;
                    totalSales += sales;
                    rowIndex = 3;

                }
                else
                {
                    if(thisYear.equals(quarter.substring(0, 4)))
                    {
                        createSalesByYearSubreportData(sheet, rowIndex, loopCount, quarter, orders,
                                sales);
                        totalOrders += orders;
                        totalSales += sales;
                        ++rowIndex;
                        if(rs.isLast())
                        {
                            createSalesByYearSubreportFooter(styles, sheet, rowIndex, totalOrders,
                                    totalSales);
                        }
                    }
                    else
                    {
                        createSalesByYearSubreportFooter(styles, sheet, rowIndex, totalOrders,
                                totalSales);
                        totalOrders = 0;
                        totalSales = 0;
                        ++rowIndex;
                        thisYear = quarter.substring(0, 4);
                        if(!rs.isLast())
                        {
                            createSalesByYearSubreportHeader(styles, sheet, rowIndex, thisYear);
                            rowIndex += 2;
                            createSalesByYearSubreportData(sheet, rowIndex, loopCount, quarter,
                                    orders, sales);
                            totalOrders += orders;
                            totalSales += sales;
                            ++rowIndex;
                        }
                    }
                }
                ++loopCount;
            }
        }
        catch (SQLException ignored)
        {
            // Something went wrong. Well, ignore the exception and save out what we've got.
        }
        finally
        {
            if(rs != null)
                rs.close();
            if(stmt != null)
                stmt.close();
            if(conn != null)
                conn.close();
        }

    }

    /* Part of createSalesByYearSubreport(). */
    private static final void createSalesByYearSubreportFooter(StyleCollection styles,
            Worksheet sheet, int rowIndex, int totalOrders, double totalSales)
    {
        Cells cells = sheet.getCells();
        Style style = styles.get("Bold");
        cells.get(rowIndex, 1).setValue("Totals:");
        cells.get(rowIndex, 1).setStyle(style);
        cells.get(rowIndex, 2).setValue(totalOrders);
        cells.get(rowIndex, 3).setValue(totalSales);
    }

    /* Part of createSalesByYearSubreport(). */
    private static final void createSalesByYearSubreportData(Worksheet sheet, int rowIndex,
            int index, String quarter, int orders, double sales) throws SQLException
    {
        Cells cells = sheet.getCells();
        cells.get(rowIndex, 1).setValue(Integer.parseInt(quarter.substring(5)));
        cells.get(rowIndex, 2).setValue(orders);
        cells.get(rowIndex, 3).setValue(sales);
    }

    /* Part of createSalesByYearSubreport(). */
    private static final void createSalesByYearSubreportHeader(StyleCollection styles,
            Worksheet sheet, int rowIndex, String year)
    {
        Cells cells = sheet.getCells();
        Style style = styles.get("Bold");
        Cell cell;

        cell = cells.get(rowIndex, 0);
        cell.setValue(year + " Summary");
        cell.setStyle(style);

        cell = cells.get(rowIndex + 1, 1);
        cell.setValue("Quarter:");
        cell.setStyle(style);

        cell = cells.get(rowIndex + 1, 2);
        cell.setValue("Orders Shipped:");
        cell.setStyle(style);

        cell = cells.get(rowIndex + 1, 3);
        cell.setValue("Sales:");
        cell.setStyle(style);
    }

    /////////////////////////// END OF Sales By Year //////////////////////////////////////

    /////////////////////////// BEGIN OF Create Sales Totals //////////////////////////////
    public static void createSalesTotals(String db_url, Workbook workbook) throws SQLException,
            Exception
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet sheet = worksheets.get("Sheet12");
        sheet.setName("Sales Totals");
        Cells cells = sheet.getCells();
        // remove unuseful sheets
        for(int i = worksheets.getCount() - 1; i >= 0; --i)
        {
            if(worksheets.get(i) != sheet)
                worksheets.removeAt(i);
        }

        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try
        {
            conn = DriverManager.getConnection(db_url);
            stmt = conn.createStatement();
            rs = stmt.executeQuery("SELECT [Order Subtotals].Subtotal, [Order Subtotals].OrderID, "
                    + "    Customers.CompanyName, Customers.CustomerID "
                    + " FROM Customers INNER JOIN ([Order Subtotals] INNER JOIN Orders "
                    + "    ON [Order Subtotals].OrderID = Orders.OrderID) "
                    + "    ON Customers.CustomerID = Orders.CustomerID "
                    + " WHERE (Orders.ShippedDate BETWEEN #1/1/1995# AND #12/31/1995#) "
                    + "  AND ([Order Subtotals].Subtotal > 2500) "
                    + " ORDER BY [Order Subtotals].Subtotal DESC");

            int row_num = cells.importResultSet(rs, 3, 1, -1, 3, false);

            double total = 0;
            for(int i = 3; i < 3 + row_num; ++i)
            {
                total += ((Double)cells.get(i, 1).getValue()).doubleValue();
                cells.get(i, 5).setValue(i - 2);
            }
            cells.get(3 + row_num, 1).setValue(total);
            cells.get(3 + row_num, 0).setValue("Total:");

            Style style = workbook.createStyle();
            Font font = style.getFont();
            font.setBold(true);
            cells.get(3 + row_num, 0).setStyle(style);
        }
        finally
        {
            if(rs != null)
                rs.close();
            if(stmt != null)
                stmt.close();
            if(conn != null)
                conn.close();
        }

    }

    /////////////////////////// END OF Create Sales Totals ////////////////////////////////

    /////////////////////////// BEGIN OF Summary By Quarter ///////////////////////////////
    public static void createSummaryByQuarter(String db_url, Workbook workbook)
            throws IOException, SQLException
    {
        WorksheetCollection worksheets = workbook.getWorksheets();
        Worksheet sheet = worksheets.get("Sheet13");
        sheet.setName("Summary By Quarter");
        Cells cells = sheet.getCells();
        // remove unuseful sheets
        for(int i = worksheets.getCount() - 1; i >= 0; --i)
        {
            if(worksheets.get(i) != sheet)
                worksheets.removeAt(i);
        }

        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try
        {
            conn = DriverManager.getConnection(db_url);
            stmt = conn.createStatement();
            rs = stmt
                    .executeQuery("SELECT COUNT(Orders.OrderID) AS Orders, SUM([Order Subtotals].Subtotal) AS Sales, "
                            + "       FORMAT(Orders.ShippedDate, 'yyyy/Q') AS Quarter "
                            + " FROM Orders INNER JOIN [Order Subtotals] "
                            + "     ON Orders.OrderID = [Order Subtotals].OrderID "
                            + " WHERE (Orders.ShippedDate IS NOT NULL) "
                            + " GROUP BY FORMAT(Orders.ShippedDate, 'yyyy/Q')");

            int row_q1 = 5, row_q2 = 11, row_q3 = 17, row_q4 = 23;
            while (rs.next())
            {
                int orders = rs.getInt(1);
                double sales = rs.getDouble(2);
                String quarter = rs.getString(3);

                int year = Integer.parseInt(quarter.substring(0, 4));
                switch (Integer.parseInt(quarter.substring(5)))
                {
                    case 1:
                        writeSummaryByQuarter(sheet, year, orders, sales, row_q1);
                        ++row_q1;
                        break;
                    case 2:
                        writeSummaryByQuarter(sheet, year, orders, sales, row_q2);
                        ++row_q2;
                        break;
                    case 3:
                        writeSummaryByQuarter(sheet, year, orders, sales, row_q3);
                        ++row_q3;
                        break;
                    case 4:
                        writeSummaryByQuarter(sheet, year, orders, sales, row_q4);
                        ++row_q4;
                        break;
                    default:
                        //assert false;
                }
            }
        }
        finally
        {
            if(rs != null)
                rs.close();
            if(stmt != null)
                stmt.close();
            if(conn != null)
                conn.close();
        }

    }

    /* Part of CreateSummaryByQuarter(). */
    private static final void writeSummaryByQuarter(Worksheet sheet, int year, int orders,
            double sales, int rowIndex)
    {
        Cells cells = sheet.getCells();
        cells.get(rowIndex, 0).setValue(year);
        cells.get(rowIndex, 1).setValue(orders);
        cells.get(rowIndex, 2).setValue(sales);
    }
    /////////////////////////// END OF Summary By Quarter /////////////////////////////////
}
