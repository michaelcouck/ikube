import com.aspose.cells.Workbook;

public class ConsoleDemo
{
   private static final String DB_URL = 
      "jdbc:odbc:driver={Microsoft Access Driver (*.mdb)};DBQ=./Database/Northwind.mdb";
   private static final String TEMPLATE_FILE_PATH = "./Designer/Northwind.xls";
   private static final String OUTPUT_FILE_PATH = "./Output/";
   
   public static void main(String[] args) throws Exception
   {
      Class.forName("sun.jdbc.odbc.JdbcOdbcDriver"); 
      String outputPath = OUTPUT_FILE_PATH;
      String command = null;
      if(args != null && args.length > 0)
      {
          command = args[0];
      }
      // Any of the following lines can run separately.
      if(createNorthwind(command))
      {
          return;
      }
      createNorthwind("ProductsList");
      createNorthwind("Catalog");
      createNorthwind("CatalogSubreport");
      createNorthwind("CustomerLabels");
      createNorthwind("EmployeeSales");
      createNorthwind("Invoice");
      createNorthwind("ProductsByCategory");
      createNorthwind("SalesByCategorySubreport");
      createNorthwind("SalesByYear");
      createNorthwind("SalesByYearSubreport");
      createNorthwind("SalesTotals");
      createNorthwind("SummaryByQuarter");
   }
   
   private static boolean createNorthwind(String command) throws Exception
   {
       Workbook wb = new Workbook(TEMPLATE_FILE_PATH);
       if("ProductsList".equals(command))
       {
           DemoNorthwind.createProductsList(DB_URL, wb);
       }
       else if("Catalog".equals(command))
       {
           DemoNorthwind.createCatalog(DB_URL, wb);
       }
       else if("CatalogSubreport".equals(command))
       {
           DemoNorthwind.createCatalogSubreport(DB_URL, wb);
       }
       else if("CustomerLabels".equals(command))
       {
           DemoNorthwind.createCustomerLabels(DB_URL, wb);
       }
       else if("EmployeeSales".equals(command))
       {
           DemoNorthwind.createEmployeeSales(DB_URL, wb);
       }
       else if("Invoice".equals(command))
       {
           DemoNorthwind.createInvoice(DB_URL, wb);
       }
       else if("ProductsByCategory".equals(command))
       {
           DemoNorthwind.createProductsByCategory(DB_URL, wb);
       }
       else if("SalesByCategorySubreport".equals(command))
       {
           DemoNorthwind.createSalesByCategorySubreport(DB_URL, wb);
       }
       else if("SalesByYear".equals(command))
       {
           DemoNorthwind.createSalesByYear(DB_URL, wb);
       }
       else if("SalesByYearSubreport".equals(command))
       {
           DemoNorthwind.createSalesByYearSubreport(DB_URL, wb);
       }
       else if("SalesTotals".equals(command))
       {
           DemoNorthwind.createSalesTotals(DB_URL, wb);
       }
       else if("SummaryByQuarter".equals(command))
       {
           DemoNorthwind.createSummaryByQuarter(DB_URL, wb);
       }
       else
       {
           return false;
       }
       wb.save(OUTPUT_FILE_PATH + command + ".xls");
       return true;
   }
   
}

