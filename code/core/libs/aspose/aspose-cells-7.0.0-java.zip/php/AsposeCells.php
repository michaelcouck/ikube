<?php
define ("AutoShapeType_ARC",19);
define ("AutoShapeType_BACK_PREVIOUS_ACTION_BUTTON",194);
define ("AutoShapeType_BALLOON",17);
define ("AutoShapeType_BEGINNING_ACTION_BUTTON",196);
define ("AutoShapeType_BENT_ARROW",91);
define ("AutoShapeType_BENT_CONNECTOR_2",33);
define ("AutoShapeType_BENT_CONNECTOR_4",35);
define ("AutoShapeType_BENT_CONNECTOR_5",36);
define ("AutoShapeType_BENT_UP_ARROW",90);
define ("AutoShapeType_BEVEL",84);
define ("AutoShapeType_BLANK_ACTION_BUTTON",189);
define ("AutoShapeType_BLOCK_ARC",95);
define ("AutoShapeType_CAN",22);
define ("AutoShapeType_CHEVRON",55);
define ("AutoShapeType_CHORD",2069);
define ("AutoShapeType_CIRCULAR_ARROW",99);
define ("AutoShapeType_CLOUD",2070);
define ("AutoShapeType_CLOUD_CALLOUT",106);
define ("AutoShapeType_CROSS",11);
define ("AutoShapeType_CUBE",16);
define ("AutoShapeType_CURVED_CONNECTOR",38);
define ("AutoShapeType_CURVED_CONNECTOR_2",37);
define ("AutoShapeType_CURVED_CONNECTOR_4",39);
define ("AutoShapeType_CURVED_CONNECTOR_5",40);
define ("AutoShapeType_CURVED_DOWN_ARROW",105);
define ("AutoShapeType_CURVED_DOWN_RIBBON",107);
define ("AutoShapeType_CURVED_LEFT_ARROW",103);
define ("AutoShapeType_CURVED_RIGHT_ARROW",102);
define ("AutoShapeType_CURVED_UP_ARROW",104);
define ("AutoShapeType_CURVED_UP_RIBBON",108);
define ("AutoShapeType_DECAGON",2050);
define ("AutoShapeType_DIAGONAL_STRIPE",2068);
define ("AutoShapeType_DIAMOND",4);
define ("AutoShapeType_DOCUMENT_ACTION_BUTTON",198);
define ("AutoShapeType_DODECAGON",2051);
define ("AutoShapeType_DONUT",23);
define ("AutoShapeType_DOUBLE_BRACE",186);
define ("AutoShapeType_DOUBLE_BRACKET",185);
define ("AutoShapeType_DOUBLE_WAVE",188);
define ("AutoShapeType_DOWN_ARROW",67);
define ("AutoShapeType_DOWN_ARROW_CALLOUT",80);
define ("AutoShapeType_DOWN_RIBBON",53);
define ("AutoShapeType_ELBOW_CONNECTOR",34);
define ("AutoShapeType_END_ACTION_BUTTON",195);
define ("AutoShapeType_EXPLOSION_1",71);
define ("AutoShapeType_EXPLOSION_2",72);
define ("AutoShapeType_FLOW_CHART_ALTERNATE_PROCESS",176);
define ("AutoShapeType_FLOW_CHART_CARD",121);
define ("AutoShapeType_FLOW_CHART_COLLATE",125);
define ("AutoShapeType_FLOW_CHART_CONNECTOR",120);
define ("AutoShapeType_FLOW_CHART_DATA",111);
define ("AutoShapeType_FLOW_CHART_DECISION",110);
define ("AutoShapeType_FLOW_CHART_DELAY",135);
define ("AutoShapeType_FLOW_CHART_DIRECT_ACCESS_STORAGE",133);
define ("AutoShapeType_FLOW_CHART_DISPLAY",134);
define ("AutoShapeType_FLOW_CHART_DOCUMENT",114);
define ("AutoShapeType_FLOW_CHART_EXTRACT",127);
define ("AutoShapeType_FLOW_CHART_INTERNAL_STORAGE",113);
define ("AutoShapeType_FLOW_CHART_MAGNETIC_DISK",132);
define ("AutoShapeType_FLOW_CHART_MANUAL_INPUT",118);
define ("AutoShapeType_FLOW_CHART_MANUAL_OPERATION",119);
define ("AutoShapeType_FLOW_CHART_MERGE",128);
define ("AutoShapeType_FLOW_CHART_MULTIDOCUMENT",115);
define ("AutoShapeType_FLOW_CHART_OFFLINE_STORAGE",129);
define ("AutoShapeType_FLOW_CHART_OFFPAGE_CONNECTOR",177);
define ("AutoShapeType_FLOW_CHART_OR",124);
define ("AutoShapeType_FLOW_CHART_PREDEFINED_PROCESS",112);
define ("AutoShapeType_FLOW_CHART_PREPARATION",117);
define ("AutoShapeType_FLOW_CHART_PROCESS",109);
define ("AutoShapeType_FLOW_CHART_PUNCHED_TAPE",122);
define ("AutoShapeType_FLOW_CHART_SEQUENTIAL_ACCESS_STORAGE",131);
define ("AutoShapeType_FLOW_CHART_SORT",126);
define ("AutoShapeType_FLOW_CHART_STORED_DATA",130);
define ("AutoShapeType_FLOW_CHART_SUMMING_JUNCTION",123);
define ("AutoShapeType_FLOW_CHART_TERMINATOR",116);
define ("AutoShapeType_FOLDED_CORNER",65);
define ("AutoShapeType_FORWARD_NEXT_ACTION_BUTTON",193);
define ("AutoShapeType_FRAME",2065);
define ("AutoShapeType_HALF_FRAME",2066);
define ("AutoShapeType_HEART",74);
define ("AutoShapeType_HELP_ACTION_BUTTON",191);
define ("AutoShapeType_HEPTAGON",2049);
define ("AutoShapeType_HEXAGON",9);
define ("AutoShapeType_HOME_ACTION_BUTTON",190);
define ("AutoShapeType_HOME_PLATE",15);
define ("AutoShapeType_HORIZONTAL_SCROLL",98);
define ("AutoShapeType_HOST_CONTROL",201);
define ("AutoShapeType_INFORMATION_ACTION_BUTTON",192);
define ("AutoShapeType_ISOSCELES_TRIANGLE",5);
define ("AutoShapeType_L_SHAPE",2067);
define ("AutoShapeType_LEFT_ARROW",66);
define ("AutoShapeType_LEFT_ARROW_CALLOUT",77);
define ("AutoShapeType_LEFT_BRACE",87);
define ("AutoShapeType_LEFT_BRACKET",85);
define ("AutoShapeType_LEFT_RIGHT_ARROW",69);
define ("AutoShapeType_LEFT_RIGHT_ARROW_CALLOUT",81);
define ("AutoShapeType_LEFT_RIGHT_UP_ARROW",182);
define ("AutoShapeType_LEFT_UP_ARROW",89);
define ("AutoShapeType_LIGHTNING_BOLT",73);
define ("AutoShapeType_LINE",20);
define ("AutoShapeType_LINE_CALLOUT_NO_BORDER_1",178);
define ("AutoShapeType_LINE_CALLOUT_NO_BORDER_2",41);
define ("AutoShapeType_LINE_CALLOUT_NO_BORDER_3",42);
define ("AutoShapeType_LINE_CALLOUT_NO_BORDER_4",43);
define ("AutoShapeType_LINE_CALLOUT_WITH_ACCENT_BAR_1",179);
define ("AutoShapeType_LINE_CALLOUT_WITH_ACCENT_BAR_2",44);
define ("AutoShapeType_LINE_CALLOUT_WITH_ACCENT_BAR_3",45);
define ("AutoShapeType_LINE_CALLOUT_WITH_ACCENT_BAR_4",46);
define ("AutoShapeType_LINE_CALLOUT_WITH_BORDER_1",180);
define ("AutoShapeType_LINE_CALLOUT_WITH_BORDER_2",47);
define ("AutoShapeType_LINE_CALLOUT_WITH_BORDER_3",48);
define ("AutoShapeType_LINE_CALLOUT_WITH_BORDER_4",49);
define ("AutoShapeType_LINE_CALLOUT_WITH_BORDER_AND_ACCENT_BAR_1",181);
define ("AutoShapeType_LINE_CALLOUT_WITH_BORDER_AND_ACCENT_BAR_2",50);
define ("AutoShapeType_LINE_CALLOUT_WITH_BORDER_AND_ACCENT_BAR_3",51);
define ("AutoShapeType_LINE_CALLOUT_WITH_BORDER_AND_ACCENT_BAR_4",52);
define ("AutoShapeType_MATH_DIVIDE",2074);
define ("AutoShapeType_MATH_EQUAL",2075);
define ("AutoShapeType_MATH_MINUS",2072);
define ("AutoShapeType_MATH_MULTIPLY",2073);
define ("AutoShapeType_MATH_NOT_EQUAL",2076);
define ("AutoShapeType_MATH_PLUS",2071);
define ("AutoShapeType_MOON",184);
define ("AutoShapeType_MOVIE_ACTION_BUTTON",200);
define ("AutoShapeType_MSOSPT_TEXT_ON_RING",31);
define ("AutoShapeType_NO_SYMBOL",57);
define ("AutoShapeType_NOTCHED_RIGHT_ARROW",94);
define ("AutoShapeType_OCTAGON",10);
define ("AutoShapeType_OVAL",3);
define ("AutoShapeType_OVAL_CALLOUT",63);
define ("AutoShapeType_PARALLELOGRAM",7);
define ("AutoShapeType_PICTURE_FRAME",75);
define ("AutoShapeType_PIE",2064);
define ("AutoShapeType_PLAQUE",21);
define ("AutoShapeType_QUAD_ARROW",76);
define ("AutoShapeType_QUAD_ARROW_CALLOUT",83);
define ("AutoShapeType_RECTANGLE",1);
define ("AutoShapeType_RECTANGULAR_CALLOUT",61);
define ("AutoShapeType_REGULAR_PENTAGON",56);
define ("AutoShapeType_RETURN_ACTION_BUTTON",197);
define ("AutoShapeType_RIGHT_ARROW",13);
define ("AutoShapeType_RIGHT_ARROW_CALLOUT",78);
define ("AutoShapeType_RIGHT_BRACE",88);
define ("AutoShapeType_RIGHT_BRACKET",86);
define ("AutoShapeType_RIGHT_TRIANGLE",6);
define ("AutoShapeType_ROUND_DIAGONAL_CORNER_RECTANGLE",2058);
define ("AutoShapeType_ROUND_SAME_SIDE_CORNER_RECTANGLE",2057);
define ("AutoShapeType_ROUND_SINGLE_CORNER_RECTANGLE",2056);
define ("AutoShapeType_ROUNDED_RECTANGLE",2);
define ("AutoShapeType_ROUNDED_RECTANGULAR_CALLOUT",62);
define ("AutoShapeType_SEAL",18);
define ("AutoShapeType_SMILEY_FACE",96);
define ("AutoShapeType_SNIP_DIAGONAL_CORNER_RECTANGLE",2062);
define ("AutoShapeType_SNIP_ROUND_SINGLE_CORNER_RECTANGLE",2059);
define ("AutoShapeType_SNIP_SAME_SIDE_CORNER_RECTANGLE",2061);
define ("AutoShapeType_SNIP_SINGLE_CORNER_RECTANGLE",2060);
define ("AutoShapeType_SOUND_ACTION_BUTTON",199);
define ("AutoShapeType_STAR_10",2054);
define ("AutoShapeType_STAR_12",2055);
define ("AutoShapeType_STAR_16",59);
define ("AutoShapeType_STAR_24",92);
define ("AutoShapeType_STAR_32",60);
define ("AutoShapeType_STAR_4",187);
define ("AutoShapeType_STAR_5",12);
define ("AutoShapeType_STAR_6",2052);
define ("AutoShapeType_STAR_7",2053);
define ("AutoShapeType_STAR_8",58);
define ("AutoShapeType_STRAIGHT_CONNECTOR",32);
define ("AutoShapeType_STRIPED_RIGHT_ARROW",93);
define ("AutoShapeType_SUN",183);
define ("AutoShapeType_TEARDROP",2063);
define ("AutoShapeType_TEXT_ARCH_DOWN_CURVE",145);
define ("AutoShapeType_TEXT_ARCH_DOWN_POUR",149);
define ("AutoShapeType_TEXT_ARCH_UP_CURVE",144);
define ("AutoShapeType_TEXT_ARCH_UP_POUR",148);
define ("AutoShapeType_TEXT_BOX",202);
define ("AutoShapeType_TEXT_BUTTON_CURVE",147);
define ("AutoShapeType_TEXT_BUTTON_POUR",151);
define ("AutoShapeType_TEXT_CAN_DOWN",175);
define ("AutoShapeType_TEXT_CAN_UP",174);
define ("AutoShapeType_TEXT_CASCADE_DOWN",155);
define ("AutoShapeType_TEXT_CASCADE_UP",154);
define ("AutoShapeType_TEXT_CHEVRON",140);
define ("AutoShapeType_TEXT_CHEVRON_INVERTED",141);
define ("AutoShapeType_TEXT_CIRCLE_CURVE",146);
define ("AutoShapeType_TEXT_CIRCLE_POUR",150);
define ("AutoShapeType_TEXT_CURVE",27);
define ("AutoShapeType_TEXT_CURVE_DOWN",153);
define ("AutoShapeType_TEXT_CURVE_UP",152);
define ("AutoShapeType_TEXT_DEFLATE",161);
define ("AutoShapeType_TEXT_DEFLATE_BOTTOM",163);
define ("AutoShapeType_TEXT_DEFLATE_INFLATE",166);
define ("AutoShapeType_TEXT_DEFLATE_INFLATE_DEFLATE",167);
define ("AutoShapeType_TEXT_DEFLATE_TOP",165);
define ("AutoShapeType_TEXT_FADE_DOWN",171);
define ("AutoShapeType_TEXT_FADE_LEFT",169);
define ("AutoShapeType_TEXT_FADE_RIGHT",168);
define ("AutoShapeType_TEXT_FADE_UP",170);
define ("AutoShapeType_TEXT_HEXAGON",26);
define ("AutoShapeType_TEXT_INFLATE",160);
define ("AutoShapeType_TEXT_INFLATE_BOTTOM",162);
define ("AutoShapeType_TEXT_INFLATE_TOP",164);
define ("AutoShapeType_TEXT_OCTAGON",25);
define ("AutoShapeType_TEXT_ON_CURVE",30);
define ("AutoShapeType_TEXT_PLAIN_TEXT",136);
define ("AutoShapeType_TEXT_RING",29);
define ("AutoShapeType_TEXT_RING_INSIDE",142);
define ("AutoShapeType_TEXT_RING_OUTSIDE",143);
define ("AutoShapeType_TEXT_SIMPLE",24);
define ("AutoShapeType_TEXT_SLANT_DOWN",173);
define ("AutoShapeType_TEXT_SLANT_UP",172);
define ("AutoShapeType_TEXT_STOP",137);
define ("AutoShapeType_TEXT_TRIANGLE",138);
define ("AutoShapeType_TEXT_TRIANGLE_INVERTED",139);
define ("AutoShapeType_TEXT_WAVE",28);
define ("AutoShapeType_TEXT_WAVE_1",156);
define ("AutoShapeType_TEXT_WAVE_2",157);
define ("AutoShapeType_TEXT_WAVE_3",158);
define ("AutoShapeType_TEXT_WAVE_4",159);
define ("AutoShapeType_TRAPEZOID",8);
define ("AutoShapeType_U_TURN_ARROW",101);
define ("AutoShapeType_UNKNOWN",4095);
define ("AutoShapeType_UP_ARROW",68);
define ("AutoShapeType_UP_ARROW_CALLOUT",79);
define ("AutoShapeType_UP_DOWN_ARROW",70);
define ("AutoShapeType_UP_DOWN_ARROW_CALLOUT",82);
define ("AutoShapeType_UP_RIBBON",54);
define ("AutoShapeType_VERTICAL_SCROLL",97);
define ("AutoShapeType_WAVE",64);
define ("BackgroundMode_AUTOMATIC",0);
define ("BackgroundMode_OPAQUE",1);
define ("BackgroundMode_TRANSPARENT",2);
define ("BackgroundType_DIAGONAL_CROSSHATCH",9);
define ("BackgroundType_DIAGONAL_STRIPE",8);
define ("BackgroundType_GRAY_12",17);
define ("BackgroundType_GRAY_25",4);
define ("BackgroundType_GRAY_50",2);
define ("BackgroundType_GRAY_6",18);
define ("BackgroundType_GRAY_75",3);
define ("BackgroundType_HORIZONTAL_STRIPE",5);
define ("BackgroundType_NONE",0);
define ("BackgroundType_REVERSE_DIAGONAL_STRIPE",7);
define ("BackgroundType_SOLID",1);
define ("BackgroundType_THICK_DIAGONAL_CROSSHATCH",10);
define ("BackgroundType_THIN_DIAGONAL_CROSSHATCH",16);
define ("BackgroundType_THIN_DIAGONAL_STRIPE",14);
define ("BackgroundType_THIN_HORIZONTAL_CROSSHATCH",15);
define ("BackgroundType_THIN_HORIZONTAL_STRIPE",11);
define ("BackgroundType_THIN_REVERSE_DIAGONAL_STRIPE",13);
define ("BackgroundType_THIN_VERTICAL_STRIPE",12);
define ("BackgroundType_VERTICAL_STRIPE",6);
define ("Bar3DShapeType_BOX",0);
define ("Bar3DShapeType_CONE_TO_MAX",5);
define ("Bar3DShapeType_CONE_TO_POINT",4);
define ("Bar3DShapeType_CYLINDER",3);
define ("Bar3DShapeType_PYRAMID_TO_MAX",2);
define ("Bar3DShapeType_PYRAMID_TO_POINT",1);
define ("BevelPresetType_ANGLE",1);
define ("BevelPresetType_ART_DECO",2);
define ("BevelPresetType_CIRCLE",3);
define ("BevelPresetType_CONVEX",4);
define ("BevelPresetType_COOL_SLANT",5);
define ("BevelPresetType_CROSS",6);
define ("BevelPresetType_DIVOT",7);
define ("BevelPresetType_HARD_EDGE",8);
define ("BevelPresetType_NONE",0);
define ("BevelPresetType_RELAXED_INSET",9);
define ("BevelPresetType_RIBLET",10);
define ("BevelPresetType_SLOPE",11);
define ("BevelPresetType_SOFT_ROUND",12);
define ("BorderType_BOTTOM_BORDER",8);
define ("BorderType_DIAGONAL_DOWN",16);
define ("BorderType_DIAGONAL_UP",32);
define ("BorderType_HORIZONTAL",63);
define ("BorderType_LEFT_BORDER",1);
define ("BorderType_RIGHT_BORDER",2);
define ("BorderType_TOP_BORDER",4);
define ("BorderType_VERTICAL",64);
define ("BubbleSizeRepresents_SIZE_IS_AREA",0);
define ("BubbleSizeRepresents_SIZE_IS_WIDTH",1);
define ("BuiltinStyleType_ACCENT_1",29);
define ("BuiltinStyleType_ACCENT_2",33);
define ("BuiltinStyleType_ACCENT_3",37);
define ("BuiltinStyleType_ACCENT_4",41);
define ("BuiltinStyleType_ACCENT_5",45);
define ("BuiltinStyleType_ACCENT_6",49);
define ("BuiltinStyleType_BAD",27);
define ("BuiltinStyleType_CALCULATION",22);
define ("BuiltinStyleType_CHECK_CELL",23);
define ("BuiltinStyleType_COLUMN_LEVEL",2);
define ("BuiltinStyleType_COMMA",3);
define ("BuiltinStyleType_COMMA_1",6);
define ("BuiltinStyleType_CURRENCY",4);
define ("BuiltinStyleType_CURRENCY_1",7);
define ("BuiltinStyleType_EXPLANATORY_TEXT",53);
define ("BuiltinStyleType_FOLLOWED_HYPERLINK",9);
define ("BuiltinStyleType_FORTY_PERCENT_ACCENT_1",31);
define ("BuiltinStyleType_FORTY_PERCENT_ACCENT_2",35);
define ("BuiltinStyleType_FORTY_PERCENT_ACCENT_3",39);
define ("BuiltinStyleType_FORTY_PERCENT_ACCENT_4",43);
define ("BuiltinStyleType_FORTY_PERCENT_ACCENT_5",47);
define ("BuiltinStyleType_FORTY_PERCENT_ACCENT_6",51);
define ("BuiltinStyleType_GOOD",26);
define ("BuiltinStyleType_HEADER_1",16);
define ("BuiltinStyleType_HEADER_2",17);
define ("BuiltinStyleType_HEADER_3",18);
define ("BuiltinStyleType_HEADER_4",19);
define ("BuiltinStyleType_HYPERLINK",8);
define ("BuiltinStyleType_INPUT",20);
define ("BuiltinStyleType_LINKED_CELL",24);
define ("BuiltinStyleType_NEUTRAL",28);
define ("BuiltinStyleType_NORMAL",0);
define ("BuiltinStyleType_NOTE",10);
define ("BuiltinStyleType_OUTPUT",21);
define ("BuiltinStyleType_PERCENT",5);
define ("BuiltinStyleType_ROW_LEVEL",1);
define ("BuiltinStyleType_SIXTY_PERCENT_ACCENT_1",32);
define ("BuiltinStyleType_SIXTY_PERCENT_ACCENT_2",36);
define ("BuiltinStyleType_SIXTY_PERCENT_ACCENT_3",40);
define ("BuiltinStyleType_SIXTY_PERCENT_ACCENT_4",44);
define ("BuiltinStyleType_SIXTY_PERCENT_ACCENT_5",48);
define ("BuiltinStyleType_SIXTY_PERCENT_ACCENT_6",52);
define ("BuiltinStyleType_TITLE",15);
define ("BuiltinStyleType_TOTAL",25);
define ("BuiltinStyleType_TWENTY_PERCENT_ACCENT_1",30);
define ("BuiltinStyleType_TWENTY_PERCENT_ACCENT_2",34);
define ("BuiltinStyleType_TWENTY_PERCENT_ACCENT_3",38);
define ("BuiltinStyleType_TWENTY_PERCENT_ACCENT_4",42);
define ("BuiltinStyleType_TWENTY_PERCENT_ACCENT_5",46);
define ("BuiltinStyleType_TWENTY_PERCENT_ACCENT_6",50);
define ("BuiltinStyleType_WARNING_TEXT",11);
define ("CalcModeType_AUTOMATIC",0);
define ("CalcModeType_AUTOMATIC_EXCEPT_TABLE",1);
define ("CalcModeType_MANUAL",2);
define ("CategoryType_AUTOMATIC_SCALE",0);
define ("CategoryType_CATEGORY_SCALE",1);
define ("CategoryType_TIME_SCALE",2);
define ("CellBorderType_DASH_DOT",9);
define ("CellBorderType_DASH_DOT_DOT",11);
define ("CellBorderType_DASHED",3);
define ("CellBorderType_DOTTED",4);
define ("CellBorderType_DOUBLE",6);
define ("CellBorderType_HAIR",7);
define ("CellBorderType_MEDIUM",2);
define ("CellBorderType_MEDIUM_DASH_DOT",10);
define ("CellBorderType_MEDIUM_DASH_DOT_DOT",12);
define ("CellBorderType_MEDIUM_DASHED",8);
define ("CellBorderType_NONE",0);
define ("CellBorderType_SLANTED_DASH_DOT",13);
define ("CellBorderType_THICK",5);
define ("CellBorderType_THIN",1);
define ("CellValueType_IS_BOOL",0);
define ("CellValueType_IS_DATE_TIME",1);
define ("CellValueType_IS_ERROR",2);
define ("CellValueType_IS_NULL",3);
define ("CellValueType_IS_NUMERIC",4);
define ("CellValueType_IS_STRING",5);
define ("CellValueType_IS_UNKNOWN",6);
define ("ChartMarkerType_AUTOMATIC",0);
define ("ChartMarkerType_CIRCLE",1);
define ("ChartMarkerType_DASH",2);
define ("ChartMarkerType_DIAMOND",3);
define ("ChartMarkerType_DOT",4);
define ("ChartMarkerType_NONE",5);
define ("ChartMarkerType_SQUARE",7);
define ("ChartMarkerType_SQUARE_PLUS",6);
define ("ChartMarkerType_SQUARE_STAR",8);
define ("ChartMarkerType_SQUARE_X",10);
define ("ChartMarkerType_TRIANGLE",9);
define ("ChartSplitType_CUSTOM",3);
define ("ChartSplitType_PERCENT_VALUE",2);
define ("ChartSplitType_POSITION",0);
define ("ChartSplitType_VALUE",1);
define ("ChartType_AREA",0);
define ("ChartType_AREA_100_PERCENT_STACKED",2);
define ("ChartType_AREA_3_D",3);
define ("ChartType_AREA_3_D_100_PERCENT_STACKED",5);
define ("ChartType_AREA_3_D_STACKED",4);
define ("ChartType_AREA_STACKED",1);
define ("ChartType_BAR",6);
define ("ChartType_BAR_100_PERCENT_STACKED",8);
define ("ChartType_BAR_3_D_100_PERCENT_STACKED",11);
define ("ChartType_BAR_3_D_CLUSTERED",9);
define ("ChartType_BAR_3_D_STACKED",10);
define ("ChartType_BAR_STACKED",7);
define ("ChartType_BUBBLE",12);
define ("ChartType_BUBBLE_3_D",13);
define ("ChartType_COLUMN",14);
define ("ChartType_COLUMN_100_PERCENT_STACKED",16);
define ("ChartType_COLUMN_3_D",17);
define ("ChartType_COLUMN_3_D_100_PERCENT_STACKED",20);
define ("ChartType_COLUMN_3_D_CLUSTERED",18);
define ("ChartType_COLUMN_3_D_STACKED",19);
define ("ChartType_COLUMN_STACKED",15);
define ("ChartType_CONE",21);
define ("ChartType_CONE_100_PERCENT_STACKED",23);
define ("ChartType_CONE_STACKED",22);
define ("ChartType_CONICAL_BAR",24);
define ("ChartType_CONICAL_BAR_100_PERCENT_STACKED",26);
define ("ChartType_CONICAL_BAR_STACKED",25);
define ("ChartType_CONICAL_COLUMN_3_D",27);
define ("ChartType_CYLINDER",28);
define ("ChartType_CYLINDER_100_PERCENT_STACKED",30);
define ("ChartType_CYLINDER_STACKED",29);
define ("ChartType_CYLINDRICAL_BAR",31);
define ("ChartType_CYLINDRICAL_BAR_100_PERCENT_STACKED",33);
define ("ChartType_CYLINDRICAL_BAR_STACKED",32);
define ("ChartType_CYLINDRICAL_COLUMN_3_D",34);
define ("ChartType_DOUGHNUT",35);
define ("ChartType_DOUGHNUT_EXPLODED",36);
define ("ChartType_LINE",37);
define ("ChartType_LINE_100_PERCENT_STACKED",39);
define ("ChartType_LINE_100_PERCENT_STACKED_WITH_DATA_MARKERS",42);
define ("ChartType_LINE_3_D",43);
define ("ChartType_LINE_STACKED",38);
define ("ChartType_LINE_STACKED_WITH_DATA_MARKERS",41);
define ("ChartType_LINE_WITH_DATA_MARKERS",40);
define ("ChartType_PIE",44);
define ("ChartType_PIE_3_D",45);
define ("ChartType_PIE_3_D_EXPLODED",48);
define ("ChartType_PIE_BAR",49);
define ("ChartType_PIE_EXPLODED",47);
define ("ChartType_PIE_PIE",46);
define ("ChartType_PYRAMID",50);
define ("ChartType_PYRAMID_100_PERCENT_STACKED",52);
define ("ChartType_PYRAMID_BAR",53);
define ("ChartType_PYRAMID_BAR_100_PERCENT_STACKED",55);
define ("ChartType_PYRAMID_BAR_STACKED",54);
define ("ChartType_PYRAMID_COLUMN_3_D",56);
define ("ChartType_PYRAMID_STACKED",51);
define ("ChartType_RADAR",57);
define ("ChartType_RADAR_FILLED",59);
define ("ChartType_RADAR_WITH_DATA_MARKERS",58);
define ("ChartType_SCATTER",60);
define ("ChartType_SCATTER_CONNECTED_BY_CURVES_WITH_DATA_MARKER",61);
define ("ChartType_SCATTER_CONNECTED_BY_CURVES_WITHOUT_DATA_MARKER",62);
define ("ChartType_SCATTER_CONNECTED_BY_LINES_WITH_DATA_MARKER",63);
define ("ChartType_SCATTER_CONNECTED_BY_LINES_WITHOUT_DATA_MARKER",64);
define ("ChartType_STOCK_HIGH_LOW_CLOSE",65);
define ("ChartType_STOCK_OPEN_HIGH_LOW_CLOSE",66);
define ("ChartType_STOCK_VOLUME_HIGH_LOW_CLOSE",67);
define ("ChartType_STOCK_VOLUME_OPEN_HIGH_LOW_CLOSE",68);
define ("ChartType_SURFACE_3_D",69);
define ("ChartType_SURFACE_CONTOUR",71);
define ("ChartType_SURFACE_CONTOUR_WIREFRAME",72);
define ("ChartType_SURFACE_WIREFRAME_3_D",70);
define ("CheckValueType_CHECKED",1);
define ("CheckValueType_MIXED",2);
define ("CheckValueType_UN_CHECKED",0);
define ("ColorType_AUTOMATIC",0);
define ("ColorType_AUTOMATIC_INDEX",1);
define ("ColorType_INDEXED_COLOR",3);
define ("ColorType_RGB",2);
define ("ColorType_THEME",4);
define ("ConsolidationFunction_AVERAGE",2);
define ("ConsolidationFunction_COUNT",1);
define ("ConsolidationFunction_COUNT_NUMS",6);
define ("ConsolidationFunction_MAX",3);
define ("ConsolidationFunction_MIN",4);
define ("ConsolidationFunction_PRODUCT",5);
define ("ConsolidationFunction_STD_DEV",7);
define ("ConsolidationFunction_STD_DEVP",8);
define ("ConsolidationFunction_SUM",0);
define ("ConsolidationFunction_VAR",9);
define ("ConsolidationFunction_VARP",10);
define ("ContentDisposition_ATTACHMENT",1);
define ("ContentDisposition_INLINE",0);
define ("CountryCode_AUSTRALIA",61);
define ("CountryCode_CANADA",2);
define ("CountryCode_CHINA",86);
define ("CountryCode_DEFAULT",0);
define ("CountryCode_FRANCE",33);
define ("CountryCode_GERMANY",49);
define ("CountryCode_INDIA",91);
define ("CountryCode_ITALY",39);
define ("CountryCode_JAPAN",81);
define ("CountryCode_NETHERLANDS",31);
define ("CountryCode_RUSSIA",7);
define ("CountryCode_SOUTH_KOREA",82);
define ("CountryCode_SPAIN",34);
define ("CountryCode_THAILAND",66);
define ("CountryCode_UNITED_KINGDOM",44);
define ("CountryCode_USA",1);
define ("CrossType_AUTOMATIC",0);
define ("CrossType_CUSTOM",2);
define ("CrossType_MAXIMUM",1);
define ("DataLablesSeparatorType_AUTO",0);
define ("DataLablesSeparatorType_COMMA",2);
define ("DataLablesSeparatorType_NEW_LINE",5);
define ("DataLablesSeparatorType_PERIOD",4);
define ("DataLablesSeparatorType_SEMICOLON",3);
define ("DataLablesSeparatorType_SPACE",1);
define ("DateTimeGroupingType_DAY",0);
define ("DateTimeGroupingType_HOUR",1);
define ("DateTimeGroupingType_MINUTE",2);
define ("DateTimeGroupingType_MONTH",3);
define ("DateTimeGroupingType_SECOND",4);
define ("DateTimeGroupingType_YEAR",5);
define ("DirectoryType_DOWN_DIRECTORY",2);
define ("DirectoryType_SAME_VOLUME",1);
define ("DirectoryType_UP_DIRECTORY",3);
define ("DirectoryType_VOLUME",0);
define ("DisplayDrawingObjects_DISPLAY_SHAPES",0);
define ("DisplayDrawingObjects_HIDE",2);
define ("DisplayDrawingObjects_PLACEHOLDERS",1);
define ("DisplayUnitType_BILLIONS",8);
define ("DisplayUnitType_HUNDREDS",1);
define ("DisplayUnitType_MILLIONS",5);
define ("DisplayUnitType_NONE",0);
define ("DisplayUnitType_THOUSANDS",2);
define ("DisplayUnitType_TRILLIONS",9);
define ("DynamicFilterType_ABOVE_AVERAGE",0);
define ("DynamicFilterType_APRIL",12);
define ("DynamicFilterType_AUGUST",16);
define ("DynamicFilterType_BELOW_AVERAGE",1);
define ("DynamicFilterType_DECEMBER",9);
define ("DynamicFilterType_FEBRURAY",10);
define ("DynamicFilterType_JANUARY",6);
define ("DynamicFilterType_JULY",15);
define ("DynamicFilterType_JUNE",14);
define ("DynamicFilterType_LAST_MONTH",2);
define ("DynamicFilterType_LAST_QUARTER",3);
define ("DynamicFilterType_LAST_WEEK",4);
define ("DynamicFilterType_LAST_YEAR",5);
define ("DynamicFilterType_MARCH",11);
define ("DynamicFilterType_MAY",13);
define ("DynamicFilterType_NEXT_MONTH",18);
define ("DynamicFilterType_NEXT_QUARTER",19);
define ("DynamicFilterType_NEXT_WEEK",20);
define ("DynamicFilterType_NEXT_YEAR",21);
define ("DynamicFilterType_NONE",22);
define ("DynamicFilterType_NOVEMBER",8);
define ("DynamicFilterType_OCTOBER",7);
define ("DynamicFilterType_QUARTER_1",23);
define ("DynamicFilterType_QUARTER_2",24);
define ("DynamicFilterType_QUARTER_3",25);
define ("DynamicFilterType_QUARTER_4",26);
define ("DynamicFilterType_SEPTEMBER",17);
define ("DynamicFilterType_THIS_MONTH",27);
define ("DynamicFilterType_THIS_QUARTER",28);
define ("DynamicFilterType_THIS_WEEK",29);
define ("DynamicFilterType_THIS_YEAR",30);
define ("DynamicFilterType_TODAY",31);
define ("DynamicFilterType_TOMORROW",32);
define ("DynamicFilterType_YEAR_TO_DATE",33);
define ("DynamicFilterType_YESTERDAY",34);
define ("EncryptionType_STRONG_CRYPTOGRAPHIC_PROVIDER",1);
define ("EncryptionType_XOR",0);
define ("ErrorBarDisplayType_BOTH",0);
define ("ErrorBarDisplayType_MINUS",1);
define ("ErrorBarDisplayType_NONE",2);
define ("ErrorBarDisplayType_PLUS",3);
define ("ErrorBarType_CUSTOM",0);
define ("ErrorBarType_FIXED_VALUE",1);
define ("ErrorBarType_PERCENT",2);
define ("ErrorBarType_ST_DEV",3);
define ("ErrorBarType_ST_ERROR",4);
define ("ErrorCheckType_CALC",1);
define ("ErrorCheckType_EMPTY_CELL_REF",2);
define ("ErrorCheckType_INCONSIST_FORMULA",16);
define ("ErrorCheckType_INCONSIST_RANGE",8);
define ("ErrorCheckType_TEXT_DATE",32);
define ("ErrorCheckType_TEXT_NUMBER",4);
define ("ErrorCheckType_UNPROCTED_FORMULA",64);
define ("ErrorCheckType_VALIDATION",128);
define ("ExceptionType_CHART",0);
define ("ExceptionType_CONDITIONAL_FORMATTING",3);
define ("ExceptionType_DATA_TYPE",1);
define ("ExceptionType_DATA_VALIDATION",2);
define ("ExceptionType_FILE_FORMAT",4);
define ("ExceptionType_FORMULA",5);
define ("ExceptionType_INCORRECT_PASSWORD",8);
define ("ExceptionType_INTERRUPTED",17);
define ("ExceptionType_INVALID_DATA",6);
define ("ExceptionType_INVALID_OPERATOR",7);
define ("ExceptionType_LICENSE",9);
define ("ExceptionType_LIMITATION",10);
define ("ExceptionType_PAGE_SETUP",11);
define ("ExceptionType_PIVOT_TABLE",12);
define ("ExceptionType_SHAPE",13);
define ("ExceptionType_SHEET_NAME",15);
define ("ExceptionType_SHEET_TYPE",16);
define ("ExceptionType_SPARKLINE",14);
define ("ExceptionType_UNDISCLOSED_INFORMATION",20);
define ("ExceptionType_UNSUPPORTED_FEATURE",18);
define ("ExceptionType_UNSUPPORTED_STREAM",19);
define ("FileFormatType_ASPOSE_PDF",0);
define ("FileFormatType_CSV",1);
define ("FileFormatType_DEFAULT",5);
define ("FileFormatType_EXCEL_2",25);
define ("FileFormatType_EXCEL_2000",3);
define ("FileFormatType_EXCEL_2003",5);
define ("FileFormatType_EXCEL_2003_XML",15);
define ("FileFormatType_EXCEL_2007_XLSB",16);
define ("FileFormatType_EXCEL_2007_XLSM",7);
define ("FileFormatType_EXCEL_2007_XLSX",6);
define ("FileFormatType_EXCEL_2007_XLTM",9);
define ("FileFormatType_EXCEL_2007_XLTX",8);
define ("FileFormatType_EXCEL_3",24);
define ("FileFormatType_EXCEL_4",23);
define ("FileFormatType_EXCEL_95",22);
define ("FileFormatType_EXCEL_97",2);
define ("FileFormatType_EXCEL_97_TO_2003",5);
define ("FileFormatType_EXCEL_XP",4);
define ("FileFormatType_HTML",12);
define ("FileFormatType_ODS",14);
define ("FileFormatType_PDF",13);
define ("FileFormatType_SPREADSHEET_ML",10);
define ("FileFormatType_TAB_DELIMITED",11);
define ("FileFormatType_TIFF",21);
define ("FileFormatType_UNKNOWN",255);
define ("FileFormatType_XLSB",16);
define ("FileFormatType_XLSM",7);
define ("FileFormatType_XLSX",6);
define ("FileFormatType_XLTM",9);
define ("FileFormatType_XLTX",8);
define ("FileFormatType_XPS",20);
define ("FillPattern_DARK_DOWNWARD_DIAGONAL",16);
define ("FillPattern_DARK_HORIZONTAL",25);
define ("FillPattern_DARK_UPWARD_DIAGONAL",17);
define ("FillPattern_DARK_VERTICAL",24);
define ("FillPattern_DASHED_DOWNWARD_DIAGONAL",26);
define ("FillPattern_DASHED_HORIZONTAL",29);
define ("FillPattern_DASHED_UPWARD_DIAGONAL",27);
define ("FillPattern_DASHED_VERTICAL",28);
define ("FillPattern_DIAGONAL_BRICK",34);
define ("FillPattern_DIVOT",38);
define ("FillPattern_DOTTED_DIAMOND",40);
define ("FillPattern_DOTTED_GRID",39);
define ("FillPattern_GRAY_10",3);
define ("FillPattern_GRAY_20",4);
define ("FillPattern_GRAY_25",13);
define ("FillPattern_GRAY_30",5);
define ("FillPattern_GRAY_40",6);
define ("FillPattern_GRAY_5",2);
define ("FillPattern_GRAY_50",7);
define ("FillPattern_GRAY_60",8);
define ("FillPattern_GRAY_70",9);
define ("FillPattern_GRAY_75",10);
define ("FillPattern_GRAY_80",11);
define ("FillPattern_GRAY_90",12);
define ("FillPattern_HORIZONTAL_BRICK",35);
define ("FillPattern_LARGE_CHECKER_BOARD",47);
define ("FillPattern_LARGE_CONFETTI",31);
define ("FillPattern_LARGE_GRID",45);
define ("FillPattern_LIGHT_DOWNWARD_DIAGONAL",14);
define ("FillPattern_LIGHT_HORIZONTAL",21);
define ("FillPattern_LIGHT_UPWARD_DIAGONAL",15);
define ("FillPattern_LIGHT_VERTICAL",20);
define ("FillPattern_NARROW_HORIZONTAL",23);
define ("FillPattern_NARROW_VERTICAL",22);
define ("FillPattern_NONE",0);
define ("FillPattern_OUTLINED_DIAMOND",48);
define ("FillPattern_PLAID",37);
define ("FillPattern_SHINGLE",41);
define ("FillPattern_SMALL_CHECKER_BOARD",46);
define ("FillPattern_SMALL_CONFETTI",30);
define ("FillPattern_SMALL_GRID",44);
define ("FillPattern_SOLID",1);
define ("FillPattern_SOLID_DIAMOND",49);
define ("FillPattern_SPHERE",43);
define ("FillPattern_TRELLIS",42);
define ("FillPattern_UNKNOWN",50);
define ("FillPattern_WAVE",33);
define ("FillPattern_WEAVE",36);
define ("FillPattern_WIDE_DOWNWARD_DIAGONAL",18);
define ("FillPattern_WIDE_UPWARD_DIAGONAL",19);
define ("FillPattern_ZIG_ZAG",32);
define ("FillPictureType_STACK",1);
define ("FillPictureType_STACK_AND_SCALE",2);
define ("FillPictureType_STRETCH",0);
define ("FilterOperatorType_EQUAL",2);
define ("FilterOperatorType_GREATER_OR_EQUAL",5);
define ("FilterOperatorType_GREATER_THAN",3);
define ("FilterOperatorType_LESS_OR_EQUAL",0);
define ("FilterOperatorType_LESS_THAN",1);
define ("FilterOperatorType_NONE",6);
define ("FilterOperatorType_NOT_EQUAL",4);
define ("FilterType_COLOR_FILTER",0);
define ("FilterType_CUSTOM_FILTERS",1);
define ("FilterType_DYNAMIC_FILTER",2);
define ("FilterType_ICON_FILTER",4);
define ("FilterType_MULTIPLE_FILTERS",3);
define ("FilterType_NONE",6);
define ("FilterType_TOP_10",5);
define ("FontUnderlineType_ACCOUNTING",0);
define ("FontUnderlineType_DOUBLE",1);
define ("FontUnderlineType_DOUBLE_ACCOUNTING",2);
define ("FontUnderlineType_NONE",3);
define ("FontUnderlineType_SINGLE",4);
define ("FormatConditionType_ABOVE_AVERAGE",17);
define ("FormatConditionType_BEGINS_WITH",10);
define ("FormatConditionType_CELL_VALUE",0);
define ("FormatConditionType_COLOR_SCALE",2);
define ("FormatConditionType_CONTAINS_BLANKS",12);
define ("FormatConditionType_CONTAINS_ERRORS",14);
define ("FormatConditionType_CONTAINS_TEXT",8);
define ("FormatConditionType_DATA_BAR",3);
define ("FormatConditionType_DUPLICATE_VALUES",7);
define ("FormatConditionType_ENDS_WITH",11);
define ("FormatConditionType_EXPRESSION",1);
define ("FormatConditionType_ICON_SET",4);
define ("FormatConditionType_NOT_CONTAINS_BLANKS",13);
define ("FormatConditionType_NOT_CONTAINS_ERRORS",15);
define ("FormatConditionType_NOT_CONTAINS_TEXT",9);
define ("FormatConditionType_TIME_PERIOD",16);
define ("FormatConditionType_TOP_10",5);
define ("FormatConditionType_UNIQUE_VALUES",6);
define ("FormatConditionValueType_FORMULA",0);
define ("FormatConditionValueType_MAX",1);
define ("FormatConditionValueType_MIN",2);
define ("FormatConditionValueType_NUMBER",3);
define ("FormatConditionValueType_PERCENT",4);
define ("FormatConditionValueType_PERCENTILE",5);
define ("FormatSetType_IS_GRADIENT_SET",1);
define ("FormatSetType_IS_PATTERN_SET",3);
define ("FormatSetType_IS_TEXTURE_SET",2);
define ("FormatSetType_NONE",0);
define ("FormattingType_AUTOMATIC",0);
define ("FormattingType_CUSTOM",2);
define ("FormattingType_NONE",1);
define ("GradientColorType_NONE",0);
define ("GradientColorType_ONE_COLOR",1);
define ("GradientColorType_PRESET_COLORS",2);
define ("GradientColorType_TWO_COLORS",3);
define ("GradientDirectionType_FROM_CENTER",4);
define ("GradientDirectionType_FROM_LOWER_LEFT_CORNER",2);
define ("GradientDirectionType_FROM_LOWER_RIGHT_CORNER",3);
define ("GradientDirectionType_FROM_UPPER_LEFT_CORNER",0);
define ("GradientDirectionType_FROM_UPPER_RIGHT_CORNER",1);
define ("GradientDirectionType_UNKNOWN",5);
define ("GradientFillType_LINEAR",0);
define ("GradientFillType_PATH",3);
define ("GradientFillType_RADIAL",1);
define ("GradientFillType_RECTANGLE",2);
define ("GradientPresetType_BRASS",0);
define ("GradientPresetType_CALM_WATER",1);
define ("GradientPresetType_CHROME",2);
define ("GradientPresetType_CHROME_II",3);
define ("GradientPresetType_DAYBREAK",4);
define ("GradientPresetType_DESERT",5);
define ("GradientPresetType_EARLY_SUNSET",6);
define ("GradientPresetType_FIRE",7);
define ("GradientPresetType_FOG",8);
define ("GradientPresetType_GOLD",9);
define ("GradientPresetType_GOLD_II",10);
define ("GradientPresetType_HORIZON",11);
define ("GradientPresetType_LATE_SUNSET",12);
define ("GradientPresetType_MAHOGANY",13);
define ("GradientPresetType_MOSS",14);
define ("GradientPresetType_NIGHTFALL",15);
define ("GradientPresetType_OCEAN",16);
define ("GradientPresetType_PARCHMENT",17);
define ("GradientPresetType_PEACOCK",18);
define ("GradientPresetType_RAINBOW",19);
define ("GradientPresetType_RAINBOW_II",20);
define ("GradientPresetType_SAPPHIRE",21);
define ("GradientPresetType_SILVER",22);
define ("GradientPresetType_UNKNOWN",24);
define ("GradientPresetType_WHEAT",23);
define ("GradientStyleType_DIAGONAL_DOWN",0);
define ("GradientStyleType_DIAGONAL_UP",1);
define ("GradientStyleType_FROM_CENTER",2);
define ("GradientStyleType_FROM_CORNER",3);
define ("GradientStyleType_HORIZONTAL",4);
define ("GradientStyleType_UNKNOWN",6);
define ("GradientStyleType_VERTICAL",5);
define ("IconSetType_ARROWS_3",0);
define ("IconSetType_ARROWS_4",8);
define ("IconSetType_ARROWS_5",13);
define ("IconSetType_ARROWS_GRAY_3",1);
define ("IconSetType_ARROWS_GRAY_4",9);
define ("IconSetType_ARROWS_GRAY_5",14);
define ("IconSetType_FLAGS_3",2);
define ("IconSetType_QUARTERS_5",15);
define ("IconSetType_RATING_4",10);
define ("IconSetType_RATING_5",16);
define ("IconSetType_RED_TO_BLACK_4",11);
define ("IconSetType_SIGNS_3",3);
define ("IconSetType_SYMBOLS_3",4);
define ("IconSetType_SYMBOLS_32",5);
define ("IconSetType_TRAFFIC_LIGHTS_31",6);
define ("IconSetType_TRAFFIC_LIGHTS_32",7);
define ("IconSetType_TRAFFIC_LIGHTS_4",12);
define ("LabelPositionType_ABOVE",4);
define ("LabelPositionType_BELOW",5);
define ("LabelPositionType_BEST_FIT",8);
define ("LabelPositionType_CENTER",0);
define ("LabelPositionType_INSIDE_BASE",1);
define ("LabelPositionType_INSIDE_END",2);
define ("LabelPositionType_LEFT",6);
define ("LabelPositionType_MOVED",9);
define ("LabelPositionType_OUTSIDE_END",3);
define ("LabelPositionType_RIGHT",7);
define ("LegendPositionType_BOTTOM",0);
define ("LegendPositionType_CORNER",1);
define ("LegendPositionType_LEFT",4);
define ("LegendPositionType_NOT_DOCKED",7);
define ("LegendPositionType_RIGHT",3);
define ("LegendPositionType_TOP",2);
define ("LightRigType_BALANCED",0);
define ("LightRigType_BRIGHT_ROOM",1);
define ("LightRigType_CHILLY",2);
define ("LightRigType_CONTRASTING",3);
define ("LightRigType_FLAT",4);
define ("LightRigType_FLOOD",5);
define ("LightRigType_FREEZING",6);
define ("LightRigType_GLOW",7);
define ("LightRigType_HARSH",8);
define ("LightRigType_LEGACY_FLAT_1",9);
define ("LightRigType_LEGACY_FLAT_2",10);
define ("LightRigType_LEGACY_FLAT_3",11);
define ("LightRigType_LEGACY_FLAT_4",12);
define ("LightRigType_LEGACY_HARSH_1",13);
define ("LightRigType_LEGACY_HARSH_2",14);
define ("LightRigType_LEGACY_HARSH_3",15);
define ("LightRigType_LEGACY_HARSH_4",16);
define ("LightRigType_LEGACY_NORMAL_1",17);
define ("LightRigType_LEGACY_NORMAL_2",18);
define ("LightRigType_LEGACY_NORMAL_3",19);
define ("LightRigType_LEGACY_NORMAL_4",20);
define ("LightRigType_MORNING",21);
define ("LightRigType_SOFT",22);
define ("LightRigType_SUNRISE",23);
define ("LightRigType_SUNSET",24);
define ("LightRigType_THREE_POINT",25);
define ("LightRigType_TWO_POINT",26);
define ("LineType_DARK_GRAY",6);
define ("LineType_DASH",1);
define ("LineType_DASH_DOT",3);
define ("LineType_DASH_DOT_DOT",4);
define ("LineType_DOT",2);
define ("LineType_LIGHT_GRAY",8);
define ("LineType_MEDIUM_GRAY",7);
define ("LineType_SOLID",0);
define ("LoadFormat_AUTO",0);
define ("LoadFormat_CSV",1);
define ("LoadFormat_EXCEL_97_TO_2003",5);
define ("LoadFormat_ODS",14);
define ("LoadFormat_SPREADSHEET_ML",15);
define ("LoadFormat_TAB_DELIMITED",11);
define ("LoadFormat_UNKNOWN",255);
define ("LoadFormat_XLSB",16);
define ("LoadFormat_XLSX",6);
define ("LookAtType_CONTAINS",0);
define ("LookAtType_END_WITH",2);
define ("LookAtType_ENTIRE_CONTENT",3);
define ("LookAtType_START_WITH",1);
define ("LookInType_COMMENTS",2);
define ("LookInType_FORMULAS",0);
define ("LookInType_ONLY_FORMULAS",3);
define ("LookInType_VALUES",1);
define ("MsoArrowheadLength_LONG",2);
define ("MsoArrowheadLength_MEDIUM",1);
define ("MsoArrowheadLength_SHORT",0);
define ("MsoArrowheadStyle_ARROW",1);
define ("MsoArrowheadStyle_ARROW_DIAMOND",3);
define ("MsoArrowheadStyle_ARROW_OPEN",5);
define ("MsoArrowheadStyle_ARROW_OVAL",4);
define ("MsoArrowheadStyle_ARROW_STEALTH",2);
define ("MsoArrowheadStyle_NONE",0);
define ("MsoArrowheadWidth_MEDIUM",1);
define ("MsoArrowheadWidth_NARROW",0);
define ("MsoArrowheadWidth_WIDE",2);
define ("MsoDrawingType_ARC",4);
define ("MsoDrawingType_BUTTON",7);
define ("MsoDrawingType_CELLS_DRAWING",30);
define ("MsoDrawingType_CHART",5);
define ("MsoDrawingType_CHECK_BOX",11);
define ("MsoDrawingType_COMBO_BOX",20);
define ("MsoDrawingType_COMMENT",25);
define ("MsoDrawingType_DIALOG_BOX",15);
define ("MsoDrawingType_GROUP",0);
define ("MsoDrawingType_GROUP_BOX",19);
define ("MsoDrawingType_LABEL",14);
define ("MsoDrawingType_LINE",1);
define ("MsoDrawingType_LIST_BOX",18);
define ("MsoDrawingType_OLE_OBJECT",24);
define ("MsoDrawingType_OVAL",3);
define ("MsoDrawingType_PICTURE",8);
define ("MsoDrawingType_POLYGON",9);
define ("MsoDrawingType_RADIO_BUTTON",12);
define ("MsoDrawingType_RECTANGLE",2);
define ("MsoDrawingType_SCROLL_BAR",17);
define ("MsoDrawingType_SPINNER",16);
define ("MsoDrawingType_TEXT_BOX",6);
define ("MsoDrawingType_UNKNOWN",29);
define ("MsoLineDashStyle_DASH",0);
define ("MsoLineDashStyle_DASH_DOT",1);
define ("MsoLineDashStyle_DASH_DOT_DOT",2);
define ("MsoLineDashStyle_DASH_LONG_DASH",3);
define ("MsoLineDashStyle_DASH_LONG_DASH_DOT",4);
define ("MsoLineDashStyle_ROUND_DOT",5);
define ("MsoLineDashStyle_SOLID",6);
define ("MsoLineDashStyle_SQUARE_DOT",7);
define ("MsoLineStyle_SINGLE",0);
define ("MsoLineStyle_THICK_BETWEEN_THIN",1);
define ("MsoLineStyle_THICK_THIN",3);
define ("MsoLineStyle_THIN_THICK",2);
define ("MsoLineStyle_THIN_THIN",4);
define ("MsoPresetTextEffect_TEXT_EFFECT_1",0);
define ("MsoPresetTextEffect_TEXT_EFFECT_10",9);
define ("MsoPresetTextEffect_TEXT_EFFECT_11",10);
define ("MsoPresetTextEffect_TEXT_EFFECT_12",11);
define ("MsoPresetTextEffect_TEXT_EFFECT_13",12);
define ("MsoPresetTextEffect_TEXT_EFFECT_14",13);
define ("MsoPresetTextEffect_TEXT_EFFECT_15",14);
define ("MsoPresetTextEffect_TEXT_EFFECT_16",15);
define ("MsoPresetTextEffect_TEXT_EFFECT_17",16);
define ("MsoPresetTextEffect_TEXT_EFFECT_18",17);
define ("MsoPresetTextEffect_TEXT_EFFECT_19",18);
define ("MsoPresetTextEffect_TEXT_EFFECT_2",1);
define ("MsoPresetTextEffect_TEXT_EFFECT_20",19);
define ("MsoPresetTextEffect_TEXT_EFFECT_21",20);
define ("MsoPresetTextEffect_TEXT_EFFECT_22",21);
define ("MsoPresetTextEffect_TEXT_EFFECT_23",22);
define ("MsoPresetTextEffect_TEXT_EFFECT_24",23);
define ("MsoPresetTextEffect_TEXT_EFFECT_25",24);
define ("MsoPresetTextEffect_TEXT_EFFECT_26",25);
define ("MsoPresetTextEffect_TEXT_EFFECT_27",26);
define ("MsoPresetTextEffect_TEXT_EFFECT_28",27);
define ("MsoPresetTextEffect_TEXT_EFFECT_29",28);
define ("MsoPresetTextEffect_TEXT_EFFECT_3",2);
define ("MsoPresetTextEffect_TEXT_EFFECT_30",29);
define ("MsoPresetTextEffect_TEXT_EFFECT_4",3);
define ("MsoPresetTextEffect_TEXT_EFFECT_5",4);
define ("MsoPresetTextEffect_TEXT_EFFECT_6",5);
define ("MsoPresetTextEffect_TEXT_EFFECT_7",6);
define ("MsoPresetTextEffect_TEXT_EFFECT_8",7);
define ("MsoPresetTextEffect_TEXT_EFFECT_9",8);
define ("MsoPresetTextEffectShape_ARCH_DOWN_CURVE",145);
define ("MsoPresetTextEffectShape_ARCH_DOWN_POUR",149);
define ("MsoPresetTextEffectShape_ARCH_UP_CURVE",144);
define ("MsoPresetTextEffectShape_ARCH_UP_POUR",148);
define ("MsoPresetTextEffectShape_BUTTON_CURVE",147);
define ("MsoPresetTextEffectShape_BUTTON_POUR",151);
define ("MsoPresetTextEffectShape_CAN_DOWN",175);
define ("MsoPresetTextEffectShape_CAN_UP",174);
define ("MsoPresetTextEffectShape_CASCADE_DOWN",155);
define ("MsoPresetTextEffectShape_CASCADE_UP",154);
define ("MsoPresetTextEffectShape_CHEVRON_DOWN",141);
define ("MsoPresetTextEffectShape_CHEVRON_UP",140);
define ("MsoPresetTextEffectShape_CIRCLE_CURVE",146);
define ("MsoPresetTextEffectShape_CIRCLE_POUR",150);
define ("MsoPresetTextEffectShape_CURVE_DOWN",153);
define ("MsoPresetTextEffectShape_CURVE_UP",152);
define ("MsoPresetTextEffectShape_DEFLATE",161);
define ("MsoPresetTextEffectShape_DEFLATE_BOTTOM",163);
define ("MsoPresetTextEffectShape_DEFLATE_INFLATE",166);
define ("MsoPresetTextEffectShape_DEFLATE_INFLATE_DEFLATE",167);
define ("MsoPresetTextEffectShape_DEFLATE_TOP",165);
define ("MsoPresetTextEffectShape_DOUBLE_WAVE_1",158);
define ("MsoPresetTextEffectShape_DOUBLE_WAVE_2",159);
define ("MsoPresetTextEffectShape_FADE_DOWN",171);
define ("MsoPresetTextEffectShape_FADE_LEFT",169);
define ("MsoPresetTextEffectShape_FADE_RIGHT",168);
define ("MsoPresetTextEffectShape_FADE_UP",170);
define ("MsoPresetTextEffectShape_INFLATE",160);
define ("MsoPresetTextEffectShape_INFLATE_BOTTOM",162);
define ("MsoPresetTextEffectShape_INFLATE_TOP",164);
define ("MsoPresetTextEffectShape_MIXED",255);
define ("MsoPresetTextEffectShape_PLAIN_TEXT",136);
define ("MsoPresetTextEffectShape_RING_INSIDE",142);
define ("MsoPresetTextEffectShape_RING_OUTSIDE",143);
define ("MsoPresetTextEffectShape_SLANT_DOWN",173);
define ("MsoPresetTextEffectShape_SLANT_UP",172);
define ("MsoPresetTextEffectShape_STOP",137);
define ("MsoPresetTextEffectShape_TRIANGLE_DOWN",139);
define ("MsoPresetTextEffectShape_TRIANGLE_UP",138);
define ("MsoPresetTextEffectShape_WAVE_1",156);
define ("MsoPresetTextEffectShape_WAVE_2",157);
define ("OleFileType_DOC",1);
define ("OleFileType_MS_EQUATION",4);
define ("OleFileType_PDF",3);
define ("OleFileType_PPT",2);
define ("OleFileType_UNKNOWN",5);
define ("OleFileType_XLS",0);
define ("OperatorType_BETWEEN",0);
define ("OperatorType_EQUAL",1);
define ("OperatorType_GREATER_OR_EQUAL",3);
define ("OperatorType_GREATER_THAN",2);
define ("OperatorType_LESS_OR_EQUAL",5);
define ("OperatorType_LESS_THAN",4);
define ("OperatorType_NONE",6);
define ("OperatorType_NOT_BETWEEN",7);
define ("OperatorType_NOT_EQUAL",8);
define ("PageOrientationType_LANDSCAPE",0);
define ("PageOrientationType_PORTRAIT",1);
define ("PaperSizeType_PAPER_10_X_11",45);
define ("PaperSizeType_PAPER_10_X_14",16);
define ("PaperSizeType_PAPER_11_X_17",17);
define ("PaperSizeType_PAPER_15_X_11",46);
define ("PaperSizeType_PAPER_9_X_11",44);
define ("PaperSizeType_PAPER_A_3",8);
define ("PaperSizeType_PAPER_A_3_ROTATED",76);
define ("PaperSizeType_PAPER_A_4",9);
define ("PaperSizeType_PAPER_A_4_ROTATED",77);
define ("PaperSizeType_PAPER_A_4_SMALL",10);
define ("PaperSizeType_PAPER_A_5",11);
define ("PaperSizeType_PAPER_A_5_ROTATED",78);
define ("PaperSizeType_PAPER_B_4",12);
define ("PaperSizeType_PAPER_B_5",13);
define ("PaperSizeType_PAPER_C_SHEET",24);
define ("PaperSizeType_PAPER_D_SHEET",25);
define ("PaperSizeType_PAPER_E_SHEET",26);
define ("PaperSizeType_PAPER_ENVELOPE_10",20);
define ("PaperSizeType_PAPER_ENVELOPE_11",21);
define ("PaperSizeType_PAPER_ENVELOPE_12",22);
define ("PaperSizeType_PAPER_ENVELOPE_14",23);
define ("PaperSizeType_PAPER_ENVELOPE_9",19);
define ("PaperSizeType_PAPER_ENVELOPE_B_4",33);
define ("PaperSizeType_PAPER_ENVELOPE_B_5",34);
define ("PaperSizeType_PAPER_ENVELOPE_B_6",35);
define ("PaperSizeType_PAPER_ENVELOPE_C_3",29);
define ("PaperSizeType_PAPER_ENVELOPE_C_4",30);
define ("PaperSizeType_PAPER_ENVELOPE_C_5",28);
define ("PaperSizeType_PAPER_ENVELOPE_C_6",31);
define ("PaperSizeType_PAPER_ENVELOPE_C_65",32);
define ("PaperSizeType_PAPER_ENVELOPE_DL",27);
define ("PaperSizeType_PAPER_ENVELOPE_INVITE",47);
define ("PaperSizeType_PAPER_ENVELOPE_ITALY",36);
define ("PaperSizeType_PAPER_ENVELOPE_MONARCH",37);
define ("PaperSizeType_PAPER_ENVELOPE_PERSONAL",38);
define ("PaperSizeType_PAPER_EXECUTIVE",7);
define ("PaperSizeType_PAPER_FANFOLD_LEGAL_GERMAN",41);
define ("PaperSizeType_PAPER_FANFOLD_STD_GERMAN",40);
define ("PaperSizeType_PAPER_FANFOLD_US",39);
define ("PaperSizeType_PAPER_FOLIO",14);
define ("PaperSizeType_PAPER_JAPANESE_POSTCARD",43);
define ("PaperSizeType_PAPER_LEDGER",4);
define ("PaperSizeType_PAPER_LEGAL",5);
define ("PaperSizeType_PAPER_LETTER",1);
define ("PaperSizeType_PAPER_LETTER_ROTATED",75);
define ("PaperSizeType_PAPER_LETTER_SMALL",2);
define ("PaperSizeType_PAPER_NOTE",18);
define ("PaperSizeType_PAPER_QUARTO",15);
define ("PaperSizeType_PAPER_STATEMENT",6);
define ("PaperSizeType_PAPER_TABLOID",3);
define ("PasteType_ALL",0);
define ("PasteType_ALL_EXCEPT_BORDERS",1);
define ("PasteType_COLUMN_WIDTHS",2);
define ("PasteType_COMMENTS",3);
define ("PasteType_FORMATS",4);
define ("PasteType_FORMULAS",5);
define ("PasteType_FORMULAS_AND_NUMBER_FORMATS",6);
define ("PasteType_VALIDATION",7);
define ("PasteType_VALUES",8);
define ("PasteType_VALUES_AND_NUMBER_FORMATS",9);
define ("PdfCompliance_NONE",0);
define ("PdfCompliance_PDF_A_1_B",1);
define ("PivotFieldDataDisplayFormat_DIFFERENCE_FROM",1);
define ("PivotFieldDataDisplayFormat_INDEX",8);
define ("PivotFieldDataDisplayFormat_NORMAL",0);
define ("PivotFieldDataDisplayFormat_PERCENTAGE_DIFFERENCE_FROM",3);
define ("PivotFieldDataDisplayFormat_PERCENTAGE_OF",2);
define ("PivotFieldDataDisplayFormat_PERCENTAGE_OF_COLUMN",6);
define ("PivotFieldDataDisplayFormat_PERCENTAGE_OF_ROW",5);
define ("PivotFieldDataDisplayFormat_PERCENTAGE_OF_TOTAL",7);
define ("PivotFieldDataDisplayFormat_RUNNING_TOTAL_IN",4);
define ("PivotFieldSubtotalType_AUTOMATIC",1);
define ("PivotFieldSubtotalType_AVERAGE",8);
define ("PivotFieldSubtotalType_COUNT",4);
define ("PivotFieldSubtotalType_COUNT_NUMS",128);
define ("PivotFieldSubtotalType_MAX",16);
define ("PivotFieldSubtotalType_MIN",32);
define ("PivotFieldSubtotalType_NONE",0);
define ("PivotFieldSubtotalType_PRODUCT",64);
define ("PivotFieldSubtotalType_STDEV",256);
define ("PivotFieldSubtotalType_STDEVP",512);
define ("PivotFieldSubtotalType_SUM",2);
define ("PivotFieldSubtotalType_VAR",1024);
define ("PivotFieldSubtotalType_VARP",2048);
define ("PivotFieldType_COLUMN",2);
define ("PivotFieldType_DATA",8);
define ("PivotFieldType_PAGE",4);
define ("PivotFieldType_ROW",1);
define ("PivotFieldType_UNDEFINED",0);
define ("PivotGroupByType_DAYS",4);
define ("PivotGroupByType_HOURS",3);
define ("PivotGroupByType_MINUTES",2);
define ("PivotGroupByType_MONTHS",5);
define ("PivotGroupByType_QUARTERS",6);
define ("PivotGroupByType_RANGE_OF_VALUES",0);
define ("PivotGroupByType_SECONDS",1);
define ("PivotGroupByType_YEARS",7);
define ("PivotItemPosition_ALL",32765);
define ("PivotItemPosition_NEXT",32764);
define ("PivotItemPosition_PREVIOUS",32763);
define ("PivotTableAutoFormatType_CLASSIC",1);
define ("PivotTableAutoFormatType_NONE",0);
define ("PivotTableAutoFormatType_REPORT_1",2);
define ("PivotTableAutoFormatType_REPORT_10",11);
define ("PivotTableAutoFormatType_REPORT_2",3);
define ("PivotTableAutoFormatType_REPORT_3",4);
define ("PivotTableAutoFormatType_REPORT_4",5);
define ("PivotTableAutoFormatType_REPORT_5",6);
define ("PivotTableAutoFormatType_REPORT_6",7);
define ("PivotTableAutoFormatType_REPORT_7",8);
define ("PivotTableAutoFormatType_REPORT_8",9);
define ("PivotTableAutoFormatType_REPORT_9",10);
define ("PivotTableAutoFormatType_TABLE_1",12);
define ("PivotTableAutoFormatType_TABLE_10",21);
define ("PivotTableAutoFormatType_TABLE_2",13);
define ("PivotTableAutoFormatType_TABLE_3",14);
define ("PivotTableAutoFormatType_TABLE_4",15);
define ("PivotTableAutoFormatType_TABLE_5",16);
define ("PivotTableAutoFormatType_TABLE_6",17);
define ("PivotTableAutoFormatType_TABLE_7",18);
define ("PivotTableAutoFormatType_TABLE_8",19);
define ("PivotTableAutoFormatType_TABLE_9",20);
define ("PivotTableSourceType_CONSILIDATION",4);
define ("PivotTableSourceType_EXTERNAL",2);
define ("PivotTableSourceType_LIST_DATABASE",1);
define ("PivotTableSourceType_PIVOT_TABLE",8);
define ("PivotTableStyleType_CUSTOM",85);
define ("PivotTableStyleType_NONE",0);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_DARK_1",57);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_DARK_10",66);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_DARK_11",67);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_DARK_12",68);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_DARK_13",69);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_DARK_14",70);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_DARK_15",71);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_DARK_16",72);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_DARK_17",73);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_DARK_18",74);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_DARK_19",75);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_DARK_2",58);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_DARK_20",76);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_DARK_21",77);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_DARK_22",78);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_DARK_23",79);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_DARK_24",80);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_DARK_25",81);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_DARK_26",82);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_DARK_27",83);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_DARK_28",84);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_DARK_3",59);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_DARK_4",60);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_DARK_5",61);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_DARK_6",62);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_DARK_7",63);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_DARK_8",64);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_DARK_9",65);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_LIGHT_1",1);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_LIGHT_10",10);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_LIGHT_11",11);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_LIGHT_12",12);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_LIGHT_13",13);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_LIGHT_14",14);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_LIGHT_15",15);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_LIGHT_16",16);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_LIGHT_17",17);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_LIGHT_18",18);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_LIGHT_19",19);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_LIGHT_2",2);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_LIGHT_20",20);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_LIGHT_21",21);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_LIGHT_22",22);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_LIGHT_23",23);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_LIGHT_24",24);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_LIGHT_25",25);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_LIGHT_26",26);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_LIGHT_27",27);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_LIGHT_28",28);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_LIGHT_3",3);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_LIGHT_4",4);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_LIGHT_5",5);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_LIGHT_6",6);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_LIGHT_7",7);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_LIGHT_8",8);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_LIGHT_9",9);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_MEDIUM_1",29);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_MEDIUM_10",38);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_MEDIUM_11",39);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_MEDIUM_12",40);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_MEDIUM_13",41);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_MEDIUM_14",42);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_MEDIUM_15",43);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_MEDIUM_16",44);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_MEDIUM_17",45);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_MEDIUM_18",46);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_MEDIUM_19",47);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_MEDIUM_2",30);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_MEDIUM_20",48);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_MEDIUM_21",49);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_MEDIUM_22",50);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_MEDIUM_23",51);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_MEDIUM_24",52);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_MEDIUM_25",53);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_MEDIUM_26",54);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_MEDIUM_27",55);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_MEDIUM_28",56);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_MEDIUM_3",31);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_MEDIUM_4",32);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_MEDIUM_5",33);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_MEDIUM_6",34);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_MEDIUM_7",35);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_MEDIUM_8",36);
define ("PivotTableStyleType_PIVOT_TABLE_STYLE_MEDIUM_9",37);
define ("PlacementType_FREE_FLOATING",0);
define ("PlacementType_MOVE",1);
define ("PlacementType_MOVE_AND_SIZE",2);
define ("PlotEmptyCellsType_INTERPOLATED",2);
define ("PlotEmptyCellsType_NOT_PLOTTED",0);
define ("PlotEmptyCellsType_ZERO",1);
define ("PresetMaterialType_CLEAR",0);
define ("PresetMaterialType_DARK_EDGE",1);
define ("PresetMaterialType_FLAT",2);
define ("PresetMaterialType_LEGACY_MATTE",3);
define ("PresetMaterialType_LEGACY_METAL",4);
define ("PresetMaterialType_LEGACY_PLASTIC",5);
define ("PresetMaterialType_LEGACY_WIREFRAME",6);
define ("PresetMaterialType_MATTE",7);
define ("PresetMaterialType_METAL",8);
define ("PresetMaterialType_PLASTIC",9);
define ("PresetMaterialType_POWDER",10);
define ("PresetMaterialType_SOFT_EDGE",11);
define ("PresetMaterialType_SOFT_METAL",12);
define ("PresetMaterialType_TRANSLUCENT_POWDER",13);
define ("PresetMaterialType_WARM_MATTE",14);
define ("PresetShadowType_BELOW",22);
define ("PresetShadowType_CUSTOM",1);
define ("PresetShadowType_INSIDE_BOTTOM",18);
define ("PresetShadowType_INSIDE_CENTER",15);
define ("PresetShadowType_INSIDE_DIAGONAL_BOTTOM_LEFT",17);
define ("PresetShadowType_INSIDE_DIAGONAL_BOTTOM_RIGHT",19);
define ("PresetShadowType_INSIDE_DIAGONAL_TOP_LEFT",11);
define ("PresetShadowType_INSIDE_DIAGONAL_TOP_RIGHT",13);
define ("PresetShadowType_INSIDE_LEFT",14);
define ("PresetShadowType_INSIDE_RIGHT",16);
define ("PresetShadowType_INSIDE_TOP",12);
define ("PresetShadowType_NO_SHADOW",0);
define ("PresetShadowType_OFFSET_BOTTOM",3);
define ("PresetShadowType_OFFSET_CENTER",6);
define ("PresetShadowType_OFFSET_DIAGONAL_BOTTOM_LEFT",4);
define ("PresetShadowType_OFFSET_DIAGONAL_BOTTOM_RIGHT",2);
define ("PresetShadowType_OFFSET_DIAGONAL_TOP_LEFT",10);
define ("PresetShadowType_OFFSET_DIAGONAL_TOP_RIGHT",8);
define ("PresetShadowType_OFFSET_LEFT",7);
define ("PresetShadowType_OFFSET_RIGHT",5);
define ("PresetShadowType_OFFSET_TOP",9);
define ("PresetShadowType_PERSPECTIVE_DIAGONAL_LOWER_LEFT",23);
define ("PresetShadowType_PERSPECTIVE_DIAGONAL_LOWER_RIGHT",24);
define ("PresetShadowType_PERSPECTIVE_DIAGONAL_UPPER_LEFT",20);
define ("PresetShadowType_PERSPECTIVE_DIAGONAL_UPPER_RIGHT",21);
define ("PrintCommentsType_PRINT_IN_PLACE",0);
define ("PrintCommentsType_PRINT_NO_COMMENTS",1);
define ("PrintCommentsType_PRINT_SHEET_END",2);
define ("PrintErrorsType_PRINT_ERRORS_BLANK",0);
define ("PrintErrorsType_PRINT_ERRORS_DASH",1);
define ("PrintErrorsType_PRINT_ERRORS_DISPLAYED",2);
define ("PrintErrorsType_PRINT_ERRORS_NA",3);
define ("PrintingPageType_DEFAULT",0);
define ("PrintingPageType_IGNORE_BLANK",1);
define ("PrintingPageType_IGNORE_STYLE",2);
define ("PrintOrderType_DOWN_THEN_OVER",0);
define ("PrintOrderType_OVER_THEN_DOWN",1);
define ("PrintSizeType_CUSTOM",2);
define ("PrintSizeType_FIT",1);
define ("PrintSizeType_FULL",0);
define ("PropertyType_BLOB",5);
define ("PropertyType_BOOLEAN",0);
define ("PropertyType_DATE_TIME",1);
define ("PropertyType_DOUBLE",2);
define ("PropertyType_NUMBER",3);
define ("PropertyType_STRING",4);
define ("ProtectionType_ALL",0);
define ("ProtectionType_CONTENTS",1);
define ("ProtectionType_NONE",6);
define ("ProtectionType_OBJECTS",2);
define ("ProtectionType_SCENARIOS",3);
define ("ProtectionType_STRUCTURE",4);
define ("ProtectionType_WINDOWS",5);
define ("RectangleAlignmentType_BOTTOM",0);
define ("RectangleAlignmentType_BOTTOM_LEFT",1);
define ("RectangleAlignmentType_BOTTOM_RIGHT",2);
define ("RectangleAlignmentType_CENTER",3);
define ("RectangleAlignmentType_LEFT",4);
define ("RectangleAlignmentType_RIGHT",5);
define ("RectangleAlignmentType_TOP",6);
define ("RectangleAlignmentType_TOP_LEFT",7);
define ("RectangleAlignmentType_TOP_RIGHT",8);
define ("SaveFormat_AUTO",0);
define ("SaveFormat_CSV",1);
define ("SaveFormat_EXCEL_97_TO_2003",5);
define ("SaveFormat_HTML",12);
define ("SaveFormat_ODS",14);
define ("SaveFormat_PDF",13);
define ("SaveFormat_SPREADSHEET_ML",15);
define ("SaveFormat_TAB_DELIMITED",11);
define ("SaveFormat_TIFF",21);
define ("SaveFormat_UNKNOWN",255);
define ("SaveFormat_XLSB",16);
define ("SaveFormat_XLSM",7);
define ("SaveFormat_XLSX",6);
define ("SaveFormat_XLTM",9);
define ("SaveFormat_XLTX",8);
define ("SaveFormat_XPS",20);
define ("SaveType_DEFAULT",0);
define ("SaveType_OPEN_IN_BROWSER",2);
define ("SaveType_OPEN_IN_EXCEL",1);
define ("SelectionType_EXTEND",2);
define ("SelectionType_MULTI",1);
define ("SelectionType_SINGLE",0);
define ("SheetType_BIFF_4_MACRO",3);
define ("SheetType_CHART",2);
define ("SheetType_OTHER",4);
define ("SheetType_VB",0);
define ("SheetType_WORKSHEET",1);
define ("ShiftType_DOWN",0);
define ("ShiftType_LEFT",1);
define ("ShiftType_NONE",2);
define ("ShiftType_RIGHT",3);
define ("ShiftType_UP",4);
define ("SmartTagShowType_ALL",0);
define ("SmartTagShowType_NO_SMART_TAG_INDICATOR",1);
define ("SmartTagShowType_NONE",2);
define ("SortOrder_ASCENDING",0);
define ("SortOrder_DESCENDING",1);
define ("SparklineAxisMinMaxType_AUTO_INDIVIDUAL",0);
define ("SparklineAxisMinMaxType_CUSTOM",2);
define ("SparklineAxisMinMaxType_GROUP",1);
define ("SparklinePresetStyleType_CUSTOM",36);
define ("SparklinePresetStyleType_STYLE_1",0);
define ("SparklinePresetStyleType_STYLE_10",9);
define ("SparklinePresetStyleType_STYLE_11",10);
define ("SparklinePresetStyleType_STYLE_12",11);
define ("SparklinePresetStyleType_STYLE_13",12);
define ("SparklinePresetStyleType_STYLE_14",13);
define ("SparklinePresetStyleType_STYLE_15",14);
define ("SparklinePresetStyleType_STYLE_16",15);
define ("SparklinePresetStyleType_STYLE_17",16);
define ("SparklinePresetStyleType_STYLE_18",17);
define ("SparklinePresetStyleType_STYLE_19",18);
define ("SparklinePresetStyleType_STYLE_2",1);
define ("SparklinePresetStyleType_STYLE_20",19);
define ("SparklinePresetStyleType_STYLE_21",20);
define ("SparklinePresetStyleType_STYLE_22",21);
define ("SparklinePresetStyleType_STYLE_23",22);
define ("SparklinePresetStyleType_STYLE_24",23);
define ("SparklinePresetStyleType_STYLE_25",24);
define ("SparklinePresetStyleType_STYLE_26",25);
define ("SparklinePresetStyleType_STYLE_27",26);
define ("SparklinePresetStyleType_STYLE_28",27);
define ("SparklinePresetStyleType_STYLE_29",28);
define ("SparklinePresetStyleType_STYLE_3",2);
define ("SparklinePresetStyleType_STYLE_30",29);
define ("SparklinePresetStyleType_STYLE_31",30);
define ("SparklinePresetStyleType_STYLE_32",31);
define ("SparklinePresetStyleType_STYLE_33",32);
define ("SparklinePresetStyleType_STYLE_34",33);
define ("SparklinePresetStyleType_STYLE_35",34);
define ("SparklinePresetStyleType_STYLE_36",35);
define ("SparklinePresetStyleType_STYLE_4",3);
define ("SparklinePresetStyleType_STYLE_5",4);
define ("SparklinePresetStyleType_STYLE_6",5);
define ("SparklinePresetStyleType_STYLE_7",6);
define ("SparklinePresetStyleType_STYLE_8",7);
define ("SparklinePresetStyleType_STYLE_9",8);
define ("SparklineType_COLUMN",1);
define ("SparklineType_LINE",0);
define ("SparklineType_STACKED",2);
define ("StyleModifyFlag_ALL",0);
define ("StyleModifyFlag_BACKGROUND_COLOR",35);
define ("StyleModifyFlag_BORDERS",1);
define ("StyleModifyFlag_BOTTOM_BORDER",5);
define ("StyleModifyFlag_CELL_SHADING",32);
define ("StyleModifyFlag_DIAGONAL",8);
define ("StyleModifyFlag_DIAGONAL_DOWN_BORDER",9);
define ("StyleModifyFlag_DIAGONAL_UP_BORDER",10);
define ("StyleModifyFlag_FONT",11);
define ("StyleModifyFlag_FONT_CHARSET",15);
define ("StyleModifyFlag_FONT_COLOR",16);
define ("StyleModifyFlag_FONT_FAMILY",14);
define ("StyleModifyFlag_FONT_ITALIC",18);
define ("StyleModifyFlag_FONT_NAME",13);
define ("StyleModifyFlag_FONT_SCRIPT",21);
define ("StyleModifyFlag_FONT_SIZE",12);
define ("StyleModifyFlag_FONT_STRIKE",20);
define ("StyleModifyFlag_FONT_SUBSCRIPT",23);
define ("StyleModifyFlag_FONT_SUPERSCRIPT",22);
define ("StyleModifyFlag_FONT_UNDERLINE",19);
define ("StyleModifyFlag_FONT_WEIGHT",17);
define ("StyleModifyFlag_FOREGROUND_COLOR",34);
define ("StyleModifyFlag_HIDE_FORMULA",37);
define ("StyleModifyFlag_HORIZONTAL_ALIGNMENT",25);
define ("StyleModifyFlag_HORIZONTAL_BORDER",6);
define ("StyleModifyFlag_INDENT",27);
define ("StyleModifyFlag_LEFT_BORDER",2);
define ("StyleModifyFlag_LOCKED",36);
define ("StyleModifyFlag_NUMBER_FORMAT",24);
define ("StyleModifyFlag_PATTERN",33);
define ("StyleModifyFlag_RIGHT_BORDER",3);
define ("StyleModifyFlag_ROTATION",28);
define ("StyleModifyFlag_SHRINK_TO_FIT",30);
define ("StyleModifyFlag_TEXT_DIRECTION",31);
define ("StyleModifyFlag_TOP_BORDER",4);
define ("StyleModifyFlag_VERTICAL_ALIGNMENT",26);
define ("StyleModifyFlag_VERTICAL_BORDER",7);
define ("StyleModifyFlag_WRAP_TEXT",29);
define ("TableStyleElementType_BLANK_ROW",18);
define ("TableStyleElementType_FIRST_COLUMN",8);
define ("TableStyleElementType_FIRST_COLUMN_STRIPE",3);
define ("TableStyleElementType_FIRST_COLUMN_SUBHEADING",22);
define ("TableStyleElementType_FIRST_HEADER_CELL",11);
define ("TableStyleElementType_FIRST_ROW_STRIPE",5);
define ("TableStyleElementType_FIRST_ROW_SUBHEADING",25);
define ("TableStyleElementType_FIRST_SUBTOTAL_COLUMN",15);
define ("TableStyleElementType_FIRST_SUBTOTAL_ROW",19);
define ("TableStyleElementType_FIRST_TOTAL_CELL",13);
define ("TableStyleElementType_GRAND_TOTAL_COLUMN",28);
define ("TableStyleElementType_GRAND_TOTAL_ROW",29);
define ("TableStyleElementType_HEADER_ROW",9);
define ("TableStyleElementType_LAST_COLUMN",7);
define ("TableStyleElementType_LAST_HEADER_CELL",12);
define ("TableStyleElementType_LAST_TOTAL_CELL",14);
define ("TableStyleElementType_PAGE_FIELD_LABELS",1);
define ("TableStyleElementType_PAGE_FIELD_VALUES",2);
define ("TableStyleElementType_SECOND_COLUMN_STRIPE",4);
define ("TableStyleElementType_SECOND_COLUMN_SUBHEADING",23);
define ("TableStyleElementType_SECOND_ROW_STRIPE",6);
define ("TableStyleElementType_SECOND_ROW_SUBHEADING",26);
define ("TableStyleElementType_SECOND_SUBTOTAL_COLUMN",16);
define ("TableStyleElementType_SECOND_SUBTOTAL_ROW",20);
define ("TableStyleElementType_THIRD_COLUMN_SUBHEADING",24);
define ("TableStyleElementType_THIRD_ROW_SUBHEADING",27);
define ("TableStyleElementType_THIRD_SUBTOTAL_COLUMN",17);
define ("TableStyleElementType_THIRD_SUBTOTAL_ROW",21);
define ("TableStyleElementType_TOTAL_ROW",10);
define ("TableStyleElementType_WHOLE_TABLE",0);
define ("TableStyleType_CUSTOM",61);
define ("TableStyleType_NONE",0);
define ("TableStyleType_TABLE_STYLE_DARK_1",50);
define ("TableStyleType_TABLE_STYLE_DARK_10",59);
define ("TableStyleType_TABLE_STYLE_DARK_11",60);
define ("TableStyleType_TABLE_STYLE_DARK_2",51);
define ("TableStyleType_TABLE_STYLE_DARK_3",52);
define ("TableStyleType_TABLE_STYLE_DARK_4",53);
define ("TableStyleType_TABLE_STYLE_DARK_5",54);
define ("TableStyleType_TABLE_STYLE_DARK_6",55);
define ("TableStyleType_TABLE_STYLE_DARK_7",56);
define ("TableStyleType_TABLE_STYLE_DARK_8",57);
define ("TableStyleType_TABLE_STYLE_DARK_9",58);
define ("TableStyleType_TABLE_STYLE_LIGHT_1",1);
define ("TableStyleType_TABLE_STYLE_LIGHT_10",10);
define ("TableStyleType_TABLE_STYLE_LIGHT_11",11);
define ("TableStyleType_TABLE_STYLE_LIGHT_12",12);
define ("TableStyleType_TABLE_STYLE_LIGHT_13",13);
define ("TableStyleType_TABLE_STYLE_LIGHT_14",14);
define ("TableStyleType_TABLE_STYLE_LIGHT_15",15);
define ("TableStyleType_TABLE_STYLE_LIGHT_16",16);
define ("TableStyleType_TABLE_STYLE_LIGHT_17",17);
define ("TableStyleType_TABLE_STYLE_LIGHT_18",18);
define ("TableStyleType_TABLE_STYLE_LIGHT_19",19);
define ("TableStyleType_TABLE_STYLE_LIGHT_2",2);
define ("TableStyleType_TABLE_STYLE_LIGHT_20",20);
define ("TableStyleType_TABLE_STYLE_LIGHT_21",21);
define ("TableStyleType_TABLE_STYLE_LIGHT_3",3);
define ("TableStyleType_TABLE_STYLE_LIGHT_4",4);
define ("TableStyleType_TABLE_STYLE_LIGHT_5",5);
define ("TableStyleType_TABLE_STYLE_LIGHT_6",6);
define ("TableStyleType_TABLE_STYLE_LIGHT_7",7);
define ("TableStyleType_TABLE_STYLE_LIGHT_8",8);
define ("TableStyleType_TABLE_STYLE_LIGHT_9",9);
define ("TableStyleType_TABLE_STYLE_MEDIUM_1",22);
define ("TableStyleType_TABLE_STYLE_MEDIUM_10",31);
define ("TableStyleType_TABLE_STYLE_MEDIUM_11",32);
define ("TableStyleType_TABLE_STYLE_MEDIUM_12",33);
define ("TableStyleType_TABLE_STYLE_MEDIUM_13",34);
define ("TableStyleType_TABLE_STYLE_MEDIUM_14",35);
define ("TableStyleType_TABLE_STYLE_MEDIUM_15",36);
define ("TableStyleType_TABLE_STYLE_MEDIUM_16",37);
define ("TableStyleType_TABLE_STYLE_MEDIUM_17",38);
define ("TableStyleType_TABLE_STYLE_MEDIUM_18",39);
define ("TableStyleType_TABLE_STYLE_MEDIUM_19",40);
define ("TableStyleType_TABLE_STYLE_MEDIUM_2",23);
define ("TableStyleType_TABLE_STYLE_MEDIUM_20",41);
define ("TableStyleType_TABLE_STYLE_MEDIUM_21",42);
define ("TableStyleType_TABLE_STYLE_MEDIUM_22",43);
define ("TableStyleType_TABLE_STYLE_MEDIUM_23",44);
define ("TableStyleType_TABLE_STYLE_MEDIUM_24",45);
define ("TableStyleType_TABLE_STYLE_MEDIUM_25",46);
define ("TableStyleType_TABLE_STYLE_MEDIUM_26",47);
define ("TableStyleType_TABLE_STYLE_MEDIUM_27",48);
define ("TableStyleType_TABLE_STYLE_MEDIUM_28",49);
define ("TableStyleType_TABLE_STYLE_MEDIUM_3",24);
define ("TableStyleType_TABLE_STYLE_MEDIUM_4",25);
define ("TableStyleType_TABLE_STYLE_MEDIUM_5",26);
define ("TableStyleType_TABLE_STYLE_MEDIUM_6",27);
define ("TableStyleType_TABLE_STYLE_MEDIUM_7",28);
define ("TableStyleType_TABLE_STYLE_MEDIUM_8",29);
define ("TableStyleType_TABLE_STYLE_MEDIUM_9",30);
define ("TextAlignmentType_BOTTOM",0);
define ("TextAlignmentType_CENTER",1);
define ("TextAlignmentType_CENTER_ACROSS",2);
define ("TextAlignmentType_DISTRIBUTED",3);
define ("TextAlignmentType_FILL",4);
define ("TextAlignmentType_GENERAL",5);
define ("TextAlignmentType_JUSTIFY",6);
define ("TextAlignmentType_LEFT",7);
define ("TextAlignmentType_RIGHT",8);
define ("TextAlignmentType_TOP",9);
define ("TextDirectionType_CONTEXT",0);
define ("TextDirectionType_LEFT_TO_RIGHT",1);
define ("TextDirectionType_RIGHT_TO_LEFT",2);
define ("TextOrientationType_CLOCK_WISE",0);
define ("TextOrientationType_COUNTER_CLOCK_WISE",1);
define ("TextOrientationType_NO_ROTATION",2);
define ("TextOrientationType_TOP_TO_BOTTOM",3);
define ("TextOverflowType_CLIP",0);
define ("TextOverflowType_ELLIPSIS",1);
define ("TextOverflowType_OVERFLOW",2);
define ("TextureType_BLUE_TISSUE_PAPER",0);
define ("TextureType_BOUQUET",1);
define ("TextureType_BROWN_MARBLE",2);
define ("TextureType_CANVAS",3);
define ("TextureType_CORK",4);
define ("TextureType_DENIM",5);
define ("TextureType_FISH_FOSSIL",6);
define ("TextureType_GRANITE",7);
define ("TextureType_GREEN_MARBLE",8);
define ("TextureType_MEDIUM_WOOD",9);
define ("TextureType_NEWSPRINT",10);
define ("TextureType_OAK",11);
define ("TextureType_PAPER_BAG",12);
define ("TextureType_PAPYRUS",13);
define ("TextureType_PARCHMENT",14);
define ("TextureType_PINK_TISSUE_PAPER",15);
define ("TextureType_PURPLE_MESH",16);
define ("TextureType_RECYCLED_PAPER",17);
define ("TextureType_SAND",18);
define ("TextureType_STATIONERY",19);
define ("TextureType_UNKNOWN",24);
define ("TextureType_WALNUT",20);
define ("TextureType_WATER_DROPLETS",21);
define ("TextureType_WHITE_MARBLE",22);
define ("TextureType_WOVEN_MAT",23);
define ("ThemeColorType_ACCENT_1",4);
define ("ThemeColorType_ACCENT_2",5);
define ("ThemeColorType_ACCENT_3",6);
define ("ThemeColorType_ACCENT_4",7);
define ("ThemeColorType_ACCENT_5",8);
define ("ThemeColorType_ACCENT_6",9);
define ("ThemeColorType_BACKGROUND_1",0);
define ("ThemeColorType_BACKGROUND_2",2);
define ("ThemeColorType_FOLLOWED_HYPERLINK",11);
define ("ThemeColorType_HYPERLINK",10);
define ("ThemeColorType_TEXT_1",1);
define ("ThemeColorType_TEXT_2",3);
define ("TickLabelPositionType_HIGH",0);
define ("TickLabelPositionType_LOW",1);
define ("TickLabelPositionType_NEXT_TO_AXIS",2);
define ("TickLabelPositionType_NONE",3);
define ("TickMarkType_CROSS",0);
define ("TickMarkType_INSIDE",1);
define ("TickMarkType_NONE",2);
define ("TickMarkType_OUTSIDE",3);
define ("TiffCompression_COMPRESSION_CCITT_3",3);
define ("TiffCompression_COMPRESSION_CCITT_4",4);
define ("TiffCompression_COMPRESSION_LZW",2);
define ("TiffCompression_COMPRESSION_NONE",0);
define ("TiffCompression_COMPRESSION_RLE",1);
define ("TimePeriodType_LAST_7_DAYS",3);
define ("TimePeriodType_LAST_MONTH",5);
define ("TimePeriodType_LAST_WEEK",8);
define ("TimePeriodType_NEXT_MONTH",6);
define ("TimePeriodType_NEXT_WEEK",9);
define ("TimePeriodType_THIS_MONTH",4);
define ("TimePeriodType_THIS_WEEK",7);
define ("TimePeriodType_TODAY",0);
define ("TimePeriodType_TOMORROW",2);
define ("TimePeriodType_YESTERDAY",1);
define ("TimeUnit_DAYS",0);
define ("TimeUnit_MONTHS",1);
define ("TimeUnit_YEARS",2);
define ("TotalsCalculation_AVERAGE",1);
define ("TotalsCalculation_COUNT",2);
define ("TotalsCalculation_COUNT_NUMS",3);
define ("TotalsCalculation_CUSTOM",9);
define ("TotalsCalculation_MAX",4);
define ("TotalsCalculation_MIN",5);
define ("TotalsCalculation_NONE",0);
define ("TotalsCalculation_STD_DEV",7);
define ("TotalsCalculation_SUM",6);
define ("TotalsCalculation_VAR",8);
define ("TrendlineType_EXPONENTIAL",0);
define ("TrendlineType_LINEAR",1);
define ("TrendlineType_LOGARITHMIC",2);
define ("TrendlineType_MOVING_AVERAGE",3);
define ("TrendlineType_POLYNOMIAL",4);
define ("TrendlineType_POWER",5);
define ("ValidationAlertType_INFORMATION",0);
define ("ValidationAlertType_STOP",1);
define ("ValidationAlertType_WARNING",2);
define ("ValidationType_ANY_VALUE",0);
define ("ValidationType_CUSTOM",7);
define ("ValidationType_DATE",4);
define ("ValidationType_DECIMAL",2);
define ("ValidationType_LIST",3);
define ("ValidationType_TEXT_LENGTH",6);
define ("ValidationType_TIME",5);
define ("ValidationType_WHOLE_NUMBER",1);
define ("ViewType_NORMAL_VIEW",0);
define ("ViewType_PAGE_BREAK_PREVIEW",1);
define ("ViewType_PAGE_LAYOUT_VIEW",2);
define ("VisibilityType_HIDDEN",1);
define ("VisibilityType_VERY_HIDDEN",2);
define ("VisibilityType_VISIBLE",0);
define ("WeightType_HAIR_LINE",-1);
define ("WeightType_MEDIUM_LINE",1);
define ("WeightType_SINGLE_LINE",0);
define ("WeightType_WIDE_LINE",2);


/*
  Wrapper for java version Class [com.aspose.cellsAboveAverage]
  
 */
class AboveAverage
{
    public $m_AboveAverage;
    
    function __construct($aboveAverage)
    {
    	$this->m_AboveAverage = $aboveAverage;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsAboveAverage.getStdDev()]

      @return int
     */
    function getStdDev()
    {
        return $this->m_AboveAverage->getStdDev();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAboveAverage.isAboveAverage()]

      @return boolean
     */
    function isAboveAverage()
    {
        return $this->m_AboveAverage->isAboveAverage();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAboveAverage.isEqualAverage()]

      @return boolean
     */
    function isEqualAverage()
    {
        return $this->m_AboveAverage->isEqualAverage();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAboveAverage.setAboveAverage(boolean)]

      @param pBoolean0  boolean
     */
    function setAboveAverage($pBoolean0)
    {
        $this->m_AboveAverage->setAboveAverage($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAboveAverage.setEqualAverage(boolean)]

      @param pBoolean0  boolean
     */
    function setEqualAverage($pBoolean0)
    {
        $this->m_AboveAverage->setEqualAverage($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAboveAverage.setStdDev(int)]

      @param pInt0  int
     */
    function setStdDev($pInt0)
    {
        $this->m_AboveAverage->setStdDev($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsArcShape]
  
 */
class ArcShape extends Shape
{
    public $m_ArcShape;
    
    function __construct($arcShape)
    {
    	$this->m_ArcShape = $arcShape;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsArcShape.characters(int, int)]

      @param pInt0  int
      @param pInt1  int
      @return com.aspose.cells.FontSetting
     */
    function characters($pInt0, $pInt1)
    {
        return ClassFactory::_t2($this->m_ArcShape->characters($pInt0, $pInt1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsArcShape.getBeginArrowheadLength()]

      @return int
     */
    function getBeginArrowheadLength()
    {
        return $this->m_ArcShape->getBeginArrowheadLength();
    }

    /*
      Wrapper for java version method [com.aspose.cellsArcShape.getBeginArrowheadStyle()]

      @return int
     */
    function getBeginArrowheadStyle()
    {
        return $this->m_ArcShape->getBeginArrowheadStyle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsArcShape.getBeginArrowheadWidth()]

      @return int
     */
    function getBeginArrowheadWidth()
    {
        return $this->m_ArcShape->getBeginArrowheadWidth();
    }

    /*
      Wrapper for java version method [com.aspose.cellsArcShape.getCharacters()]

      @return array, corresponding java type is {java.util.ArrayList}
     */
    function getCharacters()
    {
        return ClassFactory::_t2($this->m_ArcShape->getCharacters());
    }

    /*
      Wrapper for java version method [com.aspose.cellsArcShape.getEndArrowheadLength()]

      @return int
     */
    function getEndArrowheadLength()
    {
        return $this->m_ArcShape->getEndArrowheadLength();
    }

    /*
      Wrapper for java version method [com.aspose.cellsArcShape.getEndArrowheadStyle()]

      @return int
     */
    function getEndArrowheadStyle()
    {
        return $this->m_ArcShape->getEndArrowheadStyle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsArcShape.getEndArrowheadWidth()]

      @return int
     */
    function getEndArrowheadWidth()
    {
        return $this->m_ArcShape->getEndArrowheadWidth();
    }

    /*
      Wrapper for java version method [com.aspose.cellsArcShape.setBeginArrowheadLength(int)]

      @param pInt0  int
     */
    function setBeginArrowheadLength($pInt0)
    {
        $this->m_ArcShape->setBeginArrowheadLength($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsArcShape.setBeginArrowheadStyle(int)]

      @param pInt0  int
     */
    function setBeginArrowheadStyle($pInt0)
    {
        $this->m_ArcShape->setBeginArrowheadStyle($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsArcShape.setBeginArrowheadWidth(int)]

      @param pInt0  int
     */
    function setBeginArrowheadWidth($pInt0)
    {
        $this->m_ArcShape->setBeginArrowheadWidth($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsArcShape.setEndArrowheadLength(int)]

      @param pInt0  int
     */
    function setEndArrowheadLength($pInt0)
    {
        $this->m_ArcShape->setEndArrowheadLength($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsArcShape.setEndArrowheadStyle(int)]

      @param pInt0  int
     */
    function setEndArrowheadStyle($pInt0)
    {
        $this->m_ArcShape->setEndArrowheadStyle($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsArcShape.setEndArrowheadWidth(int)]

      @param pInt0  int
     */
    function setEndArrowheadWidth($pInt0)
    {
        $this->m_ArcShape->setEndArrowheadWidth($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsArea]
  
 */
class Area
{
    public $m_Area;
    
    function __construct($area)
    {
    	$this->m_Area = $area;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsArea.getBackgroundColor()]

      @return com.aspose.cells.Color
     */
    function getBackgroundColor()
    {
        return ClassFactory::_t2($this->m_Area->getBackgroundColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsArea.getFillFormat()]

      @return com.aspose.cells.FillFormat
     */
    function getFillFormat()
    {
        return ClassFactory::_t2($this->m_Area->getFillFormat());
    }

    /*
      Wrapper for java version method [com.aspose.cellsArea.getForegroundColor()]

      @return com.aspose.cells.Color
     */
    function getForegroundColor()
    {
        return ClassFactory::_t2($this->m_Area->getForegroundColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsArea.getFormatting()]

      @return int
     */
    function getFormatting()
    {
        return $this->m_Area->getFormatting();
    }

    /*
      Wrapper for java version method [com.aspose.cellsArea.getInvertIfNegative()]

      @return boolean
     */
    function getInvertIfNegative()
    {
        return $this->m_Area->getInvertIfNegative();
    }

    /*
      Wrapper for java version method [com.aspose.cellsArea.getTransparency()]

      @return double
     */
    function getTransparency()
    {
        return $this->m_Area->getTransparency();
    }

    /*
      Wrapper for java version method [com.aspose.cellsArea.setBackgroundColor(Color)]

      @param oColor0  com.aspose.cells.Color
     */
    function setBackgroundColor($oColor0)
    {
        $this->m_Area->setBackgroundColor(ClassFactory::_t1($oColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsArea.setForegroundColor(Color)]

      @param oColor0  com.aspose.cells.Color
     */
    function setForegroundColor($oColor0)
    {
        $this->m_Area->setForegroundColor(ClassFactory::_t1($oColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsArea.setFormatting(int)]

      @param pInt0  int
     */
    function setFormatting($pInt0)
    {
        $this->m_Area->setFormatting($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsArea.setInvertIfNegative(boolean)]

      @param pBoolean0  boolean
     */
    function setInvertIfNegative($pBoolean0)
    {
        $this->m_Area->setInvertIfNegative($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsArea.setTransparency(double)]

      @param pDouble0  double
     */
    function setTransparency($pDouble0)
    {
        $this->m_Area->setTransparency($pDouble0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsAsposeDataTable]
  
 */
class AsposeDataTable
{
    public $m_AsposeDataTable;
    
    function __construct($asposeDataTable)
    {
    	$this->m_AsposeDataTable = $asposeDataTable;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsAsposeDataTable.beforeFirst()]

     */
    function beforeFirst()
    {
        $this->m_AsposeDataTable->beforeFirst();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAsposeDataTable.get(String)]

      @param oString0  String
      @return corresponding java type is {java.lang.Object}
     */
    function get($oString0)
    {
        return ClassFactory::_t2($this->m_AsposeDataTable->get($oString0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsAsposeDataTable.get(int)]

      @param pInt0  int
      @return corresponding java type is {java.lang.Object}
     */
    function getI($pInt0)
    {
        return ClassFactory::_t2($this->m_AsposeDataTable->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsAsposeDataTable.getColumns()]

      @return array, corresponding java type is {String[]}
     */
    function getColumns()
    {
        return $this->m_AsposeDataTable->getColumns();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAsposeDataTable.next()]

      @return boolean
     */
    function next()
    {
        return $this->m_AsposeDataTable->next();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAsposeDataTable.size()]

      @return int
     */
    function size()
    {
        return $this->m_AsposeDataTable->size();
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsAutoFilter]
  
 */
class AutoFilter
{
    public $m_AutoFilter;
    
    function __construct($autoFilter)
    {
    	$this->m_AutoFilter = $autoFilter;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsAutoFilter.addDateFilter(int, int, int, int, int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @param pInt4  int
      @param pInt5  int
      @param pInt6  int
      @param pInt7  int
     */
    function addDateFilter($pInt0, $pInt1, $pInt2, $pInt3, $pInt4, $pInt5, $pInt6, $pInt7)
    {
        $this->m_AutoFilter->addDateFilter($pInt0, $pInt1, $pInt2, $pInt3, $pInt4, $pInt5, $pInt6, $pInt7);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAutoFilter.addFillColorFilter(int, int, CellsColor, CellsColor)]

      @param pInt0  int
      @param pInt1  int
      @param oCellsColor2  com.aspose.cells.CellsColor
      @param oCellsColor3  com.aspose.cells.CellsColor
     */
    function addFillColorFilter($pInt0, $pInt1, $oCellsColor2, $oCellsColor3)
    {
        $this->m_AutoFilter->addFillColorFilter($pInt0, $pInt1, ClassFactory::_t1($oCellsColor2), ClassFactory::_t1($oCellsColor3));
    }

    /*
      Wrapper for java version method [com.aspose.cellsAutoFilter.addFilter(int, String)]

      @param pInt0  int
      @param oString1  String
     */
    function addFilter($pInt0, $oString1)
    {
        $this->m_AutoFilter->addFilter($pInt0, $oString1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAutoFilter.addFontColorFilter(int, CellsColor)]

      @param pInt0  int
      @param oCellsColor1  com.aspose.cells.CellsColor
     */
    function addFontColorFilter($pInt0, $oCellsColor1)
    {
        $this->m_AutoFilter->addFontColorFilter($pInt0, ClassFactory::_t1($oCellsColor1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsAutoFilter.addIconFilter(int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
     */
    function addIconFilter($pInt0, $pInt1, $pInt2)
    {
        $this->m_AutoFilter->addIconFilter($pInt0, $pInt1, $pInt2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAutoFilter.custom(int, int, Object)]

      @param pInt0  int
      @param pInt1  int
      @param oObject2  corresponding java type is {java.lang.Object}
     */
    function custom($pInt0, $pInt1, $oObject2)
    {
        $this->m_AutoFilter->custom($pInt0, $pInt1, ClassFactory::_t1($oObject2));
    }

    /*
      Wrapper for java version method [com.aspose.cellsAutoFilter.custom(int, int, Object, boolean, int, Object)]

      @param pInt0  int
      @param pInt1  int
      @param oObject2  corresponding java type is {java.lang.Object}
      @param pBoolean3  boolean
      @param pInt4  int
      @param oObject5  corresponding java type is {java.lang.Object}
     */
    function customIIOBIO($pInt0, $pInt1, $oObject2, $pBoolean3, $pInt4, $oObject5)
    {
        $this->m_AutoFilter->custom($pInt0, $pInt1, ClassFactory::_t1($oObject2), $pBoolean3, $pInt4, ClassFactory::_t1($oObject5));
    }

    /*
      Wrapper for java version method [com.aspose.cellsAutoFilter.dynamicFilter(int, int)]

      @param pInt0  int
      @param pInt1  int
     */
    function dynamicFilter($pInt0, $pInt1)
    {
        $this->m_AutoFilter->dynamicFilter($pInt0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAutoFilter.filter(int, String)]

      @param pInt0  int
      @param oString1  String
     */
    function filter($pInt0, $oString1)
    {
        $this->m_AutoFilter->filter($pInt0, $oString1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAutoFilter.filterTop10(int, boolean, boolean, int)]

      @param pInt0  int
      @param pBoolean1  boolean
      @param pBoolean2  boolean
      @param pInt3  int
     */
    function filterTop10($pInt0, $pBoolean1, $pBoolean2, $pInt3)
    {
        $this->m_AutoFilter->filterTop10($pInt0, $pBoolean1, $pBoolean2, $pInt3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAutoFilter.getFilterColumnCollection()]

      @return com.aspose.cells.FilterColumnCollection
     */
    function getFilterColumnCollection()
    {
        return ClassFactory::_t2($this->m_AutoFilter->getFilterColumnCollection());
    }

    /*
      Wrapper for java version method [com.aspose.cellsAutoFilter.getRange()]

      @return String
     */
    function getRange()
    {
        return $this->m_AutoFilter->getRange();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAutoFilter.getSorter()]

      @return com.aspose.cells.DataSorter
     */
    function getSorter()
    {
        return ClassFactory::_t2($this->m_AutoFilter->getSorter());
    }

    /*
      Wrapper for java version method [com.aspose.cellsAutoFilter.matchBlanks(int)]

      @param pInt0  int
     */
    function matchBlanks($pInt0)
    {
        $this->m_AutoFilter->matchBlanks($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAutoFilter.matchNonBlanks(int)]

      @param pInt0  int
     */
    function matchNonBlanks($pInt0)
    {
        $this->m_AutoFilter->matchNonBlanks($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAutoFilter.refresh()]

     */
    function refresh()
    {
        $this->m_AutoFilter->refresh();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAutoFilter.removeDateFilter(int, int, int, int, int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @param pInt4  int
      @param pInt5  int
      @param pInt6  int
      @param pInt7  int
     */
    function removeDateFilter($pInt0, $pInt1, $pInt2, $pInt3, $pInt4, $pInt5, $pInt6, $pInt7)
    {
        $this->m_AutoFilter->removeDateFilter($pInt0, $pInt1, $pInt2, $pInt3, $pInt4, $pInt5, $pInt6, $pInt7);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAutoFilter.removeFilter(int)]

      @param pInt0  int
     */
    function removeFilter($pInt0)
    {
        $this->m_AutoFilter->removeFilter($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAutoFilter.removeFilter(int, String)]

      @param pInt0  int
      @param oString1  String
     */
    function removeFilterIS($pInt0, $oString1)
    {
        $this->m_AutoFilter->removeFilter($pInt0, $oString1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAutoFilter.setRange(String)]

      @param oString0  String
     */
    function setRange($oString0)
    {
        $this->m_AutoFilter->setRange($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAutoFilter.setRange(int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
     */
    function setRangeIII($pInt0, $pInt1, $pInt2)
    {
        $this->m_AutoFilter->setRange($pInt0, $pInt1, $pInt2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAutoFilter.showAll()]

     */
    function showAll()
    {
        $this->m_AutoFilter->showAll();
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsAutoFitterOptions]
  
 */
class AutoFitterOptions
{
    public $m_AutoFitterOptions;
    
    function __construct($autoFitterOptions)
    {
    	$this->m_AutoFitterOptions = $autoFitterOptions;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsAutoFitterOptions.getAutoFitMergedCells()]

      @return boolean
     */
    function getAutoFitMergedCells()
    {
        return $this->m_AutoFitterOptions->getAutoFitMergedCells();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAutoFitterOptions.getIgnoreHidden()]

      @return boolean
     */
    function getIgnoreHidden()
    {
        return $this->m_AutoFitterOptions->getIgnoreHidden();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAutoFitterOptions.getOnlyAuto()]

      @return boolean
     */
    function getOnlyAuto()
    {
        return $this->m_AutoFitterOptions->getOnlyAuto();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAutoFitterOptions.setAutoFitMergedCells(boolean)]

      @param pBoolean0  boolean
     */
    function setAutoFitMergedCells($pBoolean0)
    {
        $this->m_AutoFitterOptions->setAutoFitMergedCells($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAutoFitterOptions.setIgnoreHidden(boolean)]

      @param pBoolean0  boolean
     */
    function setIgnoreHidden($pBoolean0)
    {
        $this->m_AutoFitterOptions->setIgnoreHidden($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAutoFitterOptions.setOnlyAuto(boolean)]

      @param pBoolean0  boolean
     */
    function setOnlyAuto($pBoolean0)
    {
        $this->m_AutoFitterOptions->setOnlyAuto($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsAutoShapeType]
  
 */
class AutoShapeType
{
    public $m_AutoShapeType;
    
    function __construct($autoShapeType)
    {
    	$this->m_AutoShapeType = $autoShapeType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsAxis]
  
 */
class Axis
{
    public $m_Axis;
    
    function __construct($axis)
    {
    	$this->m_Axis = $axis;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsAxis.getAxisBetweenCategories()]

      @return boolean
     */
    function getAxisBetweenCategories()
    {
        return $this->m_Axis->getAxisBetweenCategories();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.getAxisLine()]

      @return com.aspose.cells.Line
     */
    function getAxisLine()
    {
        return ClassFactory::_t2($this->m_Axis->getAxisLine());
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.getBaseUnitScale()]

      @return int
     */
    function getBaseUnitScale()
    {
        return $this->m_Axis->getBaseUnitScale();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.getCategoryType()]

      @return int
     */
    function getCategoryType()
    {
        return $this->m_Axis->getCategoryType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.getCrossAt()]

      @return double
     */
    function getCrossAt()
    {
        return $this->m_Axis->getCrossAt();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.getCrossType()]

      @return int
     */
    function getCrossType()
    {
        return $this->m_Axis->getCrossType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.getCrosses()]

      @return int
     */
    function getCrosses()
    {
        return $this->m_Axis->getCrosses();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.getDisplayUnit()]

      @return int
     */
    function getDisplayUnit()
    {
        return $this->m_Axis->getDisplayUnit();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.getDisplayUnitLabel()]

      @return com.aspose.cells.DisplayUnitLabel
     */
    function getDisplayUnitLabel()
    {
        return ClassFactory::_t2($this->m_Axis->getDisplayUnitLabel());
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.getLogBase()]

      @return double
     */
    function getLogBase()
    {
        return $this->m_Axis->getLogBase();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.getMajorGridLines()]

      @return com.aspose.cells.Line
     */
    function getMajorGridLines()
    {
        return ClassFactory::_t2($this->m_Axis->getMajorGridLines());
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.getMajorTickMark()]

      @return int
     */
    function getMajorTickMark()
    {
        return $this->m_Axis->getMajorTickMark();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.getMajorUnit()]

      @return double
     */
    function getMajorUnit()
    {
        return $this->m_Axis->getMajorUnit();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.getMajorUnitScale()]

      @return int
     */
    function getMajorUnitScale()
    {
        return $this->m_Axis->getMajorUnitScale();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.getMaxValue()]

      @return corresponding java type is {java.lang.Object}
     */
    function getMaxValue()
    {
        return ClassFactory::_t2($this->m_Axis->getMaxValue());
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.getMinValue()]

      @return corresponding java type is {java.lang.Object}
     */
    function getMinValue()
    {
        return ClassFactory::_t2($this->m_Axis->getMinValue());
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.getMinorGridLines()]

      @return com.aspose.cells.Line
     */
    function getMinorGridLines()
    {
        return ClassFactory::_t2($this->m_Axis->getMinorGridLines());
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.getMinorTickMark()]

      @return int
     */
    function getMinorTickMark()
    {
        return $this->m_Axis->getMinorTickMark();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.getMinorUnit()]

      @return double
     */
    function getMinorUnit()
    {
        return $this->m_Axis->getMinorUnit();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.getMinorUnitScale()]

      @return int
     */
    function getMinorUnitScale()
    {
        return $this->m_Axis->getMinorUnitScale();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.getTickLabelPosition()]

      @return int
     */
    function getTickLabelPosition()
    {
        return $this->m_Axis->getTickLabelPosition();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.getTickLabelSpacing()]

      @return int
     */
    function getTickLabelSpacing()
    {
        return $this->m_Axis->getTickLabelSpacing();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.getTickLabels()]

      @return com.aspose.cells.TickLabels
     */
    function getTickLabels()
    {
        return ClassFactory::_t2($this->m_Axis->getTickLabels());
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.getTickMarkSpacing()]

      @return int
     */
    function getTickMarkSpacing()
    {
        return $this->m_Axis->getTickMarkSpacing();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.getTitle()]

      @return com.aspose.cells.Title
     */
    function getTitle()
    {
        return ClassFactory::_t2($this->m_Axis->getTitle());
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.isAutomaticMajorUnit()]

      @return boolean
     */
    function isAutomaticMajorUnit()
    {
        return $this->m_Axis->isAutomaticMajorUnit();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.isAutomaticMaxValue()]

      @return boolean
     */
    function isAutomaticMaxValue()
    {
        return $this->m_Axis->isAutomaticMaxValue();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.isAutomaticMinValue()]

      @return boolean
     */
    function isAutomaticMinValue()
    {
        return $this->m_Axis->isAutomaticMinValue();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.isAutomaticMinorUnit()]

      @return boolean
     */
    function isAutomaticMinorUnit()
    {
        return $this->m_Axis->isAutomaticMinorUnit();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.isDisplayUnitLabelShown()]

      @return boolean
     */
    function isDisplayUnitLabelShown()
    {
        return $this->m_Axis->isDisplayUnitLabelShown();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.isLogarithmic()]

      @return boolean
     */
    function isLogarithmic()
    {
        return $this->m_Axis->isLogarithmic();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.isPlotOrderReversed()]

      @return boolean
     */
    function isPlotOrderReversed()
    {
        return $this->m_Axis->isPlotOrderReversed();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.isVisible()]

      @return boolean
     */
    function isVisible()
    {
        return $this->m_Axis->isVisible();
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.setAutomaticMajorUnit(boolean)]

      @param pBoolean0  boolean
     */
    function setAutomaticMajorUnit($pBoolean0)
    {
        $this->m_Axis->setAutomaticMajorUnit($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.setAutomaticMaxValue(boolean)]

      @param pBoolean0  boolean
     */
    function setAutomaticMaxValue($pBoolean0)
    {
        $this->m_Axis->setAutomaticMaxValue($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.setAutomaticMinValue(boolean)]

      @param pBoolean0  boolean
     */
    function setAutomaticMinValue($pBoolean0)
    {
        $this->m_Axis->setAutomaticMinValue($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.setAutomaticMinorUnit(boolean)]

      @param pBoolean0  boolean
     */
    function setAutomaticMinorUnit($pBoolean0)
    {
        $this->m_Axis->setAutomaticMinorUnit($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.setAxisBetweenCategories(boolean)]

      @param pBoolean0  boolean
     */
    function setAxisBetweenCategories($pBoolean0)
    {
        $this->m_Axis->setAxisBetweenCategories($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.setBaseUnitScale(int)]

      @param pInt0  int
     */
    function setBaseUnitScale($pInt0)
    {
        $this->m_Axis->setBaseUnitScale($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.setCategoryType(int)]

      @param pInt0  int
     */
    function setCategoryType($pInt0)
    {
        $this->m_Axis->setCategoryType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.setCrossAt(double)]

      @param pDouble0  double
     */
    function setCrossAt($pDouble0)
    {
        $this->m_Axis->setCrossAt($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.setCrossType(int)]

      @param pInt0  int
     */
    function setCrossType($pInt0)
    {
        $this->m_Axis->setCrossType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.setCrosses(int)]

      @param pInt0  int
     */
    function setCrosses($pInt0)
    {
        $this->m_Axis->setCrosses($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.setDisplayUnit(int)]

      @param pInt0  int
     */
    function setDisplayUnit($pInt0)
    {
        $this->m_Axis->setDisplayUnit($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.setDisplayUnitLabelShown(boolean)]

      @param pBoolean0  boolean
     */
    function setDisplayUnitLabelShown($pBoolean0)
    {
        $this->m_Axis->setDisplayUnitLabelShown($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.setLogBase(double)]

      @param pDouble0  double
     */
    function setLogBase($pDouble0)
    {
        $this->m_Axis->setLogBase($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.setLogarithmic(boolean)]

      @param pBoolean0  boolean
     */
    function setLogarithmic($pBoolean0)
    {
        $this->m_Axis->setLogarithmic($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.setMajorTickMark(int)]

      @param pInt0  int
     */
    function setMajorTickMark($pInt0)
    {
        $this->m_Axis->setMajorTickMark($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.setMajorUnit(double)]

      @param pDouble0  double
     */
    function setMajorUnit($pDouble0)
    {
        $this->m_Axis->setMajorUnit($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.setMajorUnitScale(int)]

      @param pInt0  int
     */
    function setMajorUnitScale($pInt0)
    {
        $this->m_Axis->setMajorUnitScale($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.setMaxValue(Object)]

      @param oObject0  corresponding java type is {java.lang.Object}
     */
    function setMaxValue($oObject0)
    {
        $this->m_Axis->setMaxValue(ClassFactory::_t1($oObject0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.setMinValue(Object)]

      @param oObject0  corresponding java type is {java.lang.Object}
     */
    function setMinValue($oObject0)
    {
        $this->m_Axis->setMinValue(ClassFactory::_t1($oObject0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.setMinorTickMark(int)]

      @param pInt0  int
     */
    function setMinorTickMark($pInt0)
    {
        $this->m_Axis->setMinorTickMark($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.setMinorUnit(double)]

      @param pDouble0  double
     */
    function setMinorUnit($pDouble0)
    {
        $this->m_Axis->setMinorUnit($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.setMinorUnitScale(int)]

      @param pInt0  int
     */
    function setMinorUnitScale($pInt0)
    {
        $this->m_Axis->setMinorUnitScale($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.setPlotOrderReversed(boolean)]

      @param pBoolean0  boolean
     */
    function setPlotOrderReversed($pBoolean0)
    {
        $this->m_Axis->setPlotOrderReversed($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.setTickLabelPosition(int)]

      @param pInt0  int
     */
    function setTickLabelPosition($pInt0)
    {
        $this->m_Axis->setTickLabelPosition($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.setTickLabelSpacing(int)]

      @param pInt0  int
     */
    function setTickLabelSpacing($pInt0)
    {
        $this->m_Axis->setTickLabelSpacing($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.setTickMarkSpacing(int)]

      @param pInt0  int
     */
    function setTickMarkSpacing($pInt0)
    {
        $this->m_Axis->setTickMarkSpacing($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsAxis.setVisible(boolean)]

      @param pBoolean0  boolean
     */
    function setVisible($pBoolean0)
    {
        $this->m_Axis->setVisible($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsBackgroundMode]
  
 */
class BackgroundMode
{
    public $m_BackgroundMode;
    
    function __construct($backgroundMode)
    {
    	$this->m_BackgroundMode = $backgroundMode;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsBackgroundType]
  
 */
class BackgroundType
{
    public $m_BackgroundType;
    
    function __construct($backgroundType)
    {
    	$this->m_BackgroundType = $backgroundType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsBar3DShapeType]
  
 */
class Bar3DShapeType
{
    public $m_Bar3DShapeType;
    
    function __construct($bar3DShapeType)
    {
    	$this->m_Bar3DShapeType = $bar3DShapeType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsBevel]
  
 */
class Bevel
{
    public $m_Bevel;
    
    function __construct($bevel)
    {
    	$this->m_Bevel = $bevel;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsBevel.getHeight()]

      @return double
     */
    function getHeight()
    {
        return $this->m_Bevel->getHeight();
    }

    /*
      Wrapper for java version method [com.aspose.cellsBevel.getType()]

      @return int
     */
    function getType()
    {
        return $this->m_Bevel->getType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsBevel.getWidth()]

      @return double
     */
    function getWidth()
    {
        return $this->m_Bevel->getWidth();
    }

    /*
      Wrapper for java version method [com.aspose.cellsBevel.setHeight(double)]

      @param pDouble0  double
     */
    function setHeight($pDouble0)
    {
        $this->m_Bevel->setHeight($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsBevel.setType(int)]

      @param pInt0  int
     */
    function setType($pInt0)
    {
        $this->m_Bevel->setType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsBevel.setWidth(double)]

      @param pDouble0  double
     */
    function setWidth($pDouble0)
    {
        $this->m_Bevel->setWidth($pDouble0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsBevelPresetType]
  
 */
class BevelPresetType
{
    public $m_BevelPresetType;
    
    function __construct($bevelPresetType)
    {
    	$this->m_BevelPresetType = $bevelPresetType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsBorder]
  
 */
class Border
{
    public $m_Border;
    
    function __construct($border)
    {
    	$this->m_Border = $border;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsBorder.getColor()]

      @return com.aspose.cells.Color
     */
    function getColor()
    {
        return ClassFactory::_t2($this->m_Border->getColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsBorder.getLineStyle()]

      @return int
     */
    function getLineStyle()
    {
        return $this->m_Border->getLineStyle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsBorder.setColor(Color)]

      @param oColor0  com.aspose.cells.Color
     */
    function setColor($oColor0)
    {
        $this->m_Border->setColor(ClassFactory::_t1($oColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsBorder.setLineStyle(int)]

      @param pInt0  int
     */
    function setLineStyle($pInt0)
    {
        $this->m_Border->setLineStyle($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsBorderCollection]
  
 */
class BorderCollection
{
    public $m_BorderCollection;
    
    function __construct($borderCollection)
    {
    	$this->m_BorderCollection = $borderCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsBorderCollection.getByBorderType(int)]

      @param pInt0  int
      @return com.aspose.cells.Border
     */
    function getByBorderType($pInt0)
    {
        return ClassFactory::_t2($this->m_BorderCollection->getByBorderType($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsBorderCollection.getDiagonalColor()]

      @return com.aspose.cells.Color
     */
    function getDiagonalColor()
    {
        return ClassFactory::_t2($this->m_BorderCollection->getDiagonalColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsBorderCollection.getDiagonalStyle()]

      @return int
     */
    function getDiagonalStyle()
    {
        return $this->m_BorderCollection->getDiagonalStyle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsBorderCollection.setColor(Color)]

      @param oColor0  com.aspose.cells.Color
     */
    function setColor($oColor0)
    {
        $this->m_BorderCollection->setColor(ClassFactory::_t1($oColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsBorderCollection.setDiagonalColor(Color)]

      @param oColor0  com.aspose.cells.Color
     */
    function setDiagonalColor($oColor0)
    {
        $this->m_BorderCollection->setDiagonalColor(ClassFactory::_t1($oColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsBorderCollection.setDiagonalStyle(int)]

      @param pInt0  int
     */
    function setDiagonalStyle($pInt0)
    {
        $this->m_BorderCollection->setDiagonalStyle($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsBorderCollection.setStyle(int)]

      @param pInt0  int
     */
    function setStyle($pInt0)
    {
        $this->m_BorderCollection->setStyle($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsBorderType]
  
 */
class BorderType
{
    public $m_BorderType;
    
    function __construct($borderType)
    {
    	$this->m_BorderType = $borderType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsBubbleSizeRepresents]
  
 */
class BubbleSizeRepresents
{
    public $m_BubbleSizeRepresents;
    
    function __construct($bubbleSizeRepresents)
    {
    	$this->m_BubbleSizeRepresents = $bubbleSizeRepresents;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsBuiltInDocumentPropertyCollection]
  
 */
class BuiltInDocumentPropertyCollection extends DocumentPropertyCollection
{
    public $m_BuiltInDocumentPropertyCollection;
    
    function __construct($builtInDocumentPropertyCollection)
    {
    	$this->m_BuiltInDocumentPropertyCollection = $builtInDocumentPropertyCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.get(String)]

      @param oString0  String
      @return com.aspose.cells.DocumentProperty
     */
    function get($oString0)
    {
        return ClassFactory::_t2($this->m_BuiltInDocumentPropertyCollection->get($oString0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.getAuthor()]

      @return String
     */
    function getAuthor()
    {
        return $this->m_BuiltInDocumentPropertyCollection->getAuthor();
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.getBytes()]

      @return int
     */
    function getBytes()
    {
        return $this->m_BuiltInDocumentPropertyCollection->getBytes();
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.getCategory()]

      @return String
     */
    function getCategory()
    {
        return $this->m_BuiltInDocumentPropertyCollection->getCategory();
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.getCharacters()]

      @return int
     */
    function getCharacters()
    {
        return $this->m_BuiltInDocumentPropertyCollection->getCharacters();
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.getCharactersWithSpaces()]

      @return int
     */
    function getCharactersWithSpaces()
    {
        return $this->m_BuiltInDocumentPropertyCollection->getCharactersWithSpaces();
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.getComments()]

      @return String
     */
    function getComments()
    {
        return $this->m_BuiltInDocumentPropertyCollection->getComments();
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.getCompany()]

      @return String
     */
    function getCompany()
    {
        return $this->m_BuiltInDocumentPropertyCollection->getCompany();
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.getContentStatus()]

      @return String
     */
    function getContentStatus()
    {
        return $this->m_BuiltInDocumentPropertyCollection->getContentStatus();
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.getContentType()]

      @return String
     */
    function getContentType()
    {
        return $this->m_BuiltInDocumentPropertyCollection->getContentType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.getCreatedTime()]

      @return com.aspose.cells.DateTime
     */
    function getCreatedTime()
    {
        return ClassFactory::_t2($this->m_BuiltInDocumentPropertyCollection->getCreatedTime());
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.getHyperlinkBase()]

      @return String
     */
    function getHyperlinkBase()
    {
        return $this->m_BuiltInDocumentPropertyCollection->getHyperlinkBase();
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.getKeywords()]

      @return String
     */
    function getKeywords()
    {
        return $this->m_BuiltInDocumentPropertyCollection->getKeywords();
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.getLastPrinted()]

      @return com.aspose.cells.DateTime
     */
    function getLastPrinted()
    {
        return ClassFactory::_t2($this->m_BuiltInDocumentPropertyCollection->getLastPrinted());
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.getLastSavedBy()]

      @return String
     */
    function getLastSavedBy()
    {
        return $this->m_BuiltInDocumentPropertyCollection->getLastSavedBy();
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.getLastSavedTime()]

      @return com.aspose.cells.DateTime
     */
    function getLastSavedTime()
    {
        return ClassFactory::_t2($this->m_BuiltInDocumentPropertyCollection->getLastSavedTime());
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.getLines()]

      @return int
     */
    function getLines()
    {
        return $this->m_BuiltInDocumentPropertyCollection->getLines();
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.getManager()]

      @return String
     */
    function getManager()
    {
        return $this->m_BuiltInDocumentPropertyCollection->getManager();
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.getNameOfApplication()]

      @return String
     */
    function getNameOfApplication()
    {
        return $this->m_BuiltInDocumentPropertyCollection->getNameOfApplication();
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.getPages()]

      @return int
     */
    function getPages()
    {
        return $this->m_BuiltInDocumentPropertyCollection->getPages();
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.getParagraphs()]

      @return int
     */
    function getParagraphs()
    {
        return $this->m_BuiltInDocumentPropertyCollection->getParagraphs();
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.getRevisionNumber()]

      @return int
     */
    function getRevisionNumber()
    {
        return $this->m_BuiltInDocumentPropertyCollection->getRevisionNumber();
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.getSubject()]

      @return String
     */
    function getSubject()
    {
        return $this->m_BuiltInDocumentPropertyCollection->getSubject();
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.getTemplate()]

      @return String
     */
    function getTemplate()
    {
        return $this->m_BuiltInDocumentPropertyCollection->getTemplate();
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.getTitle()]

      @return String
     */
    function getTitle()
    {
        return $this->m_BuiltInDocumentPropertyCollection->getTitle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.getTotalEditingTime()]

      @return double
     */
    function getTotalEditingTime()
    {
        return $this->m_BuiltInDocumentPropertyCollection->getTotalEditingTime();
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.getVersion()]

      @return int
     */
    function getVersion()
    {
        return $this->m_BuiltInDocumentPropertyCollection->getVersion();
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.getWords()]

      @return int
     */
    function getWords()
    {
        return $this->m_BuiltInDocumentPropertyCollection->getWords();
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.setAuthor(String)]

      @param oString0  String
     */
    function setAuthor($oString0)
    {
        $this->m_BuiltInDocumentPropertyCollection->setAuthor($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.setBytes(int)]

      @param pInt0  int
     */
    function setBytes($pInt0)
    {
        $this->m_BuiltInDocumentPropertyCollection->setBytes($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.setCategory(String)]

      @param oString0  String
     */
    function setCategory($oString0)
    {
        $this->m_BuiltInDocumentPropertyCollection->setCategory($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.setCharacters(int)]

      @param pInt0  int
     */
    function setCharacters($pInt0)
    {
        $this->m_BuiltInDocumentPropertyCollection->setCharacters($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.setCharactersWithSpaces(int)]

      @param pInt0  int
     */
    function setCharactersWithSpaces($pInt0)
    {
        $this->m_BuiltInDocumentPropertyCollection->setCharactersWithSpaces($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.setComments(String)]

      @param oString0  String
     */
    function setComments($oString0)
    {
        $this->m_BuiltInDocumentPropertyCollection->setComments($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.setCompany(String)]

      @param oString0  String
     */
    function setCompany($oString0)
    {
        $this->m_BuiltInDocumentPropertyCollection->setCompany($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.setContentStatus(String)]

      @param oString0  String
     */
    function setContentStatus($oString0)
    {
        $this->m_BuiltInDocumentPropertyCollection->setContentStatus($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.setContentType(String)]

      @param oString0  String
     */
    function setContentType($oString0)
    {
        $this->m_BuiltInDocumentPropertyCollection->setContentType($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.setCreatedTime(DateTime)]

      @param oDateTime0  com.aspose.cells.DateTime
     */
    function setCreatedTime($oDateTime0)
    {
        $this->m_BuiltInDocumentPropertyCollection->setCreatedTime(ClassFactory::_t1($oDateTime0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.setHyperlinkBase(String)]

      @param oString0  String
     */
    function setHyperlinkBase($oString0)
    {
        $this->m_BuiltInDocumentPropertyCollection->setHyperlinkBase($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.setKeywords(String)]

      @param oString0  String
     */
    function setKeywords($oString0)
    {
        $this->m_BuiltInDocumentPropertyCollection->setKeywords($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.setLastPrinted(DateTime)]

      @param oDateTime0  com.aspose.cells.DateTime
     */
    function setLastPrinted($oDateTime0)
    {
        $this->m_BuiltInDocumentPropertyCollection->setLastPrinted(ClassFactory::_t1($oDateTime0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.setLastSavedBy(String)]

      @param oString0  String
     */
    function setLastSavedBy($oString0)
    {
        $this->m_BuiltInDocumentPropertyCollection->setLastSavedBy($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.setLastSavedTime(DateTime)]

      @param oDateTime0  com.aspose.cells.DateTime
     */
    function setLastSavedTime($oDateTime0)
    {
        $this->m_BuiltInDocumentPropertyCollection->setLastSavedTime(ClassFactory::_t1($oDateTime0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.setLines(int)]

      @param pInt0  int
     */
    function setLines($pInt0)
    {
        $this->m_BuiltInDocumentPropertyCollection->setLines($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.setManager(String)]

      @param oString0  String
     */
    function setManager($oString0)
    {
        $this->m_BuiltInDocumentPropertyCollection->setManager($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.setNameOfApplication(String)]

      @param oString0  String
     */
    function setNameOfApplication($oString0)
    {
        $this->m_BuiltInDocumentPropertyCollection->setNameOfApplication($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.setPages(int)]

      @param pInt0  int
     */
    function setPages($pInt0)
    {
        $this->m_BuiltInDocumentPropertyCollection->setPages($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.setParagraphs(int)]

      @param pInt0  int
     */
    function setParagraphs($pInt0)
    {
        $this->m_BuiltInDocumentPropertyCollection->setParagraphs($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.setRevisionNumber(int)]

      @param pInt0  int
     */
    function setRevisionNumber($pInt0)
    {
        $this->m_BuiltInDocumentPropertyCollection->setRevisionNumber($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.setSubject(String)]

      @param oString0  String
     */
    function setSubject($oString0)
    {
        $this->m_BuiltInDocumentPropertyCollection->setSubject($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.setTemplate(String)]

      @param oString0  String
     */
    function setTemplate($oString0)
    {
        $this->m_BuiltInDocumentPropertyCollection->setTemplate($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.setTitle(String)]

      @param oString0  String
     */
    function setTitle($oString0)
    {
        $this->m_BuiltInDocumentPropertyCollection->setTitle($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.setTotalEditingTime(double)]

      @param pDouble0  double
     */
    function setTotalEditingTime($pDouble0)
    {
        $this->m_BuiltInDocumentPropertyCollection->setTotalEditingTime($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.setVersion(int)]

      @param pInt0  int
     */
    function setVersion($pInt0)
    {
        $this->m_BuiltInDocumentPropertyCollection->setVersion($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsBuiltInDocumentPropertyCollection.setWords(int)]

      @param pInt0  int
     */
    function setWords($pInt0)
    {
        $this->m_BuiltInDocumentPropertyCollection->setWords($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsBuiltinStyleType]
  
 */
class BuiltinStyleType
{
    public $m_BuiltinStyleType;
    
    function __construct($builtinStyleType)
    {
    	$this->m_BuiltinStyleType = $builtinStyleType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsButton]
  
 */
class Button extends Shape
{
    public $m_Button;
    
    function __construct($button)
    {
    	$this->m_Button = $button;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsCalcModeType]
  
 */
class CalcModeType
{
    public $m_CalcModeType;
    
    function __construct($calcModeType)
    {
    	$this->m_CalcModeType = $calcModeType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsCategoryType]
  
 */
class CategoryType
{
    public $m_CategoryType;
    
    function __construct($categoryType)
    {
    	$this->m_CategoryType = $categoryType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsCell]
  
 */
class Cell
{
    public $m_Cell;
    
    function __construct($cell)
    {
    	$this->m_Cell = $cell;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsCell.characters(int, int)]

      @param pInt0  int
      @param pInt1  int
      @return com.aspose.cells.FontSetting
     */
    function characters($pInt0, $pInt1)
    {
        return ClassFactory::_t2($this->m_Cell->characters($pInt0, $pInt1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.containsExternalLink()]

      @return boolean
     */
    function containsExternalLink()
    {
        return $this->m_Cell->containsExternalLink();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.copy(Cell)]

      @param oCell0  com.aspose.cells.Cell
     */
    function copy($oCell0)
    {
        $this->m_Cell->copy(ClassFactory::_t1($oCell0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.getArrayRange()]

      @return com.aspose.cells.CellArea
     */
    function getArrayRange()
    {
        return ClassFactory::_t2($this->m_Cell->getArrayRange());
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.getBoolValue()]

      @return boolean
     */
    function getBoolValue()
    {
        return $this->m_Cell->getBoolValue();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.getCharacters()]

      @return com.aspose.cells.FontSetting[]
     */
    function getCharacters()
    {
        return ClassFactory::_t2($this->m_Cell->getCharacters());
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.getColumn()]

      @return int
     */
    function getColumn()
    {
        return $this->m_Cell->getColumn();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.getConditionalStyle()]

      @return com.aspose.cells.Style
     */
    function getConditionalStyle()
    {
        return ClassFactory::_t2($this->m_Cell->getConditionalStyle());
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.getDateTimeValue()]

      @return com.aspose.cells.DateTime
     */
    function getDateTimeValue()
    {
        return ClassFactory::_t2($this->m_Cell->getDateTimeValue());
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.getDisplayStyle()]

      @return com.aspose.cells.Style
     */
    function getDisplayStyle()
    {
        return ClassFactory::_t2($this->m_Cell->getDisplayStyle());
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.getDoubleValue()]

      @return double
     */
    function getDoubleValue()
    {
        return $this->m_Cell->getDoubleValue();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.getFloatValue()]

      @return float
     */
    function getFloatValue()
    {
        return $this->m_Cell->getFloatValue();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.getFormatConditions()]

      @return com.aspose.cells.FormatConditionCollection
     */
    function getFormatConditions()
    {
        return ClassFactory::_t2($this->m_Cell->getFormatConditions());
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.getFormatCondtions()]

      @return com.aspose.cells.FormatConditionCollection
     */
    function getFormatCondtions()
    {
        return ClassFactory::_t2($this->m_Cell->getFormatCondtions());
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.getFormula()]

      @return String
     */
    function getFormula()
    {
        return $this->m_Cell->getFormula();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.getHtmlString()]

      @return String
     */
    function getHtmlString()
    {
        return $this->m_Cell->getHtmlString();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.getIntValue()]

      @return int
     */
    function getIntValue()
    {
        return $this->m_Cell->getIntValue();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.getMergedRange()]

      @return com.aspose.cells.Range
     */
    function getMergedRange()
    {
        return ClassFactory::_t2($this->m_Cell->getMergedRange());
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.getName()]

      @return String
     */
    function getName()
    {
        return $this->m_Cell->getName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.getPrecedents()]

      @return com.aspose.cells.ReferredAreaCollection
     */
    function getPrecedents()
    {
        return ClassFactory::_t2($this->m_Cell->getPrecedents());
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.getR1C1Formula()]

      @return String
     */
    function getR1C1Formula()
    {
        return $this->m_Cell->getR1C1Formula();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.getRow()]

      @return int
     */
    function getRow()
    {
        return $this->m_Cell->getRow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.getStringValue()]

      @return String
     */
    function getStringValue()
    {
        return $this->m_Cell->getStringValue();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.getStyle()]

      @return com.aspose.cells.Style
     */
    function getStyle()
    {
        return ClassFactory::_t2($this->m_Cell->getStyle());
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.getType()]

      @return int
     */
    function getType()
    {
        return $this->m_Cell->getType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.getValue()]

      @return corresponding java type is {java.lang.Object}
     */
    function getValue()
    {
        return ClassFactory::_t2($this->m_Cell->getValue());
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.getWorksheet()]

      @return com.aspose.cells.Worksheet
     */
    function getWorksheet()
    {
        return ClassFactory::_t2($this->m_Cell->getWorksheet());
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.isArrayHeader()]

      @return boolean
     */
    function isArrayHeader()
    {
        return $this->m_Cell->isArrayHeader();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.isErrorValue()]

      @return boolean
     */
    function isErrorValue()
    {
        return $this->m_Cell->isErrorValue();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.isFormula()]

      @return boolean
     */
    function isFormula()
    {
        return $this->m_Cell->isFormula();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.isInArray()]

      @return boolean
     */
    function isInArray()
    {
        return $this->m_Cell->isInArray();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.isMerged()]

      @return boolean
     */
    function isMerged()
    {
        return $this->m_Cell->isMerged();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.isRichText()]

      @return boolean
     */
    function isRichText()
    {
        return $this->m_Cell->isRichText();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.isStyleSet()]

      @return boolean
     */
    function isStyleSet()
    {
        return $this->m_Cell->isStyleSet();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.putValue(DateTime)]

      @param oDateTime0  com.aspose.cells.DateTime
     */
    function putValue($oDateTime0)
    {
        $this->m_Cell->putValue(ClassFactory::_t1($oDateTime0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.putValue(Object)]

      @param oObject0  corresponding java type is {java.lang.Object}
     */
    function putValueO($oObject0)
    {
        $this->m_Cell->putValue(ClassFactory::_t1($oObject0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.putValue(String)]

      @param oString0  String
     */
    function putValueS($oString0)
    {
        $this->m_Cell->putValue($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.putValue(boolean)]

      @param pBoolean0  boolean
     */
    function putValueB($pBoolean0)
    {
        $this->m_Cell->putValue($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.putValue(double)]

      @param pDouble0  double
     */
    function putValueD($pDouble0)
    {
        $this->m_Cell->putValue($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.putValue(int)]

      @param pInt0  int
     */
    function putValueI($pInt0)
    {
        $this->m_Cell->putValue($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.putValue(String, boolean)]

      @param oString0  String
      @param pBoolean1  boolean
     */
    function putValueSB($oString0, $pBoolean1)
    {
        $this->m_Cell->putValue($oString0, $pBoolean1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.setAddInFormula(String, String)]

      @param oString0  String
      @param oString1  String
     */
    function setAddInFormula($oString0, $oString1)
    {
        $this->m_Cell->setAddInFormula($oString0, $oString1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.setArrayFormula(String, int, int)]

      @param oString0  String
      @param pInt1  int
      @param pInt2  int
     */
    function setArrayFormula($oString0, $pInt1, $pInt2)
    {
        $this->m_Cell->setArrayFormula($oString0, $pInt1, $pInt2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.setFormula(String)]

      @param oString0  String
     */
    function setFormula($oString0)
    {
        $this->m_Cell->setFormula($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.setHtmlString(String)]

      @param oString0  String
     */
    function setHtmlString($oString0)
    {
        $this->m_Cell->setHtmlString($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.setR1C1Formula(String)]

      @param oString0  String
     */
    function setR1C1Formula($oString0)
    {
        $this->m_Cell->setR1C1Formula($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.setSharedFormula(String, int, int)]

      @param oString0  String
      @param pInt1  int
      @param pInt2  int
     */
    function setSharedFormula($oString0, $pInt1, $pInt2)
    {
        $this->m_Cell->setSharedFormula($oString0, $pInt1, $pInt2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.setStyle(Style)]

      @param oStyle0  com.aspose.cells.Style
     */
    function setStyle($oStyle0)
    {
        $this->m_Cell->setStyle(ClassFactory::_t1($oStyle0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.setStyle(Style, StyleFlag)]

      @param oStyle0  com.aspose.cells.Style
      @param oStyleFlag1  com.aspose.cells.StyleFlag
     */
    function setStyleSS($oStyle0, $oStyleFlag1)
    {
        $this->m_Cell->setStyle(ClassFactory::_t1($oStyle0), ClassFactory::_t1($oStyleFlag1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCell.setValue(Object)]

      @param oObject0  corresponding java type is {java.lang.Object}
     */
    function setValue($oObject0)
    {
        $this->m_Cell->setValue(ClassFactory::_t1($oObject0));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsCellArea]
  
 */
class CellArea
{
    public $m_CellArea;
    
    function __construct($cellArea)
    {
    	$this->m_CellArea = $cellArea;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsCellArea.compareTo(Object)]

      @param oObject0  corresponding java type is {java.lang.Object}
      @return int
     */
    function compareTo($oObject0)
    {
        return $this->m_CellArea->compareTo(ClassFactory::_t1($oObject0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellArea.createCellArea(String, String)]

      @param oString0  String
      @param oString1  String
      @return com.aspose.cells.CellArea
     */
    function createCellArea($oString0, $oString1)
    {
        return ClassFactory::_t2($this->m_CellArea->createCellArea($oString0, $oString1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellArea.createCellArea(int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @return com.aspose.cells.CellArea
     */
    function createCellAreaIIII($pInt0, $pInt1, $pInt2, $pInt3)
    {
        return ClassFactory::_t2($this->m_CellArea->createCellArea($pInt0, $pInt1, $pInt2, $pInt3));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsCellBorderType]
  
 */
class CellBorderType
{
    public $m_CellBorderType;
    
    function __construct($cellBorderType)
    {
    	$this->m_CellBorderType = $cellBorderType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsCells]
  
 */
class Cells
{
    public $m_Cells;
    
    function __construct($cells)
    {
    	$this->m_Cells = $cells;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsCells.addRange(Range)]

      @param oRange0  com.aspose.cells.Range
     */
    function addRange($oRange0)
    {
        $this->m_Cells->addRange(ClassFactory::_t1($oRange0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.applyColumnStyle(int, Style, StyleFlag)]

      @param pInt0  int
      @param oStyle1  com.aspose.cells.Style
      @param oStyleFlag2  com.aspose.cells.StyleFlag
     */
    function applyColumnStyle($pInt0, $oStyle1, $oStyleFlag2)
    {
        $this->m_Cells->applyColumnStyle($pInt0, ClassFactory::_t1($oStyle1), ClassFactory::_t1($oStyleFlag2));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.applyRowStyle(int, Style, StyleFlag)]

      @param pInt0  int
      @param oStyle1  com.aspose.cells.Style
      @param oStyleFlag2  com.aspose.cells.StyleFlag
     */
    function applyRowStyle($pInt0, $oStyle1, $oStyleFlag2)
    {
        $this->m_Cells->applyRowStyle($pInt0, ClassFactory::_t1($oStyle1), ClassFactory::_t1($oStyleFlag2));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.applyStyle(Style, StyleFlag)]

      @param oStyle0  com.aspose.cells.Style
      @param oStyleFlag1  com.aspose.cells.StyleFlag
     */
    function applyStyle($oStyle0, $oStyleFlag1)
    {
        $this->m_Cells->applyStyle(ClassFactory::_t1($oStyle0), ClassFactory::_t1($oStyleFlag1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.checkCell(int, int)]

      @param pInt0  int
      @param pInt1  int
      @return com.aspose.cells.Cell
     */
    function checkCell($pInt0, $pInt1)
    {
        return ClassFactory::_t2($this->m_Cells->checkCell($pInt0, $pInt1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.checkRow(int)]

      @param pInt0  int
      @return com.aspose.cells.Row
     */
    function checkRow($pInt0)
    {
        return ClassFactory::_t2($this->m_Cells->checkRow($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.clear()]

     */
    function clear()
    {
        $this->m_Cells->clear();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.clearContents(int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
     */
    function clearContents($pInt0, $pInt1, $pInt2, $pInt3)
    {
        $this->m_Cells->clearContents($pInt0, $pInt1, $pInt2, $pInt3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.clearFormats(int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
     */
    function clearFormats($pInt0, $pInt1, $pInt2, $pInt3)
    {
        $this->m_Cells->clearFormats($pInt0, $pInt1, $pInt2, $pInt3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.clearRange(int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
     */
    function clearRange($pInt0, $pInt1, $pInt2, $pInt3)
    {
        $this->m_Cells->clearRange($pInt0, $pInt1, $pInt2, $pInt3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.convertStringToNumericValue()]

     */
    function convertStringToNumericValue()
    {
        $this->m_Cells->convertStringToNumericValue();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.copyColumn(Cells, int, int)]

      @param oCells0  com.aspose.cells.Cells
      @param pInt1  int
      @param pInt2  int
     */
    function copyColumn($oCells0, $pInt1, $pInt2)
    {
        $this->m_Cells->copyColumn(ClassFactory::_t1($oCells0), $pInt1, $pInt2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.copyColumns(Cells, int, int, int)]

      @param oCells0  com.aspose.cells.Cells
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
     */
    function copyColumns($oCells0, $pInt1, $pInt2, $pInt3)
    {
        $this->m_Cells->copyColumns(ClassFactory::_t1($oCells0), $pInt1, $pInt2, $pInt3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.copyRow(Cells, int, int)]

      @param oCells0  com.aspose.cells.Cells
      @param pInt1  int
      @param pInt2  int
     */
    function copyRow($oCells0, $pInt1, $pInt2)
    {
        $this->m_Cells->copyRow(ClassFactory::_t1($oCells0), $pInt1, $pInt2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.copyRows(Cells, int, int, int)]

      @param oCells0  com.aspose.cells.Cells
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
     */
    function copyRows($oCells0, $pInt1, $pInt2, $pInt3)
    {
        $this->m_Cells->copyRows(ClassFactory::_t1($oCells0), $pInt1, $pInt2, $pInt3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.createRange(String)]

      @param oString0  String
      @return com.aspose.cells.Range
     */
    function createRange($oString0)
    {
        return ClassFactory::_t2($this->m_Cells->createRange($oString0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.createRange(String, String)]

      @param oString0  String
      @param oString1  String
      @return com.aspose.cells.Range
     */
    function createRangeSS($oString0, $oString1)
    {
        return ClassFactory::_t2($this->m_Cells->createRange($oString0, $oString1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.createRange(int, int, boolean)]

      @param pInt0  int
      @param pInt1  int
      @param pBoolean2  boolean
      @return com.aspose.cells.Range
     */
    function createRangeIIB($pInt0, $pInt1, $pBoolean2)
    {
        return ClassFactory::_t2($this->m_Cells->createRange($pInt0, $pInt1, $pBoolean2));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.createRange(int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @return com.aspose.cells.Range
     */
    function createRangeIIII($pInt0, $pInt1, $pInt2, $pInt3)
    {
        return ClassFactory::_t2($this->m_Cells->createRange($pInt0, $pInt1, $pInt2, $pInt3));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.deleteBlankColumns()]

     */
    function deleteBlankColumns()
    {
        $this->m_Cells->deleteBlankColumns();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.deleteBlankRows()]

     */
    function deleteBlankRows()
    {
        $this->m_Cells->deleteBlankRows();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.deleteColumn(int)]

      @param pInt0  int
     */
    function deleteColumn($pInt0)
    {
        $this->m_Cells->deleteColumn($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.deleteColumn(int, boolean)]

      @param pInt0  int
      @param pBoolean1  boolean
     */
    function deleteColumnIB($pInt0, $pBoolean1)
    {
        $this->m_Cells->deleteColumn($pInt0, $pBoolean1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.deleteColumns(int, int, boolean)]

      @param pInt0  int
      @param pInt1  int
      @param pBoolean2  boolean
     */
    function deleteColumns($pInt0, $pInt1, $pBoolean2)
    {
        $this->m_Cells->deleteColumns($pInt0, $pInt1, $pBoolean2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.deleteRange(int, int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @param pInt4  int
     */
    function deleteRange($pInt0, $pInt1, $pInt2, $pInt3, $pInt4)
    {
        $this->m_Cells->deleteRange($pInt0, $pInt1, $pInt2, $pInt3, $pInt4);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.deleteRow(int)]

      @param pInt0  int
     */
    function deleteRow($pInt0)
    {
        $this->m_Cells->deleteRow($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.deleteRows(int, int)]

      @param pInt0  int
      @param pInt1  int
      @return boolean
     */
    function deleteRows($pInt0, $pInt1)
    {
        return $this->m_Cells->deleteRows($pInt0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.deleteRows(int, int, boolean)]

      @param pInt0  int
      @param pInt1  int
      @param pBoolean2  boolean
     */
    function deleteRowsIIB($pInt0, $pInt1, $pBoolean2)
    {
        $this->m_Cells->deleteRows($pInt0, $pInt1, $pBoolean2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.endCellInColumn(short)]

      @param pShort0  short
      @return com.aspose.cells.Cell
     */
    function endCellInColumn($pShort0)
    {
        return ClassFactory::_t2($this->m_Cells->endCellInColumn($pShort0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.endCellInColumn(int, int, short, short)]

      @param pInt0  int
      @param pInt1  int
      @param pShort2  short
      @param pShort3  short
      @return com.aspose.cells.Cell
     */
    function endCellInColumnIISS($pInt0, $pInt1, $pShort2, $pShort3)
    {
        return ClassFactory::_t2($this->m_Cells->endCellInColumn($pInt0, $pInt1, $pShort2, $pShort3));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.endCellInRow(int)]

      @param pInt0  int
      @return com.aspose.cells.Cell
     */
    function endCellInRow($pInt0)
    {
        return ClassFactory::_t2($this->m_Cells->endCellInRow($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.endCellInRow(int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @return com.aspose.cells.Cell
     */
    function endCellInRowIIII($pInt0, $pInt1, $pInt2, $pInt3)
    {
        return ClassFactory::_t2($this->m_Cells->endCellInRow($pInt0, $pInt1, $pInt2, $pInt3));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.exportArray(int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @return array, corresponding java type is {java.lang.Object[][]}
     */
    function exportArray($pInt0, $pInt1, $pInt2, $pInt3)
    {
        return ClassFactory::_t2($this->m_Cells->exportArray($pInt0, $pInt1, $pInt2, $pInt3));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.exportTypeArray(int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @return int[][]
     */
    function exportTypeArray($pInt0, $pInt1, $pInt2, $pInt3)
    {
        return $this->m_Cells->exportTypeArray($pInt0, $pInt1, $pInt2, $pInt3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.find(Object, Cell, FindOptions)]

      @param oObject0  corresponding java type is {java.lang.Object}
      @param oCell1  com.aspose.cells.Cell
      @param oFindOptions2  com.aspose.cells.FindOptions
      @return com.aspose.cells.Cell
     */
    function find($oObject0, $oCell1, $oFindOptions2)
    {
        return ClassFactory::_t2($this->m_Cells->find(ClassFactory::_t1($oObject0), ClassFactory::_t1($oCell1), ClassFactory::_t1($oFindOptions2)));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.findFormula(String, Cell)]

      @param oString0  String
      @param oCell1  com.aspose.cells.Cell
      @return com.aspose.cells.Cell
     */
    function findFormula($oString0, $oCell1)
    {
        return ClassFactory::_t2($this->m_Cells->findFormula($oString0, ClassFactory::_t1($oCell1)));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.findFormulaContains(String, Cell)]

      @param oString0  String
      @param oCell1  com.aspose.cells.Cell
      @return com.aspose.cells.Cell
     */
    function findFormulaContains($oString0, $oCell1)
    {
        return ClassFactory::_t2($this->m_Cells->findFormulaContains($oString0, ClassFactory::_t1($oCell1)));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.findNumber(double, Cell)]

      @param pDouble0  double
      @param oCell1  com.aspose.cells.Cell
      @return com.aspose.cells.Cell
     */
    function findNumber($pDouble0, $oCell1)
    {
        return ClassFactory::_t2($this->m_Cells->findNumber($pDouble0, ClassFactory::_t1($oCell1)));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.findNumber(int, Cell)]

      @param pInt0  int
      @param oCell1  com.aspose.cells.Cell
      @return com.aspose.cells.Cell
     */
    function findNumberIC($pInt0, $oCell1)
    {
        return ClassFactory::_t2($this->m_Cells->findNumber($pInt0, ClassFactory::_t1($oCell1)));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.findString(String, Cell)]

      @param oString0  String
      @param oCell1  com.aspose.cells.Cell
      @return com.aspose.cells.Cell
     */
    function findString($oString0, $oCell1)
    {
        return ClassFactory::_t2($this->m_Cells->findString($oString0, ClassFactory::_t1($oCell1)));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.findString(String, Cell, CellArea)]

      @param oString0  String
      @param oCell1  com.aspose.cells.Cell
      @param oCellArea2  com.aspose.cells.CellArea
      @return com.aspose.cells.Cell
     */
    function findStringSCC($oString0, $oCell1, $oCellArea2)
    {
        return ClassFactory::_t2($this->m_Cells->findString($oString0, ClassFactory::_t1($oCell1), ClassFactory::_t1($oCellArea2)));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.findString(String, Cell, FindOptions)]

      @param oString0  String
      @param oCell1  com.aspose.cells.Cell
      @param oFindOptions2  com.aspose.cells.FindOptions
      @return com.aspose.cells.Cell
     */
    function findStringSCF($oString0, $oCell1, $oFindOptions2)
    {
        return ClassFactory::_t2($this->m_Cells->findString($oString0, ClassFactory::_t1($oCell1), ClassFactory::_t1($oFindOptions2)));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.findString(String, Cell, boolean)]

      @param oString0  String
      @param oCell1  com.aspose.cells.Cell
      @param pBoolean2  boolean
      @return com.aspose.cells.Cell
     */
    function findStringSCB($oString0, $oCell1, $pBoolean2)
    {
        return ClassFactory::_t2($this->m_Cells->findString($oString0, ClassFactory::_t1($oCell1), $pBoolean2));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.findString(String, Cell, CellArea, boolean)]

      @param oString0  String
      @param oCell1  com.aspose.cells.Cell
      @param oCellArea2  com.aspose.cells.CellArea
      @param pBoolean3  boolean
      @return com.aspose.cells.Cell
     */
    function findStringSCCB($oString0, $oCell1, $oCellArea2, $pBoolean3)
    {
        return ClassFactory::_t2($this->m_Cells->findString($oString0, ClassFactory::_t1($oCell1), ClassFactory::_t1($oCellArea2), $pBoolean3));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.findStringContains(String, Cell)]

      @param oString0  String
      @param oCell1  com.aspose.cells.Cell
      @return com.aspose.cells.Cell
     */
    function findStringContains($oString0, $oCell1)
    {
        return ClassFactory::_t2($this->m_Cells->findStringContains($oString0, ClassFactory::_t1($oCell1)));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.findStringContains(String, Cell, boolean)]

      @param oString0  String
      @param oCell1  com.aspose.cells.Cell
      @param pBoolean2  boolean
      @return com.aspose.cells.Cell
     */
    function findStringContainsSCB($oString0, $oCell1, $pBoolean2)
    {
        return ClassFactory::_t2($this->m_Cells->findStringContains($oString0, ClassFactory::_t1($oCell1), $pBoolean2));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.findStringContains(String, Cell, boolean, CellArea)]

      @param oString0  String
      @param oCell1  com.aspose.cells.Cell
      @param pBoolean2  boolean
      @param oCellArea3  com.aspose.cells.CellArea
      @return com.aspose.cells.Cell
     */
    function findStringContainsSCBC($oString0, $oCell1, $pBoolean2, $oCellArea3)
    {
        return ClassFactory::_t2($this->m_Cells->findStringContains($oString0, ClassFactory::_t1($oCell1), $pBoolean2, ClassFactory::_t1($oCellArea3)));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.findStringEndsWith(String, Cell)]

      @param oString0  String
      @param oCell1  com.aspose.cells.Cell
      @return com.aspose.cells.Cell
     */
    function findStringEndsWith($oString0, $oCell1)
    {
        return ClassFactory::_t2($this->m_Cells->findStringEndsWith($oString0, ClassFactory::_t1($oCell1)));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.findStringStartsWith(String, Cell)]

      @param oString0  String
      @param oCell1  com.aspose.cells.Cell
      @return com.aspose.cells.Cell
     */
    function findStringStartsWith($oString0, $oCell1)
    {
        return ClassFactory::_t2($this->m_Cells->findStringStartsWith($oString0, ClassFactory::_t1($oCell1)));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.get(String)]

      @param oString0  String
      @return com.aspose.cells.Cell
     */
    function get($oString0)
    {
        return ClassFactory::_t2($this->m_Cells->get($oString0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.get(int)]

      @param pInt0  int
      @return com.aspose.cells.Cell
     */
    function getI($pInt0)
    {
        return ClassFactory::_t2($this->m_Cells->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.get(int, int)]

      @param pInt0  int
      @param pInt1  int
      @return com.aspose.cells.Cell
     */
    function getII($pInt0, $pInt1)
    {
        return ClassFactory::_t2($this->m_Cells->get($pInt0, $pInt1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.getColumnWidth(int)]

      @param pInt0  int
      @return double
     */
    function getColumnWidth($pInt0)
    {
        return $this->m_Cells->getColumnWidth($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.getColumnWidthInch(int)]

      @param pInt0  int
      @return double
     */
    function getColumnWidthInch($pInt0)
    {
        return $this->m_Cells->getColumnWidthInch($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.getColumnWidthPixel(int)]

      @param pInt0  int
      @return int
     */
    function getColumnWidthPixel($pInt0)
    {
        return $this->m_Cells->getColumnWidthPixel($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.getColumns()]

      @return com.aspose.cells.ColumnCollection
     */
    function getColumns()
    {
        return ClassFactory::_t2($this->m_Cells->getColumns());
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.getCount()]

      @return int
     */
    function getCount()
    {
        return $this->m_Cells->getCount();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.getEnd()]

      @return com.aspose.cells.Cell
     */
    function getEnd()
    {
        return ClassFactory::_t2($this->m_Cells->getEnd());
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.getFirstCell()]

      @return com.aspose.cells.Cell
     */
    function getFirstCell()
    {
        return ClassFactory::_t2($this->m_Cells->getFirstCell());
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.getGroupedColumnOutlineLevel(int)]

      @param pInt0  int
      @return int
     */
    function getGroupedColumnOutlineLevel($pInt0)
    {
        return $this->m_Cells->getGroupedColumnOutlineLevel($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.getGroupedRowOutlineLevel(int)]

      @param pInt0  int
      @return int
     */
    function getGroupedRowOutlineLevel($pInt0)
    {
        return $this->m_Cells->getGroupedRowOutlineLevel($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.getLastCell()]

      @return com.aspose.cells.Cell
     */
    function getLastCell()
    {
        return ClassFactory::_t2($this->m_Cells->getLastCell());
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.getLastDataRow(int)]

      @param pInt0  int
      @return int
     */
    function getLastDataRow($pInt0)
    {
        return $this->m_Cells->getLastDataRow($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.getMaxColumn()]

      @return int
     */
    function getMaxColumn()
    {
        return $this->m_Cells->getMaxColumn();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.getMaxDataColumn()]

      @return int
     */
    function getMaxDataColumn()
    {
        return $this->m_Cells->getMaxDataColumn();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.getMaxDataRow()]

      @return int
     */
    function getMaxDataRow()
    {
        return $this->m_Cells->getMaxDataRow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.getMaxGroupedColumnOutlineLevel()]

      @return int
     */
    function getMaxGroupedColumnOutlineLevel()
    {
        return $this->m_Cells->getMaxGroupedColumnOutlineLevel();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.getMaxGroupedRowOutlineLevel()]

      @return int
     */
    function getMaxGroupedRowOutlineLevel()
    {
        return $this->m_Cells->getMaxGroupedRowOutlineLevel();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.getMaxRow()]

      @return int
     */
    function getMaxRow()
    {
        return $this->m_Cells->getMaxRow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.getMergedCells()]

      @return array, corresponding java type is {java.util.ArrayList}
     */
    function getMergedCells()
    {
        return ClassFactory::_t2($this->m_Cells->getMergedCells());
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.getMinColumn()]

      @return int
     */
    function getMinColumn()
    {
        return $this->m_Cells->getMinColumn();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.getMinRow()]

      @return int
     */
    function getMinRow()
    {
        return $this->m_Cells->getMinRow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.getPreserveString()]

      @return boolean
     */
    function getPreserveString()
    {
        return $this->m_Cells->getPreserveString();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.getRanges()]

      @return com.aspose.cells.RangeCollection
     */
    function getRanges()
    {
        return ClassFactory::_t2($this->m_Cells->getRanges());
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.getRowEnumerator()]

      @return corresponding java type is {java.util.Iterator}
     */
    function getRowEnumerator()
    {
        return ClassFactory::_t2($this->m_Cells->getRowEnumerator());
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.getRowHeight(int)]

      @param pInt0  int
      @return double
     */
    function getRowHeight($pInt0)
    {
        return $this->m_Cells->getRowHeight($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.getRowHeightInch(int)]

      @param pInt0  int
      @return double
     */
    function getRowHeightInch($pInt0)
    {
        return $this->m_Cells->getRowHeightInch($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.getRowHeightPixel(int)]

      @param pInt0  int
      @return int
     */
    function getRowHeightPixel($pInt0)
    {
        return $this->m_Cells->getRowHeightPixel($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.getRows()]

      @return com.aspose.cells.RowCollection
     */
    function getRows()
    {
        return ClassFactory::_t2($this->m_Cells->getRows());
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.getStandardHeight()]

      @return double
     */
    function getStandardHeight()
    {
        return $this->m_Cells->getStandardHeight();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.getStandardWidth()]

      @return double
     */
    function getStandardWidth()
    {
        return $this->m_Cells->getStandardWidth();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.getStart()]

      @return com.aspose.cells.Cell
     */
    function getStart()
    {
        return ClassFactory::_t2($this->m_Cells->getStart());
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.groupColumns(int, int)]

      @param pInt0  int
      @param pInt1  int
     */
    function groupColumns($pInt0, $pInt1)
    {
        $this->m_Cells->groupColumns($pInt0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.groupColumns(int, int, boolean)]

      @param pInt0  int
      @param pInt1  int
      @param pBoolean2  boolean
     */
    function groupColumnsIIB($pInt0, $pInt1, $pBoolean2)
    {
        $this->m_Cells->groupColumns($pInt0, $pInt1, $pBoolean2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.groupRows(int, int)]

      @param pInt0  int
      @param pInt1  int
     */
    function groupRows($pInt0, $pInt1)
    {
        $this->m_Cells->groupRows($pInt0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.groupRows(int, int, boolean)]

      @param pInt0  int
      @param pInt1  int
      @param pBoolean2  boolean
     */
    function groupRowsIIB($pInt0, $pInt1, $pBoolean2)
    {
        $this->m_Cells->groupRows($pInt0, $pInt1, $pBoolean2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.hideColumn(int)]

      @param pInt0  int
     */
    function hideColumn($pInt0)
    {
        $this->m_Cells->hideColumn($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.hideColumns(int, int)]

      @param pInt0  int
      @param pInt1  int
     */
    function hideColumns($pInt0, $pInt1)
    {
        $this->m_Cells->hideColumns($pInt0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.hideGroupDetail(boolean, int)]

      @param pBoolean0  boolean
      @param pInt1  int
     */
    function hideGroupDetail($pBoolean0, $pInt1)
    {
        $this->m_Cells->hideGroupDetail($pBoolean0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.hideRow(int)]

      @param pInt0  int
     */
    function hideRow($pInt0)
    {
        $this->m_Cells->hideRow($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.hideRows(int, int)]

      @param pInt0  int
      @param pInt1  int
     */
    function hideRows($pInt0, $pInt1)
    {
        $this->m_Cells->hideRows($pInt0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.importArray(String[][], int, int)]

      @param arrD2DString0  array, corresponding java type is {String[][]}
      @param pInt1  int
      @param pInt2  int
     */
    function importArray($arrD2DString0, $pInt1, $pInt2)
    {
        $this->m_Cells->importArray($arrD2DString0, $pInt1, $pInt2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.importArray(double[][], int, int)]

      @param arrP2DDouble0  double[][]
      @param pInt1  int
      @param pInt2  int
     */
    function importArrayDII($arrP2DDouble0, $pInt1, $pInt2)
    {
        $this->m_Cells->importArray($arrP2DDouble0, $pInt1, $pInt2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.importArray(int[][], int, int)]

      @param arrP2DInt0  int[][]
      @param pInt1  int
      @param pInt2  int
     */
    function importArrayIII($arrP2DInt0, $pInt1, $pInt2)
    {
        $this->m_Cells->importArray($arrP2DInt0, $pInt1, $pInt2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.importArray(String[], int, int, boolean)]

      @param arrD1DString0  array, corresponding java type is {String[]}
      @param pInt1  int
      @param pInt2  int
      @param pBoolean3  boolean
     */
    function importArraySIIB($arrD1DString0, $pInt1, $pInt2, $pBoolean3)
    {
        $this->m_Cells->importArray($arrD1DString0, $pInt1, $pInt2, $pBoolean3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.importArray(double[], int, int, boolean)]

      @param arrP1DDouble0  double[]
      @param pInt1  int
      @param pInt2  int
      @param pBoolean3  boolean
     */
    function importArrayDIIB($arrP1DDouble0, $pInt1, $pInt2, $pBoolean3)
    {
        $this->m_Cells->importArray($arrP1DDouble0, $pInt1, $pInt2, $pBoolean3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.importArray(int[], int, int, boolean)]

      @param arrP1DInt0  int[]
      @param pInt1  int
      @param pInt2  int
      @param pBoolean3  boolean
     */
    function importArrayIIIB($arrP1DInt0, $pInt1, $pInt2, $pBoolean3)
    {
        $this->m_Cells->importArray($arrP1DInt0, $pInt1, $pInt2, $pBoolean3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.importArrayList(ArrayList, int, int, boolean)]

      @param arrA1DFromArrayList0  array, corresponding java type is {java.util.ArrayList}
      @param pInt1  int
      @param pInt2  int
      @param pBoolean3  boolean
     */
    function importArrayList($arrA1DFromArrayList0, $pInt1, $pInt2, $pBoolean3)
    {
        $this->m_Cells->importArrayList(ClassFactory::_t1($arrA1DFromArrayList0), $pInt1, $pInt2, $pBoolean3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.importCSV(InputStream, String, boolean, int, int)]

      @param oInputStream0  corresponding java type is {java.io.InputStream}
      @param oString1  String
      @param pBoolean2  boolean
      @param pInt3  int
      @param pInt4  int
     */
    function importCSV($oInputStream0, $oString1, $pBoolean2, $pInt3, $pInt4)
    {
        $this->m_Cells->importCSV(ClassFactory::_t1($oInputStream0), $oString1, $pBoolean2, $pInt3, $pInt4);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.importCSV(String, String, boolean, int, int)]

      @param oString0  String
      @param oString1  String
      @param pBoolean2  boolean
      @param pInt3  int
      @param pInt4  int
     */
    function importCSVSSBII($oString0, $oString1, $pBoolean2, $pInt3, $pInt4)
    {
        $this->m_Cells->importCSV($oString0, $oString1, $pBoolean2, $pInt3, $pInt4);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.importFormulaArray(String[], int, int, boolean)]

      @param arrD1DString0  array, corresponding java type is {String[]}
      @param pInt1  int
      @param pInt2  int
      @param pBoolean3  boolean
     */
    function importFormulaArray($arrD1DString0, $pInt1, $pInt2, $pBoolean3)
    {
        $this->m_Cells->importFormulaArray($arrD1DString0, $pInt1, $pInt2, $pBoolean3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.importObjectArray(Object[], int, int, boolean)]

      @param arrO1DObject0  array, corresponding java type is {java.lang.Object[]}
      @param pInt1  int
      @param pInt2  int
      @param pBoolean3  boolean
     */
    function importObjectArray($arrO1DObject0, $pInt1, $pInt2, $pBoolean3)
    {
        $this->m_Cells->importObjectArray(ClassFactory::_t1($arrO1DObject0), $pInt1, $pInt2, $pBoolean3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.importObjectArray(Object[], int, int, boolean, int)]

      @param arrO1DObject0  array, corresponding java type is {java.lang.Object[]}
      @param pInt1  int
      @param pInt2  int
      @param pBoolean3  boolean
      @param pInt4  int
     */
    function importObjectArrayOIIBI($arrO1DObject0, $pInt1, $pInt2, $pBoolean3, $pInt4)
    {
        $this->m_Cells->importObjectArray(ClassFactory::_t1($arrO1DObject0), $pInt1, $pInt2, $pBoolean3, $pInt4);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.importResultSet(ResultSet, String, boolean)]

      @param oResultSet0  corresponding java type is {java.sql.ResultSet}
      @param oString1  String
      @param pBoolean2  boolean
      @return int
     */
    function importResultSet($oResultSet0, $oString1, $pBoolean2)
    {
        return $this->m_Cells->importResultSet(ClassFactory::_t1($oResultSet0), $oString1, $pBoolean2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.importResultSet(ResultSet, int, int, boolean)]

      @param oResultSet0  corresponding java type is {java.sql.ResultSet}
      @param pInt1  int
      @param pInt2  int
      @param pBoolean3  boolean
      @return int
     */
    function importResultSetRIIB($oResultSet0, $pInt1, $pInt2, $pBoolean3)
    {
        return $this->m_Cells->importResultSet(ClassFactory::_t1($oResultSet0), $pInt1, $pInt2, $pBoolean3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.importResultSet(ResultSet, String, int, int, boolean)]

      @param oResultSet0  corresponding java type is {java.sql.ResultSet}
      @param oString1  String
      @param pInt2  int
      @param pInt3  int
      @param pBoolean4  boolean
      @return int
     */
    function importResultSetRSIIB($oResultSet0, $oString1, $pInt2, $pInt3, $pBoolean4)
    {
        return $this->m_Cells->importResultSet(ClassFactory::_t1($oResultSet0), $oString1, $pInt2, $pInt3, $pBoolean4);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.importResultSet(ResultSet, int, int, boolean, String, boolean)]

      @param oResultSet0  corresponding java type is {java.sql.ResultSet}
      @param pInt1  int
      @param pInt2  int
      @param pBoolean3  boolean
      @param oString4  String
      @param pBoolean5  boolean
      @return int
     */
    function importResultSetRIIBSB($oResultSet0, $pInt1, $pInt2, $pBoolean3, $oString4, $pBoolean5)
    {
        return $this->m_Cells->importResultSet(ClassFactory::_t1($oResultSet0), $pInt1, $pInt2, $pBoolean3, $oString4, $pBoolean5);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.importResultSet(ResultSet, int, int, int, int, boolean)]

      @param oResultSet0  corresponding java type is {java.sql.ResultSet}
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @param pInt4  int
      @param pBoolean5  boolean
      @return int
     */
    function importResultSetRIIIIB($oResultSet0, $pInt1, $pInt2, $pInt3, $pInt4, $pBoolean5)
    {
        return $this->m_Cells->importResultSet(ClassFactory::_t1($oResultSet0), $pInt1, $pInt2, $pInt3, $pInt4, $pBoolean5);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.importResultSet(ResultSet, int, int, int, int, boolean, String, boolean)]

      @param oResultSet0  corresponding java type is {java.sql.ResultSet}
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @param pInt4  int
      @param pBoolean5  boolean
      @param oString6  String
      @param pBoolean7  boolean
      @return int
     */
    function importResultSetRIIIIBSB($oResultSet0, $pInt1, $pInt2, $pInt3, $pInt4, $pBoolean5, $oString6, $pBoolean7)
    {
        return $this->m_Cells->importResultSet(ClassFactory::_t1($oResultSet0), $pInt1, $pInt2, $pInt3, $pInt4, $pBoolean5, $oString6, $pBoolean7);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.importTwoDimensionArray(Object[][], int, int)]

      @param arrO2DObject0  array, corresponding java type is {java.lang.Object[][]}
      @param pInt1  int
      @param pInt2  int
     */
    function importTwoDimensionArray($arrO2DObject0, $pInt1, $pInt2)
    {
        $this->m_Cells->importTwoDimensionArray(ClassFactory::_t1($arrO2DObject0), $pInt1, $pInt2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.importTwoDimensionArray(Object[][], int, int, boolean)]

      @param arrO2DObject0  array, corresponding java type is {java.lang.Object[][]}
      @param pInt1  int
      @param pInt2  int
      @param pBoolean3  boolean
     */
    function importTwoDimensionArrayOIIB($arrO2DObject0, $pInt1, $pInt2, $pBoolean3)
    {
        $this->m_Cells->importTwoDimensionArray(ClassFactory::_t1($arrO2DObject0), $pInt1, $pInt2, $pBoolean3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.insertColumn(int)]

      @param pInt0  int
     */
    function insertColumn($pInt0)
    {
        $this->m_Cells->insertColumn($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.insertColumn(int, boolean)]

      @param pInt0  int
      @param pBoolean1  boolean
     */
    function insertColumnIB($pInt0, $pBoolean1)
    {
        $this->m_Cells->insertColumn($pInt0, $pBoolean1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.insertColumns(int, int)]

      @param pInt0  int
      @param pInt1  int
     */
    function insertColumns($pInt0, $pInt1)
    {
        $this->m_Cells->insertColumns($pInt0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.insertColumns(int, int, boolean)]

      @param pInt0  int
      @param pInt1  int
      @param pBoolean2  boolean
     */
    function insertColumnsIIB($pInt0, $pInt1, $pBoolean2)
    {
        $this->m_Cells->insertColumns($pInt0, $pInt1, $pBoolean2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.insertRange(CellArea, int)]

      @param oCellArea0  com.aspose.cells.CellArea
      @param pInt1  int
     */
    function insertRange($oCellArea0, $pInt1)
    {
        $this->m_Cells->insertRange(ClassFactory::_t1($oCellArea0), $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.insertRange(CellArea, int, int)]

      @param oCellArea0  com.aspose.cells.CellArea
      @param pInt1  int
      @param pInt2  int
     */
    function insertRangeCII($oCellArea0, $pInt1, $pInt2)
    {
        $this->m_Cells->insertRange(ClassFactory::_t1($oCellArea0), $pInt1, $pInt2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.insertRange(CellArea, int, int, boolean)]

      @param oCellArea0  com.aspose.cells.CellArea
      @param pInt1  int
      @param pInt2  int
      @param pBoolean3  boolean
     */
    function insertRangeCIIB($oCellArea0, $pInt1, $pInt2, $pBoolean3)
    {
        $this->m_Cells->insertRange(ClassFactory::_t1($oCellArea0), $pInt1, $pInt2, $pBoolean3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.insertRow(int)]

      @param pInt0  int
     */
    function insertRow($pInt0)
    {
        $this->m_Cells->insertRow($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.insertRows(int, int)]

      @param pInt0  int
      @param pInt1  int
     */
    function insertRows($pInt0, $pInt1)
    {
        $this->m_Cells->insertRows($pInt0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.insertRows(int, int, boolean)]

      @param pInt0  int
      @param pInt1  int
      @param pBoolean2  boolean
     */
    function insertRowsIIB($pInt0, $pInt1, $pBoolean2)
    {
        $this->m_Cells->insertRows($pInt0, $pInt1, $pBoolean2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.isDefaultRowHeightMatched()]

      @return boolean
     */
    function isDefaultRowHeightMatched()
    {
        return $this->m_Cells->isDefaultRowHeightMatched();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.isDeletingRangeEnabled(int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @return boolean
     */
    function isDeletingRangeEnabled($pInt0, $pInt1, $pInt2, $pInt3)
    {
        return $this->m_Cells->isDeletingRangeEnabled($pInt0, $pInt1, $pInt2, $pInt3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.isStringsPreserved()]

      @return boolean
     */
    function isStringsPreserved()
    {
        return $this->m_Cells->isStringsPreserved();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.iterator()]

      @return corresponding java type is {java.util.Iterator}
     */
    function iterator()
    {
        return ClassFactory::_t2($this->m_Cells->iterator());
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.maxDataRowInColumn(int)]

      @param pInt0  int
      @return int
     */
    function maxDataRowInColumn($pInt0)
    {
        return $this->m_Cells->maxDataRowInColumn($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.merge(int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
     */
    function merge($pInt0, $pInt1, $pInt2, $pInt3)
    {
        $this->m_Cells->merge($pInt0, $pInt1, $pInt2, $pInt3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.merge(int, int, int, int, boolean)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @param pBoolean4  boolean
     */
    function mergeIIIIB($pInt0, $pInt1, $pInt2, $pInt3, $pBoolean4)
    {
        $this->m_Cells->merge($pInt0, $pInt1, $pInt2, $pInt3, $pBoolean4);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.merge(int, int, int, int, boolean, boolean)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @param pBoolean4  boolean
      @param pBoolean5  boolean
     */
    function mergeIIIIBB($pInt0, $pInt1, $pInt2, $pInt3, $pBoolean4, $pBoolean5)
    {
        $this->m_Cells->merge($pInt0, $pInt1, $pInt2, $pInt3, $pBoolean4, $pBoolean5);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.moveRange(CellArea, int, int)]

      @param oCellArea0  com.aspose.cells.CellArea
      @param pInt1  int
      @param pInt2  int
     */
    function moveRange($oCellArea0, $pInt1, $pInt2)
    {
        $this->m_Cells->moveRange(ClassFactory::_t1($oCellArea0), $pInt1, $pInt2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.removeDuplicates(int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
     */
    function removeDuplicates($pInt0, $pInt1, $pInt2, $pInt3)
    {
        $this->m_Cells->removeDuplicates($pInt0, $pInt1, $pInt2, $pInt3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.removeFormulas()]

     */
    function removeFormulas()
    {
        $this->m_Cells->removeFormulas();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.setColumnWidth(int, double)]

      @param pInt0  int
      @param pDouble1  double
     */
    function setColumnWidth($pInt0, $pDouble1)
    {
        $this->m_Cells->setColumnWidth($pInt0, $pDouble1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.setColumnWidthInch(int, double)]

      @param pInt0  int
      @param pDouble1  double
     */
    function setColumnWidthInch($pInt0, $pDouble1)
    {
        $this->m_Cells->setColumnWidthInch($pInt0, $pDouble1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.setColumnWidthPixel(int, int)]

      @param pInt0  int
      @param pInt1  int
     */
    function setColumnWidthPixel($pInt0, $pInt1)
    {
        $this->m_Cells->setColumnWidthPixel($pInt0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.setDefaultRowHeightMatched(boolean)]

      @param pBoolean0  boolean
     */
    function setDefaultRowHeightMatched($pBoolean0)
    {
        $this->m_Cells->setDefaultRowHeightMatched($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.setPreserveString(boolean)]

      @param pBoolean0  boolean
     */
    function setPreserveString($pBoolean0)
    {
        $this->m_Cells->setPreserveString($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.setRowHeight(int, double)]

      @param pInt0  int
      @param pDouble1  double
     */
    function setRowHeight($pInt0, $pDouble1)
    {
        $this->m_Cells->setRowHeight($pInt0, $pDouble1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.setRowHeightInch(int, double)]

      @param pInt0  int
      @param pDouble1  double
     */
    function setRowHeightInch($pInt0, $pDouble1)
    {
        $this->m_Cells->setRowHeightInch($pInt0, $pDouble1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.setRowHeightPixel(int, int)]

      @param pInt0  int
      @param pInt1  int
     */
    function setRowHeightPixel($pInt0, $pInt1)
    {
        $this->m_Cells->setRowHeightPixel($pInt0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.setStandardHeight(double)]

      @param pDouble0  double
     */
    function setStandardHeight($pDouble0)
    {
        $this->m_Cells->setStandardHeight($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.setStandardWidth(double)]

      @param pDouble0  double
     */
    function setStandardWidth($pDouble0)
    {
        $this->m_Cells->setStandardWidth($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.setStringsPreserved(boolean)]

      @param pBoolean0  boolean
     */
    function setStringsPreserved($pBoolean0)
    {
        $this->m_Cells->setStringsPreserved($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.showGroupDetail(boolean, int)]

      @param pBoolean0  boolean
      @param pInt1  int
     */
    function showGroupDetail($pBoolean0, $pInt1)
    {
        $this->m_Cells->showGroupDetail($pBoolean0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.subtotal(CellArea, int, int, int[])]

      @param oCellArea0  com.aspose.cells.CellArea
      @param pInt1  int
      @param pInt2  int
      @param arrP1DInt3  int[]
     */
    function subtotal($oCellArea0, $pInt1, $pInt2, $arrP1DInt3)
    {
        $this->m_Cells->subtotal(ClassFactory::_t1($oCellArea0), $pInt1, $pInt2, $arrP1DInt3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.subtotal(CellArea, int, int, int[], boolean, boolean, boolean)]

      @param oCellArea0  com.aspose.cells.CellArea
      @param pInt1  int
      @param pInt2  int
      @param arrP1DInt3  int[]
      @param pBoolean4  boolean
      @param pBoolean5  boolean
      @param pBoolean6  boolean
     */
    function subtotalCIIIBBB($oCellArea0, $pInt1, $pInt2, $arrP1DInt3, $pBoolean4, $pBoolean5, $pBoolean6)
    {
        $this->m_Cells->subtotal(ClassFactory::_t1($oCellArea0), $pInt1, $pInt2, $arrP1DInt3, $pBoolean4, $pBoolean5, $pBoolean6);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.unMerge(int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
     */
    function unMerge($pInt0, $pInt1, $pInt2, $pInt3)
    {
        $this->m_Cells->unMerge($pInt0, $pInt1, $pInt2, $pInt3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.ungroupColumns(int, int)]

      @param pInt0  int
      @param pInt1  int
     */
    function ungroupColumns($pInt0, $pInt1)
    {
        $this->m_Cells->ungroupColumns($pInt0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.ungroupRows(int, int)]

      @param pInt0  int
      @param pInt1  int
     */
    function ungroupRows($pInt0, $pInt1)
    {
        $this->m_Cells->ungroupRows($pInt0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.ungroupRows(int, int, boolean)]

      @param pInt0  int
      @param pInt1  int
      @param pBoolean2  boolean
     */
    function ungroupRowsIIB($pInt0, $pInt1, $pBoolean2)
    {
        $this->m_Cells->ungroupRows($pInt0, $pInt1, $pBoolean2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.unhideColumn(int, double)]

      @param pInt0  int
      @param pDouble1  double
     */
    function unhideColumn($pInt0, $pDouble1)
    {
        $this->m_Cells->unhideColumn($pInt0, $pDouble1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.unhideColumns(int, int, double)]

      @param pInt0  int
      @param pInt1  int
      @param pDouble2  double
     */
    function unhideColumns($pInt0, $pInt1, $pDouble2)
    {
        $this->m_Cells->unhideColumns($pInt0, $pInt1, $pDouble2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.unhideRow(int, double)]

      @param pInt0  int
      @param pDouble1  double
     */
    function unhideRow($pInt0, $pDouble1)
    {
        $this->m_Cells->unhideRow($pInt0, $pDouble1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCells.unhideRows(int, int, double)]

      @param pInt0  int
      @param pInt1  int
      @param pDouble2  double
     */
    function unhideRows($pInt0, $pInt1, $pDouble2)
    {
        $this->m_Cells->unhideRows($pInt0, $pInt1, $pDouble2);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsCellsColor]
  
 */
class CellsColor
{
    public $m_CellsColor;
    
    function __construct($cellsColor)
    {
    	$this->m_CellsColor = $cellsColor;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsCellsColor.getColor()]

      @return com.aspose.cells.Color
     */
    function getColor()
    {
        return ClassFactory::_t2($this->m_CellsColor->getColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsColor.getColorIndex()]

      @return int
     */
    function getColorIndex()
    {
        return $this->m_CellsColor->getColorIndex();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsColor.getThemeColor()]

      @return com.aspose.cells.ThemeColor
     */
    function getThemeColor()
    {
        return ClassFactory::_t2($this->m_CellsColor->getThemeColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsColor.getType()]

      @return int
     */
    function getType()
    {
        return $this->m_CellsColor->getType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsColor.isShapeColor()]

      @return boolean
     */
    function isShapeColor()
    {
        return $this->m_CellsColor->isShapeColor();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsColor.setColor(Color)]

      @param oColor0  com.aspose.cells.Color
     */
    function setColor($oColor0)
    {
        $this->m_CellsColor->setColor(ClassFactory::_t1($oColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsColor.setColorIndex(int)]

      @param pInt0  int
     */
    function setColorIndex($pInt0)
    {
        $this->m_CellsColor->setColorIndex($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsColor.setShapeColor(boolean)]

      @param pBoolean0  boolean
     */
    function setShapeColor($pBoolean0)
    {
        $this->m_CellsColor->setShapeColor($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsColor.setThemeColor(ThemeColor)]

      @param oThemeColor0  com.aspose.cells.ThemeColor
     */
    function setThemeColor($oThemeColor0)
    {
        $this->m_CellsColor->setThemeColor(ClassFactory::_t1($oThemeColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsColor.setTintOfShapeColor(double)]

      @param pDouble0  double
     */
    function setTintOfShapeColor($pDouble0)
    {
        $this->m_CellsColor->setTintOfShapeColor($pDouble0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsCellsDrawing]
  
 */
class CellsDrawing extends Shape
{
    public $m_CellsDrawing;
    
    function __construct($cellsDrawing)
    {
    	$this->m_CellsDrawing = $cellsDrawing;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsCellsException]
  
 */
class CellsException
{
    public $m_CellsException;
    
    function __construct($cellsException)
    {
    	$this->m_CellsException = $cellsException;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsCellsException.getCode()]

      @return int
     */
    function getCode()
    {
        return $this->m_CellsException->getCode();
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsCellsHelper]
  
 */
class CellsHelper
{
    public $m_CellsHelper;
    
    function __construct($cellsHelper)
    {
    	$this->m_CellsHelper = $cellsHelper;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsCellsHelper.cellIndexToName(int, int)]

      @param pInt0  int
      @param pInt1  int
      @return String
     */
    function cellIndexToName($pInt0, $pInt1)
    {
        return $this->m_CellsHelper->cellIndexToName($pInt0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsHelper.cellNameToIndex(String)]

      @param oString0  String
      @return int[]
     */
    function cellNameToIndex($oString0)
    {
        return $this->m_CellsHelper->cellNameToIndex($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsHelper.columnIndexToName(int)]

      @param pInt0  int
      @return String
     */
    function columnIndexToName($pInt0)
    {
        return $this->m_CellsHelper->columnIndexToName($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsHelper.columnNameToIndex(String)]

      @param oString0  String
      @return int
     */
    function columnNameToIndex($oString0)
    {
        return $this->m_CellsHelper->columnNameToIndex($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsHelper.convertA1FormulaToR1C1(String, int, int)]

      @param oString0  String
      @param pInt1  int
      @param pInt2  int
      @return String
     */
    function convertA1FormulaToR1C1($oString0, $pInt1, $pInt2)
    {
        return $this->m_CellsHelper->convertA1FormulaToR1C1($oString0, $pInt1, $pInt2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsHelper.convertR1C1FormulaToA1(String, int, int)]

      @param oString0  String
      @param pInt1  int
      @param pInt2  int
      @return String
     */
    function convertR1C1FormulaToA1($oString0, $pInt1, $pInt2)
    {
        return $this->m_CellsHelper->convertR1C1FormulaToA1($oString0, $pInt1, $pInt2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsHelper.detectFileFormat(InputStream)]

      @param oInputStream0  corresponding java type is {java.io.InputStream}
      @return int
     */
    function detectFileFormat($oInputStream0)
    {
        return $this->m_CellsHelper->detectFileFormat(ClassFactory::_t1($oInputStream0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsHelper.detectFileFormat(String)]

      @param oString0  String
      @return int
     */
    function detectFileFormatS($oString0)
    {
        return $this->m_CellsHelper->detectFileFormat($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsHelper.detectLoadFormat(InputStream)]

      @param oInputStream0  corresponding java type is {java.io.InputStream}
      @return int
     */
    function detectLoadFormat($oInputStream0)
    {
        return $this->m_CellsHelper->detectLoadFormat(ClassFactory::_t1($oInputStream0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsHelper.detectLoadFormat(String)]

      @param oString0  String
      @return int
     */
    function detectLoadFormatS($oString0)
    {
        return $this->m_CellsHelper->detectLoadFormat($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsHelper.getAltStartPath()]

      @return String
     */
    function getAltStartPath()
    {
        return $this->m_CellsHelper->getAltStartPath();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsHelper.getDoubleFromDateTime(DateTime, boolean)]

      @param oDateTime0  com.aspose.cells.DateTime
      @param pBoolean1  boolean
      @return double
     */
    function getDoubleFromDateTime($oDateTime0, $pBoolean1)
    {
        return $this->m_CellsHelper->getDoubleFromDateTime(ClassFactory::_t1($oDateTime0), $pBoolean1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsHelper.getFontDir()]

      @return String
     */
    function getFontDir()
    {
        return $this->m_CellsHelper->getFontDir();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsHelper.getFontDirs()]

      @return array, corresponding java type is {java.util.ArrayList}
     */
    function getFontDirs()
    {
        return ClassFactory::_t2($this->m_CellsHelper->getFontDirs());
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsHelper.getFontFiles()]

      @return array, corresponding java type is {java.util.ArrayList}
     */
    function getFontFiles()
    {
        return ClassFactory::_t2($this->m_CellsHelper->getFontFiles());
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsHelper.getLibraryPath()]

      @return String
     */
    function getLibraryPath()
    {
        return $this->m_CellsHelper->getLibraryPath();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsHelper.getStartupPath()]

      @return String
     */
    function getStartupPath()
    {
        return $this->m_CellsHelper->getStartupPath();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsHelper.getVersion()]

      @return String
     */
    function getVersion()
    {
        return $this->m_CellsHelper->getVersion();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsHelper.isProtectedByRMS(InputStream)]

      @param oInputStream0  corresponding java type is {java.io.InputStream}
      @return boolean
     */
    function isProtectedByRMS($oInputStream0)
    {
        return $this->m_CellsHelper->isProtectedByRMS(ClassFactory::_t1($oInputStream0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsHelper.isProtectedByRMS(String)]

      @param oString0  String
      @return boolean
     */
    function isProtectedByRMSS($oString0)
    {
        return $this->m_CellsHelper->isProtectedByRMS($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsHelper.mergeFiles(String[], String, String)]

      @param arrD1DString0  array, corresponding java type is {String[]}
      @param oString1  String
      @param oString2  String
     */
    function mergeFiles($arrD1DString0, $oString1, $oString2)
    {
        $this->m_CellsHelper->mergeFiles($arrD1DString0, $oString1, $oString2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsHelper.rowIndexToName(int)]

      @param pInt0  int
      @return String
     */
    function rowIndexToName($pInt0)
    {
        return $this->m_CellsHelper->rowIndexToName($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsHelper.rowNameToIndex(String)]

      @param oString0  String
      @return int
     */
    function rowNameToIndex($oString0)
    {
        return $this->m_CellsHelper->rowNameToIndex($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsHelper.setAltStartPath(String)]

      @param oString0  String
     */
    function setAltStartPath($oString0)
    {
        $this->m_CellsHelper->setAltStartPath($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsHelper.setFontDir(String)]

      @param oString0  String
     */
    function setFontDir($oString0)
    {
        $this->m_CellsHelper->setFontDir($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsHelper.setFontDirs(ArrayList)]

      @param arrA1DFromArrayList0  array, corresponding java type is {java.util.ArrayList}
     */
    function setFontDirs($arrA1DFromArrayList0)
    {
        $this->m_CellsHelper->setFontDirs(ClassFactory::_t1($arrA1DFromArrayList0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsHelper.setFontFiles(ArrayList)]

      @param arrA1DFromArrayList0  array, corresponding java type is {java.util.ArrayList}
     */
    function setFontFiles($arrA1DFromArrayList0)
    {
        $this->m_CellsHelper->setFontFiles(ClassFactory::_t1($arrA1DFromArrayList0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsHelper.setLibraryPath(String)]

      @param oString0  String
     */
    function setLibraryPath($oString0)
    {
        $this->m_CellsHelper->setLibraryPath($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCellsHelper.setStartupPath(String)]

      @param oString0  String
     */
    function setStartupPath($oString0)
    {
        $this->m_CellsHelper->setStartupPath($oString0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsCellValueType]
  
 */
class CellValueType
{
    public $m_CellValueType;
    
    function __construct($cellValueType)
    {
    	$this->m_CellValueType = $cellValueType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsChart]
  
 */
class Chart
{
    public $m_Chart;
    
    function __construct($chart)
    {
    	$this->m_Chart = $chart;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsChart.calculate()]

     */
    function calculate()
    {
        $this->m_Chart->calculate();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getAutoScaling()]

      @return boolean
     */
    function getAutoScaling()
    {
        return $this->m_Chart->getAutoScaling();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getCategoryAxis()]

      @return com.aspose.cells.Axis
     */
    function getCategoryAxis()
    {
        return ClassFactory::_t2($this->m_Chart->getCategoryAxis());
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getChartArea()]

      @return com.aspose.cells.ChartArea
     */
    function getChartArea()
    {
        return ClassFactory::_t2($this->m_Chart->getChartArea());
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getChartDataTable()]

      @return com.aspose.cells.ChartDataTable
     */
    function getChartDataTable()
    {
        return ClassFactory::_t2($this->m_Chart->getChartDataTable());
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getChartObject()]

      @return com.aspose.cells.ChartShape
     */
    function getChartObject()
    {
        return ClassFactory::_t2($this->m_Chart->getChartObject());
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getDepthPercent()]

      @return int
     */
    function getDepthPercent()
    {
        return $this->m_Chart->getDepthPercent();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getElevation()]

      @return int
     */
    function getElevation()
    {
        return $this->m_Chart->getElevation();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getFirstSliceAngle()]

      @return int
     */
    function getFirstSliceAngle()
    {
        return $this->m_Chart->getFirstSliceAngle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getFloor()]

      @return com.aspose.cells.Floor
     */
    function getFloor()
    {
        return ClassFactory::_t2($this->m_Chart->getFloor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getGapDepth()]

      @return int
     */
    function getGapDepth()
    {
        return $this->m_Chart->getGapDepth();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getGapWidth()]

      @return int
     */
    function getGapWidth()
    {
        return $this->m_Chart->getGapWidth();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getHeightPercent()]

      @return short
     */
    function getHeightPercent()
    {
        return $this->m_Chart->getHeightPercent();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getHidePivotFieldButtons()]

      @return boolean
     */
    function getHidePivotFieldButtons()
    {
        return $this->m_Chart->getHidePivotFieldButtons();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getIs3D()]

      @return boolean
     */
    function getIs3D()
    {
        return $this->m_Chart->getIs3D();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getLegend()]

      @return com.aspose.cells.Legend
     */
    function getLegend()
    {
        return ClassFactory::_t2($this->m_Chart->getLegend());
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getNSeries()]

      @return com.aspose.cells.SeriesCollection
     */
    function getNSeries()
    {
        return ClassFactory::_t2($this->m_Chart->getNSeries());
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getName()]

      @return String
     */
    function getName()
    {
        return $this->m_Chart->getName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getPageSetup()]

      @return com.aspose.cells.PageSetup
     */
    function getPageSetup()
    {
        return ClassFactory::_t2($this->m_Chart->getPageSetup());
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getPerspective()]

      @return short
     */
    function getPerspective()
    {
        return $this->m_Chart->getPerspective();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getPivotSource()]

      @return String
     */
    function getPivotSource()
    {
        return $this->m_Chart->getPivotSource();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getPlacement()]

      @return int
     */
    function getPlacement()
    {
        return $this->m_Chart->getPlacement();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getPlotArea()]

      @return com.aspose.cells.ChartFrame
     */
    function getPlotArea()
    {
        return ClassFactory::_t2($this->m_Chart->getPlotArea());
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getPlotAreaWithoutTickLabels()]

      @return com.aspose.cells.ChartFrame
     */
    function getPlotAreaWithoutTickLabels()
    {
        return ClassFactory::_t2($this->m_Chart->getPlotAreaWithoutTickLabels());
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getPlotEmptyCellsType()]

      @return int
     */
    function getPlotEmptyCellsType()
    {
        return $this->m_Chart->getPlotEmptyCellsType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getPlotVisibleCells()]

      @return boolean
     */
    function getPlotVisibleCells()
    {
        return $this->m_Chart->getPlotVisibleCells();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getPrintSize()]

      @return int
     */
    function getPrintSize()
    {
        return $this->m_Chart->getPrintSize();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getRightAngleAxes()]

      @return boolean
     */
    function getRightAngleAxes()
    {
        return $this->m_Chart->getRightAngleAxes();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getRotation()]

      @return int
     */
    function getRotation()
    {
        return $this->m_Chart->getRotation();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getRotationAngle()]

      @return int
     */
    function getRotationAngle()
    {
        return $this->m_Chart->getRotationAngle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getSecondCategoryAxis()]

      @return com.aspose.cells.Axis
     */
    function getSecondCategoryAxis()
    {
        return ClassFactory::_t2($this->m_Chart->getSecondCategoryAxis());
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getSecondValueAxis()]

      @return com.aspose.cells.Axis
     */
    function getSecondValueAxis()
    {
        return ClassFactory::_t2($this->m_Chart->getSecondValueAxis());
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getSeriesAxis()]

      @return com.aspose.cells.Axis
     */
    function getSeriesAxis()
    {
        return ClassFactory::_t2($this->m_Chart->getSeriesAxis());
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getShapes()]

      @return com.aspose.cells.ShapeCollection
     */
    function getShapes()
    {
        return ClassFactory::_t2($this->m_Chart->getShapes());
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getShowDataTable()]

      @return boolean
     */
    function getShowDataTable()
    {
        return $this->m_Chart->getShowDataTable();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getShowLegend()]

      @return boolean
     */
    function getShowLegend()
    {
        return $this->m_Chart->getShowLegend();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getSizeWithWindow()]

      @return boolean
     */
    function getSizeWithWindow()
    {
        return $this->m_Chart->getSizeWithWindow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getStyle()]

      @return int
     */
    function getStyle()
    {
        return $this->m_Chart->getStyle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getTitle()]

      @return com.aspose.cells.Title
     */
    function getTitle()
    {
        return ClassFactory::_t2($this->m_Chart->getTitle());
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getType()]

      @return int
     */
    function getType()
    {
        return $this->m_Chart->getType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getValueAxis()]

      @return com.aspose.cells.Axis
     */
    function getValueAxis()
    {
        return ClassFactory::_t2($this->m_Chart->getValueAxis());
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getWalls()]

      @return com.aspose.cells.Walls
     */
    function getWalls()
    {
        return ClassFactory::_t2($this->m_Chart->getWalls());
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.getWallsAndGridlines2D()]

      @return boolean
     */
    function getWallsAndGridlines2D()
    {
        return $this->m_Chart->getWallsAndGridlines2D();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.isDataTableShown()]

      @return boolean
     */
    function isDataTableShown()
    {
        return $this->m_Chart->isDataTableShown();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.isLegendShown()]

      @return boolean
     */
    function isLegendShown()
    {
        return $this->m_Chart->isLegendShown();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.isRectangularCornered()]

      @return boolean
     */
    function isRectangularCornered()
    {
        return $this->m_Chart->isRectangularCornered();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.move(int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
     */
    function move($pInt0, $pInt1, $pInt2, $pInt3)
    {
        $this->m_Chart->move($pInt0, $pInt1, $pInt2, $pInt3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.setAutoScaling(boolean)]

      @param pBoolean0  boolean
     */
    function setAutoScaling($pBoolean0)
    {
        $this->m_Chart->setAutoScaling($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.setDataTableShown(boolean)]

      @param pBoolean0  boolean
     */
    function setDataTableShown($pBoolean0)
    {
        $this->m_Chart->setDataTableShown($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.setDepthPercent(int)]

      @param pInt0  int
     */
    function setDepthPercent($pInt0)
    {
        $this->m_Chart->setDepthPercent($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.setElevation(int)]

      @param pInt0  int
     */
    function setElevation($pInt0)
    {
        $this->m_Chart->setElevation($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.setFirstSliceAngle(int)]

      @param pInt0  int
     */
    function setFirstSliceAngle($pInt0)
    {
        $this->m_Chart->setFirstSliceAngle($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.setGapDepth(int)]

      @param pInt0  int
     */
    function setGapDepth($pInt0)
    {
        $this->m_Chart->setGapDepth($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.setGapWidth(int)]

      @param pInt0  int
     */
    function setGapWidth($pInt0)
    {
        $this->m_Chart->setGapWidth($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.setHeightPercent(short)]

      @param pShort0  short
     */
    function setHeightPercent($pShort0)
    {
        $this->m_Chart->setHeightPercent($pShort0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.setHidePivotFieldButtons(boolean)]

      @param pBoolean0  boolean
     */
    function setHidePivotFieldButtons($pBoolean0)
    {
        $this->m_Chart->setHidePivotFieldButtons($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.setLegendShown(boolean)]

      @param pBoolean0  boolean
     */
    function setLegendShown($pBoolean0)
    {
        $this->m_Chart->setLegendShown($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.setName(String)]

      @param oString0  String
     */
    function setName($oString0)
    {
        $this->m_Chart->setName($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.setPerspective(short)]

      @param pShort0  short
     */
    function setPerspective($pShort0)
    {
        $this->m_Chart->setPerspective($pShort0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.setPivotSource(String)]

      @param oString0  String
     */
    function setPivotSource($oString0)
    {
        $this->m_Chart->setPivotSource($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.setPlacement(int)]

      @param pInt0  int
     */
    function setPlacement($pInt0)
    {
        $this->m_Chart->setPlacement($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.setPlotEmptyCellsType(int)]

      @param pInt0  int
     */
    function setPlotEmptyCellsType($pInt0)
    {
        $this->m_Chart->setPlotEmptyCellsType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.setPlotVisibleCells(boolean)]

      @param pBoolean0  boolean
     */
    function setPlotVisibleCells($pBoolean0)
    {
        $this->m_Chart->setPlotVisibleCells($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.setPrintSize(int)]

      @param pInt0  int
     */
    function setPrintSize($pInt0)
    {
        $this->m_Chart->setPrintSize($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.setRectangularCornered(boolean)]

      @param pBoolean0  boolean
     */
    function setRectangularCornered($pBoolean0)
    {
        $this->m_Chart->setRectangularCornered($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.setRightAngleAxes(boolean)]

      @param pBoolean0  boolean
     */
    function setRightAngleAxes($pBoolean0)
    {
        $this->m_Chart->setRightAngleAxes($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.setRotation(int)]

      @param pInt0  int
     */
    function setRotation($pInt0)
    {
        $this->m_Chart->setRotation($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.setRotationAngle(int)]

      @param pInt0  int
     */
    function setRotationAngle($pInt0)
    {
        $this->m_Chart->setRotationAngle($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.setShowDataTable(boolean)]

      @param pBoolean0  boolean
     */
    function setShowDataTable($pBoolean0)
    {
        $this->m_Chart->setShowDataTable($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.setShowLegend(boolean)]

      @param pBoolean0  boolean
     */
    function setShowLegend($pBoolean0)
    {
        $this->m_Chart->setShowLegend($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.setSizeWithWindow(boolean)]

      @param pBoolean0  boolean
     */
    function setSizeWithWindow($pBoolean0)
    {
        $this->m_Chart->setSizeWithWindow($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.setStyle(int)]

      @param pInt0  int
     */
    function setStyle($pInt0)
    {
        $this->m_Chart->setStyle($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.setType(int)]

      @param pInt0  int
     */
    function setType($pInt0)
    {
        $this->m_Chart->setType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.setWallsAndGridlines2D(boolean)]

      @param pBoolean0  boolean
     */
    function setWallsAndGridlines2D($pBoolean0)
    {
        $this->m_Chart->setWallsAndGridlines2D($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.toImage(String)]

      @param oString0  String
     */
    function toImage($oString0)
    {
        $this->m_Chart->toImage($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.toImage(OutputStream, ImageOrPrintOptions)]

      @param oOutputStream0  corresponding java type is {java.io.OutputStream}
      @param oImageOrPrintOptions1  com.aspose.cells.ImageOrPrintOptions
     */
    function toImageOI($oOutputStream0, $oImageOrPrintOptions1)
    {
        $this->m_Chart->toImage(ClassFactory::_t1($oOutputStream0), ClassFactory::_t1($oImageOrPrintOptions1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.toImage(String, ImageFormat)]

      @param oString0  String
      @param oImageFormat1  com.aspose.cells.ImageFormat
     */
    function toImageSI($oString0, $oImageFormat1)
    {
        $this->m_Chart->toImage($oString0, ClassFactory::_t1($oImageFormat1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.toImage(String, ImageOrPrintOptions)]

      @param oString0  String
      @param oImageOrPrintOptions1  com.aspose.cells.ImageOrPrintOptions
     */
    function toImageSI1($oString0, $oImageOrPrintOptions1)
    {
        $this->m_Chart->toImage($oString0, ClassFactory::_t1($oImageOrPrintOptions1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsChart.toImage(String, long)]

      @param oString0  String
      @param pLong1  long
     */
    function toImageSL($oString0, $pLong1)
    {
        $this->m_Chart->toImage($oString0, $pLong1);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsChartArea]
  
 */
class ChartArea extends ChartFrame
{
    public $m_ChartArea;
    
    function __construct($chartArea)
    {
    	$this->m_ChartArea = $chartArea;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsChartArea.getHeight()]

      @return int
     */
    function getHeight()
    {
        return $this->m_ChartArea->getHeight();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartArea.getTextFont()]

      @return com.aspose.cells.Font
     */
    function getTextFont()
    {
        return ClassFactory::_t2($this->m_ChartArea->getTextFont());
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartArea.getWidth()]

      @return int
     */
    function getWidth()
    {
        return $this->m_ChartArea->getWidth();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartArea.getX()]

      @return int
     */
    function getX()
    {
        return $this->m_ChartArea->getX();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartArea.getY()]

      @return int
     */
    function getY()
    {
        return $this->m_ChartArea->getY();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartArea.setHeight(int)]

      @param pInt0  int
     */
    function setHeight($pInt0)
    {
        $this->m_ChartArea->setHeight($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartArea.setWidth(int)]

      @param pInt0  int
     */
    function setWidth($pInt0)
    {
        $this->m_ChartArea->setWidth($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartArea.setX(int)]

      @param pInt0  int
     */
    function setX($pInt0)
    {
        $this->m_ChartArea->setX($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartArea.setY(int)]

      @param pInt0  int
     */
    function setY($pInt0)
    {
        $this->m_ChartArea->setY($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsChartCollection]
  
 */
class ChartCollection extends CollectionBase
{
    public $m_ChartCollection;
    
    function __construct($chartCollection)
    {
    	$this->m_ChartCollection = $chartCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsChartCollection.add(int, int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @param pInt4  int
      @return int
     */
    function add($pInt0, $pInt1, $pInt2, $pInt3, $pInt4)
    {
        return $this->m_ChartCollection->add($pInt0, $pInt1, $pInt2, $pInt3, $pInt4);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartCollection.addFloatingChart(int, int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @param pInt4  int
      @return int
     */
    function addFloatingChart($pInt0, $pInt1, $pInt2, $pInt3, $pInt4)
    {
        return $this->m_ChartCollection->addFloatingChart($pInt0, $pInt1, $pInt2, $pInt3, $pInt4);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartCollection.clear()]

     */
    function clear()
    {
        $this->m_ChartCollection->clear();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartCollection.get(String)]

      @param oString0  String
      @return com.aspose.cells.Chart
     */
    function get($oString0)
    {
        return ClassFactory::_t2($this->m_ChartCollection->get($oString0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartCollection.get(int)]

      @param pInt0  int
      @return com.aspose.cells.Chart
     */
    function getI($pInt0)
    {
        return ClassFactory::_t2($this->m_ChartCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartCollection.removeAt(int)]

      @param pInt0  int
     */
    function removeAt($pInt0)
    {
        $this->m_ChartCollection->removeAt($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsChartDataTable]
  
 */
class ChartDataTable
{
    public $m_ChartDataTable;
    
    function __construct($chartDataTable)
    {
    	$this->m_ChartDataTable = $chartDataTable;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsChartDataTable.getAutoScaleFont()]

      @return boolean
     */
    function getAutoScaleFont()
    {
        return $this->m_ChartDataTable->getAutoScaleFont();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartDataTable.getBackground()]

      @return int
     */
    function getBackground()
    {
        return $this->m_ChartDataTable->getBackground();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartDataTable.getBorder()]

      @return com.aspose.cells.Line
     */
    function getBorder()
    {
        return ClassFactory::_t2($this->m_ChartDataTable->getBorder());
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartDataTable.getFont()]

      @return com.aspose.cells.Font
     */
    function getFont()
    {
        return ClassFactory::_t2($this->m_ChartDataTable->getFont());
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartDataTable.getShowLegendKey()]

      @return boolean
     */
    function getShowLegendKey()
    {
        return $this->m_ChartDataTable->getShowLegendKey();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartDataTable.hasBorderHorizontal()]

      @return boolean
     */
    function hasBorderHorizontal()
    {
        return $this->m_ChartDataTable->hasBorderHorizontal();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartDataTable.hasBorderOutline()]

      @return boolean
     */
    function hasBorderOutline()
    {
        return $this->m_ChartDataTable->hasBorderOutline();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartDataTable.hasBorderVertical()]

      @return boolean
     */
    function hasBorderVertical()
    {
        return $this->m_ChartDataTable->hasBorderVertical();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartDataTable.setAutoScaleFont(boolean)]

      @param pBoolean0  boolean
     */
    function setAutoScaleFont($pBoolean0)
    {
        $this->m_ChartDataTable->setAutoScaleFont($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartDataTable.setBackground(int)]

      @param pInt0  int
     */
    function setBackground($pInt0)
    {
        $this->m_ChartDataTable->setBackground($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartDataTable.setHasBorderHorizontal(boolean)]

      @param pBoolean0  boolean
     */
    function setHasBorderHorizontal($pBoolean0)
    {
        $this->m_ChartDataTable->setHasBorderHorizontal($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartDataTable.setHasBorderOutline(boolean)]

      @param pBoolean0  boolean
     */
    function setHasBorderOutline($pBoolean0)
    {
        $this->m_ChartDataTable->setHasBorderOutline($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartDataTable.setHasBorderVertical(boolean)]

      @param pBoolean0  boolean
     */
    function setHasBorderVertical($pBoolean0)
    {
        $this->m_ChartDataTable->setHasBorderVertical($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartDataTable.setShowLegendKey(boolean)]

      @param pBoolean0  boolean
     */
    function setShowLegendKey($pBoolean0)
    {
        $this->m_ChartDataTable->setShowLegendKey($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsChartFrame]
  
 */
class ChartFrame
{
    public $m_ChartFrame;
    
    function __construct($chartFrame)
    {
    	$this->m_ChartFrame = $chartFrame;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsChartFrame.getArea()]

      @return com.aspose.cells.Area
     */
    function getArea()
    {
        return ClassFactory::_t2($this->m_ChartFrame->getArea());
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartFrame.getAutoScaleFont()]

      @return boolean
     */
    function getAutoScaleFont()
    {
        return $this->m_ChartFrame->getAutoScaleFont();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartFrame.getBackground()]

      @return int
     */
    function getBackground()
    {
        return $this->m_ChartFrame->getBackground();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartFrame.getBackgroundMode()]

      @return int
     */
    function getBackgroundMode()
    {
        return $this->m_ChartFrame->getBackgroundMode();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartFrame.getBorder()]

      @return com.aspose.cells.Line
     */
    function getBorder()
    {
        return ClassFactory::_t2($this->m_ChartFrame->getBorder());
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartFrame.getHeight()]

      @return int
     */
    function getHeight()
    {
        return $this->m_ChartFrame->getHeight();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartFrame.getShadow()]

      @return boolean
     */
    function getShadow()
    {
        return $this->m_ChartFrame->getShadow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartFrame.getShapeProperties()]

      @return com.aspose.cells.ShapeProperties
     */
    function getShapeProperties()
    {
        return ClassFactory::_t2($this->m_ChartFrame->getShapeProperties());
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartFrame.getTextFont()]

      @return com.aspose.cells.Font
     */
    function getTextFont()
    {
        return ClassFactory::_t2($this->m_ChartFrame->getTextFont());
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartFrame.getWidth()]

      @return int
     */
    function getWidth()
    {
        return $this->m_ChartFrame->getWidth();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartFrame.getX()]

      @return int
     */
    function getX()
    {
        return $this->m_ChartFrame->getX();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartFrame.getY()]

      @return int
     */
    function getY()
    {
        return $this->m_ChartFrame->getY();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartFrame.isAutomaticSize()]

      @return boolean
     */
    function isAutomaticSize()
    {
        return $this->m_ChartFrame->isAutomaticSize();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartFrame.setArea(Area)]

      @param oArea0  com.aspose.cells.Area
     */
    function setArea($oArea0)
    {
        $this->m_ChartFrame->setArea(ClassFactory::_t1($oArea0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartFrame.setAutoScaleFont(boolean)]

      @param pBoolean0  boolean
     */
    function setAutoScaleFont($pBoolean0)
    {
        $this->m_ChartFrame->setAutoScaleFont($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartFrame.setAutomaticSize(boolean)]

      @param pBoolean0  boolean
     */
    function setAutomaticSize($pBoolean0)
    {
        $this->m_ChartFrame->setAutomaticSize($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartFrame.setBackground(int)]

      @param pInt0  int
     */
    function setBackground($pInt0)
    {
        $this->m_ChartFrame->setBackground($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartFrame.setBackgroundMode(int)]

      @param pInt0  int
     */
    function setBackgroundMode($pInt0)
    {
        $this->m_ChartFrame->setBackgroundMode($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartFrame.setBorder(Line)]

      @param oLine0  com.aspose.cells.Line
     */
    function setBorder($oLine0)
    {
        $this->m_ChartFrame->setBorder(ClassFactory::_t1($oLine0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartFrame.setHeight(int)]

      @param pInt0  int
     */
    function setHeight($pInt0)
    {
        $this->m_ChartFrame->setHeight($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartFrame.setShadow(boolean)]

      @param pBoolean0  boolean
     */
    function setShadow($pBoolean0)
    {
        $this->m_ChartFrame->setShadow($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartFrame.setWidth(int)]

      @param pInt0  int
     */
    function setWidth($pInt0)
    {
        $this->m_ChartFrame->setWidth($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartFrame.setX(int)]

      @param pInt0  int
     */
    function setX($pInt0)
    {
        $this->m_ChartFrame->setX($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartFrame.setY(int)]

      @param pInt0  int
     */
    function setY($pInt0)
    {
        $this->m_ChartFrame->setY($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsChartMarkerType]
  
 */
class ChartMarkerType
{
    public $m_ChartMarkerType;
    
    function __construct($chartMarkerType)
    {
    	$this->m_ChartMarkerType = $chartMarkerType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsChartPoint]
  
 */
class ChartPoint
{
    public $m_ChartPoint;
    
    function __construct($chartPoint)
    {
    	$this->m_ChartPoint = $chartPoint;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsChartPoint.getArea()]

      @return com.aspose.cells.Area
     */
    function getArea()
    {
        return ClassFactory::_t2($this->m_ChartPoint->getArea());
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartPoint.getBorder()]

      @return com.aspose.cells.Line
     */
    function getBorder()
    {
        return ClassFactory::_t2($this->m_ChartPoint->getBorder());
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartPoint.getDataLabels()]

      @return com.aspose.cells.DataLabels
     */
    function getDataLabels()
    {
        return ClassFactory::_t2($this->m_ChartPoint->getDataLabels());
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartPoint.getExplosion()]

      @return int
     */
    function getExplosion()
    {
        return $this->m_ChartPoint->getExplosion();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartPoint.getMarkerBackgroundColor()]

      @return com.aspose.cells.Color
     */
    function getMarkerBackgroundColor()
    {
        return ClassFactory::_t2($this->m_ChartPoint->getMarkerBackgroundColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartPoint.getMarkerBackgroundColorSetType()]

      @return int
     */
    function getMarkerBackgroundColorSetType()
    {
        return $this->m_ChartPoint->getMarkerBackgroundColorSetType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartPoint.getMarkerForegroundColor()]

      @return com.aspose.cells.Color
     */
    function getMarkerForegroundColor()
    {
        return ClassFactory::_t2($this->m_ChartPoint->getMarkerForegroundColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartPoint.getMarkerForegroundColorSetType()]

      @return int
     */
    function getMarkerForegroundColorSetType()
    {
        return $this->m_ChartPoint->getMarkerForegroundColorSetType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartPoint.getMarkerSize()]

      @return int
     */
    function getMarkerSize()
    {
        return $this->m_ChartPoint->getMarkerSize();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartPoint.getMarkerStyle()]

      @return int
     */
    function getMarkerStyle()
    {
        return $this->m_ChartPoint->getMarkerStyle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartPoint.getShadow()]

      @return boolean
     */
    function getShadow()
    {
        return $this->m_ChartPoint->getShadow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartPoint.setExplosion(int)]

      @param pInt0  int
     */
    function setExplosion($pInt0)
    {
        $this->m_ChartPoint->setExplosion($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartPoint.setMarkerBackgroundColor(Color)]

      @param oColor0  com.aspose.cells.Color
     */
    function setMarkerBackgroundColor($oColor0)
    {
        $this->m_ChartPoint->setMarkerBackgroundColor(ClassFactory::_t1($oColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartPoint.setMarkerBackgroundColorSetType(int)]

      @param pInt0  int
     */
    function setMarkerBackgroundColorSetType($pInt0)
    {
        $this->m_ChartPoint->setMarkerBackgroundColorSetType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartPoint.setMarkerForegroundColor(Color)]

      @param oColor0  com.aspose.cells.Color
     */
    function setMarkerForegroundColor($oColor0)
    {
        $this->m_ChartPoint->setMarkerForegroundColor(ClassFactory::_t1($oColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartPoint.setMarkerForegroundColorSetType(int)]

      @param pInt0  int
     */
    function setMarkerForegroundColorSetType($pInt0)
    {
        $this->m_ChartPoint->setMarkerForegroundColorSetType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartPoint.setMarkerSize(int)]

      @param pInt0  int
     */
    function setMarkerSize($pInt0)
    {
        $this->m_ChartPoint->setMarkerSize($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartPoint.setMarkerStyle(int)]

      @param pInt0  int
     */
    function setMarkerStyle($pInt0)
    {
        $this->m_ChartPoint->setMarkerStyle($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartPoint.setShadow(boolean)]

      @param pBoolean0  boolean
     */
    function setShadow($pBoolean0)
    {
        $this->m_ChartPoint->setShadow($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsChartPointCollection]
  
 */
class ChartPointCollection
{
    public $m_ChartPointCollection;
    
    function __construct($chartPointCollection)
    {
    	$this->m_ChartPointCollection = $chartPointCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsChartPointCollection.clear()]

     */
    function clear()
    {
        $this->m_ChartPointCollection->clear();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartPointCollection.get(int)]

      @param pInt0  int
      @return com.aspose.cells.ChartPoint
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_ChartPointCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartPointCollection.getCount()]

      @return int
     */
    function getCount()
    {
        return $this->m_ChartPointCollection->getCount();
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartPointCollection.iterator()]

      @return corresponding java type is {java.util.Iterator}
     */
    function iterator()
    {
        return ClassFactory::_t2($this->m_ChartPointCollection->iterator());
    }

    /*
      Wrapper for java version method [com.aspose.cellsChartPointCollection.removeAt(int)]

      @param pInt0  int
     */
    function removeAt($pInt0)
    {
        $this->m_ChartPointCollection->removeAt($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsChartShape]
  
 */
class ChartShape extends Shape
{
    public $m_ChartShape;
    
    function __construct($chartShape)
    {
    	$this->m_ChartShape = $chartShape;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsChartShape.getChart()]

      @return com.aspose.cells.Chart
     */
    function getChart()
    {
        return ClassFactory::_t2($this->m_ChartShape->getChart());
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsChartSplitType]
  
 */
class ChartSplitType
{
    public $m_ChartSplitType;
    
    function __construct($chartSplitType)
    {
    	$this->m_ChartSplitType = $chartSplitType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsChartType]
  
 */
class ChartType
{
    public $m_ChartType;
    
    function __construct($chartType)
    {
    	$this->m_ChartType = $chartType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsCheckBox]
  
 */
class CheckBox extends Shape
{
    public $m_CheckBox;
    
    function __construct($checkBox)
    {
    	$this->m_CheckBox = $checkBox;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsCheckBox.getCheckValue()]

      @return int
     */
    function getCheckValue()
    {
        return $this->m_CheckBox->getCheckValue();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCheckBox.getCheckedValue()]

      @return int
     */
    function getCheckedValue()
    {
        return $this->m_CheckBox->getCheckedValue();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCheckBox.getShadow()]

      @return boolean
     */
    function getShadow()
    {
        return $this->m_CheckBox->getShadow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCheckBox.getValue()]

      @return boolean
     */
    function getValue()
    {
        return $this->m_CheckBox->getValue();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCheckBox.setCheckValue(int)]

      @param pInt0  int
     */
    function setCheckValue($pInt0)
    {
        $this->m_CheckBox->setCheckValue($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCheckBox.setCheckedValue(int)]

      @param pInt0  int
     */
    function setCheckedValue($pInt0)
    {
        $this->m_CheckBox->setCheckedValue($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCheckBox.setShadow(boolean)]

      @param pBoolean0  boolean
     */
    function setShadow($pBoolean0)
    {
        $this->m_CheckBox->setShadow($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCheckBox.setValue(boolean)]

      @param pBoolean0  boolean
     */
    function setValue($pBoolean0)
    {
        $this->m_CheckBox->setValue($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsCheckBoxCollection]
  
 */
class CheckBoxCollection extends CollectionBase
{
    public $m_CheckBoxCollection;
    
    function __construct($checkBoxCollection)
    {
    	$this->m_CheckBoxCollection = $checkBoxCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsCheckBoxCollection.add(int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @return int
     */
    function add($pInt0, $pInt1, $pInt2, $pInt3)
    {
        return $this->m_CheckBoxCollection->add($pInt0, $pInt1, $pInt2, $pInt3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCheckBoxCollection.get(int)]

      @param pInt0  int
      @return com.aspose.cells.CheckBox
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_CheckBoxCollection->get($pInt0));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsCheckValueType]
  
 */
class CheckValueType
{
    public $m_CheckValueType;
    
    function __construct($checkValueType)
    {
    	$this->m_CheckValueType = $checkValueType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsCollectionBase]
  
 */
class CollectionBase
{
    public $m_CollectionBase;
    
    function __construct($collectionBase)
    {
    	$this->m_CollectionBase = $collectionBase;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsCollectionBase.add(Object)]

      @param oObject0  corresponding java type is {java.lang.Object}
      @return int
     */
    function add($oObject0)
    {
        return $this->m_CollectionBase->add(ClassFactory::_t1($oObject0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCollectionBase.clear()]

     */
    function clear()
    {
        $this->m_CollectionBase->clear();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCollectionBase.contains(Object)]

      @param oObject0  corresponding java type is {java.lang.Object}
      @return boolean
     */
    function contains($oObject0)
    {
        return $this->m_CollectionBase->contains(ClassFactory::_t1($oObject0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCollectionBase.get(int)]

      @param pInt0  int
      @return corresponding java type is {java.lang.Object}
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_CollectionBase->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCollectionBase.getCount()]

      @return int
     */
    function getCount()
    {
        return $this->m_CollectionBase->getCount();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCollectionBase.indexOf(Object)]

      @param oObject0  corresponding java type is {java.lang.Object}
      @return int
     */
    function indexOf($oObject0)
    {
        return $this->m_CollectionBase->indexOf(ClassFactory::_t1($oObject0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCollectionBase.iterator()]

      @return corresponding java type is {java.util.Iterator}
     */
    function iterator()
    {
        return ClassFactory::_t2($this->m_CollectionBase->iterator());
    }

    /*
      Wrapper for java version method [com.aspose.cellsCollectionBase.remove(Object)]

      @param oObject0  corresponding java type is {java.lang.Object}
     */
    function remove($oObject0)
    {
        $this->m_CollectionBase->remove(ClassFactory::_t1($oObject0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCollectionBase.removeAt(int)]

      @param pInt0  int
     */
    function removeAt($pInt0)
    {
        $this->m_CollectionBase->removeAt($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsColor]
  
 */
class Color
{
    public $m_Color;
    
    function __construct($color)
    {
    	$this->m_Color = $color;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsColor.equals(Object)]

      @param oObject0  corresponding java type is {java.lang.Object}
      @return boolean
     */
    function equals($oObject0)
    {
        return $this->m_Color->equals(ClassFactory::_t1($oObject0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.fromArgb(int)]

      @param pInt0  int
      @return com.aspose.cells.Color
     */
    function fromArgb($pInt0)
    {
        return ClassFactory::_t2($this->m_Color->fromArgb($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.fromArgb(int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @return com.aspose.cells.Color
     */
    function fromArgbIII($pInt0, $pInt1, $pInt2)
    {
        return ClassFactory::_t2($this->m_Color->fromArgb($pInt0, $pInt1, $pInt2));
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.fromArgb(int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @return com.aspose.cells.Color
     */
    function fromArgbIIII($pInt0, $pInt1, $pInt2, $pInt3)
    {
        return ClassFactory::_t2($this->m_Color->fromArgb($pInt0, $pInt1, $pInt2, $pInt3));
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getA()]

      @return byte
     */
    function getA()
    {
        return $this->m_Color->getA();
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getAliceBlue()]

      @return com.aspose.cells.Color
     */
    function getAliceBlue()
    {
        return ClassFactory::_t2($this->m_Color->getAliceBlue());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getAntiqueWhite()]

      @return com.aspose.cells.Color
     */
    function getAntiqueWhite()
    {
        return ClassFactory::_t2($this->m_Color->getAntiqueWhite());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getAqua()]

      @return com.aspose.cells.Color
     */
    function getAqua()
    {
        return ClassFactory::_t2($this->m_Color->getAqua());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getAquamarine()]

      @return com.aspose.cells.Color
     */
    function getAquamarine()
    {
        return ClassFactory::_t2($this->m_Color->getAquamarine());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getAzure()]

      @return com.aspose.cells.Color
     */
    function getAzure()
    {
        return ClassFactory::_t2($this->m_Color->getAzure());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getB()]

      @return byte
     */
    function getB()
    {
        return $this->m_Color->getB();
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getBeige()]

      @return com.aspose.cells.Color
     */
    function getBeige()
    {
        return ClassFactory::_t2($this->m_Color->getBeige());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getBisque()]

      @return com.aspose.cells.Color
     */
    function getBisque()
    {
        return ClassFactory::_t2($this->m_Color->getBisque());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getBlack()]

      @return com.aspose.cells.Color
     */
    function getBlack()
    {
        return ClassFactory::_t2($this->m_Color->getBlack());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getBlanchedAlmond()]

      @return com.aspose.cells.Color
     */
    function getBlanchedAlmond()
    {
        return ClassFactory::_t2($this->m_Color->getBlanchedAlmond());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getBlue()]

      @return com.aspose.cells.Color
     */
    function getBlue()
    {
        return ClassFactory::_t2($this->m_Color->getBlue());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getBlueViolet()]

      @return com.aspose.cells.Color
     */
    function getBlueViolet()
    {
        return ClassFactory::_t2($this->m_Color->getBlueViolet());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getBrown()]

      @return com.aspose.cells.Color
     */
    function getBrown()
    {
        return ClassFactory::_t2($this->m_Color->getBrown());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getBurlyWood()]

      @return com.aspose.cells.Color
     */
    function getBurlyWood()
    {
        return ClassFactory::_t2($this->m_Color->getBurlyWood());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getCadetBlue()]

      @return com.aspose.cells.Color
     */
    function getCadetBlue()
    {
        return ClassFactory::_t2($this->m_Color->getCadetBlue());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getChartreuse()]

      @return com.aspose.cells.Color
     */
    function getChartreuse()
    {
        return ClassFactory::_t2($this->m_Color->getChartreuse());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getChocolate()]

      @return com.aspose.cells.Color
     */
    function getChocolate()
    {
        return ClassFactory::_t2($this->m_Color->getChocolate());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getCoral()]

      @return com.aspose.cells.Color
     */
    function getCoral()
    {
        return ClassFactory::_t2($this->m_Color->getCoral());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getCornflowerBlue()]

      @return com.aspose.cells.Color
     */
    function getCornflowerBlue()
    {
        return ClassFactory::_t2($this->m_Color->getCornflowerBlue());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getCornsilk()]

      @return com.aspose.cells.Color
     */
    function getCornsilk()
    {
        return ClassFactory::_t2($this->m_Color->getCornsilk());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getCrimson()]

      @return com.aspose.cells.Color
     */
    function getCrimson()
    {
        return ClassFactory::_t2($this->m_Color->getCrimson());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getCyan()]

      @return com.aspose.cells.Color
     */
    function getCyan()
    {
        return ClassFactory::_t2($this->m_Color->getCyan());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getDarkBlue()]

      @return com.aspose.cells.Color
     */
    function getDarkBlue()
    {
        return ClassFactory::_t2($this->m_Color->getDarkBlue());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getDarkCyan()]

      @return com.aspose.cells.Color
     */
    function getDarkCyan()
    {
        return ClassFactory::_t2($this->m_Color->getDarkCyan());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getDarkGoldenrod()]

      @return com.aspose.cells.Color
     */
    function getDarkGoldenrod()
    {
        return ClassFactory::_t2($this->m_Color->getDarkGoldenrod());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getDarkGray()]

      @return com.aspose.cells.Color
     */
    function getDarkGray()
    {
        return ClassFactory::_t2($this->m_Color->getDarkGray());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getDarkGreen()]

      @return com.aspose.cells.Color
     */
    function getDarkGreen()
    {
        return ClassFactory::_t2($this->m_Color->getDarkGreen());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getDarkKhaki()]

      @return com.aspose.cells.Color
     */
    function getDarkKhaki()
    {
        return ClassFactory::_t2($this->m_Color->getDarkKhaki());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getDarkMagenta()]

      @return com.aspose.cells.Color
     */
    function getDarkMagenta()
    {
        return ClassFactory::_t2($this->m_Color->getDarkMagenta());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getDarkOliveGreen()]

      @return com.aspose.cells.Color
     */
    function getDarkOliveGreen()
    {
        return ClassFactory::_t2($this->m_Color->getDarkOliveGreen());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getDarkOrange()]

      @return com.aspose.cells.Color
     */
    function getDarkOrange()
    {
        return ClassFactory::_t2($this->m_Color->getDarkOrange());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getDarkOrchid()]

      @return com.aspose.cells.Color
     */
    function getDarkOrchid()
    {
        return ClassFactory::_t2($this->m_Color->getDarkOrchid());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getDarkRed()]

      @return com.aspose.cells.Color
     */
    function getDarkRed()
    {
        return ClassFactory::_t2($this->m_Color->getDarkRed());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getDarkSalmon()]

      @return com.aspose.cells.Color
     */
    function getDarkSalmon()
    {
        return ClassFactory::_t2($this->m_Color->getDarkSalmon());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getDarkSeaGreen()]

      @return com.aspose.cells.Color
     */
    function getDarkSeaGreen()
    {
        return ClassFactory::_t2($this->m_Color->getDarkSeaGreen());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getDarkSlateBlue()]

      @return com.aspose.cells.Color
     */
    function getDarkSlateBlue()
    {
        return ClassFactory::_t2($this->m_Color->getDarkSlateBlue());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getDarkSlateGray()]

      @return com.aspose.cells.Color
     */
    function getDarkSlateGray()
    {
        return ClassFactory::_t2($this->m_Color->getDarkSlateGray());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getDarkTurquoise()]

      @return com.aspose.cells.Color
     */
    function getDarkTurquoise()
    {
        return ClassFactory::_t2($this->m_Color->getDarkTurquoise());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getDarkViolet()]

      @return com.aspose.cells.Color
     */
    function getDarkViolet()
    {
        return ClassFactory::_t2($this->m_Color->getDarkViolet());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getDeepPink()]

      @return com.aspose.cells.Color
     */
    function getDeepPink()
    {
        return ClassFactory::_t2($this->m_Color->getDeepPink());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getDeepSkyBlue()]

      @return com.aspose.cells.Color
     */
    function getDeepSkyBlue()
    {
        return ClassFactory::_t2($this->m_Color->getDeepSkyBlue());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getDimGray()]

      @return com.aspose.cells.Color
     */
    function getDimGray()
    {
        return ClassFactory::_t2($this->m_Color->getDimGray());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getDodgerBlue()]

      @return com.aspose.cells.Color
     */
    function getDodgerBlue()
    {
        return ClassFactory::_t2($this->m_Color->getDodgerBlue());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getEmpty()]

      @return com.aspose.cells.Color
     */
    function getEmpty()
    {
        return ClassFactory::_t2($this->m_Color->getEmpty());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getFirebrick()]

      @return com.aspose.cells.Color
     */
    function getFirebrick()
    {
        return ClassFactory::_t2($this->m_Color->getFirebrick());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getFloralWhite()]

      @return com.aspose.cells.Color
     */
    function getFloralWhite()
    {
        return ClassFactory::_t2($this->m_Color->getFloralWhite());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getForestGreen()]

      @return com.aspose.cells.Color
     */
    function getForestGreen()
    {
        return ClassFactory::_t2($this->m_Color->getForestGreen());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getFuchsia()]

      @return com.aspose.cells.Color
     */
    function getFuchsia()
    {
        return ClassFactory::_t2($this->m_Color->getFuchsia());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getG()]

      @return byte
     */
    function getG()
    {
        return $this->m_Color->getG();
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getGainsboro()]

      @return com.aspose.cells.Color
     */
    function getGainsboro()
    {
        return ClassFactory::_t2($this->m_Color->getGainsboro());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getGhostWhite()]

      @return com.aspose.cells.Color
     */
    function getGhostWhite()
    {
        return ClassFactory::_t2($this->m_Color->getGhostWhite());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getGold()]

      @return com.aspose.cells.Color
     */
    function getGold()
    {
        return ClassFactory::_t2($this->m_Color->getGold());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getGoldenrod()]

      @return com.aspose.cells.Color
     */
    function getGoldenrod()
    {
        return ClassFactory::_t2($this->m_Color->getGoldenrod());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getGray()]

      @return com.aspose.cells.Color
     */
    function getGray()
    {
        return ClassFactory::_t2($this->m_Color->getGray());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getGreen()]

      @return com.aspose.cells.Color
     */
    function getGreen()
    {
        return ClassFactory::_t2($this->m_Color->getGreen());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getGreenYellow()]

      @return com.aspose.cells.Color
     */
    function getGreenYellow()
    {
        return ClassFactory::_t2($this->m_Color->getGreenYellow());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getHoneydew()]

      @return com.aspose.cells.Color
     */
    function getHoneydew()
    {
        return ClassFactory::_t2($this->m_Color->getHoneydew());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getHotPink()]

      @return com.aspose.cells.Color
     */
    function getHotPink()
    {
        return ClassFactory::_t2($this->m_Color->getHotPink());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getIndianRed()]

      @return com.aspose.cells.Color
     */
    function getIndianRed()
    {
        return ClassFactory::_t2($this->m_Color->getIndianRed());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getIndigo()]

      @return com.aspose.cells.Color
     */
    function getIndigo()
    {
        return ClassFactory::_t2($this->m_Color->getIndigo());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getIvory()]

      @return com.aspose.cells.Color
     */
    function getIvory()
    {
        return ClassFactory::_t2($this->m_Color->getIvory());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getKhaki()]

      @return com.aspose.cells.Color
     */
    function getKhaki()
    {
        return ClassFactory::_t2($this->m_Color->getKhaki());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getLavender()]

      @return com.aspose.cells.Color
     */
    function getLavender()
    {
        return ClassFactory::_t2($this->m_Color->getLavender());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getLavenderBlush()]

      @return com.aspose.cells.Color
     */
    function getLavenderBlush()
    {
        return ClassFactory::_t2($this->m_Color->getLavenderBlush());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getLawnGreen()]

      @return com.aspose.cells.Color
     */
    function getLawnGreen()
    {
        return ClassFactory::_t2($this->m_Color->getLawnGreen());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getLemonChiffon()]

      @return com.aspose.cells.Color
     */
    function getLemonChiffon()
    {
        return ClassFactory::_t2($this->m_Color->getLemonChiffon());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getLightBlue()]

      @return com.aspose.cells.Color
     */
    function getLightBlue()
    {
        return ClassFactory::_t2($this->m_Color->getLightBlue());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getLightCoral()]

      @return com.aspose.cells.Color
     */
    function getLightCoral()
    {
        return ClassFactory::_t2($this->m_Color->getLightCoral());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getLightCyan()]

      @return com.aspose.cells.Color
     */
    function getLightCyan()
    {
        return ClassFactory::_t2($this->m_Color->getLightCyan());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getLightGoldenrodYellow()]

      @return com.aspose.cells.Color
     */
    function getLightGoldenrodYellow()
    {
        return ClassFactory::_t2($this->m_Color->getLightGoldenrodYellow());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getLightGray()]

      @return com.aspose.cells.Color
     */
    function getLightGray()
    {
        return ClassFactory::_t2($this->m_Color->getLightGray());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getLightGreen()]

      @return com.aspose.cells.Color
     */
    function getLightGreen()
    {
        return ClassFactory::_t2($this->m_Color->getLightGreen());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getLightPink()]

      @return com.aspose.cells.Color
     */
    function getLightPink()
    {
        return ClassFactory::_t2($this->m_Color->getLightPink());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getLightSalmon()]

      @return com.aspose.cells.Color
     */
    function getLightSalmon()
    {
        return ClassFactory::_t2($this->m_Color->getLightSalmon());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getLightSeaGreen()]

      @return com.aspose.cells.Color
     */
    function getLightSeaGreen()
    {
        return ClassFactory::_t2($this->m_Color->getLightSeaGreen());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getLightSkyBlue()]

      @return com.aspose.cells.Color
     */
    function getLightSkyBlue()
    {
        return ClassFactory::_t2($this->m_Color->getLightSkyBlue());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getLightSlateGray()]

      @return com.aspose.cells.Color
     */
    function getLightSlateGray()
    {
        return ClassFactory::_t2($this->m_Color->getLightSlateGray());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getLightSteelBlue()]

      @return com.aspose.cells.Color
     */
    function getLightSteelBlue()
    {
        return ClassFactory::_t2($this->m_Color->getLightSteelBlue());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getLightYellow()]

      @return com.aspose.cells.Color
     */
    function getLightYellow()
    {
        return ClassFactory::_t2($this->m_Color->getLightYellow());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getLime()]

      @return com.aspose.cells.Color
     */
    function getLime()
    {
        return ClassFactory::_t2($this->m_Color->getLime());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getLimeGreen()]

      @return com.aspose.cells.Color
     */
    function getLimeGreen()
    {
        return ClassFactory::_t2($this->m_Color->getLimeGreen());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getLinen()]

      @return com.aspose.cells.Color
     */
    function getLinen()
    {
        return ClassFactory::_t2($this->m_Color->getLinen());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getMagenta()]

      @return com.aspose.cells.Color
     */
    function getMagenta()
    {
        return ClassFactory::_t2($this->m_Color->getMagenta());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getMaroon()]

      @return com.aspose.cells.Color
     */
    function getMaroon()
    {
        return ClassFactory::_t2($this->m_Color->getMaroon());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getMediumAquamarine()]

      @return com.aspose.cells.Color
     */
    function getMediumAquamarine()
    {
        return ClassFactory::_t2($this->m_Color->getMediumAquamarine());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getMediumBlue()]

      @return com.aspose.cells.Color
     */
    function getMediumBlue()
    {
        return ClassFactory::_t2($this->m_Color->getMediumBlue());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getMediumOrchid()]

      @return com.aspose.cells.Color
     */
    function getMediumOrchid()
    {
        return ClassFactory::_t2($this->m_Color->getMediumOrchid());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getMediumPurple()]

      @return com.aspose.cells.Color
     */
    function getMediumPurple()
    {
        return ClassFactory::_t2($this->m_Color->getMediumPurple());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getMediumSeaGreen()]

      @return com.aspose.cells.Color
     */
    function getMediumSeaGreen()
    {
        return ClassFactory::_t2($this->m_Color->getMediumSeaGreen());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getMediumSlateBlue()]

      @return com.aspose.cells.Color
     */
    function getMediumSlateBlue()
    {
        return ClassFactory::_t2($this->m_Color->getMediumSlateBlue());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getMediumSpringGreen()]

      @return com.aspose.cells.Color
     */
    function getMediumSpringGreen()
    {
        return ClassFactory::_t2($this->m_Color->getMediumSpringGreen());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getMediumTurquoise()]

      @return com.aspose.cells.Color
     */
    function getMediumTurquoise()
    {
        return ClassFactory::_t2($this->m_Color->getMediumTurquoise());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getMediumVioletRed()]

      @return com.aspose.cells.Color
     */
    function getMediumVioletRed()
    {
        return ClassFactory::_t2($this->m_Color->getMediumVioletRed());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getMidnightBlue()]

      @return com.aspose.cells.Color
     */
    function getMidnightBlue()
    {
        return ClassFactory::_t2($this->m_Color->getMidnightBlue());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getMintCream()]

      @return com.aspose.cells.Color
     */
    function getMintCream()
    {
        return ClassFactory::_t2($this->m_Color->getMintCream());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getMistyRose()]

      @return com.aspose.cells.Color
     */
    function getMistyRose()
    {
        return ClassFactory::_t2($this->m_Color->getMistyRose());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getMoccasin()]

      @return com.aspose.cells.Color
     */
    function getMoccasin()
    {
        return ClassFactory::_t2($this->m_Color->getMoccasin());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getNavajoWhite()]

      @return com.aspose.cells.Color
     */
    function getNavajoWhite()
    {
        return ClassFactory::_t2($this->m_Color->getNavajoWhite());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getNavy()]

      @return com.aspose.cells.Color
     */
    function getNavy()
    {
        return ClassFactory::_t2($this->m_Color->getNavy());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getOldLace()]

      @return com.aspose.cells.Color
     */
    function getOldLace()
    {
        return ClassFactory::_t2($this->m_Color->getOldLace());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getOlive()]

      @return com.aspose.cells.Color
     */
    function getOlive()
    {
        return ClassFactory::_t2($this->m_Color->getOlive());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getOliveDrab()]

      @return com.aspose.cells.Color
     */
    function getOliveDrab()
    {
        return ClassFactory::_t2($this->m_Color->getOliveDrab());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getOrange()]

      @return com.aspose.cells.Color
     */
    function getOrange()
    {
        return ClassFactory::_t2($this->m_Color->getOrange());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getOrangeRed()]

      @return com.aspose.cells.Color
     */
    function getOrangeRed()
    {
        return ClassFactory::_t2($this->m_Color->getOrangeRed());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getOrchid()]

      @return com.aspose.cells.Color
     */
    function getOrchid()
    {
        return ClassFactory::_t2($this->m_Color->getOrchid());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getPaleGoldenrod()]

      @return com.aspose.cells.Color
     */
    function getPaleGoldenrod()
    {
        return ClassFactory::_t2($this->m_Color->getPaleGoldenrod());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getPaleGreen()]

      @return com.aspose.cells.Color
     */
    function getPaleGreen()
    {
        return ClassFactory::_t2($this->m_Color->getPaleGreen());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getPaleTurquoise()]

      @return com.aspose.cells.Color
     */
    function getPaleTurquoise()
    {
        return ClassFactory::_t2($this->m_Color->getPaleTurquoise());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getPaleVioletRed()]

      @return com.aspose.cells.Color
     */
    function getPaleVioletRed()
    {
        return ClassFactory::_t2($this->m_Color->getPaleVioletRed());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getPapayaWhip()]

      @return com.aspose.cells.Color
     */
    function getPapayaWhip()
    {
        return ClassFactory::_t2($this->m_Color->getPapayaWhip());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getPeachPuff()]

      @return com.aspose.cells.Color
     */
    function getPeachPuff()
    {
        return ClassFactory::_t2($this->m_Color->getPeachPuff());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getPeru()]

      @return com.aspose.cells.Color
     */
    function getPeru()
    {
        return ClassFactory::_t2($this->m_Color->getPeru());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getPink()]

      @return com.aspose.cells.Color
     */
    function getPink()
    {
        return ClassFactory::_t2($this->m_Color->getPink());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getPlum()]

      @return com.aspose.cells.Color
     */
    function getPlum()
    {
        return ClassFactory::_t2($this->m_Color->getPlum());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getPowderBlue()]

      @return com.aspose.cells.Color
     */
    function getPowderBlue()
    {
        return ClassFactory::_t2($this->m_Color->getPowderBlue());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getPurple()]

      @return com.aspose.cells.Color
     */
    function getPurple()
    {
        return ClassFactory::_t2($this->m_Color->getPurple());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getR()]

      @return byte
     */
    function getR()
    {
        return $this->m_Color->getR();
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getRed()]

      @return com.aspose.cells.Color
     */
    function getRed()
    {
        return ClassFactory::_t2($this->m_Color->getRed());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getRosyBrown()]

      @return com.aspose.cells.Color
     */
    function getRosyBrown()
    {
        return ClassFactory::_t2($this->m_Color->getRosyBrown());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getRoyalBlue()]

      @return com.aspose.cells.Color
     */
    function getRoyalBlue()
    {
        return ClassFactory::_t2($this->m_Color->getRoyalBlue());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getSaddleBrown()]

      @return com.aspose.cells.Color
     */
    function getSaddleBrown()
    {
        return ClassFactory::_t2($this->m_Color->getSaddleBrown());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getSalmon()]

      @return com.aspose.cells.Color
     */
    function getSalmon()
    {
        return ClassFactory::_t2($this->m_Color->getSalmon());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getSandyBrown()]

      @return com.aspose.cells.Color
     */
    function getSandyBrown()
    {
        return ClassFactory::_t2($this->m_Color->getSandyBrown());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getSeaGreen()]

      @return com.aspose.cells.Color
     */
    function getSeaGreen()
    {
        return ClassFactory::_t2($this->m_Color->getSeaGreen());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getSeaShell()]

      @return com.aspose.cells.Color
     */
    function getSeaShell()
    {
        return ClassFactory::_t2($this->m_Color->getSeaShell());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getSienna()]

      @return com.aspose.cells.Color
     */
    function getSienna()
    {
        return ClassFactory::_t2($this->m_Color->getSienna());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getSilver()]

      @return com.aspose.cells.Color
     */
    function getSilver()
    {
        return ClassFactory::_t2($this->m_Color->getSilver());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getSkyBlue()]

      @return com.aspose.cells.Color
     */
    function getSkyBlue()
    {
        return ClassFactory::_t2($this->m_Color->getSkyBlue());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getSlateBlue()]

      @return com.aspose.cells.Color
     */
    function getSlateBlue()
    {
        return ClassFactory::_t2($this->m_Color->getSlateBlue());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getSlateGray()]

      @return com.aspose.cells.Color
     */
    function getSlateGray()
    {
        return ClassFactory::_t2($this->m_Color->getSlateGray());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getSnow()]

      @return com.aspose.cells.Color
     */
    function getSnow()
    {
        return ClassFactory::_t2($this->m_Color->getSnow());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getSpringGreen()]

      @return com.aspose.cells.Color
     */
    function getSpringGreen()
    {
        return ClassFactory::_t2($this->m_Color->getSpringGreen());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getSteelBlue()]

      @return com.aspose.cells.Color
     */
    function getSteelBlue()
    {
        return ClassFactory::_t2($this->m_Color->getSteelBlue());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getTan()]

      @return com.aspose.cells.Color
     */
    function getTan()
    {
        return ClassFactory::_t2($this->m_Color->getTan());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getTeal()]

      @return com.aspose.cells.Color
     */
    function getTeal()
    {
        return ClassFactory::_t2($this->m_Color->getTeal());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getThistle()]

      @return com.aspose.cells.Color
     */
    function getThistle()
    {
        return ClassFactory::_t2($this->m_Color->getThistle());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getTomato()]

      @return com.aspose.cells.Color
     */
    function getTomato()
    {
        return ClassFactory::_t2($this->m_Color->getTomato());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getTransparent()]

      @return com.aspose.cells.Color
     */
    function getTransparent()
    {
        return ClassFactory::_t2($this->m_Color->getTransparent());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getTurquoise()]

      @return com.aspose.cells.Color
     */
    function getTurquoise()
    {
        return ClassFactory::_t2($this->m_Color->getTurquoise());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getViolet()]

      @return com.aspose.cells.Color
     */
    function getViolet()
    {
        return ClassFactory::_t2($this->m_Color->getViolet());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getWheat()]

      @return com.aspose.cells.Color
     */
    function getWheat()
    {
        return ClassFactory::_t2($this->m_Color->getWheat());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getWhite()]

      @return com.aspose.cells.Color
     */
    function getWhite()
    {
        return ClassFactory::_t2($this->m_Color->getWhite());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getWhiteSmoke()]

      @return com.aspose.cells.Color
     */
    function getWhiteSmoke()
    {
        return ClassFactory::_t2($this->m_Color->getWhiteSmoke());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getYellow()]

      @return com.aspose.cells.Color
     */
    function getYellow()
    {
        return ClassFactory::_t2($this->m_Color->getYellow());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.getYellowGreen()]

      @return com.aspose.cells.Color
     */
    function getYellowGreen()
    {
        return ClassFactory::_t2($this->m_Color->getYellowGreen());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.hashCode()]

      @return int
     */
    function hashCode()
    {
        return $this->m_Color->hashCode();
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.isEmpty()]

      @return boolean
     */
    function isEmpty()
    {
        return $this->m_Color->isEmpty();
    }

    /*
      Wrapper for java version method [com.aspose.cellsColor.toArgb()]

      @return int
     */
    function toArgb()
    {
        return $this->m_Color->toArgb();
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsColorFilter]
  
 */
class ColorFilter
{
    public $m_ColorFilter;
    
    function __construct($colorFilter)
    {
    	$this->m_ColorFilter = $colorFilter;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsColorFilter.getColor(WorksheetCollection)]

      @param oWorksheetCollection0  com.aspose.cells.WorksheetCollection
      @return com.aspose.cells.Color
     */
    function getColor($oWorksheetCollection0)
    {
        return ClassFactory::_t2($this->m_ColorFilter->getColor(ClassFactory::_t1($oWorksheetCollection0)));
    }

    /*
      Wrapper for java version method [com.aspose.cellsColorFilter.getFilterByFillColor()]

      @return boolean
     */
    function getFilterByFillColor()
    {
        return $this->m_ColorFilter->getFilterByFillColor();
    }

    /*
      Wrapper for java version method [com.aspose.cellsColorFilter.setFilterByFillColor(boolean)]

      @param pBoolean0  boolean
     */
    function setFilterByFillColor($pBoolean0)
    {
        $this->m_ColorFilter->setFilterByFillColor($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsColorScale]
  
 */
class ColorScale
{
    public $m_ColorScale;
    
    function __construct($colorScale)
    {
    	$this->m_ColorScale = $colorScale;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsColorScale.getMaxCfvo()]

      @return com.aspose.cells.ConditionalFormattingValue
     */
    function getMaxCfvo()
    {
        return ClassFactory::_t2($this->m_ColorScale->getMaxCfvo());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColorScale.getMaxColor()]

      @return com.aspose.cells.Color
     */
    function getMaxColor()
    {
        return ClassFactory::_t2($this->m_ColorScale->getMaxColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColorScale.getMidCfvo()]

      @return com.aspose.cells.ConditionalFormattingValue
     */
    function getMidCfvo()
    {
        return ClassFactory::_t2($this->m_ColorScale->getMidCfvo());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColorScale.getMidColor()]

      @return com.aspose.cells.Color
     */
    function getMidColor()
    {
        return ClassFactory::_t2($this->m_ColorScale->getMidColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColorScale.getMinCfvo()]

      @return com.aspose.cells.ConditionalFormattingValue
     */
    function getMinCfvo()
    {
        return ClassFactory::_t2($this->m_ColorScale->getMinCfvo());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColorScale.getMinColor()]

      @return com.aspose.cells.Color
     */
    function getMinColor()
    {
        return ClassFactory::_t2($this->m_ColorScale->getMinColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColorScale.setMaxColor(Color)]

      @param oColor0  com.aspose.cells.Color
     */
    function setMaxColor($oColor0)
    {
        $this->m_ColorScale->setMaxColor(ClassFactory::_t1($oColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsColorScale.setMidColor(Color)]

      @param oColor0  com.aspose.cells.Color
     */
    function setMidColor($oColor0)
    {
        $this->m_ColorScale->setMidColor(ClassFactory::_t1($oColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsColorScale.setMinColor(Color)]

      @param oColor0  com.aspose.cells.Color
     */
    function setMinColor($oColor0)
    {
        $this->m_ColorScale->setMinColor(ClassFactory::_t1($oColor0));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsColorType]
  
 */
class ColorType
{
    public $m_ColorType;
    
    function __construct($colorType)
    {
    	$this->m_ColorType = $colorType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsColumn]
  
 */
class Column
{
    public $m_Column;
    
    function __construct($column)
    {
    	$this->m_Column = $column;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsColumn.applyStyle(Style, StyleFlag)]

      @param oStyle0  com.aspose.cells.Style
      @param oStyleFlag1  com.aspose.cells.StyleFlag
     */
    function applyStyle($oStyle0, $oStyleFlag1)
    {
        $this->m_Column->applyStyle(ClassFactory::_t1($oStyle0), ClassFactory::_t1($oStyleFlag1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsColumn.getGroupLevel()]

      @return byte
     */
    function getGroupLevel()
    {
        return $this->m_Column->getGroupLevel();
    }

    /*
      Wrapper for java version method [com.aspose.cellsColumn.getIndex()]

      @return int
     */
    function getIndex()
    {
        return $this->m_Column->getIndex();
    }

    /*
      Wrapper for java version method [com.aspose.cellsColumn.getStyle()]

      @return com.aspose.cells.Style
     */
    function getStyle()
    {
        return ClassFactory::_t2($this->m_Column->getStyle());
    }

    /*
      Wrapper for java version method [com.aspose.cellsColumn.getWidth()]

      @return double
     */
    function getWidth()
    {
        return $this->m_Column->getWidth();
    }

    /*
      Wrapper for java version method [com.aspose.cellsColumn.isHidden()]

      @return boolean
     */
    function isHidden()
    {
        return $this->m_Column->isHidden();
    }

    /*
      Wrapper for java version method [com.aspose.cellsColumn.setHidden(boolean)]

      @param pBoolean0  boolean
     */
    function setHidden($pBoolean0)
    {
        $this->m_Column->setHidden($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsColumn.setWidth(double)]

      @param pDouble0  double
     */
    function setWidth($pDouble0)
    {
        $this->m_Column->setWidth($pDouble0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsColumnCollection]
  
 */
class ColumnCollection extends CollectionBase
{
    public $m_ColumnCollection;
    
    function __construct($columnCollection)
    {
    	$this->m_ColumnCollection = $columnCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsColumnCollection.get(int)]

      @param pInt0  int
      @return com.aspose.cells.Column
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_ColumnCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsColumnCollection.getByIndex(int)]

      @param pInt0  int
      @return com.aspose.cells.Column
     */
    function getByIndex($pInt0)
    {
        return ClassFactory::_t2($this->m_ColumnCollection->getByIndex($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsColumnCollection.getColumnByIndex(int)]

      @param pInt0  int
      @return com.aspose.cells.Column
     */
    function getColumnByIndex($pInt0)
    {
        return ClassFactory::_t2($this->m_ColumnCollection->getColumnByIndex($pInt0));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsComboBox]
  
 */
class ComboBox extends Shape
{
    public $m_ComboBox;
    
    function __construct($comboBox)
    {
    	$this->m_ComboBox = $comboBox;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsComboBox.getDropDownLines()]

      @return int
     */
    function getDropDownLines()
    {
        return $this->m_ComboBox->getDropDownLines();
    }

    /*
      Wrapper for java version method [com.aspose.cellsComboBox.getInputRange()]

      @return String
     */
    function getInputRange()
    {
        return $this->m_ComboBox->getInputRange();
    }

    /*
      Wrapper for java version method [com.aspose.cellsComboBox.getSelectedCell()]

      @return com.aspose.cells.Cell
     */
    function getSelectedCell()
    {
        return ClassFactory::_t2($this->m_ComboBox->getSelectedCell());
    }

    /*
      Wrapper for java version method [com.aspose.cellsComboBox.getSelectedIndex()]

      @return int
     */
    function getSelectedIndex()
    {
        return $this->m_ComboBox->getSelectedIndex();
    }

    /*
      Wrapper for java version method [com.aspose.cellsComboBox.getSelectedValue()]

      @return String
     */
    function getSelectedValue()
    {
        return $this->m_ComboBox->getSelectedValue();
    }

    /*
      Wrapper for java version method [com.aspose.cellsComboBox.getShadow()]

      @return boolean
     */
    function getShadow()
    {
        return $this->m_ComboBox->getShadow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsComboBox.setDropDownLines(int)]

      @param pInt0  int
     */
    function setDropDownLines($pInt0)
    {
        $this->m_ComboBox->setDropDownLines($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsComboBox.setInputRange(String)]

      @param oString0  String
     */
    function setInputRange($oString0)
    {
        $this->m_ComboBox->setInputRange($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsComboBox.setSelectedIndex(int)]

      @param pInt0  int
     */
    function setSelectedIndex($pInt0)
    {
        $this->m_ComboBox->setSelectedIndex($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsComboBox.setShadow(boolean)]

      @param pBoolean0  boolean
     */
    function setShadow($pBoolean0)
    {
        $this->m_ComboBox->setShadow($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsComment]
  
 */
class Comment
{
    public $m_Comment;
    
    function __construct($comment)
    {
    	$this->m_Comment = $comment;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsComment.characters(int, int)]

      @param pInt0  int
      @param pInt1  int
      @return com.aspose.cells.FontSetting
     */
    function characters($pInt0, $pInt1)
    {
        return ClassFactory::_t2($this->m_Comment->characters($pInt0, $pInt1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsComment.getAuthor()]

      @return String
     */
    function getAuthor()
    {
        return $this->m_Comment->getAuthor();
    }

    /*
      Wrapper for java version method [com.aspose.cellsComment.getAutoSize()]

      @return boolean
     */
    function getAutoSize()
    {
        return $this->m_Comment->getAutoSize();
    }

    /*
      Wrapper for java version method [com.aspose.cellsComment.getCharacters()]

      @return array, corresponding java type is {java.util.ArrayList}
     */
    function getCharacters()
    {
        return ClassFactory::_t2($this->m_Comment->getCharacters());
    }

    /*
      Wrapper for java version method [com.aspose.cellsComment.getColumn()]

      @return int
     */
    function getColumn()
    {
        return $this->m_Comment->getColumn();
    }

    /*
      Wrapper for java version method [com.aspose.cellsComment.getCommentShape()]

      @return com.aspose.cells.CommentShape
     */
    function getCommentShape()
    {
        return ClassFactory::_t2($this->m_Comment->getCommentShape());
    }

    /*
      Wrapper for java version method [com.aspose.cellsComment.getFont()]

      @return com.aspose.cells.Font
     */
    function getFont()
    {
        return ClassFactory::_t2($this->m_Comment->getFont());
    }

    /*
      Wrapper for java version method [com.aspose.cellsComment.getHeightCM()]

      @return double
     */
    function getHeightCM()
    {
        return $this->m_Comment->getHeightCM();
    }

    /*
      Wrapper for java version method [com.aspose.cellsComment.getHeightInch()]

      @return double
     */
    function getHeightInch()
    {
        return $this->m_Comment->getHeightInch();
    }

    /*
      Wrapper for java version method [com.aspose.cellsComment.getHtmlNote()]

      @return String
     */
    function getHtmlNote()
    {
        return $this->m_Comment->getHtmlNote();
    }

    /*
      Wrapper for java version method [com.aspose.cellsComment.getNote()]

      @return String
     */
    function getNote()
    {
        return $this->m_Comment->getNote();
    }

    /*
      Wrapper for java version method [com.aspose.cellsComment.getRow()]

      @return int
     */
    function getRow()
    {
        return $this->m_Comment->getRow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsComment.getTextHorizontalAlignment()]

      @return int
     */
    function getTextHorizontalAlignment()
    {
        return $this->m_Comment->getTextHorizontalAlignment();
    }

    /*
      Wrapper for java version method [com.aspose.cellsComment.getTextOrientationType()]

      @return int
     */
    function getTextOrientationType()
    {
        return $this->m_Comment->getTextOrientationType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsComment.getTextVerticalAlignment()]

      @return int
     */
    function getTextVerticalAlignment()
    {
        return $this->m_Comment->getTextVerticalAlignment();
    }

    /*
      Wrapper for java version method [com.aspose.cellsComment.getWidthCM()]

      @return double
     */
    function getWidthCM()
    {
        return $this->m_Comment->getWidthCM();
    }

    /*
      Wrapper for java version method [com.aspose.cellsComment.getWidthInch()]

      @return double
     */
    function getWidthInch()
    {
        return $this->m_Comment->getWidthInch();
    }

    /*
      Wrapper for java version method [com.aspose.cellsComment.isVisible()]

      @return boolean
     */
    function isVisible()
    {
        return $this->m_Comment->isVisible();
    }

    /*
      Wrapper for java version method [com.aspose.cellsComment.setAuthor(String)]

      @param oString0  String
     */
    function setAuthor($oString0)
    {
        $this->m_Comment->setAuthor($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsComment.setAutoSize(boolean)]

      @param pBoolean0  boolean
     */
    function setAutoSize($pBoolean0)
    {
        $this->m_Comment->setAutoSize($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsComment.setHeightCM(double)]

      @param pDouble0  double
     */
    function setHeightCM($pDouble0)
    {
        $this->m_Comment->setHeightCM($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsComment.setHeightInch(double)]

      @param pDouble0  double
     */
    function setHeightInch($pDouble0)
    {
        $this->m_Comment->setHeightInch($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsComment.setHtmlNote(String)]

      @param oString0  String
     */
    function setHtmlNote($oString0)
    {
        $this->m_Comment->setHtmlNote($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsComment.setNote(String)]

      @param oString0  String
     */
    function setNote($oString0)
    {
        $this->m_Comment->setNote($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsComment.setTextHorizontalAlignment(int)]

      @param pInt0  int
     */
    function setTextHorizontalAlignment($pInt0)
    {
        $this->m_Comment->setTextHorizontalAlignment($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsComment.setTextOrientationType(int)]

      @param pInt0  int
     */
    function setTextOrientationType($pInt0)
    {
        $this->m_Comment->setTextOrientationType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsComment.setTextVerticalAlignment(int)]

      @param pInt0  int
     */
    function setTextVerticalAlignment($pInt0)
    {
        $this->m_Comment->setTextVerticalAlignment($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsComment.setVisible(boolean)]

      @param pBoolean0  boolean
     */
    function setVisible($pBoolean0)
    {
        $this->m_Comment->setVisible($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsComment.setWidthCM(double)]

      @param pDouble0  double
     */
    function setWidthCM($pDouble0)
    {
        $this->m_Comment->setWidthCM($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsComment.setWidthInch(double)]

      @param pDouble0  double
     */
    function setWidthInch($pDouble0)
    {
        $this->m_Comment->setWidthInch($pDouble0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsCommentCollection]
  
 */
class CommentCollection extends CollectionBase
{
    public $m_CommentCollection;
    
    function __construct($commentCollection)
    {
    	$this->m_CommentCollection = $commentCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsCommentCollection.add(String)]

      @param oString0  String
      @return int
     */
    function add($oString0)
    {
        return $this->m_CommentCollection->add($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCommentCollection.add(int, int)]

      @param pInt0  int
      @param pInt1  int
      @return int
     */
    function addII($pInt0, $pInt1)
    {
        return $this->m_CommentCollection->add($pInt0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCommentCollection.clear()]

     */
    function clear()
    {
        $this->m_CommentCollection->clear();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCommentCollection.get(String)]

      @param oString0  String
      @return com.aspose.cells.Comment
     */
    function get($oString0)
    {
        return ClassFactory::_t2($this->m_CommentCollection->get($oString0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCommentCollection.get(int)]

      @param pInt0  int
      @return com.aspose.cells.Comment
     */
    function getI($pInt0)
    {
        return ClassFactory::_t2($this->m_CommentCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCommentCollection.get(int, int)]

      @param pInt0  int
      @param pInt1  int
      @return com.aspose.cells.Comment
     */
    function getII($pInt0, $pInt1)
    {
        return ClassFactory::_t2($this->m_CommentCollection->get($pInt0, $pInt1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCommentCollection.removeAt(String)]

      @param oString0  String
     */
    function removeAt($oString0)
    {
        $this->m_CommentCollection->removeAt($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCommentCollection.removeAt(int, int)]

      @param pInt0  int
      @param pInt1  int
     */
    function removeAtII($pInt0, $pInt1)
    {
        $this->m_CommentCollection->removeAt($pInt0, $pInt1);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsCommentShape]
  
 */
class CommentShape extends Shape
{
    public $m_CommentShape;
    
    function __construct($commentShape)
    {
    	$this->m_CommentShape = $commentShape;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsCommentShape.getComment()]

      @return com.aspose.cells.Comment
     */
    function getComment()
    {
        return ClassFactory::_t2($this->m_CommentShape->getComment());
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsConditionalFormattingCollection]
  
 */
class ConditionalFormattingCollection extends CollectionBase
{
    public $m_ConditionalFormattingCollection;
    
    function __construct($conditionalFormattingCollection)
    {
    	$this->m_ConditionalFormattingCollection = $conditionalFormattingCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsConditionalFormattingCollection.add()]

      @return int
     */
    function add()
    {
        return $this->m_ConditionalFormattingCollection->add();
    }

    /*
      Wrapper for java version method [com.aspose.cellsConditionalFormattingCollection.copy(ConditionalFormattingCollection)]

      @param oConditionalFormattingCollection0  com.aspose.cells.ConditionalFormattingCollection
     */
    function copy($oConditionalFormattingCollection0)
    {
        $this->m_ConditionalFormattingCollection->copy(ClassFactory::_t1($oConditionalFormattingCollection0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsConditionalFormattingCollection.get(int)]

      @param pInt0  int
      @return corresponding java type is {java.lang.Object}
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_ConditionalFormattingCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsConditionalFormattingCollection.removeArea(int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
     */
    function removeArea($pInt0, $pInt1, $pInt2, $pInt3)
    {
        $this->m_ConditionalFormattingCollection->removeArea($pInt0, $pInt1, $pInt2, $pInt3);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsConditionalFormattingValue]
  
 */
class ConditionalFormattingValue
{
    public $m_ConditionalFormattingValue;
    
    function __construct($conditionalFormattingValue)
    {
    	$this->m_ConditionalFormattingValue = $conditionalFormattingValue;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsConditionalFormattingValue.getType()]

      @return int
     */
    function getType()
    {
        return $this->m_ConditionalFormattingValue->getType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsConditionalFormattingValue.getValue()]

      @return corresponding java type is {java.lang.Object}
     */
    function getValue()
    {
        return ClassFactory::_t2($this->m_ConditionalFormattingValue->getValue());
    }

    /*
      Wrapper for java version method [com.aspose.cellsConditionalFormattingValue.isGTE()]

      @return boolean
     */
    function isGTE()
    {
        return $this->m_ConditionalFormattingValue->isGTE();
    }

    /*
      Wrapper for java version method [com.aspose.cellsConditionalFormattingValue.setGTE(boolean)]

      @param pBoolean0  boolean
     */
    function setGTE($pBoolean0)
    {
        $this->m_ConditionalFormattingValue->setGTE($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsConditionalFormattingValue.setType(int)]

      @param pInt0  int
     */
    function setType($pInt0)
    {
        $this->m_ConditionalFormattingValue->setType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsConditionalFormattingValue.setValue(Object)]

      @param oObject0  corresponding java type is {java.lang.Object}
     */
    function setValue($oObject0)
    {
        $this->m_ConditionalFormattingValue->setValue(ClassFactory::_t1($oObject0));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsConditionalFormattingValueCollection]
  
 */
class ConditionalFormattingValueCollection extends CollectionBase
{
    public $m_ConditionalFormattingValueCollection;
    
    function __construct($conditionalFormattingValueCollection)
    {
    	$this->m_ConditionalFormattingValueCollection = $conditionalFormattingValueCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsConditionalFormattingValueCollection.add(int, String)]

      @param pInt0  int
      @param oString1  String
      @return int
     */
    function add($pInt0, $oString1)
    {
        return $this->m_ConditionalFormattingValueCollection->add($pInt0, $oString1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsConditionalFormattingValueCollection.get(int)]

      @param pInt0  int
      @return com.aspose.cells.ConditionalFormattingValue
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_ConditionalFormattingValueCollection->get($pInt0));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsConsolidationFunction]
  
 */
class ConsolidationFunction
{
    public $m_ConsolidationFunction;
    
    function __construct($consolidationFunction)
    {
    	$this->m_ConsolidationFunction = $consolidationFunction;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsContentDisposition]
  
 */
class ContentDisposition
{
    public $m_ContentDisposition;
    
    function __construct($contentDisposition)
    {
    	$this->m_ContentDisposition = $contentDisposition;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsCountryCode]
  
 */
class CountryCode
{
    public $m_CountryCode;
    
    function __construct($countryCode)
    {
    	$this->m_CountryCode = $countryCode;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsCrossType]
  
 */
class CrossType
{
    public $m_CrossType;
    
    function __construct($crossType)
    {
    	$this->m_CrossType = $crossType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsCustomDocumentPropertyCollection]
  
 */
class CustomDocumentPropertyCollection extends DocumentPropertyCollection
{
    public $m_CustomDocumentPropertyCollection;
    
    function __construct($customDocumentPropertyCollection)
    {
    	$this->m_CustomDocumentPropertyCollection = $customDocumentPropertyCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsCustomDocumentPropertyCollection.add(String, DateTime)]

      @param oString0  String
      @param oDateTime1  com.aspose.cells.DateTime
      @return com.aspose.cells.DocumentProperty
     */
    function add($oString0, $oDateTime1)
    {
        return ClassFactory::_t2($this->m_CustomDocumentPropertyCollection->add($oString0, ClassFactory::_t1($oDateTime1)));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCustomDocumentPropertyCollection.add(String, String)]

      @param oString0  String
      @param oString1  String
      @return com.aspose.cells.DocumentProperty
     */
    function addSS($oString0, $oString1)
    {
        return ClassFactory::_t2($this->m_CustomDocumentPropertyCollection->add($oString0, $oString1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCustomDocumentPropertyCollection.add(String, boolean)]

      @param oString0  String
      @param pBoolean1  boolean
      @return com.aspose.cells.DocumentProperty
     */
    function addSB($oString0, $pBoolean1)
    {
        return ClassFactory::_t2($this->m_CustomDocumentPropertyCollection->add($oString0, $pBoolean1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCustomDocumentPropertyCollection.add(String, double)]

      @param oString0  String
      @param pDouble1  double
      @return com.aspose.cells.DocumentProperty
     */
    function addSD($oString0, $pDouble1)
    {
        return ClassFactory::_t2($this->m_CustomDocumentPropertyCollection->add($oString0, $pDouble1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCustomDocumentPropertyCollection.add(String, int)]

      @param oString0  String
      @param pInt1  int
      @return com.aspose.cells.DocumentProperty
     */
    function addSI($oString0, $pInt1)
    {
        return ClassFactory::_t2($this->m_CustomDocumentPropertyCollection->add($oString0, $pInt1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCustomDocumentPropertyCollection.addLinkToContent(String, String)]

      @param oString0  String
      @param oString1  String
      @return com.aspose.cells.DocumentProperty
     */
    function addLinkToContent($oString0, $oString1)
    {
        return ClassFactory::_t2($this->m_CustomDocumentPropertyCollection->addLinkToContent($oString0, $oString1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCustomDocumentPropertyCollection.updateLinkedPropertyValue()]

     */
    function updateLinkedPropertyValue()
    {
        $this->m_CustomDocumentPropertyCollection->updateLinkedPropertyValue();
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsCustomFilter]
  
 */
class CustomFilter
{
    public $m_CustomFilter;
    
    function __construct($customFilter)
    {
    	$this->m_CustomFilter = $customFilter;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsCustomFilter.getCriteria()]

      @return corresponding java type is {java.lang.Object}
     */
    function getCriteria()
    {
        return ClassFactory::_t2($this->m_CustomFilter->getCriteria());
    }

    /*
      Wrapper for java version method [com.aspose.cellsCustomFilter.getFilterOperatorType()]

      @return int
     */
    function getFilterOperatorType()
    {
        return $this->m_CustomFilter->getFilterOperatorType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCustomFilter.setCriteria(Object)]

      @param oObject0  corresponding java type is {java.lang.Object}
     */
    function setCriteria($oObject0)
    {
        $this->m_CustomFilter->setCriteria(ClassFactory::_t1($oObject0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCustomFilter.setFilterOperatorType(int)]

      @param pInt0  int
     */
    function setFilterOperatorType($pInt0)
    {
        $this->m_CustomFilter->setFilterOperatorType($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsCustomFilterCollection]
  
 */
class CustomFilterCollection extends CollectionBase
{
    public $m_CustomFilterCollection;
    
    function __construct($customFilterCollection)
    {
    	$this->m_CustomFilterCollection = $customFilterCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsCustomFilterCollection.get(int)]

      @param pInt0  int
      @return corresponding java type is {java.lang.Object}
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_CustomFilterCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCustomFilterCollection.getAnd()]

      @return boolean
     */
    function getAnd()
    {
        return $this->m_CustomFilterCollection->getAnd();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCustomFilterCollection.setAnd(boolean)]

      @param pBoolean0  boolean
     */
    function setAnd($pBoolean0)
    {
        $this->m_CustomFilterCollection->setAnd($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsCustomProperty]
  
 */
class CustomProperty
{
    public $m_CustomProperty;
    
    function __construct($customProperty)
    {
    	$this->m_CustomProperty = $customProperty;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsCustomProperty.getName()]

      @return String
     */
    function getName()
    {
        return $this->m_CustomProperty->getName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCustomProperty.getStringValue()]

      @return String
     */
    function getStringValue()
    {
        return $this->m_CustomProperty->getStringValue();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCustomProperty.getValue()]

      @return String
     */
    function getValue()
    {
        return $this->m_CustomProperty->getValue();
    }

    /*
      Wrapper for java version method [com.aspose.cellsCustomProperty.setName(String)]

      @param oString0  String
     */
    function setName($oString0)
    {
        $this->m_CustomProperty->setName($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCustomProperty.setStringValue(String)]

      @param oString0  String
     */
    function setStringValue($oString0)
    {
        $this->m_CustomProperty->setStringValue($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCustomProperty.setValue(String)]

      @param oString0  String
     */
    function setValue($oString0)
    {
        $this->m_CustomProperty->setValue($oString0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsCustomPropertyCollection]
  
 */
class CustomPropertyCollection extends CollectionBase
{
    public $m_CustomPropertyCollection;
    
    function __construct($customPropertyCollection)
    {
    	$this->m_CustomPropertyCollection = $customPropertyCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsCustomPropertyCollection.add(String, String)]

      @param oString0  String
      @param oString1  String
      @return int
     */
    function add($oString0, $oString1)
    {
        return $this->m_CustomPropertyCollection->add($oString0, $oString1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsCustomPropertyCollection.get(String)]

      @param oString0  String
      @return com.aspose.cells.CustomProperty
     */
    function get($oString0)
    {
        return ClassFactory::_t2($this->m_CustomPropertyCollection->get($oString0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsCustomPropertyCollection.get(int)]

      @param pInt0  int
      @return com.aspose.cells.CustomProperty
     */
    function getI($pInt0)
    {
        return ClassFactory::_t2($this->m_CustomPropertyCollection->get($pInt0));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsDataBar]
  
 */
class DataBar
{
    public $m_DataBar;
    
    function __construct($dataBar)
    {
    	$this->m_DataBar = $dataBar;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsDataBar.getColor()]

      @return com.aspose.cells.Color
     */
    function getColor()
    {
        return ClassFactory::_t2($this->m_DataBar->getColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataBar.getMaxCfvo()]

      @return com.aspose.cells.ConditionalFormattingValue
     */
    function getMaxCfvo()
    {
        return ClassFactory::_t2($this->m_DataBar->getMaxCfvo());
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataBar.getMinCfvo()]

      @return com.aspose.cells.ConditionalFormattingValue
     */
    function getMinCfvo()
    {
        return ClassFactory::_t2($this->m_DataBar->getMinCfvo());
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataBar.getShowValue()]

      @return boolean
     */
    function getShowValue()
    {
        return $this->m_DataBar->getShowValue();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataBar.setColor(Color)]

      @param oColor0  com.aspose.cells.Color
     */
    function setColor($oColor0)
    {
        $this->m_DataBar->setColor(ClassFactory::_t1($oColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataBar.setShowValue(boolean)]

      @param pBoolean0  boolean
     */
    function setShowValue($pBoolean0)
    {
        $this->m_DataBar->setShowValue($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsDataLabels]
  
 */
class DataLabels extends ChartFrame
{
    public $m_DataLabels;
    
    function __construct($dataLabels)
    {
    	$this->m_DataLabels = $dataLabels;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.getBackground()]

      @return int
     */
    function getBackground()
    {
        return $this->m_DataLabels->getBackground();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.getBackgroundMode()]

      @return int
     */
    function getBackgroundMode()
    {
        return $this->m_DataLabels->getBackgroundMode();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.getLinkedSource()]

      @return String
     */
    function getLinkedSource()
    {
        return $this->m_DataLabels->getLinkedSource();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.getNumber()]

      @return int
     */
    function getNumber()
    {
        return $this->m_DataLabels->getNumber();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.getNumberFormat()]

      @return String
     */
    function getNumberFormat()
    {
        return $this->m_DataLabels->getNumberFormat();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.getNumberFormatLinked()]

      @return boolean
     */
    function getNumberFormatLinked()
    {
        return $this->m_DataLabels->getNumberFormatLinked();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.getPosition()]

      @return int
     */
    function getPosition()
    {
        return $this->m_DataLabels->getPosition();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.getPostion()]

      @return int
     */
    function getPostion()
    {
        return $this->m_DataLabels->getPostion();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.getRotation()]

      @return int
     */
    function getRotation()
    {
        return $this->m_DataLabels->getRotation();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.getRotationAngle()]

      @return int
     */
    function getRotationAngle()
    {
        return $this->m_DataLabels->getRotationAngle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.getSeparator()]

      @return int
     */
    function getSeparator()
    {
        return $this->m_DataLabels->getSeparator();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.getShowBubbleSize()]

      @return boolean
     */
    function getShowBubbleSize()
    {
        return $this->m_DataLabels->getShowBubbleSize();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.getShowCategoryName()]

      @return boolean
     */
    function getShowCategoryName()
    {
        return $this->m_DataLabels->getShowCategoryName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.getShowLegendKey()]

      @return boolean
     */
    function getShowLegendKey()
    {
        return $this->m_DataLabels->getShowLegendKey();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.getShowPercentage()]

      @return boolean
     */
    function getShowPercentage()
    {
        return $this->m_DataLabels->getShowPercentage();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.getShowSeriesName()]

      @return boolean
     */
    function getShowSeriesName()
    {
        return $this->m_DataLabels->getShowSeriesName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.getShowValue()]

      @return boolean
     */
    function getShowValue()
    {
        return $this->m_DataLabels->getShowValue();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.getText()]

      @return String
     */
    function getText()
    {
        return $this->m_DataLabels->getText();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.getTextDirection()]

      @return int
     */
    function getTextDirection()
    {
        return $this->m_DataLabels->getTextDirection();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.getTextFont()]

      @return com.aspose.cells.Font
     */
    function getTextFont()
    {
        return ClassFactory::_t2($this->m_DataLabels->getTextFont());
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.getTextHorizontalAlignment()]

      @return int
     */
    function getTextHorizontalAlignment()
    {
        return $this->m_DataLabels->getTextHorizontalAlignment();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.getTextVerticalAlignment()]

      @return int
     */
    function getTextVerticalAlignment()
    {
        return $this->m_DataLabels->getTextVerticalAlignment();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.isAutoText()]

      @return boolean
     */
    function isAutoText()
    {
        return $this->m_DataLabels->isAutoText();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.isBubbleSizeShown()]

      @return boolean
     */
    function isBubbleSizeShown()
    {
        return $this->m_DataLabels->isBubbleSizeShown();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.isCategoryNameShown()]

      @return boolean
     */
    function isCategoryNameShown()
    {
        return $this->m_DataLabels->isCategoryNameShown();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.isDeleted()]

      @return boolean
     */
    function isDeleted()
    {
        return $this->m_DataLabels->isDeleted();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.isLegendKeyShown()]

      @return boolean
     */
    function isLegendKeyShown()
    {
        return $this->m_DataLabels->isLegendKeyShown();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.isPercentageShown()]

      @return boolean
     */
    function isPercentageShown()
    {
        return $this->m_DataLabels->isPercentageShown();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.isSeriesNameShown()]

      @return boolean
     */
    function isSeriesNameShown()
    {
        return $this->m_DataLabels->isSeriesNameShown();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.isValueShown()]

      @return boolean
     */
    function isValueShown()
    {
        return $this->m_DataLabels->isValueShown();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.setAutoText(boolean)]

      @param pBoolean0  boolean
     */
    function setAutoText($pBoolean0)
    {
        $this->m_DataLabels->setAutoText($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.setBackground(int)]

      @param pInt0  int
     */
    function setBackground($pInt0)
    {
        $this->m_DataLabels->setBackground($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.setBackgroundMode(int)]

      @param pInt0  int
     */
    function setBackgroundMode($pInt0)
    {
        $this->m_DataLabels->setBackgroundMode($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.setBubbleSizeShown(boolean)]

      @param pBoolean0  boolean
     */
    function setBubbleSizeShown($pBoolean0)
    {
        $this->m_DataLabels->setBubbleSizeShown($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.setCategoryNameShown(boolean)]

      @param pBoolean0  boolean
     */
    function setCategoryNameShown($pBoolean0)
    {
        $this->m_DataLabels->setCategoryNameShown($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.setDeleted(boolean)]

      @param pBoolean0  boolean
     */
    function setDeleted($pBoolean0)
    {
        $this->m_DataLabels->setDeleted($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.setLegendKeyShown(boolean)]

      @param pBoolean0  boolean
     */
    function setLegendKeyShown($pBoolean0)
    {
        $this->m_DataLabels->setLegendKeyShown($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.setLinkedSource(String)]

      @param oString0  String
     */
    function setLinkedSource($oString0)
    {
        $this->m_DataLabels->setLinkedSource($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.setNumber(int)]

      @param pInt0  int
     */
    function setNumber($pInt0)
    {
        $this->m_DataLabels->setNumber($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.setNumberFormat(String)]

      @param oString0  String
     */
    function setNumberFormat($oString0)
    {
        $this->m_DataLabels->setNumberFormat($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.setNumberFormatLinked(boolean)]

      @param pBoolean0  boolean
     */
    function setNumberFormatLinked($pBoolean0)
    {
        $this->m_DataLabels->setNumberFormatLinked($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.setPercentageShown(boolean)]

      @param pBoolean0  boolean
     */
    function setPercentageShown($pBoolean0)
    {
        $this->m_DataLabels->setPercentageShown($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.setPosition(int)]

      @param pInt0  int
     */
    function setPosition($pInt0)
    {
        $this->m_DataLabels->setPosition($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.setPostion(int)]

      @param pInt0  int
     */
    function setPostion($pInt0)
    {
        $this->m_DataLabels->setPostion($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.setRotation(int)]

      @param pInt0  int
     */
    function setRotation($pInt0)
    {
        $this->m_DataLabels->setRotation($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.setRotationAngle(int)]

      @param pInt0  int
     */
    function setRotationAngle($pInt0)
    {
        $this->m_DataLabels->setRotationAngle($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.setSeparator(int)]

      @param pInt0  int
     */
    function setSeparator($pInt0)
    {
        $this->m_DataLabels->setSeparator($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.setSeriesNameShown(boolean)]

      @param pBoolean0  boolean
     */
    function setSeriesNameShown($pBoolean0)
    {
        $this->m_DataLabels->setSeriesNameShown($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.setShowBubbleSize(boolean)]

      @param pBoolean0  boolean
     */
    function setShowBubbleSize($pBoolean0)
    {
        $this->m_DataLabels->setShowBubbleSize($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.setShowCategoryName(boolean)]

      @param pBoolean0  boolean
     */
    function setShowCategoryName($pBoolean0)
    {
        $this->m_DataLabels->setShowCategoryName($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.setShowLegendKey(boolean)]

      @param pBoolean0  boolean
     */
    function setShowLegendKey($pBoolean0)
    {
        $this->m_DataLabels->setShowLegendKey($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.setShowPercentage(boolean)]

      @param pBoolean0  boolean
     */
    function setShowPercentage($pBoolean0)
    {
        $this->m_DataLabels->setShowPercentage($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.setShowSeriesName(boolean)]

      @param pBoolean0  boolean
     */
    function setShowSeriesName($pBoolean0)
    {
        $this->m_DataLabels->setShowSeriesName($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.setShowValue(boolean)]

      @param pBoolean0  boolean
     */
    function setShowValue($pBoolean0)
    {
        $this->m_DataLabels->setShowValue($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.setText(String)]

      @param oString0  String
     */
    function setText($oString0)
    {
        $this->m_DataLabels->setText($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.setTextDirection(int)]

      @param pInt0  int
     */
    function setTextDirection($pInt0)
    {
        $this->m_DataLabels->setTextDirection($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.setTextHorizontalAlignment(int)]

      @param pInt0  int
     */
    function setTextHorizontalAlignment($pInt0)
    {
        $this->m_DataLabels->setTextHorizontalAlignment($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.setTextVerticalAlignment(int)]

      @param pInt0  int
     */
    function setTextVerticalAlignment($pInt0)
    {
        $this->m_DataLabels->setTextVerticalAlignment($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataLabels.setValueShown(boolean)]

      @param pBoolean0  boolean
     */
    function setValueShown($pBoolean0)
    {
        $this->m_DataLabels->setValueShown($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsDataLablesSeparatorType]
  
 */
class DataLablesSeparatorType
{
    public $m_DataLablesSeparatorType;
    
    function __construct($dataLablesSeparatorType)
    {
    	$this->m_DataLablesSeparatorType = $dataLablesSeparatorType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsDataSorter]
  
 */
class DataSorter
{
    public $m_DataSorter;
    
    function __construct($dataSorter)
    {
    	$this->m_DataSorter = $dataSorter;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsDataSorter.addKey(int, int)]

      @param pInt0  int
      @param pInt1  int
     */
    function addKey($pInt0, $pInt1)
    {
        $this->m_DataSorter->addKey($pInt0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataSorter.clear()]

     */
    function clear()
    {
        $this->m_DataSorter->clear();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataSorter.getCaseSensitive()]

      @return boolean
     */
    function getCaseSensitive()
    {
        return $this->m_DataSorter->getCaseSensitive();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataSorter.getKey1()]

      @return int
     */
    function getKey1()
    {
        return $this->m_DataSorter->getKey1();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataSorter.getKey2()]

      @return int
     */
    function getKey2()
    {
        return $this->m_DataSorter->getKey2();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataSorter.getKey3()]

      @return int
     */
    function getKey3()
    {
        return $this->m_DataSorter->getKey3();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataSorter.getOrder1()]

      @return int
     */
    function getOrder1()
    {
        return $this->m_DataSorter->getOrder1();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataSorter.getOrder2()]

      @return int
     */
    function getOrder2()
    {
        return $this->m_DataSorter->getOrder2();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataSorter.getOrder3()]

      @return int
     */
    function getOrder3()
    {
        return $this->m_DataSorter->getOrder3();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataSorter.getSortLeftToRight()]

      @return boolean
     */
    function getSortLeftToRight()
    {
        return $this->m_DataSorter->getSortLeftToRight();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataSorter.hasHeaders()]

      @return boolean
     */
    function hasHeaders()
    {
        return $this->m_DataSorter->hasHeaders();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataSorter.setCaseSensitive(boolean)]

      @param pBoolean0  boolean
     */
    function setCaseSensitive($pBoolean0)
    {
        $this->m_DataSorter->setCaseSensitive($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataSorter.setHasHeaders(boolean)]

      @param pBoolean0  boolean
     */
    function setHasHeaders($pBoolean0)
    {
        $this->m_DataSorter->setHasHeaders($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataSorter.setKey1(int)]

      @param pInt0  int
     */
    function setKey1($pInt0)
    {
        $this->m_DataSorter->setKey1($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataSorter.setKey2(int)]

      @param pInt0  int
     */
    function setKey2($pInt0)
    {
        $this->m_DataSorter->setKey2($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataSorter.setKey3(int)]

      @param pInt0  int
     */
    function setKey3($pInt0)
    {
        $this->m_DataSorter->setKey3($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataSorter.setOrder1(int)]

      @param pInt0  int
     */
    function setOrder1($pInt0)
    {
        $this->m_DataSorter->setOrder1($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataSorter.setOrder2(int)]

      @param pInt0  int
     */
    function setOrder2($pInt0)
    {
        $this->m_DataSorter->setOrder2($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataSorter.setOrder3(int)]

      @param pInt0  int
     */
    function setOrder3($pInt0)
    {
        $this->m_DataSorter->setOrder3($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataSorter.setSortLeftToRight(boolean)]

      @param pBoolean0  boolean
     */
    function setSortLeftToRight($pBoolean0)
    {
        $this->m_DataSorter->setSortLeftToRight($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataSorter.sort()]

     */
    function sort()
    {
        $this->m_DataSorter->sort();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataSorter.sort(Cells, CellArea)]

      @param oCells0  com.aspose.cells.Cells
      @param oCellArea1  com.aspose.cells.CellArea
     */
    function sortCC($oCells0, $oCellArea1)
    {
        $this->m_DataSorter->sort(ClassFactory::_t1($oCells0), ClassFactory::_t1($oCellArea1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsDataSorter.sort(Cells, int, int, int, int)]

      @param oCells0  com.aspose.cells.Cells
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @param pInt4  int
     */
    function sortCIIII($oCells0, $pInt1, $pInt2, $pInt3, $pInt4)
    {
        $this->m_DataSorter->sort(ClassFactory::_t1($oCells0), $pInt1, $pInt2, $pInt3, $pInt4);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsDateTime]
  
 */
class DateTime
{
    public $m_DateTime;
    
    function __construct($dateTime)
    {
    	$this->m_DateTime = $dateTime;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsDateTime.addDays(double)]

      @param pDouble0  double
      @return com.aspose.cells.DateTime
     */
    function addDays($pDouble0)
    {
        return ClassFactory::_t2($this->m_DateTime->addDays($pDouble0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTime.addHours(double)]

      @param pDouble0  double
      @return com.aspose.cells.DateTime
     */
    function addHours($pDouble0)
    {
        return ClassFactory::_t2($this->m_DateTime->addHours($pDouble0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTime.addMilliseconds(double)]

      @param pDouble0  double
      @return com.aspose.cells.DateTime
     */
    function addMilliseconds($pDouble0)
    {
        return ClassFactory::_t2($this->m_DateTime->addMilliseconds($pDouble0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTime.addMinutes(double)]

      @param pDouble0  double
      @return com.aspose.cells.DateTime
     */
    function addMinutes($pDouble0)
    {
        return ClassFactory::_t2($this->m_DateTime->addMinutes($pDouble0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTime.addMonths(int)]

      @param pInt0  int
      @return com.aspose.cells.DateTime
     */
    function addMonths($pInt0)
    {
        return ClassFactory::_t2($this->m_DateTime->addMonths($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTime.addSeconds(double)]

      @param pDouble0  double
      @return com.aspose.cells.DateTime
     */
    function addSeconds($pDouble0)
    {
        return ClassFactory::_t2($this->m_DateTime->addSeconds($pDouble0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTime.addYears(int)]

      @param pInt0  int
      @return com.aspose.cells.DateTime
     */
    function addYears($pInt0)
    {
        return ClassFactory::_t2($this->m_DateTime->addYears($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTime.compareTo(DateTime)]

      @param oDateTime0  com.aspose.cells.DateTime
      @return int
     */
    function compareTo($oDateTime0)
    {
        return $this->m_DateTime->compareTo(ClassFactory::_t1($oDateTime0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTime.compareTo(Object)]

      @param oObject0  corresponding java type is {java.lang.Object}
      @return int
     */
    function compareToO($oObject0)
    {
        return $this->m_DateTime->compareTo(ClassFactory::_t1($oObject0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTime.equals(Object)]

      @param oObject0  corresponding java type is {java.lang.Object}
      @return boolean
     */
    function equals($oObject0)
    {
        return $this->m_DateTime->equals(ClassFactory::_t1($oObject0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTime.getDay()]

      @return int
     */
    function getDay()
    {
        return $this->m_DateTime->getDay();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTime.getDayOfWeek()]

      @return int
     */
    function getDayOfWeek()
    {
        return $this->m_DateTime->getDayOfWeek();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTime.getDayOfYear()]

      @return int
     */
    function getDayOfYear()
    {
        return $this->m_DateTime->getDayOfYear();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTime.getHour()]

      @return int
     */
    function getHour()
    {
        return $this->m_DateTime->getHour();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTime.getMillisecond()]

      @return int
     */
    function getMillisecond()
    {
        return $this->m_DateTime->getMillisecond();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTime.getMinute()]

      @return int
     */
    function getMinute()
    {
        return $this->m_DateTime->getMinute();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTime.getMonth()]

      @return int
     */
    function getMonth()
    {
        return $this->m_DateTime->getMonth();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTime.getNow()]

      @return com.aspose.cells.DateTime
     */
    function getNow()
    {
        return ClassFactory::_t2($this->m_DateTime->getNow());
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTime.getSecond()]

      @return int
     */
    function getSecond()
    {
        return $this->m_DateTime->getSecond();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTime.getYear()]

      @return int
     */
    function getYear()
    {
        return $this->m_DateTime->getYear();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTime.hashCode()]

      @return int
     */
    function hashCode()
    {
        return $this->m_DateTime->hashCode();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTime.toCalendar()]

      @return corresponding java type is {java.util.Calendar}
     */
    function toCalendar()
    {
        return ClassFactory::_t2($this->m_DateTime->toCalendar());
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTime.toDate()]

      @return corresponding java type is {java.util.Date}
     */
    function toDate()
    {
        return ClassFactory::_t2($this->m_DateTime->toDate());
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTime.toString()]

      @return String
     */
    function toString()
    {
        return $this->m_DateTime->toString();
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsDateTimeGroupingType]
  
 */
class DateTimeGroupingType
{
    public $m_DateTimeGroupingType;
    
    function __construct($dateTimeGroupingType)
    {
    	$this->m_DateTimeGroupingType = $dateTimeGroupingType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsDateTimeGroupItem]
  
 */
class DateTimeGroupItem
{
    public $m_DateTimeGroupItem;
    
    function __construct($dateTimeGroupItem)
    {
    	$this->m_DateTimeGroupItem = $dateTimeGroupItem;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsDateTimeGroupItem.getDateTimeGroupingType()]

      @return int
     */
    function getDateTimeGroupingType()
    {
        return $this->m_DateTimeGroupItem->getDateTimeGroupingType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTimeGroupItem.getDay()]

      @return int
     */
    function getDay()
    {
        return $this->m_DateTimeGroupItem->getDay();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTimeGroupItem.getHour()]

      @return int
     */
    function getHour()
    {
        return $this->m_DateTimeGroupItem->getHour();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTimeGroupItem.getMinValue()]

      @return com.aspose.cells.DateTime
     */
    function getMinValue()
    {
        return ClassFactory::_t2($this->m_DateTimeGroupItem->getMinValue());
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTimeGroupItem.getMinute()]

      @return int
     */
    function getMinute()
    {
        return $this->m_DateTimeGroupItem->getMinute();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTimeGroupItem.getMonth()]

      @return int
     */
    function getMonth()
    {
        return $this->m_DateTimeGroupItem->getMonth();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTimeGroupItem.getSecond()]

      @return int
     */
    function getSecond()
    {
        return $this->m_DateTimeGroupItem->getSecond();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTimeGroupItem.getYear()]

      @return int
     */
    function getYear()
    {
        return $this->m_DateTimeGroupItem->getYear();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTimeGroupItem.setDateTimeGroupingType(int)]

      @param pInt0  int
     */
    function setDateTimeGroupingType($pInt0)
    {
        $this->m_DateTimeGroupItem->setDateTimeGroupingType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTimeGroupItem.setDay(int)]

      @param pInt0  int
     */
    function setDay($pInt0)
    {
        $this->m_DateTimeGroupItem->setDay($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTimeGroupItem.setHour(int)]

      @param pInt0  int
     */
    function setHour($pInt0)
    {
        $this->m_DateTimeGroupItem->setHour($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTimeGroupItem.setMinute(int)]

      @param pInt0  int
     */
    function setMinute($pInt0)
    {
        $this->m_DateTimeGroupItem->setMinute($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTimeGroupItem.setMonth(int)]

      @param pInt0  int
     */
    function setMonth($pInt0)
    {
        $this->m_DateTimeGroupItem->setMonth($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTimeGroupItem.setSecond(int)]

      @param pInt0  int
     */
    function setSecond($pInt0)
    {
        $this->m_DateTimeGroupItem->setSecond($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDateTimeGroupItem.setYear(int)]

      @param pInt0  int
     */
    function setYear($pInt0)
    {
        $this->m_DateTimeGroupItem->setYear($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsDirectoryType]
  
 */
class DirectoryType
{
    public $m_DirectoryType;
    
    function __construct($directoryType)
    {
    	$this->m_DirectoryType = $directoryType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsDisplayDrawingObjects]
  
 */
class DisplayDrawingObjects
{
    public $m_DisplayDrawingObjects;
    
    function __construct($displayDrawingObjects)
    {
    	$this->m_DisplayDrawingObjects = $displayDrawingObjects;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsDisplayUnitLabel]
  
 */
class DisplayUnitLabel extends ChartFrame
{
    public $m_DisplayUnitLabel;
    
    function __construct($displayUnitLabel)
    {
    	$this->m_DisplayUnitLabel = $displayUnitLabel;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsDisplayUnitLabel.getAutoScaleFont()]

      @return boolean
     */
    function getAutoScaleFont()
    {
        return $this->m_DisplayUnitLabel->getAutoScaleFont();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDisplayUnitLabel.getLinkedSource()]

      @return String
     */
    function getLinkedSource()
    {
        return $this->m_DisplayUnitLabel->getLinkedSource();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDisplayUnitLabel.getRotation()]

      @return int
     */
    function getRotation()
    {
        return $this->m_DisplayUnitLabel->getRotation();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDisplayUnitLabel.getRotationAngle()]

      @return int
     */
    function getRotationAngle()
    {
        return $this->m_DisplayUnitLabel->getRotationAngle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDisplayUnitLabel.getText()]

      @return String
     */
    function getText()
    {
        return $this->m_DisplayUnitLabel->getText();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDisplayUnitLabel.getTextDirection()]

      @return int
     */
    function getTextDirection()
    {
        return $this->m_DisplayUnitLabel->getTextDirection();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDisplayUnitLabel.getTextFont()]

      @return com.aspose.cells.Font
     */
    function getTextFont()
    {
        return ClassFactory::_t2($this->m_DisplayUnitLabel->getTextFont());
    }

    /*
      Wrapper for java version method [com.aspose.cellsDisplayUnitLabel.getTextHorizontalAlignment()]

      @return int
     */
    function getTextHorizontalAlignment()
    {
        return $this->m_DisplayUnitLabel->getTextHorizontalAlignment();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDisplayUnitLabel.getTextVerticalAlignment()]

      @return int
     */
    function getTextVerticalAlignment()
    {
        return $this->m_DisplayUnitLabel->getTextVerticalAlignment();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDisplayUnitLabel.setAutoScaleFont(boolean)]

      @param pBoolean0  boolean
     */
    function setAutoScaleFont($pBoolean0)
    {
        $this->m_DisplayUnitLabel->setAutoScaleFont($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDisplayUnitLabel.setLinkedSource(String)]

      @param oString0  String
     */
    function setLinkedSource($oString0)
    {
        $this->m_DisplayUnitLabel->setLinkedSource($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDisplayUnitLabel.setRotation(int)]

      @param pInt0  int
     */
    function setRotation($pInt0)
    {
        $this->m_DisplayUnitLabel->setRotation($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDisplayUnitLabel.setRotationAngle(int)]

      @param pInt0  int
     */
    function setRotationAngle($pInt0)
    {
        $this->m_DisplayUnitLabel->setRotationAngle($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDisplayUnitLabel.setText(String)]

      @param oString0  String
     */
    function setText($oString0)
    {
        $this->m_DisplayUnitLabel->setText($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDisplayUnitLabel.setTextDirection(int)]

      @param pInt0  int
     */
    function setTextDirection($pInt0)
    {
        $this->m_DisplayUnitLabel->setTextDirection($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDisplayUnitLabel.setTextHorizontalAlignment(int)]

      @param pInt0  int
     */
    function setTextHorizontalAlignment($pInt0)
    {
        $this->m_DisplayUnitLabel->setTextHorizontalAlignment($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDisplayUnitLabel.setTextVerticalAlignment(int)]

      @param pInt0  int
     */
    function setTextVerticalAlignment($pInt0)
    {
        $this->m_DisplayUnitLabel->setTextVerticalAlignment($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsDisplayUnitType]
  
 */
class DisplayUnitType
{
    public $m_DisplayUnitType;
    
    function __construct($displayUnitType)
    {
    	$this->m_DisplayUnitType = $displayUnitType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsDocumentProperty]
  
 */
class DocumentProperty
{
    public $m_DocumentProperty;
    
    function __construct($documentProperty)
    {
    	$this->m_DocumentProperty = $documentProperty;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsDocumentProperty.getName()]

      @return String
     */
    function getName()
    {
        return $this->m_DocumentProperty->getName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDocumentProperty.getSource()]

      @return String
     */
    function getSource()
    {
        return $this->m_DocumentProperty->getSource();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDocumentProperty.getType()]

      @return int
     */
    function getType()
    {
        return $this->m_DocumentProperty->getType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDocumentProperty.getValue()]

      @return corresponding java type is {java.lang.Object}
     */
    function getValue()
    {
        return ClassFactory::_t2($this->m_DocumentProperty->getValue());
    }

    /*
      Wrapper for java version method [com.aspose.cellsDocumentProperty.isGeneratedName()]

      @return boolean
     */
    function isGeneratedName()
    {
        return $this->m_DocumentProperty->isGeneratedName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDocumentProperty.isLinkedToContent()]

      @return boolean
     */
    function isLinkedToContent()
    {
        return $this->m_DocumentProperty->isLinkedToContent();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDocumentProperty.setValue(Object)]

      @param oObject0  corresponding java type is {java.lang.Object}
     */
    function setValue($oObject0)
    {
        $this->m_DocumentProperty->setValue(ClassFactory::_t1($oObject0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsDocumentProperty.toBool()]

      @return boolean
     */
    function toBool()
    {
        return $this->m_DocumentProperty->toBool();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDocumentProperty.toDateTime()]

      @return com.aspose.cells.DateTime
     */
    function toDateTime()
    {
        return ClassFactory::_t2($this->m_DocumentProperty->toDateTime());
    }

    /*
      Wrapper for java version method [com.aspose.cellsDocumentProperty.toDouble()]

      @return double
     */
    function toDouble()
    {
        return $this->m_DocumentProperty->toDouble();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDocumentProperty.toInt()]

      @return int
     */
    function toInt()
    {
        return $this->m_DocumentProperty->toInt();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDocumentProperty.toString()]

      @return String
     */
    function toString()
    {
        return $this->m_DocumentProperty->toString();
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsDocumentPropertyCollection]
  
 */
class DocumentPropertyCollection
{
    public $m_DocumentPropertyCollection;
    
    function __construct($documentPropertyCollection)
    {
    	$this->m_DocumentPropertyCollection = $documentPropertyCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsDocumentPropertyCollection.clear()]

     */
    function clear()
    {
        $this->m_DocumentPropertyCollection->clear();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDocumentPropertyCollection.contains(String)]

      @param oString0  String
      @return boolean
     */
    function contains($oString0)
    {
        return $this->m_DocumentPropertyCollection->contains($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDocumentPropertyCollection.get(String)]

      @param oString0  String
      @return com.aspose.cells.DocumentProperty
     */
    function get($oString0)
    {
        return ClassFactory::_t2($this->m_DocumentPropertyCollection->get($oString0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsDocumentPropertyCollection.get(int)]

      @param pInt0  int
      @return com.aspose.cells.DocumentProperty
     */
    function getI($pInt0)
    {
        return ClassFactory::_t2($this->m_DocumentPropertyCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsDocumentPropertyCollection.getCount()]

      @return int
     */
    function getCount()
    {
        return $this->m_DocumentPropertyCollection->getCount();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDocumentPropertyCollection.indexOf(String)]

      @param oString0  String
      @return int
     */
    function indexOf($oString0)
    {
        return $this->m_DocumentPropertyCollection->indexOf($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDocumentPropertyCollection.iterator()]

      @return corresponding java type is {java.util.Iterator}
     */
    function iterator()
    {
        return ClassFactory::_t2($this->m_DocumentPropertyCollection->iterator());
    }

    /*
      Wrapper for java version method [com.aspose.cellsDocumentPropertyCollection.remove(String)]

      @param oString0  String
     */
    function remove($oString0)
    {
        $this->m_DocumentPropertyCollection->remove($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDocumentPropertyCollection.removeAt(int)]

      @param pInt0  int
     */
    function removeAt($pInt0)
    {
        $this->m_DocumentPropertyCollection->removeAt($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsDropBars]
  
 */
class DropBars
{
    public $m_DropBars;
    
    function __construct($dropBars)
    {
    	$this->m_DropBars = $dropBars;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsDropBars.getArea()]

      @return com.aspose.cells.Area
     */
    function getArea()
    {
        return ClassFactory::_t2($this->m_DropBars->getArea());
    }

    /*
      Wrapper for java version method [com.aspose.cellsDropBars.getBorder()]

      @return com.aspose.cells.Line
     */
    function getBorder()
    {
        return ClassFactory::_t2($this->m_DropBars->getBorder());
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsDynamicFilter]
  
 */
class DynamicFilter
{
    public $m_DynamicFilter;
    
    function __construct($dynamicFilter)
    {
    	$this->m_DynamicFilter = $dynamicFilter;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsDynamicFilter.getDynamicFilterType()]

      @return int
     */
    function getDynamicFilterType()
    {
        return $this->m_DynamicFilter->getDynamicFilterType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsDynamicFilter.getMaxValue()]

      @return corresponding java type is {java.lang.Object}
     */
    function getMaxValue()
    {
        return ClassFactory::_t2($this->m_DynamicFilter->getMaxValue());
    }

    /*
      Wrapper for java version method [com.aspose.cellsDynamicFilter.getValue()]

      @return corresponding java type is {java.lang.Object}
     */
    function getValue()
    {
        return ClassFactory::_t2($this->m_DynamicFilter->getValue());
    }

    /*
      Wrapper for java version method [com.aspose.cellsDynamicFilter.setDynamicFilterType(int)]

      @param pInt0  int
     */
    function setDynamicFilterType($pInt0)
    {
        $this->m_DynamicFilter->setDynamicFilterType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsDynamicFilter.setMaxValue(Object)]

      @param oObject0  corresponding java type is {java.lang.Object}
     */
    function setMaxValue($oObject0)
    {
        $this->m_DynamicFilter->setMaxValue(ClassFactory::_t1($oObject0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsDynamicFilter.setValue(Object)]

      @param oObject0  corresponding java type is {java.lang.Object}
     */
    function setValue($oObject0)
    {
        $this->m_DynamicFilter->setValue(ClassFactory::_t1($oObject0));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsDynamicFilterType]
  
 */
class DynamicFilterType
{
    public $m_DynamicFilterType;
    
    function __construct($dynamicFilterType)
    {
    	$this->m_DynamicFilterType = $dynamicFilterType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsEncoding]
  
 */
class Encoding
{
    public $m_Encoding;
    
    function __construct($encoding)
    {
    	$this->m_Encoding = $encoding;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsEncoding.equals(Encoding)]

      @param oEncoding0  com.aspose.cells.Encoding
      @return boolean
     */
    function equals($oEncoding0)
    {
        return $this->m_Encoding->equals(ClassFactory::_t1($oEncoding0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsEncoding.equals(Object)]

      @param oObject0  corresponding java type is {java.lang.Object}
      @return boolean
     */
    function equalsO($oObject0)
    {
        return $this->m_Encoding->equals(ClassFactory::_t1($oObject0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsEncoding.getASCII()]

      @return com.aspose.cells.Encoding
     */
    function getASCII()
    {
        return ClassFactory::_t2($this->m_Encoding->getASCII());
    }

    /*
      Wrapper for java version method [com.aspose.cellsEncoding.getBigEndianUnicode()]

      @return com.aspose.cells.Encoding
     */
    function getBigEndianUnicode()
    {
        return ClassFactory::_t2($this->m_Encoding->getBigEndianUnicode());
    }

    /*
      Wrapper for java version method [com.aspose.cellsEncoding.getDefault()]

      @return com.aspose.cells.Encoding
     */
    function getDefault()
    {
        return ClassFactory::_t2($this->m_Encoding->getDefault());
    }

    /*
      Wrapper for java version method [com.aspose.cellsEncoding.getEncoding(Charset)]

      @param oCharset0  corresponding java type is {java.nio.charset.Charset}
      @return com.aspose.cells.Encoding
     */
    function getEncoding($oCharset0)
    {
        return ClassFactory::_t2($this->m_Encoding->getEncoding(ClassFactory::_t1($oCharset0)));
    }

    /*
      Wrapper for java version method [com.aspose.cellsEncoding.getEncoding(String)]

      @param oString0  String
      @return com.aspose.cells.Encoding
     */
    function getEncodingS($oString0)
    {
        return ClassFactory::_t2($this->m_Encoding->getEncoding($oString0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsEncoding.getEncoding(int)]

      @param pInt0  int
      @return com.aspose.cells.Encoding
     */
    function getEncodingI($pInt0)
    {
        return ClassFactory::_t2($this->m_Encoding->getEncoding($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsEncoding.getUTF7()]

      @return com.aspose.cells.Encoding
     */
    function getUTF7()
    {
        return ClassFactory::_t2($this->m_Encoding->getUTF7());
    }

    /*
      Wrapper for java version method [com.aspose.cellsEncoding.getUTF8()]

      @return com.aspose.cells.Encoding
     */
    function getUTF8()
    {
        return ClassFactory::_t2($this->m_Encoding->getUTF8());
    }

    /*
      Wrapper for java version method [com.aspose.cellsEncoding.getUnicode()]

      @return com.aspose.cells.Encoding
     */
    function getUnicode()
    {
        return ClassFactory::_t2($this->m_Encoding->getUnicode());
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsEncryptionType]
  
 */
class EncryptionType
{
    public $m_EncryptionType;
    
    function __construct($encryptionType)
    {
    	$this->m_EncryptionType = $encryptionType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsErrorBar]
  
 */
class ErrorBar extends Line
{
    public $m_ErrorBar;
    
    function __construct($errorBar)
    {
    	$this->m_ErrorBar = $errorBar;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsErrorBar.getAmount()]

      @return double
     */
    function getAmount()
    {
        return $this->m_ErrorBar->getAmount();
    }

    /*
      Wrapper for java version method [com.aspose.cellsErrorBar.getDisplayType()]

      @return int
     */
    function getDisplayType()
    {
        return $this->m_ErrorBar->getDisplayType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsErrorBar.getMinusValue()]

      @return String
     */
    function getMinusValue()
    {
        return $this->m_ErrorBar->getMinusValue();
    }

    /*
      Wrapper for java version method [com.aspose.cellsErrorBar.getPlusValue()]

      @return String
     */
    function getPlusValue()
    {
        return $this->m_ErrorBar->getPlusValue();
    }

    /*
      Wrapper for java version method [com.aspose.cellsErrorBar.getShowMarkerTTop()]

      @return boolean
     */
    function getShowMarkerTTop()
    {
        return $this->m_ErrorBar->getShowMarkerTTop();
    }

    /*
      Wrapper for java version method [com.aspose.cellsErrorBar.getType()]

      @return int
     */
    function getType()
    {
        return $this->m_ErrorBar->getType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsErrorBar.setAmount(double)]

      @param pDouble0  double
     */
    function setAmount($pDouble0)
    {
        $this->m_ErrorBar->setAmount($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsErrorBar.setDisplayType(int)]

      @param pInt0  int
     */
    function setDisplayType($pInt0)
    {
        $this->m_ErrorBar->setDisplayType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsErrorBar.setMinusValue(String)]

      @param oString0  String
     */
    function setMinusValue($oString0)
    {
        $this->m_ErrorBar->setMinusValue($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsErrorBar.setPlusValue(String)]

      @param oString0  String
     */
    function setPlusValue($oString0)
    {
        $this->m_ErrorBar->setPlusValue($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsErrorBar.setShowMarkerTTop(boolean)]

      @param pBoolean0  boolean
     */
    function setShowMarkerTTop($pBoolean0)
    {
        $this->m_ErrorBar->setShowMarkerTTop($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsErrorBar.setType(int)]

      @param pInt0  int
     */
    function setType($pInt0)
    {
        $this->m_ErrorBar->setType($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsErrorBarDisplayType]
  
 */
class ErrorBarDisplayType
{
    public $m_ErrorBarDisplayType;
    
    function __construct($errorBarDisplayType)
    {
    	$this->m_ErrorBarDisplayType = $errorBarDisplayType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsErrorBarType]
  
 */
class ErrorBarType
{
    public $m_ErrorBarType;
    
    function __construct($errorBarType)
    {
    	$this->m_ErrorBarType = $errorBarType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsErrorCheckOption]
  
 */
class ErrorCheckOption
{
    public $m_ErrorCheckOption;
    
    function __construct($errorCheckOption)
    {
    	$this->m_ErrorCheckOption = $errorCheckOption;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsErrorCheckOption.addRange(CellArea)]

      @param oCellArea0  com.aspose.cells.CellArea
      @return int
     */
    function addRange($oCellArea0)
    {
        return $this->m_ErrorCheckOption->addRange(ClassFactory::_t1($oCellArea0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsErrorCheckOption.getCountOfRange()]

      @return int
     */
    function getCountOfRange()
    {
        return $this->m_ErrorCheckOption->getCountOfRange();
    }

    /*
      Wrapper for java version method [com.aspose.cellsErrorCheckOption.getRange(int)]

      @param pInt0  int
      @return com.aspose.cells.CellArea
     */
    function getRange($pInt0)
    {
        return ClassFactory::_t2($this->m_ErrorCheckOption->getRange($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsErrorCheckOption.isErrorCheck(int)]

      @param pInt0  int
      @return boolean
     */
    function isErrorCheck($pInt0)
    {
        return $this->m_ErrorCheckOption->isErrorCheck($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsErrorCheckOption.removeRange(int)]

      @param pInt0  int
     */
    function removeRange($pInt0)
    {
        $this->m_ErrorCheckOption->removeRange($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsErrorCheckOption.setErrorCheck(int, boolean)]

      @param pInt0  int
      @param pBoolean1  boolean
     */
    function setErrorCheck($pInt0, $pBoolean1)
    {
        $this->m_ErrorCheckOption->setErrorCheck($pInt0, $pBoolean1);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsErrorCheckOptionCollection]
  
 */
class ErrorCheckOptionCollection extends CollectionBase
{
    public $m_ErrorCheckOptionCollection;
    
    function __construct($errorCheckOptionCollection)
    {
    	$this->m_ErrorCheckOptionCollection = $errorCheckOptionCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsErrorCheckOptionCollection.add()]

      @return int
     */
    function add()
    {
        return $this->m_ErrorCheckOptionCollection->add();
    }

    /*
      Wrapper for java version method [com.aspose.cellsErrorCheckOptionCollection.get(int)]

      @param pInt0  int
      @return com.aspose.cells.ErrorCheckOption
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_ErrorCheckOptionCollection->get($pInt0));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsErrorCheckType]
  
 */
class ErrorCheckType
{
    public $m_ErrorCheckType;
    
    function __construct($errorCheckType)
    {
    	$this->m_ErrorCheckType = $errorCheckType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsExceptionType]
  
 */
class ExceptionType
{
    public $m_ExceptionType;
    
    function __construct($exceptionType)
    {
    	$this->m_ExceptionType = $exceptionType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsExportTableOptions]
  
 */
class ExportTableOptions
{
    public $m_ExportTableOptions;
    
    function __construct($exportTableOptions)
    {
    	$this->m_ExportTableOptions = $exportTableOptions;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsExportTableOptions.getExportColumnName()]

      @return boolean
     */
    function getExportColumnName()
    {
        return $this->m_ExportTableOptions->getExportColumnName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsExportTableOptions.getSkipErrorValue()]

      @return boolean
     */
    function getSkipErrorValue()
    {
        return $this->m_ExportTableOptions->getSkipErrorValue();
    }

    /*
      Wrapper for java version method [com.aspose.cellsExportTableOptions.setExportColumnName(boolean)]

      @param pBoolean0  boolean
     */
    function setExportColumnName($pBoolean0)
    {
        $this->m_ExportTableOptions->setExportColumnName($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsExportTableOptions.setSkipErrorValue(boolean)]

      @param pBoolean0  boolean
     */
    function setSkipErrorValue($pBoolean0)
    {
        $this->m_ExportTableOptions->setSkipErrorValue($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsExternalLink]
  
 */
class ExternalLink
{
    public $m_ExternalLink;
    
    function __construct($externalLink)
    {
    	$this->m_ExternalLink = $externalLink;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsExternalLink.addExternalName(String, String)]

      @param oString0  String
      @param oString1  String
     */
    function addExternalName($oString0, $oString1)
    {
        $this->m_ExternalLink->addExternalName($oString0, $oString1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsExternalLink.getDataSource()]

      @return String
     */
    function getDataSource()
    {
        return $this->m_ExternalLink->getDataSource();
    }

    /*
      Wrapper for java version method [com.aspose.cellsExternalLink.isReferred()]

      @return boolean
     */
    function isReferred()
    {
        return $this->m_ExternalLink->isReferred();
    }

    /*
      Wrapper for java version method [com.aspose.cellsExternalLink.setDataSource(String)]

      @param oString0  String
     */
    function setDataSource($oString0)
    {
        $this->m_ExternalLink->setDataSource($oString0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsExternalLinkCollection]
  
 */
class ExternalLinkCollection
{
    public $m_ExternalLinkCollection;
    
    function __construct($externalLinkCollection)
    {
    	$this->m_ExternalLinkCollection = $externalLinkCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsExternalLinkCollection.add(String, String[])]

      @param oString0  String
      @param arrD1DString1  array, corresponding java type is {String[]}
      @return int
     */
    function add($oString0, $arrD1DString1)
    {
        return $this->m_ExternalLinkCollection->add($oString0, $arrD1DString1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsExternalLinkCollection.add(int, String, String[])]

      @param pInt0  int
      @param oString1  String
      @param arrD1DString2  array, corresponding java type is {String[]}
      @return int
     */
    function addISS($pInt0, $oString1, $arrD1DString2)
    {
        return $this->m_ExternalLinkCollection->add($pInt0, $oString1, $arrD1DString2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsExternalLinkCollection.get(int)]

      @param pInt0  int
      @return com.aspose.cells.ExternalLink
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_ExternalLinkCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsExternalLinkCollection.getCount()]

      @return int
     */
    function getCount()
    {
        return $this->m_ExternalLinkCollection->getCount();
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsFileFormatType]
  
 */
class FileFormatType
{
    public $m_FileFormatType;
    
    function __construct($fileFormatType)
    {
    	$this->m_FileFormatType = $fileFormatType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsFileFormatUtil]
  
 */
class FileFormatUtil
{
    public $m_FileFormatUtil;
    
    function __construct($fileFormatUtil)
    {
    	$this->m_FileFormatUtil = $fileFormatUtil;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsFileFormatUtil.extensionToSaveFormat(String)]

      @param oString0  String
      @return int
     */
    function extensionToSaveFormat($oString0)
    {
        return $this->m_FileFormatUtil->extensionToSaveFormat($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFileFormatUtil.isTemplateFormat(String)]

      @param oString0  String
      @return boolean
     */
    function isTemplateFormat($oString0)
    {
        return $this->m_FileFormatUtil->isTemplateFormat($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFileFormatUtil.loadFormatToExtension(int)]

      @param pInt0  int
      @return String
     */
    function loadFormatToExtension($pInt0)
    {
        return $this->m_FileFormatUtil->loadFormatToExtension($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFileFormatUtil.loadFormatToSaveFormat(int)]

      @param pInt0  int
      @return int
     */
    function loadFormatToSaveFormat($pInt0)
    {
        return $this->m_FileFormatUtil->loadFormatToSaveFormat($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFileFormatUtil.saveFormatToExtension(int)]

      @param pInt0  int
      @return String
     */
    function saveFormatToExtension($pInt0)
    {
        return $this->m_FileFormatUtil->saveFormatToExtension($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFileFormatUtil.saveFormatToLoadFormat(int)]

      @param pInt0  int
      @return int
     */
    function saveFormatToLoadFormat($pInt0)
    {
        return $this->m_FileFormatUtil->saveFormatToLoadFormat($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsFillFormat]
  
 */
class FillFormat
{
    public $m_FillFormat;
    
    function __construct($fillFormat)
    {
    	$this->m_FillFormat = $fillFormat;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsFillFormat.getGradientColor1()]

      @return com.aspose.cells.Color
     */
    function getGradientColor1()
    {
        return ClassFactory::_t2($this->m_FillFormat->getGradientColor1());
    }

    /*
      Wrapper for java version method [com.aspose.cellsFillFormat.getGradientColor2()]

      @return com.aspose.cells.Color
     */
    function getGradientColor2()
    {
        return ClassFactory::_t2($this->m_FillFormat->getGradientColor2());
    }

    /*
      Wrapper for java version method [com.aspose.cellsFillFormat.getGradientColorType()]

      @return int
     */
    function getGradientColorType()
    {
        return $this->m_FillFormat->getGradientColorType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFillFormat.getGradientDegree()]

      @return double
     */
    function getGradientDegree()
    {
        return $this->m_FillFormat->getGradientDegree();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFillFormat.getGradientFill()]

      @return com.aspose.cells.GradientFill
     */
    function getGradientFill()
    {
        return ClassFactory::_t2($this->m_FillFormat->getGradientFill());
    }

    /*
      Wrapper for java version method [com.aspose.cellsFillFormat.getGradientStyle()]

      @return int
     */
    function getGradientStyle()
    {
        return $this->m_FillFormat->getGradientStyle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFillFormat.getGradientVariant()]

      @return int
     */
    function getGradientVariant()
    {
        return $this->m_FillFormat->getGradientVariant();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFillFormat.getImageData()]

      @return byte[]
     */
    function getImageData()
    {
        return $this->m_FillFormat->getImageData();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFillFormat.getPattern()]

      @return int
     */
    function getPattern()
    {
        return $this->m_FillFormat->getPattern();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFillFormat.getPictureFormatType()]

      @return int
     */
    function getPictureFormatType()
    {
        return $this->m_FillFormat->getPictureFormatType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFillFormat.getPresetColor()]

      @return int
     */
    function getPresetColor()
    {
        return $this->m_FillFormat->getPresetColor();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFillFormat.getScale()]

      @return double
     */
    function getScale()
    {
        return $this->m_FillFormat->getScale();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFillFormat.getSetType()]

      @return int
     */
    function getSetType()
    {
        return $this->m_FillFormat->getSetType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFillFormat.getTexture()]

      @return int
     */
    function getTexture()
    {
        return $this->m_FillFormat->getTexture();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFillFormat.setImageData(byte[])]

      @param arrP1DByte0  byte[]
     */
    function setImageData($arrP1DByte0)
    {
        $this->m_FillFormat->setImageData($arrP1DByte0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFillFormat.setOneColorGradient(Color, double, int, int)]

      @param oColor0  com.aspose.cells.Color
      @param pDouble1  double
      @param pInt2  int
      @param pInt3  int
     */
    function setOneColorGradient($oColor0, $pDouble1, $pInt2, $pInt3)
    {
        $this->m_FillFormat->setOneColorGradient(ClassFactory::_t1($oColor0), $pDouble1, $pInt2, $pInt3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFillFormat.setPattern(int)]

      @param pInt0  int
     */
    function setPattern($pInt0)
    {
        $this->m_FillFormat->setPattern($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFillFormat.setPictureFormatType(int)]

      @param pInt0  int
     */
    function setPictureFormatType($pInt0)
    {
        $this->m_FillFormat->setPictureFormatType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFillFormat.setPresetColorGradient(int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
     */
    function setPresetColorGradient($pInt0, $pInt1, $pInt2)
    {
        $this->m_FillFormat->setPresetColorGradient($pInt0, $pInt1, $pInt2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFillFormat.setScale(double)]

      @param pDouble0  double
     */
    function setScale($pDouble0)
    {
        $this->m_FillFormat->setScale($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFillFormat.setSetType(int)]

      @param pInt0  int
     */
    function setSetType($pInt0)
    {
        $this->m_FillFormat->setSetType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFillFormat.setTexture(int)]

      @param pInt0  int
     */
    function setTexture($pInt0)
    {
        $this->m_FillFormat->setTexture($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFillFormat.setTwoColorGradient(Color, Color, int, int)]

      @param oColor0  com.aspose.cells.Color
      @param oColor1  com.aspose.cells.Color
      @param pInt2  int
      @param pInt3  int
     */
    function setTwoColorGradient($oColor0, $oColor1, $pInt2, $pInt3)
    {
        $this->m_FillFormat->setTwoColorGradient(ClassFactory::_t1($oColor0), ClassFactory::_t1($oColor1), $pInt2, $pInt3);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsFillPattern]
  
 */
class FillPattern
{
    public $m_FillPattern;
    
    function __construct($fillPattern)
    {
    	$this->m_FillPattern = $fillPattern;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsFillPictureType]
  
 */
class FillPictureType
{
    public $m_FillPictureType;
    
    function __construct($fillPictureType)
    {
    	$this->m_FillPictureType = $fillPictureType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsFilterColumn]
  
 */
class FilterColumn
{
    public $m_FilterColumn;
    
    function __construct($filterColumn)
    {
    	$this->m_FilterColumn = $filterColumn;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsFilterColumn.getFieldIndex()]

      @return int
     */
    function getFieldIndex()
    {
        return $this->m_FilterColumn->getFieldIndex();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFilterColumn.getFilter()]

      @return corresponding java type is {java.lang.Object}
     */
    function getFilter()
    {
        return ClassFactory::_t2($this->m_FilterColumn->getFilter());
    }

    /*
      Wrapper for java version method [com.aspose.cellsFilterColumn.getFilterType()]

      @return int
     */
    function getFilterType()
    {
        return $this->m_FilterColumn->getFilterType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFilterColumn.getVisibledropdown()]

      @return boolean
     */
    function getVisibledropdown()
    {
        return $this->m_FilterColumn->getVisibledropdown();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFilterColumn.setFieldIndex(int)]

      @param pInt0  int
     */
    function setFieldIndex($pInt0)
    {
        $this->m_FilterColumn->setFieldIndex($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFilterColumn.setFilter(Object)]

      @param oObject0  corresponding java type is {java.lang.Object}
     */
    function setFilter($oObject0)
    {
        $this->m_FilterColumn->setFilter(ClassFactory::_t1($oObject0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsFilterColumn.setFilterType(int)]

      @param pInt0  int
     */
    function setFilterType($pInt0)
    {
        $this->m_FilterColumn->setFilterType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFilterColumn.setVisibledropdown(boolean)]

      @param pBoolean0  boolean
     */
    function setVisibledropdown($pBoolean0)
    {
        $this->m_FilterColumn->setVisibledropdown($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsFilterColumnCollection]
  
 */
class FilterColumnCollection extends CollectionBase
{
    public $m_FilterColumnCollection;
    
    function __construct($filterColumnCollection)
    {
    	$this->m_FilterColumnCollection = $filterColumnCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsFilterColumnCollection.get(int)]

      @param pInt0  int
      @return corresponding java type is {java.lang.Object}
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_FilterColumnCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsFilterColumnCollection.getByIndex(int)]

      @param pInt0  int
      @return com.aspose.cells.FilterColumn
     */
    function getByIndex($pInt0)
    {
        return ClassFactory::_t2($this->m_FilterColumnCollection->getByIndex($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsFilterColumnCollection.removeAt(int)]

      @param pInt0  int
     */
    function removeAt($pInt0)
    {
        $this->m_FilterColumnCollection->removeAt($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsFilterOperatorType]
  
 */
class FilterOperatorType
{
    public $m_FilterOperatorType;
    
    function __construct($filterOperatorType)
    {
    	$this->m_FilterOperatorType = $filterOperatorType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsFilterType]
  
 */
class FilterType
{
    public $m_FilterType;
    
    function __construct($filterType)
    {
    	$this->m_FilterType = $filterType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsFindOptions]
  
 */
class FindOptions
{
    public $m_FindOptions;
    
    function __construct($findOptions)
    {
    	$this->m_FindOptions = $findOptions;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsFindOptions.getCaseSensitive()]

      @return boolean
     */
    function getCaseSensitive()
    {
        return $this->m_FindOptions->getCaseSensitive();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFindOptions.getLookAtType()]

      @return int
     */
    function getLookAtType()
    {
        return $this->m_FindOptions->getLookAtType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFindOptions.getLookInType()]

      @return int
     */
    function getLookInType()
    {
        return $this->m_FindOptions->getLookInType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFindOptions.getRange()]

      @return com.aspose.cells.CellArea
     */
    function getRange()
    {
        return ClassFactory::_t2($this->m_FindOptions->getRange());
    }

    /*
      Wrapper for java version method [com.aspose.cellsFindOptions.getSeachOrderByRows()]

      @return boolean
     */
    function getSeachOrderByRows()
    {
        return $this->m_FindOptions->getSeachOrderByRows();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFindOptions.getSearchNext()]

      @return boolean
     */
    function getSearchNext()
    {
        return $this->m_FindOptions->getSearchNext();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFindOptions.isRangeSet()]

      @return boolean
     */
    function isRangeSet()
    {
        return $this->m_FindOptions->isRangeSet();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFindOptions.setCaseSensitive(boolean)]

      @param pBoolean0  boolean
     */
    function setCaseSensitive($pBoolean0)
    {
        $this->m_FindOptions->setCaseSensitive($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFindOptions.setLookAtType(int)]

      @param pInt0  int
     */
    function setLookAtType($pInt0)
    {
        $this->m_FindOptions->setLookAtType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFindOptions.setLookInType(int)]

      @param pInt0  int
     */
    function setLookInType($pInt0)
    {
        $this->m_FindOptions->setLookInType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFindOptions.setRange(CellArea)]

      @param oCellArea0  com.aspose.cells.CellArea
     */
    function setRange($oCellArea0)
    {
        $this->m_FindOptions->setRange(ClassFactory::_t1($oCellArea0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsFindOptions.setSeachOrderByRows(boolean)]

      @param pBoolean0  boolean
     */
    function setSeachOrderByRows($pBoolean0)
    {
        $this->m_FindOptions->setSeachOrderByRows($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFindOptions.setSearchNext(boolean)]

      @param pBoolean0  boolean
     */
    function setSearchNext($pBoolean0)
    {
        $this->m_FindOptions->setSearchNext($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsFloor]
  
 */
class Floor extends Area
{
    public $m_Floor;
    
    function __construct($floor)
    {
    	$this->m_Floor = $floor;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsFloor.getBorder()]

      @return com.aspose.cells.Line
     */
    function getBorder()
    {
        return ClassFactory::_t2($this->m_Floor->getBorder());
    }

    /*
      Wrapper for java version method [com.aspose.cellsFloor.setBorder(Line)]

      @param oLine0  com.aspose.cells.Line
     */
    function setBorder($oLine0)
    {
        $this->m_Floor->setBorder(ClassFactory::_t1($oLine0));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsFont]
  
 */
class Font
{
    public $m_Font;
    
    function __construct($font)
    {
    	$this->m_Font = $font;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsFont.equals(Font)]

      @param oFont0  com.aspose.cells.Font
      @return boolean
     */
    function equals($oFont0)
    {
        return $this->m_Font->equals(ClassFactory::_t1($oFont0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsFont.getColor()]

      @return com.aspose.cells.Color
     */
    function getColor()
    {
        return ClassFactory::_t2($this->m_Font->getColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsFont.getDoubleSize()]

      @return double
     */
    function getDoubleSize()
    {
        return $this->m_Font->getDoubleSize();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFont.getName()]

      @return String
     */
    function getName()
    {
        return $this->m_Font->getName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFont.getSize()]

      @return int
     */
    function getSize()
    {
        return $this->m_Font->getSize();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFont.getThemeColor()]

      @return com.aspose.cells.ThemeColor
     */
    function getThemeColor()
    {
        return ClassFactory::_t2($this->m_Font->getThemeColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsFont.getUnderline()]

      @return int
     */
    function getUnderline()
    {
        return $this->m_Font->getUnderline();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFont.isBold()]

      @return boolean
     */
    function isBold()
    {
        return $this->m_Font->isBold();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFont.isItalic()]

      @return boolean
     */
    function isItalic()
    {
        return $this->m_Font->isItalic();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFont.isStrikeout()]

      @return boolean
     */
    function isStrikeout()
    {
        return $this->m_Font->isStrikeout();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFont.isSubscript()]

      @return boolean
     */
    function isSubscript()
    {
        return $this->m_Font->isSubscript();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFont.isSuperscript()]

      @return boolean
     */
    function isSuperscript()
    {
        return $this->m_Font->isSuperscript();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFont.setBold(boolean)]

      @param pBoolean0  boolean
     */
    function setBold($pBoolean0)
    {
        $this->m_Font->setBold($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFont.setColor(Color)]

      @param oColor0  com.aspose.cells.Color
     */
    function setColor($oColor0)
    {
        $this->m_Font->setColor(ClassFactory::_t1($oColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsFont.setDoubleSize(double)]

      @param pDouble0  double
     */
    function setDoubleSize($pDouble0)
    {
        $this->m_Font->setDoubleSize($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFont.setItalic(boolean)]

      @param pBoolean0  boolean
     */
    function setItalic($pBoolean0)
    {
        $this->m_Font->setItalic($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFont.setName(String)]

      @param oString0  String
     */
    function setName($oString0)
    {
        $this->m_Font->setName($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFont.setSize(int)]

      @param pInt0  int
     */
    function setSize($pInt0)
    {
        $this->m_Font->setSize($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFont.setStrikeout(boolean)]

      @param pBoolean0  boolean
     */
    function setStrikeout($pBoolean0)
    {
        $this->m_Font->setStrikeout($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFont.setSubscript(boolean)]

      @param pBoolean0  boolean
     */
    function setSubscript($pBoolean0)
    {
        $this->m_Font->setSubscript($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFont.setSuperscript(boolean)]

      @param pBoolean0  boolean
     */
    function setSuperscript($pBoolean0)
    {
        $this->m_Font->setSuperscript($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFont.setThemeColor(ThemeColor)]

      @param oThemeColor0  com.aspose.cells.ThemeColor
     */
    function setThemeColor($oThemeColor0)
    {
        $this->m_Font->setThemeColor(ClassFactory::_t1($oThemeColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsFont.setUnderline(int)]

      @param pInt0  int
     */
    function setUnderline($pInt0)
    {
        $this->m_Font->setUnderline($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsFontSetting]
  
 */
class FontSetting
{
    public $m_FontSetting;
    
    function __construct($fontSetting)
    {
    	$this->m_FontSetting = $fontSetting;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsFontSetting.getFont()]

      @return com.aspose.cells.Font
     */
    function getFont()
    {
        return ClassFactory::_t2($this->m_FontSetting->getFont());
    }

    /*
      Wrapper for java version method [com.aspose.cellsFontSetting.getLength()]

      @return int
     */
    function getLength()
    {
        return $this->m_FontSetting->getLength();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFontSetting.getStartIndex()]

      @return int
     */
    function getStartIndex()
    {
        return $this->m_FontSetting->getStartIndex();
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsFontUnderlineType]
  
 */
class FontUnderlineType
{
    public $m_FontUnderlineType;
    
    function __construct($fontUnderlineType)
    {
    	$this->m_FontUnderlineType = $fontUnderlineType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsFormat3D]
  
 */
class Format3D
{
    public $m_Format3D;
    
    function __construct($format3D)
    {
    	$this->m_Format3D = $format3D;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsFormat3D.getLightingAngle()]

      @return double
     */
    function getLightingAngle()
    {
        return $this->m_Format3D->getLightingAngle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormat3D.getSurfaceLightingType()]

      @return int
     */
    function getSurfaceLightingType()
    {
        return $this->m_Format3D->getSurfaceLightingType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormat3D.getSurfaceMaterialType()]

      @return int
     */
    function getSurfaceMaterialType()
    {
        return $this->m_Format3D->getSurfaceMaterialType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormat3D.getTopBevel()]

      @return com.aspose.cells.Bevel
     */
    function getTopBevel()
    {
        return ClassFactory::_t2($this->m_Format3D->getTopBevel());
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormat3D.hasTopBevelData()]

      @return boolean
     */
    function hasTopBevelData()
    {
        return $this->m_Format3D->hasTopBevelData();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormat3D.setLightingAngle(double)]

      @param pDouble0  double
     */
    function setLightingAngle($pDouble0)
    {
        $this->m_Format3D->setLightingAngle($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormat3D.setSurfaceLightingType(int)]

      @param pInt0  int
     */
    function setSurfaceLightingType($pInt0)
    {
        $this->m_Format3D->setSurfaceLightingType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormat3D.setSurfaceMaterialType(int)]

      @param pInt0  int
     */
    function setSurfaceMaterialType($pInt0)
    {
        $this->m_Format3D->setSurfaceMaterialType($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsFormatCondition]
  
 */
class FormatCondition
{
    public $m_FormatCondition;
    
    function __construct($formatCondition)
    {
    	$this->m_FormatCondition = $formatCondition;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsFormatCondition.getAboveAverage()]

      @return com.aspose.cells.AboveAverage
     */
    function getAboveAverage()
    {
        return ClassFactory::_t2($this->m_FormatCondition->getAboveAverage());
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatCondition.getColorScale()]

      @return com.aspose.cells.ColorScale
     */
    function getColorScale()
    {
        return ClassFactory::_t2($this->m_FormatCondition->getColorScale());
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatCondition.getDataBar()]

      @return com.aspose.cells.DataBar
     */
    function getDataBar()
    {
        return ClassFactory::_t2($this->m_FormatCondition->getDataBar());
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatCondition.getFormula1()]

      @return String
     */
    function getFormula1()
    {
        return $this->m_FormatCondition->getFormula1();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatCondition.getFormula1(int, int)]

      @param pInt0  int
      @param pInt1  int
      @return String
     */
    function getFormula1II($pInt0, $pInt1)
    {
        return $this->m_FormatCondition->getFormula1($pInt0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatCondition.getFormula2()]

      @return String
     */
    function getFormula2()
    {
        return $this->m_FormatCondition->getFormula2();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatCondition.getFormula2(int, int)]

      @param pInt0  int
      @param pInt1  int
      @return String
     */
    function getFormula2II($pInt0, $pInt1)
    {
        return $this->m_FormatCondition->getFormula2($pInt0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatCondition.getIconSet()]

      @return com.aspose.cells.IconSet
     */
    function getIconSet()
    {
        return ClassFactory::_t2($this->m_FormatCondition->getIconSet());
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatCondition.getOperator()]

      @return int
     */
    function getOperator()
    {
        return $this->m_FormatCondition->getOperator();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatCondition.getStopIfTrue()]

      @return boolean
     */
    function getStopIfTrue()
    {
        return $this->m_FormatCondition->getStopIfTrue();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatCondition.getStyle()]

      @return com.aspose.cells.Style
     */
    function getStyle()
    {
        return ClassFactory::_t2($this->m_FormatCondition->getStyle());
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatCondition.getText()]

      @return String
     */
    function getText()
    {
        return $this->m_FormatCondition->getText();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatCondition.getTimePeriod()]

      @return int
     */
    function getTimePeriod()
    {
        return $this->m_FormatCondition->getTimePeriod();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatCondition.getTop10()]

      @return com.aspose.cells.Top10
     */
    function getTop10()
    {
        return ClassFactory::_t2($this->m_FormatCondition->getTop10());
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatCondition.getType()]

      @return int
     */
    function getType()
    {
        return $this->m_FormatCondition->getType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatCondition.setFormula1(String)]

      @param oString0  String
     */
    function setFormula1($oString0)
    {
        $this->m_FormatCondition->setFormula1($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatCondition.setFormula2(String)]

      @param oString0  String
     */
    function setFormula2($oString0)
    {
        $this->m_FormatCondition->setFormula2($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatCondition.setOperator(int)]

      @param pInt0  int
     */
    function setOperator($pInt0)
    {
        $this->m_FormatCondition->setOperator($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatCondition.setStopIfTrue(boolean)]

      @param pBoolean0  boolean
     */
    function setStopIfTrue($pBoolean0)
    {
        $this->m_FormatCondition->setStopIfTrue($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatCondition.setStyle(Style)]

      @param oStyle0  com.aspose.cells.Style
     */
    function setStyle($oStyle0)
    {
        $this->m_FormatCondition->setStyle(ClassFactory::_t1($oStyle0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatCondition.setText(String)]

      @param oString0  String
     */
    function setText($oString0)
    {
        $this->m_FormatCondition->setText($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatCondition.setTimePeriod(int)]

      @param pInt0  int
     */
    function setTimePeriod($pInt0)
    {
        $this->m_FormatCondition->setTimePeriod($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatCondition.setType(int)]

      @param pInt0  int
     */
    function setType($pInt0)
    {
        $this->m_FormatCondition->setType($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsFormatConditionCollection]
  
 */
class FormatConditionCollection
{
    public $m_FormatConditionCollection;
    
    function __construct($formatConditionCollection)
    {
    	$this->m_FormatConditionCollection = $formatConditionCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsFormatConditionCollection.add(CellArea, int, int, String, String)]

      @param oCellArea0  com.aspose.cells.CellArea
      @param pInt1  int
      @param pInt2  int
      @param oString3  String
      @param oString4  String
      @return int[]
     */
    function add($oCellArea0, $pInt1, $pInt2, $oString3, $oString4)
    {
        return $this->m_FormatConditionCollection->add(ClassFactory::_t1($oCellArea0), $pInt1, $pInt2, $oString3, $oString4);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatConditionCollection.addArea(CellArea)]

      @param oCellArea0  com.aspose.cells.CellArea
      @return int
     */
    function addArea($oCellArea0)
    {
        return $this->m_FormatConditionCollection->addArea(ClassFactory::_t1($oCellArea0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatConditionCollection.addCondition(int, int, String, String)]

      @param pInt0  int
      @param pInt1  int
      @param oString2  String
      @param oString3  String
      @return int
     */
    function addCondition($pInt0, $pInt1, $oString2, $oString3)
    {
        return $this->m_FormatConditionCollection->addCondition($pInt0, $pInt1, $oString2, $oString3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatConditionCollection.addCondtion(int)]

      @param pInt0  int
      @return int
     */
    function addCondtion($pInt0)
    {
        return $this->m_FormatConditionCollection->addCondtion($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatConditionCollection.get(int)]

      @param pInt0  int
      @return com.aspose.cells.FormatCondition
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_FormatConditionCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatConditionCollection.getCellArea(int)]

      @param pInt0  int
      @return com.aspose.cells.CellArea
     */
    function getCellArea($pInt0)
    {
        return ClassFactory::_t2($this->m_FormatConditionCollection->getCellArea($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatConditionCollection.getCount()]

      @return int
     */
    function getCount()
    {
        return $this->m_FormatConditionCollection->getCount();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatConditionCollection.getRangeCount()]

      @return int
     */
    function getRangeCount()
    {
        return $this->m_FormatConditionCollection->getRangeCount();
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatConditionCollection.removeArea(int)]

      @param pInt0  int
     */
    function removeArea($pInt0)
    {
        $this->m_FormatConditionCollection->removeArea($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatConditionCollection.removeArea(int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @return boolean
     */
    function removeAreaIIII($pInt0, $pInt1, $pInt2, $pInt3)
    {
        return $this->m_FormatConditionCollection->removeArea($pInt0, $pInt1, $pInt2, $pInt3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsFormatConditionCollection.removeCondition(int)]

      @param pInt0  int
     */
    function removeCondition($pInt0)
    {
        $this->m_FormatConditionCollection->removeCondition($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsFormatConditionType]
  
 */
class FormatConditionType
{
    public $m_FormatConditionType;
    
    function __construct($formatConditionType)
    {
    	$this->m_FormatConditionType = $formatConditionType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsFormatConditionValueType]
  
 */
class FormatConditionValueType
{
    public $m_FormatConditionValueType;
    
    function __construct($formatConditionValueType)
    {
    	$this->m_FormatConditionValueType = $formatConditionValueType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsFormatSetType]
  
 */
class FormatSetType
{
    public $m_FormatSetType;
    
    function __construct($formatSetType)
    {
    	$this->m_FormatSetType = $formatSetType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsFormattingType]
  
 */
class FormattingType
{
    public $m_FormattingType;
    
    function __construct($formattingType)
    {
    	$this->m_FormattingType = $formattingType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsGlowEffect]
  
 */
class GlowEffect
{
    public $m_GlowEffect;
    
    function __construct($glowEffect)
    {
    	$this->m_GlowEffect = $glowEffect;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsGlowEffect.getCellsColor()]

      @return com.aspose.cells.CellsColor
     */
    function getCellsColor()
    {
        return ClassFactory::_t2($this->m_GlowEffect->getCellsColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsGlowEffect.getRadius()]

      @return double
     */
    function getRadius()
    {
        return $this->m_GlowEffect->getRadius();
    }

    /*
      Wrapper for java version method [com.aspose.cellsGlowEffect.getTransparency()]

      @return double
     */
    function getTransparency()
    {
        return $this->m_GlowEffect->getTransparency();
    }

    /*
      Wrapper for java version method [com.aspose.cellsGlowEffect.setCellsColor(CellsColor)]

      @param oCellsColor0  com.aspose.cells.CellsColor
     */
    function setCellsColor($oCellsColor0)
    {
        $this->m_GlowEffect->setCellsColor(ClassFactory::_t1($oCellsColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsGlowEffect.setRadius(double)]

      @param pDouble0  double
     */
    function setRadius($pDouble0)
    {
        $this->m_GlowEffect->setRadius($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsGlowEffect.setTransparency(double)]

      @param pDouble0  double
     */
    function setTransparency($pDouble0)
    {
        $this->m_GlowEffect->setTransparency($pDouble0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsGradientColorType]
  
 */
class GradientColorType
{
    public $m_GradientColorType;
    
    function __construct($gradientColorType)
    {
    	$this->m_GradientColorType = $gradientColorType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsGradientDirectionType]
  
 */
class GradientDirectionType
{
    public $m_GradientDirectionType;
    
    function __construct($gradientDirectionType)
    {
    	$this->m_GradientDirectionType = $gradientDirectionType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsGradientFill]
  
 */
class GradientFill
{
    public $m_GradientFill;
    
    function __construct($gradientFill)
    {
    	$this->m_GradientFill = $gradientFill;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsGradientFill.getAngle()]

      @return int
     */
    function getAngle()
    {
        return $this->m_GradientFill->getAngle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsGradientFill.getFillType()]

      @return int
     */
    function getFillType()
    {
        return $this->m_GradientFill->getFillType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsGradientFill.getGradientStops()]

      @return com.aspose.cells.GradientStopCollection
     */
    function getGradientStops()
    {
        return ClassFactory::_t2($this->m_GradientFill->getGradientStops());
    }

    /*
      Wrapper for java version method [com.aspose.cellsGradientFill.setAngle(int)]

      @param pInt0  int
     */
    function setAngle($pInt0)
    {
        $this->m_GradientFill->setAngle($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsGradientFill.setGradient(int, double, int)]

      @param pInt0  int
      @param pDouble1  double
      @param pInt2  int
     */
    function setGradient($pInt0, $pDouble1, $pInt2)
    {
        $this->m_GradientFill->setGradient($pInt0, $pDouble1, $pInt2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsGradientFill.setOneColorGradient(Color, double, int, int)]

      @param oColor0  com.aspose.cells.Color
      @param pDouble1  double
      @param pInt2  int
      @param pInt3  int
     */
    function setOneColorGradient($oColor0, $pDouble1, $pInt2, $pInt3)
    {
        $this->m_GradientFill->setOneColorGradient(ClassFactory::_t1($oColor0), $pDouble1, $pInt2, $pInt3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsGradientFill.setTwoColorGradient(Color, Color, int, int)]

      @param oColor0  com.aspose.cells.Color
      @param oColor1  com.aspose.cells.Color
      @param pInt2  int
      @param pInt3  int
     */
    function setTwoColorGradient($oColor0, $oColor1, $pInt2, $pInt3)
    {
        $this->m_GradientFill->setTwoColorGradient(ClassFactory::_t1($oColor0), ClassFactory::_t1($oColor1), $pInt2, $pInt3);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsGradientFillType]
  
 */
class GradientFillType
{
    public $m_GradientFillType;
    
    function __construct($gradientFillType)
    {
    	$this->m_GradientFillType = $gradientFillType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsGradientPresetType]
  
 */
class GradientPresetType
{
    public $m_GradientPresetType;
    
    function __construct($gradientPresetType)
    {
    	$this->m_GradientPresetType = $gradientPresetType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsGradientStop]
  
 */
class GradientStop
{
    public $m_GradientStop;
    
    function __construct($gradientStop)
    {
    	$this->m_GradientStop = $gradientStop;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsGradientStop.getCellsColor()]

      @return com.aspose.cells.CellsColor
     */
    function getCellsColor()
    {
        return ClassFactory::_t2($this->m_GradientStop->getCellsColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsGradientStop.getPosition()]

      @return double
     */
    function getPosition()
    {
        return $this->m_GradientStop->getPosition();
    }

    /*
      Wrapper for java version method [com.aspose.cellsGradientStop.setPosition(double)]

      @param pDouble0  double
     */
    function setPosition($pDouble0)
    {
        $this->m_GradientStop->setPosition($pDouble0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsGradientStopCollection]
  
 */
class GradientStopCollection extends CollectionBase
{
    public $m_GradientStopCollection;
    
    function __construct($gradientStopCollection)
    {
    	$this->m_GradientStopCollection = $gradientStopCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsGradientStopCollection.add(double, CellsColor, int)]

      @param pDouble0  double
      @param oCellsColor1  com.aspose.cells.CellsColor
      @param pInt2  int
     */
    function add($pDouble0, $oCellsColor1, $pInt2)
    {
        $this->m_GradientStopCollection->add($pDouble0, ClassFactory::_t1($oCellsColor1), $pInt2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsGradientStopCollection.get(int)]

      @param pInt0  int
      @return com.aspose.cells.GradientStop
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_GradientStopCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsGradientStopCollection.set(int, GradientStop)]

      @param pInt0  int
      @param oGradientStop1  com.aspose.cells.GradientStop
     */
    function set($pInt0, $oGradientStop1)
    {
        $this->m_GradientStopCollection->set($pInt0, ClassFactory::_t1($oGradientStop1));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsGradientStyleType]
  
 */
class GradientStyleType
{
    public $m_GradientStyleType;
    
    function __construct($gradientStyleType)
    {
    	$this->m_GradientStyleType = $gradientStyleType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsGroupBox]
  
 */
class GroupBox extends Shape
{
    public $m_GroupBox;
    
    function __construct($groupBox)
    {
    	$this->m_GroupBox = $groupBox;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsGroupBox.getShadow()]

      @return boolean
     */
    function getShadow()
    {
        return $this->m_GroupBox->getShadow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsGroupBox.setShadow(boolean)]

      @param pBoolean0  boolean
     */
    function setShadow($pBoolean0)
    {
        $this->m_GroupBox->setShadow($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsGroupShape]
  
 */
class GroupShape extends Shape
{
    public $m_GroupShape;
    
    function __construct($groupShape)
    {
    	$this->m_GroupShape = $groupShape;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsGroupShape.get(int)]

      @param pInt0  int
      @return com.aspose.cells.Shape
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_GroupShape->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsGroupShape.getGroupedShapes()]

      @return com.aspose.cells.Shape[]
     */
    function getGroupedShapes()
    {
        return ClassFactory::_t2($this->m_GroupShape->getGroupedShapes());
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsHorizontalPageBreak]
  
 */
class HorizontalPageBreak
{
    public $m_HorizontalPageBreak;
    
    function __construct($horizontalPageBreak)
    {
    	$this->m_HorizontalPageBreak = $horizontalPageBreak;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsHorizontalPageBreak.getEndColumn()]

      @return int
     */
    function getEndColumn()
    {
        return $this->m_HorizontalPageBreak->getEndColumn();
    }

    /*
      Wrapper for java version method [com.aspose.cellsHorizontalPageBreak.getRow()]

      @return int
     */
    function getRow()
    {
        return $this->m_HorizontalPageBreak->getRow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsHorizontalPageBreak.getStartColumn()]

      @return int
     */
    function getStartColumn()
    {
        return $this->m_HorizontalPageBreak->getStartColumn();
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsHorizontalPageBreakCollection]
  
 */
class HorizontalPageBreakCollection extends CollectionBase
{
    public $m_HorizontalPageBreakCollection;
    
    function __construct($horizontalPageBreakCollection)
    {
    	$this->m_HorizontalPageBreakCollection = $horizontalPageBreakCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsHorizontalPageBreakCollection.add(String)]

      @param oString0  String
      @return int
     */
    function add($oString0)
    {
        return $this->m_HorizontalPageBreakCollection->add($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsHorizontalPageBreakCollection.add(int)]

      @param pInt0  int
      @return int
     */
    function addI($pInt0)
    {
        return $this->m_HorizontalPageBreakCollection->add($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsHorizontalPageBreakCollection.add(int, int)]

      @param pInt0  int
      @param pInt1  int
      @return int
     */
    function addII($pInt0, $pInt1)
    {
        return $this->m_HorizontalPageBreakCollection->add($pInt0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsHorizontalPageBreakCollection.add(int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @return int
     */
    function addIII($pInt0, $pInt1, $pInt2)
    {
        return $this->m_HorizontalPageBreakCollection->add($pInt0, $pInt1, $pInt2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsHorizontalPageBreakCollection.get(String)]

      @param oString0  String
      @return com.aspose.cells.HorizontalPageBreak
     */
    function get($oString0)
    {
        return ClassFactory::_t2($this->m_HorizontalPageBreakCollection->get($oString0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsHorizontalPageBreakCollection.get(int)]

      @param pInt0  int
      @return com.aspose.cells.HorizontalPageBreak
     */
    function getI($pInt0)
    {
        return ClassFactory::_t2($this->m_HorizontalPageBreakCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsHorizontalPageBreakCollection.removeAt(int)]

      @param pInt0  int
     */
    function removeAt($pInt0)
    {
        $this->m_HorizontalPageBreakCollection->removeAt($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsHtmlSaveOptions]
  
 */
class HtmlSaveOptions extends SaveOptions
{
    public $m_HtmlSaveOptions;
    
    function __construct($htmlSaveOptions)
    {
    	$this->m_HtmlSaveOptions = $htmlSaveOptions;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsHtmlSaveOptions.getAttachedFilesDirectory()]

      @return String
     */
    function getAttachedFilesDirectory()
    {
        return $this->m_HtmlSaveOptions->getAttachedFilesDirectory();
    }

    /*
      Wrapper for java version method [com.aspose.cellsHtmlSaveOptions.getAttachedFilesUrlPrefix()]

      @return String
     */
    function getAttachedFilesUrlPrefix()
    {
        return $this->m_HtmlSaveOptions->getAttachedFilesUrlPrefix();
    }

    /*
      Wrapper for java version method [com.aspose.cellsHtmlSaveOptions.getDisplayHTMLCrossString()]

      @return boolean
     */
    function getDisplayHTMLCrossString()
    {
        return $this->m_HtmlSaveOptions->getDisplayHTMLCrossString();
    }

    /*
      Wrapper for java version method [com.aspose.cellsHtmlSaveOptions.getExportActiveWorksheetOnly()]

      @return boolean
     */
    function getExportActiveWorksheetOnly()
    {
        return $this->m_HtmlSaveOptions->getExportActiveWorksheetOnly();
    }

    /*
      Wrapper for java version method [com.aspose.cellsHtmlSaveOptions.getPageTitle()]

      @return String
     */
    function getPageTitle()
    {
        return $this->m_HtmlSaveOptions->getPageTitle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsHtmlSaveOptions.isExpImageToTempDir()]

      @return boolean
     */
    function isExpImageToTempDir()
    {
        return $this->m_HtmlSaveOptions->isExpImageToTempDir();
    }

    /*
      Wrapper for java version method [com.aspose.cellsHtmlSaveOptions.setAttachedFilesDirectory(String)]

      @param oString0  String
     */
    function setAttachedFilesDirectory($oString0)
    {
        $this->m_HtmlSaveOptions->setAttachedFilesDirectory($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsHtmlSaveOptions.setAttachedFilesUrlPrefix(String)]

      @param oString0  String
     */
    function setAttachedFilesUrlPrefix($oString0)
    {
        $this->m_HtmlSaveOptions->setAttachedFilesUrlPrefix($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsHtmlSaveOptions.setDisplayHTMLCrossString(boolean)]

      @param pBoolean0  boolean
     */
    function setDisplayHTMLCrossString($pBoolean0)
    {
        $this->m_HtmlSaveOptions->setDisplayHTMLCrossString($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsHtmlSaveOptions.setExpImageToTempDir(boolean)]

      @param pBoolean0  boolean
     */
    function setExpImageToTempDir($pBoolean0)
    {
        $this->m_HtmlSaveOptions->setExpImageToTempDir($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsHtmlSaveOptions.setExportActiveWorksheetOnly(boolean)]

      @param pBoolean0  boolean
     */
    function setExportActiveWorksheetOnly($pBoolean0)
    {
        $this->m_HtmlSaveOptions->setExportActiveWorksheetOnly($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsHtmlSaveOptions.setPageTitle(String)]

      @param oString0  String
     */
    function setPageTitle($oString0)
    {
        $this->m_HtmlSaveOptions->setPageTitle($oString0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsHyperlink]
  
 */
class Hyperlink
{
    public $m_Hyperlink;
    
    function __construct($hyperlink)
    {
    	$this->m_Hyperlink = $hyperlink;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsHyperlink.getAddress()]

      @return String
     */
    function getAddress()
    {
        return $this->m_Hyperlink->getAddress();
    }

    /*
      Wrapper for java version method [com.aspose.cellsHyperlink.getArea()]

      @return com.aspose.cells.CellArea
     */
    function getArea()
    {
        return ClassFactory::_t2($this->m_Hyperlink->getArea());
    }

    /*
      Wrapper for java version method [com.aspose.cellsHyperlink.getScreenTip()]

      @return String
     */
    function getScreenTip()
    {
        return $this->m_Hyperlink->getScreenTip();
    }

    /*
      Wrapper for java version method [com.aspose.cellsHyperlink.getTextToDisplay()]

      @return String
     */
    function getTextToDisplay()
    {
        return $this->m_Hyperlink->getTextToDisplay();
    }

    /*
      Wrapper for java version method [com.aspose.cellsHyperlink.setAddress(String)]

      @param oString0  String
     */
    function setAddress($oString0)
    {
        $this->m_Hyperlink->setAddress($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsHyperlink.setScreenTip(String)]

      @param oString0  String
     */
    function setScreenTip($oString0)
    {
        $this->m_Hyperlink->setScreenTip($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsHyperlink.setTextToDisplay(String)]

      @param oString0  String
     */
    function setTextToDisplay($oString0)
    {
        $this->m_Hyperlink->setTextToDisplay($oString0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsHyperlinkCollection]
  
 */
class HyperlinkCollection extends CollectionBase
{
    public $m_HyperlinkCollection;
    
    function __construct($hyperlinkCollection)
    {
    	$this->m_HyperlinkCollection = $hyperlinkCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsHyperlinkCollection.add(String, int, int, String)]

      @param oString0  String
      @param pInt1  int
      @param pInt2  int
      @param oString3  String
      @return int
     */
    function add($oString0, $pInt1, $pInt2, $oString3)
    {
        return $this->m_HyperlinkCollection->add($oString0, $pInt1, $pInt2, $oString3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsHyperlinkCollection.add(String, String, String, String, String)]

      @param oString0  String
      @param oString1  String
      @param oString2  String
      @param oString3  String
      @param oString4  String
      @return int
     */
    function addSSSSS($oString0, $oString1, $oString2, $oString3, $oString4)
    {
        return $this->m_HyperlinkCollection->add($oString0, $oString1, $oString2, $oString3, $oString4);
    }

    /*
      Wrapper for java version method [com.aspose.cellsHyperlinkCollection.add(int, int, int, int, String)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @param oString4  String
      @return int
     */
    function addIIIIS($pInt0, $pInt1, $pInt2, $pInt3, $oString4)
    {
        return $this->m_HyperlinkCollection->add($pInt0, $pInt1, $pInt2, $pInt3, $oString4);
    }

    /*
      Wrapper for java version method [com.aspose.cellsHyperlinkCollection.clear()]

     */
    function clear()
    {
        $this->m_HyperlinkCollection->clear();
    }

    /*
      Wrapper for java version method [com.aspose.cellsHyperlinkCollection.get(int)]

      @param pInt0  int
      @return com.aspose.cells.Hyperlink
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_HyperlinkCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsHyperlinkCollection.removeAt(int)]

      @param pInt0  int
     */
    function removeAt($pInt0)
    {
        $this->m_HyperlinkCollection->removeAt($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsIconFilter]
  
 */
class IconFilter
{
    public $m_IconFilter;
    
    function __construct($iconFilter)
    {
    	$this->m_IconFilter = $iconFilter;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsIconFilter.getIconId()]

      @return int
     */
    function getIconId()
    {
        return $this->m_IconFilter->getIconId();
    }

    /*
      Wrapper for java version method [com.aspose.cellsIconFilter.getIconSetType()]

      @return int
     */
    function getIconSetType()
    {
        return $this->m_IconFilter->getIconSetType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsIconFilter.setIconId(int)]

      @param pInt0  int
     */
    function setIconId($pInt0)
    {
        $this->m_IconFilter->setIconId($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsIconFilter.setIconSetType(int)]

      @param pInt0  int
     */
    function setIconSetType($pInt0)
    {
        $this->m_IconFilter->setIconSetType($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsIconSet]
  
 */
class IconSet
{
    public $m_IconSet;
    
    function __construct($iconSet)
    {
    	$this->m_IconSet = $iconSet;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsIconSet.getCfvos()]

      @return com.aspose.cells.ConditionalFormattingValueCollection
     */
    function getCfvos()
    {
        return ClassFactory::_t2($this->m_IconSet->getCfvos());
    }

    /*
      Wrapper for java version method [com.aspose.cellsIconSet.getReverse()]

      @return boolean
     */
    function getReverse()
    {
        return $this->m_IconSet->getReverse();
    }

    /*
      Wrapper for java version method [com.aspose.cellsIconSet.getShowValue()]

      @return boolean
     */
    function getShowValue()
    {
        return $this->m_IconSet->getShowValue();
    }

    /*
      Wrapper for java version method [com.aspose.cellsIconSet.getType()]

      @return int
     */
    function getType()
    {
        return $this->m_IconSet->getType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsIconSet.setReverse(boolean)]

      @param pBoolean0  boolean
     */
    function setReverse($pBoolean0)
    {
        $this->m_IconSet->setReverse($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsIconSet.setShowValue(boolean)]

      @param pBoolean0  boolean
     */
    function setShowValue($pBoolean0)
    {
        $this->m_IconSet->setShowValue($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsIconSet.setType(int)]

      @param pInt0  int
     */
    function setType($pInt0)
    {
        $this->m_IconSet->setType($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsIconSetType]
  
 */
class IconSetType
{
    public $m_IconSetType;
    
    function __construct($iconSetType)
    {
    	$this->m_IconSetType = $iconSetType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsICustomFunction]
  
 */
class ICustomFunction
{
    public $m_ICustomFunction;
    
    function __construct($iCustomFunction)
    {
    	$this->m_ICustomFunction = $iCustomFunction;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsICustomFunction.calculateCustomFunction(String, ArrayList, ArrayList)]

      @param oString0  String
      @param arrA1DFromArrayList1  array, corresponding java type is {java.util.ArrayList}
      @param arrA1DFromArrayList2  array, corresponding java type is {java.util.ArrayList}
      @return corresponding java type is {java.lang.Object}
     */
    function calculateCustomFunction($oString0, $arrA1DFromArrayList1, $arrA1DFromArrayList2)
    {
        return ClassFactory::_t2($this->m_ICustomFunction->calculateCustomFunction($oString0, ClassFactory::_t1($arrA1DFromArrayList1), ClassFactory::_t1($arrA1DFromArrayList2)));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsImageFormat]
  
 */
class ImageFormat
{
    public $m_ImageFormat;
    
    function __construct($imageFormat)
    {
    	$this->m_ImageFormat = $imageFormat;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsImageFormat.equals(Object)]

      @param oObject0  corresponding java type is {java.lang.Object}
      @return boolean
     */
    function equals($oObject0)
    {
        return $this->m_ImageFormat->equals(ClassFactory::_t1($oObject0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageFormat.getBmp()]

      @return com.aspose.cells.ImageFormat
     */
    function getBmp()
    {
        return ClassFactory::_t2($this->m_ImageFormat->getBmp());
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageFormat.getEmf()]

      @return com.aspose.cells.ImageFormat
     */
    function getEmf()
    {
        return ClassFactory::_t2($this->m_ImageFormat->getEmf());
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageFormat.getExif()]

      @return com.aspose.cells.ImageFormat
     */
    function getExif()
    {
        return ClassFactory::_t2($this->m_ImageFormat->getExif());
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageFormat.getGif()]

      @return com.aspose.cells.ImageFormat
     */
    function getGif()
    {
        return ClassFactory::_t2($this->m_ImageFormat->getGif());
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageFormat.getIcon()]

      @return com.aspose.cells.ImageFormat
     */
    function getIcon()
    {
        return ClassFactory::_t2($this->m_ImageFormat->getIcon());
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageFormat.getImageFormatFromSuffixName(String)]

      @param oString0  String
      @return com.aspose.cells.ImageFormat
     */
    function getImageFormatFromSuffixName($oString0)
    {
        return ClassFactory::_t2($this->m_ImageFormat->getImageFormatFromSuffixName($oString0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageFormat.getJpeg()]

      @return com.aspose.cells.ImageFormat
     */
    function getJpeg()
    {
        return ClassFactory::_t2($this->m_ImageFormat->getJpeg());
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageFormat.getMemoryBmp()]

      @return com.aspose.cells.ImageFormat
     */
    function getMemoryBmp()
    {
        return ClassFactory::_t2($this->m_ImageFormat->getMemoryBmp());
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageFormat.getName()]

      @return String
     */
    function getName()
    {
        return $this->m_ImageFormat->getName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageFormat.getPng()]

      @return com.aspose.cells.ImageFormat
     */
    function getPng()
    {
        return ClassFactory::_t2($this->m_ImageFormat->getPng());
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageFormat.getTiff()]

      @return com.aspose.cells.ImageFormat
     */
    function getTiff()
    {
        return ClassFactory::_t2($this->m_ImageFormat->getTiff());
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageFormat.getWmf()]

      @return com.aspose.cells.ImageFormat
     */
    function getWmf()
    {
        return ClassFactory::_t2($this->m_ImageFormat->getWmf());
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsImageOrPrintOptions]
  
 */
class ImageOrPrintOptions
{
    public $m_ImageOrPrintOptions;
    
    function __construct($imageOrPrintOptions)
    {
    	$this->m_ImageOrPrintOptions = $imageOrPrintOptions;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsImageOrPrintOptions.getHorizontalResolution()]

      @return int
     */
    function getHorizontalResolution()
    {
        return $this->m_ImageOrPrintOptions->getHorizontalResolution();
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageOrPrintOptions.getImageFormat()]

      @return com.aspose.cells.ImageFormat
     */
    function getImageFormat()
    {
        return ClassFactory::_t2($this->m_ImageOrPrintOptions->getImageFormat());
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageOrPrintOptions.getOnePagePerSheet()]

      @return boolean
     */
    function getOnePagePerSheet()
    {
        return $this->m_ImageOrPrintOptions->getOnePagePerSheet();
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageOrPrintOptions.getPrintWithStatusDialog()]

      @return boolean
     */
    function getPrintWithStatusDialog()
    {
        return $this->m_ImageOrPrintOptions->getPrintWithStatusDialog();
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageOrPrintOptions.getPrintingPage()]

      @return int
     */
    function getPrintingPage()
    {
        return $this->m_ImageOrPrintOptions->getPrintingPage();
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageOrPrintOptions.getQuality()]

      @return int
     */
    function getQuality()
    {
        return $this->m_ImageOrPrintOptions->getQuality();
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageOrPrintOptions.getSaveFormat()]

      @return int
     */
    function getSaveFormat()
    {
        return $this->m_ImageOrPrintOptions->getSaveFormat();
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageOrPrintOptions.getTiffCompression()]

      @return int
     */
    function getTiffCompression()
    {
        return $this->m_ImageOrPrintOptions->getTiffCompression();
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageOrPrintOptions.getVerticalResolution()]

      @return int
     */
    function getVerticalResolution()
    {
        return $this->m_ImageOrPrintOptions->getVerticalResolution();
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageOrPrintOptions.isCellAutoFit()]

      @return boolean
     */
    function isCellAutoFit()
    {
        return $this->m_ImageOrPrintOptions->isCellAutoFit();
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageOrPrintOptions.isImageFitToPage()]

      @return boolean
     */
    function isImageFitToPage()
    {
        return $this->m_ImageOrPrintOptions->isImageFitToPage();
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageOrPrintOptions.setCellAutoFit(boolean)]

      @param pBoolean0  boolean
     */
    function setCellAutoFit($pBoolean0)
    {
        $this->m_ImageOrPrintOptions->setCellAutoFit($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageOrPrintOptions.setHorizontalResolution(int)]

      @param pInt0  int
     */
    function setHorizontalResolution($pInt0)
    {
        $this->m_ImageOrPrintOptions->setHorizontalResolution($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageOrPrintOptions.setImageFitToPage(boolean)]

      @param pBoolean0  boolean
     */
    function setImageFitToPage($pBoolean0)
    {
        $this->m_ImageOrPrintOptions->setImageFitToPage($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageOrPrintOptions.setImageFormat(ImageFormat)]

      @param oImageFormat0  com.aspose.cells.ImageFormat
     */
    function setImageFormat($oImageFormat0)
    {
        $this->m_ImageOrPrintOptions->setImageFormat(ClassFactory::_t1($oImageFormat0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageOrPrintOptions.setOnePagePerSheet(boolean)]

      @param pBoolean0  boolean
     */
    function setOnePagePerSheet($pBoolean0)
    {
        $this->m_ImageOrPrintOptions->setOnePagePerSheet($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageOrPrintOptions.setPrintWithStatusDialog(boolean)]

      @param pBoolean0  boolean
     */
    function setPrintWithStatusDialog($pBoolean0)
    {
        $this->m_ImageOrPrintOptions->setPrintWithStatusDialog($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageOrPrintOptions.setPrintingPage(int)]

      @param pInt0  int
     */
    function setPrintingPage($pInt0)
    {
        $this->m_ImageOrPrintOptions->setPrintingPage($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageOrPrintOptions.setQuality(int)]

      @param pInt0  int
     */
    function setQuality($pInt0)
    {
        $this->m_ImageOrPrintOptions->setQuality($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageOrPrintOptions.setSaveFormat(int)]

      @param pInt0  int
     */
    function setSaveFormat($pInt0)
    {
        $this->m_ImageOrPrintOptions->setSaveFormat($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageOrPrintOptions.setTiffCompression(int)]

      @param pInt0  int
     */
    function setTiffCompression($pInt0)
    {
        $this->m_ImageOrPrintOptions->setTiffCompression($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsImageOrPrintOptions.setVerticalResolution(int)]

      @param pInt0  int
     */
    function setVerticalResolution($pInt0)
    {
        $this->m_ImageOrPrintOptions->setVerticalResolution($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsInterruptMonitor]
  
 */
class InterruptMonitor
{
    public $m_InterruptMonitor;
    
    function __construct($interruptMonitor)
    {
    	$this->m_InterruptMonitor = $interruptMonitor;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsInterruptMonitor.interrupt()]

     */
    function interrupt()
    {
        $this->m_InterruptMonitor->interrupt();
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsLabel]
  
 */
class Label extends Shape
{
    public $m_Label;
    
    function __construct($label)
    {
    	$this->m_Label = $label;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsLabelPositionType]
  
 */
class LabelPositionType
{
    public $m_LabelPositionType;
    
    function __construct($labelPositionType)
    {
    	$this->m_LabelPositionType = $labelPositionType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsLegend]
  
 */
class Legend extends ChartFrame
{
    public $m_Legend;
    
    function __construct($legend)
    {
    	$this->m_Legend = $legend;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsLegend.getLegendEntries()]

      @return com.aspose.cells.LegendEntryCollection
     */
    function getLegendEntries()
    {
        return ClassFactory::_t2($this->m_Legend->getLegendEntries());
    }

    /*
      Wrapper for java version method [com.aspose.cellsLegend.getPosition()]

      @return int
     */
    function getPosition()
    {
        return $this->m_Legend->getPosition();
    }

    /*
      Wrapper for java version method [com.aspose.cellsLegend.setPosition(int)]

      @param pInt0  int
     */
    function setPosition($pInt0)
    {
        $this->m_Legend->setPosition($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsLegendEntry]
  
 */
class LegendEntry
{
    public $m_LegendEntry;
    
    function __construct($legendEntry)
    {
    	$this->m_LegendEntry = $legendEntry;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsLegendEntry.getAutoScaleFont()]

      @return boolean
     */
    function getAutoScaleFont()
    {
        return $this->m_LegendEntry->getAutoScaleFont();
    }

    /*
      Wrapper for java version method [com.aspose.cellsLegendEntry.getBackground()]

      @return int
     */
    function getBackground()
    {
        return $this->m_LegendEntry->getBackground();
    }

    /*
      Wrapper for java version method [com.aspose.cellsLegendEntry.getBackgroundMode()]

      @return int
     */
    function getBackgroundMode()
    {
        return $this->m_LegendEntry->getBackgroundMode();
    }

    /*
      Wrapper for java version method [com.aspose.cellsLegendEntry.getTextFont()]

      @return com.aspose.cells.Font
     */
    function getTextFont()
    {
        return ClassFactory::_t2($this->m_LegendEntry->getTextFont());
    }

    /*
      Wrapper for java version method [com.aspose.cellsLegendEntry.isDeleted()]

      @return boolean
     */
    function isDeleted()
    {
        return $this->m_LegendEntry->isDeleted();
    }

    /*
      Wrapper for java version method [com.aspose.cellsLegendEntry.setAutoScaleFont(boolean)]

      @param pBoolean0  boolean
     */
    function setAutoScaleFont($pBoolean0)
    {
        $this->m_LegendEntry->setAutoScaleFont($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsLegendEntry.setBackground(int)]

      @param pInt0  int
     */
    function setBackground($pInt0)
    {
        $this->m_LegendEntry->setBackground($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsLegendEntry.setBackgroundMode(int)]

      @param pInt0  int
     */
    function setBackgroundMode($pInt0)
    {
        $this->m_LegendEntry->setBackgroundMode($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsLegendEntry.setDeleted(boolean)]

      @param pBoolean0  boolean
     */
    function setDeleted($pBoolean0)
    {
        $this->m_LegendEntry->setDeleted($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsLegendEntryCollection]
  
 */
class LegendEntryCollection extends CollectionBase
{
    public $m_LegendEntryCollection;
    
    function __construct($legendEntryCollection)
    {
    	$this->m_LegendEntryCollection = $legendEntryCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsLegendEntryCollection.get(int)]

      @param pInt0  int
      @return corresponding java type is {java.lang.Object}
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_LegendEntryCollection->get($pInt0));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsLegendPositionType]
  
 */
class LegendPositionType
{
    public $m_LegendPositionType;
    
    function __construct($legendPositionType)
    {
    	$this->m_LegendPositionType = $legendPositionType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsLicense]
  
 */
class License
{
    public $m_License;
    
    function __construct($license)
    {
    	$this->m_License = $license;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsLicense.getSubscriptionExpireDate()]

      @return corresponding java type is {java.util.Date}
     */
    function getSubscriptionExpireDate()
    {
        return ClassFactory::_t2($this->m_License->getSubscriptionExpireDate());
    }

    /*
      Wrapper for java version method [com.aspose.cellsLicense.isLicenseSet()]

      @return boolean
     */
    function isLicenseSet()
    {
        return $this->m_License->isLicenseSet();
    }

    /*
      Wrapper for java version method [com.aspose.cellsLicense.setLicense(InputStream)]

      @param oInputStream0  corresponding java type is {java.io.InputStream}
     */
    function setLicense($oInputStream0)
    {
        $this->m_License->setLicense(ClassFactory::_t1($oInputStream0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsLicense.setLicense(Reader)]

      @param oReader0  corresponding java type is {java.io.Reader}
     */
    function setLicenseR($oReader0)
    {
        $this->m_License->setLicense(ClassFactory::_t1($oReader0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsLicense.setLicense(String)]

      @param oString0  String
     */
    function setLicenseS($oString0)
    {
        $this->m_License->setLicense($oString0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsLightRigType]
  
 */
class LightRigType
{
    public $m_LightRigType;
    
    function __construct($lightRigType)
    {
    	$this->m_LightRigType = $lightRigType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsLine]
  
 */
class Line
{
    public $m_Line;
    
    function __construct($line)
    {
    	$this->m_Line = $line;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsLine.getColor()]

      @return com.aspose.cells.Color
     */
    function getColor()
    {
        return ClassFactory::_t2($this->m_Line->getColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsLine.getStyle()]

      @return int
     */
    function getStyle()
    {
        return $this->m_Line->getStyle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsLine.getTransparency()]

      @return double
     */
    function getTransparency()
    {
        return $this->m_Line->getTransparency();
    }

    /*
      Wrapper for java version method [com.aspose.cellsLine.getWeight()]

      @return int
     */
    function getWeight()
    {
        return $this->m_Line->getWeight();
    }

    /*
      Wrapper for java version method [com.aspose.cellsLine.getWeightPt()]

      @return double
     */
    function getWeightPt()
    {
        return $this->m_Line->getWeightPt();
    }

    /*
      Wrapper for java version method [com.aspose.cellsLine.isAuto()]

      @return boolean
     */
    function isAuto()
    {
        return $this->m_Line->isAuto();
    }

    /*
      Wrapper for java version method [com.aspose.cellsLine.isAutomaticColor()]

      @return boolean
     */
    function isAutomaticColor()
    {
        return $this->m_Line->isAutomaticColor();
    }

    /*
      Wrapper for java version method [com.aspose.cellsLine.isVisible()]

      @return boolean
     */
    function isVisible()
    {
        return $this->m_Line->isVisible();
    }

    /*
      Wrapper for java version method [com.aspose.cellsLine.setAuto(boolean)]

      @param pBoolean0  boolean
     */
    function setAuto($pBoolean0)
    {
        $this->m_Line->setAuto($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsLine.setColor(Color)]

      @param oColor0  com.aspose.cells.Color
     */
    function setColor($oColor0)
    {
        $this->m_Line->setColor(ClassFactory::_t1($oColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsLine.setStyle(int)]

      @param pInt0  int
     */
    function setStyle($pInt0)
    {
        $this->m_Line->setStyle($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsLine.setTransparency(double)]

      @param pDouble0  double
     */
    function setTransparency($pDouble0)
    {
        $this->m_Line->setTransparency($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsLine.setVisible(boolean)]

      @param pBoolean0  boolean
     */
    function setVisible($pBoolean0)
    {
        $this->m_Line->setVisible($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsLine.setWeight(int)]

      @param pInt0  int
     */
    function setWeight($pInt0)
    {
        $this->m_Line->setWeight($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsLine.setWeightPt(double)]

      @param pDouble0  double
     */
    function setWeightPt($pDouble0)
    {
        $this->m_Line->setWeightPt($pDouble0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsLineShape]
  
 */
class LineShape extends Shape
{
    public $m_LineShape;
    
    function __construct($lineShape)
    {
    	$this->m_LineShape = $lineShape;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsLineShape.getBeginArrowheadLength()]

      @return int
     */
    function getBeginArrowheadLength()
    {
        return $this->m_LineShape->getBeginArrowheadLength();
    }

    /*
      Wrapper for java version method [com.aspose.cellsLineShape.getBeginArrowheadStyle()]

      @return int
     */
    function getBeginArrowheadStyle()
    {
        return $this->m_LineShape->getBeginArrowheadStyle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsLineShape.getBeginArrowheadWidth()]

      @return int
     */
    function getBeginArrowheadWidth()
    {
        return $this->m_LineShape->getBeginArrowheadWidth();
    }

    /*
      Wrapper for java version method [com.aspose.cellsLineShape.getEndArrowheadLength()]

      @return int
     */
    function getEndArrowheadLength()
    {
        return $this->m_LineShape->getEndArrowheadLength();
    }

    /*
      Wrapper for java version method [com.aspose.cellsLineShape.getEndArrowheadStyle()]

      @return int
     */
    function getEndArrowheadStyle()
    {
        return $this->m_LineShape->getEndArrowheadStyle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsLineShape.getEndArrowheadWidth()]

      @return int
     */
    function getEndArrowheadWidth()
    {
        return $this->m_LineShape->getEndArrowheadWidth();
    }

    /*
      Wrapper for java version method [com.aspose.cellsLineShape.setBeginArrowheadLength(int)]

      @param pInt0  int
     */
    function setBeginArrowheadLength($pInt0)
    {
        $this->m_LineShape->setBeginArrowheadLength($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsLineShape.setBeginArrowheadStyle(int)]

      @param pInt0  int
     */
    function setBeginArrowheadStyle($pInt0)
    {
        $this->m_LineShape->setBeginArrowheadStyle($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsLineShape.setBeginArrowheadWidth(int)]

      @param pInt0  int
     */
    function setBeginArrowheadWidth($pInt0)
    {
        $this->m_LineShape->setBeginArrowheadWidth($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsLineShape.setEndArrowheadLength(int)]

      @param pInt0  int
     */
    function setEndArrowheadLength($pInt0)
    {
        $this->m_LineShape->setEndArrowheadLength($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsLineShape.setEndArrowheadStyle(int)]

      @param pInt0  int
     */
    function setEndArrowheadStyle($pInt0)
    {
        $this->m_LineShape->setEndArrowheadStyle($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsLineShape.setEndArrowheadWidth(int)]

      @param pInt0  int
     */
    function setEndArrowheadWidth($pInt0)
    {
        $this->m_LineShape->setEndArrowheadWidth($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsLineType]
  
 */
class LineType
{
    public $m_LineType;
    
    function __construct($lineType)
    {
    	$this->m_LineType = $lineType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsListBox]
  
 */
class ListBox extends Shape
{
    public $m_ListBox;
    
    function __construct($listBox)
    {
    	$this->m_ListBox = $listBox;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsListBox.getInputRange()]

      @return String
     */
    function getInputRange()
    {
        return $this->m_ListBox->getInputRange();
    }

    /*
      Wrapper for java version method [com.aspose.cellsListBox.getItemCount()]

      @return int
     */
    function getItemCount()
    {
        return $this->m_ListBox->getItemCount();
    }

    /*
      Wrapper for java version method [com.aspose.cellsListBox.getSelectedCells()]

      @return com.aspose.cells.Cell[]
     */
    function getSelectedCells()
    {
        return ClassFactory::_t2($this->m_ListBox->getSelectedCells());
    }

    /*
      Wrapper for java version method [com.aspose.cellsListBox.getSelectedIndex()]

      @return int
     */
    function getSelectedIndex()
    {
        return $this->m_ListBox->getSelectedIndex();
    }

    /*
      Wrapper for java version method [com.aspose.cellsListBox.getSelectionType()]

      @return int
     */
    function getSelectionType()
    {
        return $this->m_ListBox->getSelectionType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsListBox.getShadow()]

      @return boolean
     */
    function getShadow()
    {
        return $this->m_ListBox->getShadow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsListBox.isSelected(int)]

      @param pInt0  int
      @return boolean
     */
    function isSelected($pInt0)
    {
        return $this->m_ListBox->isSelected($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsListBox.selectedItem(int, boolean)]

      @param pInt0  int
      @param pBoolean1  boolean
     */
    function selectedItem($pInt0, $pBoolean1)
    {
        $this->m_ListBox->selectedItem($pInt0, $pBoolean1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsListBox.setInputRange(String)]

      @param oString0  String
     */
    function setInputRange($oString0)
    {
        $this->m_ListBox->setInputRange($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsListBox.setSelectedIndex(int)]

      @param pInt0  int
     */
    function setSelectedIndex($pInt0)
    {
        $this->m_ListBox->setSelectedIndex($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsListBox.setSelectionType(int)]

      @param pInt0  int
     */
    function setSelectionType($pInt0)
    {
        $this->m_ListBox->setSelectionType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsListBox.setShadow(boolean)]

      @param pBoolean0  boolean
     */
    function setShadow($pBoolean0)
    {
        $this->m_ListBox->setShadow($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsListColumn]
  
 */
class ListColumn
{
    public $m_ListColumn;
    
    function __construct($listColumn)
    {
    	$this->m_ListColumn = $listColumn;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsListColumn.getName()]

      @return String
     */
    function getName()
    {
        return $this->m_ListColumn->getName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsListColumn.getRange()]

      @return com.aspose.cells.Range
     */
    function getRange()
    {
        return ClassFactory::_t2($this->m_ListColumn->getRange());
    }

    /*
      Wrapper for java version method [com.aspose.cellsListColumn.getTotalsCalculation()]

      @return int
     */
    function getTotalsCalculation()
    {
        return $this->m_ListColumn->getTotalsCalculation();
    }

    /*
      Wrapper for java version method [com.aspose.cellsListColumn.setName(String)]

      @param oString0  String
     */
    function setName($oString0)
    {
        $this->m_ListColumn->setName($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsListColumn.setTotalsCalculation(int)]

      @param pInt0  int
     */
    function setTotalsCalculation($pInt0)
    {
        $this->m_ListColumn->setTotalsCalculation($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsListColumnCollection]
  
 */
class ListColumnCollection extends CollectionBase
{
    public $m_ListColumnCollection;
    
    function __construct($listColumnCollection)
    {
    	$this->m_ListColumnCollection = $listColumnCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsListColumnCollection.get(String)]

      @param oString0  String
      @return com.aspose.cells.ListColumn
     */
    function get($oString0)
    {
        return ClassFactory::_t2($this->m_ListColumnCollection->get($oString0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsListColumnCollection.get(int)]

      @param pInt0  int
      @return com.aspose.cells.ListColumn
     */
    function getI($pInt0)
    {
        return ClassFactory::_t2($this->m_ListColumnCollection->get($pInt0));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsListObject]
  
 */
class ListObject
{
    public $m_ListObject;
    
    function __construct($listObject)
    {
    	$this->m_ListObject = $listObject;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsListObject.getAutoFilter()]

      @return com.aspose.cells.AutoFilter
     */
    function getAutoFilter()
    {
        return ClassFactory::_t2($this->m_ListObject->getAutoFilter());
    }

    /*
      Wrapper for java version method [com.aspose.cellsListObject.getDataRange()]

      @return com.aspose.cells.Range
     */
    function getDataRange()
    {
        return ClassFactory::_t2($this->m_ListObject->getDataRange());
    }

    /*
      Wrapper for java version method [com.aspose.cellsListObject.getDisplayName()]

      @return String
     */
    function getDisplayName()
    {
        return $this->m_ListObject->getDisplayName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsListObject.getEndColumn()]

      @return int
     */
    function getEndColumn()
    {
        return $this->m_ListObject->getEndColumn();
    }

    /*
      Wrapper for java version method [com.aspose.cellsListObject.getEndRow()]

      @return int
     */
    function getEndRow()
    {
        return $this->m_ListObject->getEndRow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsListObject.getListColumns()]

      @return com.aspose.cells.ListColumnCollection
     */
    function getListColumns()
    {
        return ClassFactory::_t2($this->m_ListObject->getListColumns());
    }

    /*
      Wrapper for java version method [com.aspose.cellsListObject.getShowHeaderRow()]

      @return boolean
     */
    function getShowHeaderRow()
    {
        return $this->m_ListObject->getShowHeaderRow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsListObject.getShowTableStyleColumnStripes()]

      @return boolean
     */
    function getShowTableStyleColumnStripes()
    {
        return $this->m_ListObject->getShowTableStyleColumnStripes();
    }

    /*
      Wrapper for java version method [com.aspose.cellsListObject.getShowTableStyleFirstColumn()]

      @return boolean
     */
    function getShowTableStyleFirstColumn()
    {
        return $this->m_ListObject->getShowTableStyleFirstColumn();
    }

    /*
      Wrapper for java version method [com.aspose.cellsListObject.getShowTableStyleLastColumn()]

      @return boolean
     */
    function getShowTableStyleLastColumn()
    {
        return $this->m_ListObject->getShowTableStyleLastColumn();
    }

    /*
      Wrapper for java version method [com.aspose.cellsListObject.getShowTableStyleRowStripes()]

      @return boolean
     */
    function getShowTableStyleRowStripes()
    {
        return $this->m_ListObject->getShowTableStyleRowStripes();
    }

    /*
      Wrapper for java version method [com.aspose.cellsListObject.getShowTotals()]

      @return boolean
     */
    function getShowTotals()
    {
        return $this->m_ListObject->getShowTotals();
    }

    /*
      Wrapper for java version method [com.aspose.cellsListObject.getStartColumn()]

      @return int
     */
    function getStartColumn()
    {
        return $this->m_ListObject->getStartColumn();
    }

    /*
      Wrapper for java version method [com.aspose.cellsListObject.getStartRow()]

      @return int
     */
    function getStartRow()
    {
        return $this->m_ListObject->getStartRow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsListObject.getTableStyleName()]

      @return String
     */
    function getTableStyleName()
    {
        return $this->m_ListObject->getTableStyleName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsListObject.getTableStyleType()]

      @return int
     */
    function getTableStyleType()
    {
        return $this->m_ListObject->getTableStyleType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsListObject.setDisplayName(String)]

      @param oString0  String
     */
    function setDisplayName($oString0)
    {
        $this->m_ListObject->setDisplayName($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsListObject.setShowHeaderRow(boolean)]

      @param pBoolean0  boolean
     */
    function setShowHeaderRow($pBoolean0)
    {
        $this->m_ListObject->setShowHeaderRow($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsListObject.setShowTableStyleColumnStripes(boolean)]

      @param pBoolean0  boolean
     */
    function setShowTableStyleColumnStripes($pBoolean0)
    {
        $this->m_ListObject->setShowTableStyleColumnStripes($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsListObject.setShowTableStyleFirstColumn(boolean)]

      @param pBoolean0  boolean
     */
    function setShowTableStyleFirstColumn($pBoolean0)
    {
        $this->m_ListObject->setShowTableStyleFirstColumn($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsListObject.setShowTableStyleLastColumn(boolean)]

      @param pBoolean0  boolean
     */
    function setShowTableStyleLastColumn($pBoolean0)
    {
        $this->m_ListObject->setShowTableStyleLastColumn($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsListObject.setShowTableStyleRowStripes(boolean)]

      @param pBoolean0  boolean
     */
    function setShowTableStyleRowStripes($pBoolean0)
    {
        $this->m_ListObject->setShowTableStyleRowStripes($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsListObject.setShowTotals(boolean)]

      @param pBoolean0  boolean
     */
    function setShowTotals($pBoolean0)
    {
        $this->m_ListObject->setShowTotals($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsListObject.setTableStyleName(String)]

      @param oString0  String
     */
    function setTableStyleName($oString0)
    {
        $this->m_ListObject->setTableStyleName($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsListObject.setTableStyleType(int)]

      @param pInt0  int
     */
    function setTableStyleType($pInt0)
    {
        $this->m_ListObject->setTableStyleType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsListObject.updateColumnName()]

     */
    function updateColumnName()
    {
        $this->m_ListObject->updateColumnName();
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsListObjectCollection]
  
 */
class ListObjectCollection extends CollectionBase
{
    public $m_ListObjectCollection;
    
    function __construct($listObjectCollection)
    {
    	$this->m_ListObjectCollection = $listObjectCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsListObjectCollection.add(String, String, boolean)]

      @param oString0  String
      @param oString1  String
      @param pBoolean2  boolean
      @return int
     */
    function add($oString0, $oString1, $pBoolean2)
    {
        return $this->m_ListObjectCollection->add($oString0, $oString1, $pBoolean2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsListObjectCollection.add(int, int, int, int, boolean)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @param pBoolean4  boolean
      @return int
     */
    function addIIIIB($pInt0, $pInt1, $pInt2, $pInt3, $pBoolean4)
    {
        return $this->m_ListObjectCollection->add($pInt0, $pInt1, $pInt2, $pInt3, $pBoolean4);
    }

    /*
      Wrapper for java version method [com.aspose.cellsListObjectCollection.get(String)]

      @param oString0  String
      @return com.aspose.cells.ListObject
     */
    function get($oString0)
    {
        return ClassFactory::_t2($this->m_ListObjectCollection->get($oString0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsListObjectCollection.get(int)]

      @param pInt0  int
      @return com.aspose.cells.ListObject
     */
    function getI($pInt0)
    {
        return ClassFactory::_t2($this->m_ListObjectCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsListObjectCollection.updateColumnName()]

     */
    function updateColumnName()
    {
        $this->m_ListObjectCollection->updateColumnName();
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsLoadDataOption]
  
 */
class LoadDataOption
{
    public $m_LoadDataOption;
    
    function __construct($loadDataOption)
    {
    	$this->m_LoadDataOption = $loadDataOption;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsLoadDataOption.getFormula()]

      @return boolean
     */
    function getFormula()
    {
        return $this->m_LoadDataOption->getFormula();
    }

    /*
      Wrapper for java version method [com.aspose.cellsLoadDataOption.getImportFormula()]

      @return boolean
     */
    function getImportFormula()
    {
        return $this->m_LoadDataOption->getImportFormula();
    }

    /*
      Wrapper for java version method [com.aspose.cellsLoadDataOption.setFormula(boolean)]

      @param pBoolean0  boolean
     */
    function setFormula($pBoolean0)
    {
        $this->m_LoadDataOption->setFormula($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsLoadDataOption.setImportFormula(boolean)]

      @param pBoolean0  boolean
     */
    function setImportFormula($pBoolean0)
    {
        $this->m_LoadDataOption->setImportFormula($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsLoadFormat]
  
 */
class LoadFormat
{
    public $m_LoadFormat;
    
    function __construct($loadFormat)
    {
    	$this->m_LoadFormat = $loadFormat;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsLoadOptions]
  
 */
class LoadOptions
{
    public $m_LoadOptions;
    
    function __construct($loadOptions)
    {
    	$this->m_LoadOptions = $loadOptions;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsLoadOptions.getConvertNumericData()]

      @return boolean
     */
    function getConvertNumericData()
    {
        return $this->m_LoadOptions->getConvertNumericData();
    }

    /*
      Wrapper for java version method [com.aspose.cellsLoadOptions.getInterruptMonitor()]

      @return com.aspose.cells.InterruptMonitor
     */
    function getInterruptMonitor()
    {
        return ClassFactory::_t2($this->m_LoadOptions->getInterruptMonitor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsLoadOptions.getLanguageCode()]

      @return int
     */
    function getLanguageCode()
    {
        return $this->m_LoadOptions->getLanguageCode();
    }

    /*
      Wrapper for java version method [com.aspose.cellsLoadOptions.getLoadDataOnly()]

      @return boolean
     */
    function getLoadDataOnly()
    {
        return $this->m_LoadOptions->getLoadDataOnly();
    }

    /*
      Wrapper for java version method [com.aspose.cellsLoadOptions.getLoadDataOptions()]

      @return com.aspose.cells.LoadDataOption
     */
    function getLoadDataOptions()
    {
        return ClassFactory::_t2($this->m_LoadOptions->getLoadDataOptions());
    }

    /*
      Wrapper for java version method [com.aspose.cellsLoadOptions.getLoadFormat()]

      @return int
     */
    function getLoadFormat()
    {
        return $this->m_LoadOptions->getLoadFormat();
    }

    /*
      Wrapper for java version method [com.aspose.cellsLoadOptions.getParsingFormulaOnOpen()]

      @return boolean
     */
    function getParsingFormulaOnOpen()
    {
        return $this->m_LoadOptions->getParsingFormulaOnOpen();
    }

    /*
      Wrapper for java version method [com.aspose.cellsLoadOptions.getPassword()]

      @return String
     */
    function getPassword()
    {
        return $this->m_LoadOptions->getPassword();
    }

    /*
      Wrapper for java version method [com.aspose.cellsLoadOptions.getRegion()]

      @return int
     */
    function getRegion()
    {
        return $this->m_LoadOptions->getRegion();
    }

    /*
      Wrapper for java version method [com.aspose.cellsLoadOptions.getStandardFont()]

      @return String
     */
    function getStandardFont()
    {
        return $this->m_LoadOptions->getStandardFont();
    }

    /*
      Wrapper for java version method [com.aspose.cellsLoadOptions.getStandardFontSize()]

      @return double
     */
    function getStandardFontSize()
    {
        return $this->m_LoadOptions->getStandardFontSize();
    }

    /*
      Wrapper for java version method [com.aspose.cellsLoadOptions.setConvertNumericData(boolean)]

      @param pBoolean0  boolean
     */
    function setConvertNumericData($pBoolean0)
    {
        $this->m_LoadOptions->setConvertNumericData($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsLoadOptions.setInterruptMonitor(InterruptMonitor)]

      @param oInterruptMonitor0  com.aspose.cells.InterruptMonitor
     */
    function setInterruptMonitor($oInterruptMonitor0)
    {
        $this->m_LoadOptions->setInterruptMonitor(ClassFactory::_t1($oInterruptMonitor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsLoadOptions.setLanguageCode(int)]

      @param pInt0  int
     */
    function setLanguageCode($pInt0)
    {
        $this->m_LoadOptions->setLanguageCode($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsLoadOptions.setLoadDataOnly(boolean)]

      @param pBoolean0  boolean
     */
    function setLoadDataOnly($pBoolean0)
    {
        $this->m_LoadOptions->setLoadDataOnly($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsLoadOptions.setLoadDataOptions(LoadDataOption)]

      @param oLoadDataOption0  com.aspose.cells.LoadDataOption
     */
    function setLoadDataOptions($oLoadDataOption0)
    {
        $this->m_LoadOptions->setLoadDataOptions(ClassFactory::_t1($oLoadDataOption0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsLoadOptions.setParsingFormulaOnOpen(boolean)]

      @param pBoolean0  boolean
     */
    function setParsingFormulaOnOpen($pBoolean0)
    {
        $this->m_LoadOptions->setParsingFormulaOnOpen($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsLoadOptions.setPassword(String)]

      @param oString0  String
     */
    function setPassword($oString0)
    {
        $this->m_LoadOptions->setPassword($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsLoadOptions.setRegion(int)]

      @param pInt0  int
     */
    function setRegion($pInt0)
    {
        $this->m_LoadOptions->setRegion($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsLoadOptions.setStandardFont(String)]

      @param oString0  String
     */
    function setStandardFont($oString0)
    {
        $this->m_LoadOptions->setStandardFont($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsLoadOptions.setStandardFontSize(double)]

      @param pDouble0  double
     */
    function setStandardFontSize($pDouble0)
    {
        $this->m_LoadOptions->setStandardFontSize($pDouble0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsLookAtType]
  
 */
class LookAtType
{
    public $m_LookAtType;
    
    function __construct($lookAtType)
    {
    	$this->m_LookAtType = $lookAtType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsLookInType]
  
 */
class LookInType
{
    public $m_LookInType;
    
    function __construct($lookInType)
    {
    	$this->m_LookInType = $lookInType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsMsoArrowheadLength]
  
 */
class MsoArrowheadLength
{
    public $m_MsoArrowheadLength;
    
    function __construct($msoArrowheadLength)
    {
    	$this->m_MsoArrowheadLength = $msoArrowheadLength;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsMsoArrowheadStyle]
  
 */
class MsoArrowheadStyle
{
    public $m_MsoArrowheadStyle;
    
    function __construct($msoArrowheadStyle)
    {
    	$this->m_MsoArrowheadStyle = $msoArrowheadStyle;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsMsoArrowheadWidth]
  
 */
class MsoArrowheadWidth
{
    public $m_MsoArrowheadWidth;
    
    function __construct($msoArrowheadWidth)
    {
    	$this->m_MsoArrowheadWidth = $msoArrowheadWidth;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsMsoDrawingType]
  
 */
class MsoDrawingType
{
    public $m_MsoDrawingType;
    
    function __construct($msoDrawingType)
    {
    	$this->m_MsoDrawingType = $msoDrawingType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsMsoFillFormat]
  
 */
class MsoFillFormat
{
    public $m_MsoFillFormat;
    
    function __construct($msoFillFormat)
    {
    	$this->m_MsoFillFormat = $msoFillFormat;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsMsoFillFormat.getBackColor()]

      @return com.aspose.cells.Color
     */
    function getBackColor()
    {
        return ClassFactory::_t2($this->m_MsoFillFormat->getBackColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoFillFormat.getForeColor()]

      @return com.aspose.cells.Color
     */
    function getForeColor()
    {
        return ClassFactory::_t2($this->m_MsoFillFormat->getForeColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoFillFormat.getImageData()]

      @return byte[]
     */
    function getImageData()
    {
        return $this->m_MsoFillFormat->getImageData();
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoFillFormat.getTexture()]

      @return int
     */
    function getTexture()
    {
        return $this->m_MsoFillFormat->getTexture();
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoFillFormat.getTransparency()]

      @return double
     */
    function getTransparency()
    {
        return $this->m_MsoFillFormat->getTransparency();
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoFillFormat.isVisible()]

      @return boolean
     */
    function isVisible()
    {
        return $this->m_MsoFillFormat->isVisible();
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoFillFormat.setBackColor(Color)]

      @param oColor0  com.aspose.cells.Color
     */
    function setBackColor($oColor0)
    {
        $this->m_MsoFillFormat->setBackColor(ClassFactory::_t1($oColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoFillFormat.setForeColor(Color)]

      @param oColor0  com.aspose.cells.Color
     */
    function setForeColor($oColor0)
    {
        $this->m_MsoFillFormat->setForeColor(ClassFactory::_t1($oColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoFillFormat.setImageData(byte[])]

      @param arrP1DByte0  byte[]
     */
    function setImageData($arrP1DByte0)
    {
        $this->m_MsoFillFormat->setImageData($arrP1DByte0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoFillFormat.setOneColorGradient(Color, double, int, int)]

      @param oColor0  com.aspose.cells.Color
      @param pDouble1  double
      @param pInt2  int
      @param pInt3  int
     */
    function setOneColorGradient($oColor0, $pDouble1, $pInt2, $pInt3)
    {
        $this->m_MsoFillFormat->setOneColorGradient(ClassFactory::_t1($oColor0), $pDouble1, $pInt2, $pInt3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoFillFormat.setTransparency(double)]

      @param pDouble0  double
     */
    function setTransparency($pDouble0)
    {
        $this->m_MsoFillFormat->setTransparency($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoFillFormat.setVisible(boolean)]

      @param pBoolean0  boolean
     */
    function setVisible($pBoolean0)
    {
        $this->m_MsoFillFormat->setVisible($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsMsoFormatPicture]
  
 */
class MsoFormatPicture
{
    public $m_MsoFormatPicture;
    
    function __construct($msoFormatPicture)
    {
    	$this->m_MsoFormatPicture = $msoFormatPicture;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsMsoFormatPicture.getTransparentColor()]

      @return com.aspose.cells.CellsColor
     */
    function getTransparentColor()
    {
        return ClassFactory::_t2($this->m_MsoFormatPicture->getTransparentColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoFormatPicture.setTransparentColor(CellsColor)]

      @param oCellsColor0  com.aspose.cells.CellsColor
     */
    function setTransparentColor($oCellsColor0)
    {
        $this->m_MsoFormatPicture->setTransparentColor(ClassFactory::_t1($oCellsColor0));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsMsoLineDashStyle]
  
 */
class MsoLineDashStyle
{
    public $m_MsoLineDashStyle;
    
    function __construct($msoLineDashStyle)
    {
    	$this->m_MsoLineDashStyle = $msoLineDashStyle;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsMsoLineFormat]
  
 */
class MsoLineFormat
{
    public $m_MsoLineFormat;
    
    function __construct($msoLineFormat)
    {
    	$this->m_MsoLineFormat = $msoLineFormat;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsMsoLineFormat.getBackColor()]

      @return com.aspose.cells.Color
     */
    function getBackColor()
    {
        return ClassFactory::_t2($this->m_MsoLineFormat->getBackColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoLineFormat.getDashStyle()]

      @return int
     */
    function getDashStyle()
    {
        return $this->m_MsoLineFormat->getDashStyle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoLineFormat.getForeColor()]

      @return com.aspose.cells.Color
     */
    function getForeColor()
    {
        return ClassFactory::_t2($this->m_MsoLineFormat->getForeColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoLineFormat.getStyle()]

      @return int
     */
    function getStyle()
    {
        return $this->m_MsoLineFormat->getStyle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoLineFormat.getTransparency()]

      @return double
     */
    function getTransparency()
    {
        return $this->m_MsoLineFormat->getTransparency();
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoLineFormat.getWeight()]

      @return double
     */
    function getWeight()
    {
        return $this->m_MsoLineFormat->getWeight();
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoLineFormat.isVisible()]

      @return boolean
     */
    function isVisible()
    {
        return $this->m_MsoLineFormat->isVisible();
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoLineFormat.setBackColor(Color)]

      @param oColor0  com.aspose.cells.Color
     */
    function setBackColor($oColor0)
    {
        $this->m_MsoLineFormat->setBackColor(ClassFactory::_t1($oColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoLineFormat.setDashStyle(int)]

      @param pInt0  int
     */
    function setDashStyle($pInt0)
    {
        $this->m_MsoLineFormat->setDashStyle($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoLineFormat.setForeColor(Color)]

      @param oColor0  com.aspose.cells.Color
     */
    function setForeColor($oColor0)
    {
        $this->m_MsoLineFormat->setForeColor(ClassFactory::_t1($oColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoLineFormat.setStyle(int)]

      @param pInt0  int
     */
    function setStyle($pInt0)
    {
        $this->m_MsoLineFormat->setStyle($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoLineFormat.setTransparency(double)]

      @param pDouble0  double
     */
    function setTransparency($pDouble0)
    {
        $this->m_MsoLineFormat->setTransparency($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoLineFormat.setVisible(boolean)]

      @param pBoolean0  boolean
     */
    function setVisible($pBoolean0)
    {
        $this->m_MsoLineFormat->setVisible($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoLineFormat.setWeight(double)]

      @param pDouble0  double
     */
    function setWeight($pDouble0)
    {
        $this->m_MsoLineFormat->setWeight($pDouble0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsMsoLineStyle]
  
 */
class MsoLineStyle
{
    public $m_MsoLineStyle;
    
    function __construct($msoLineStyle)
    {
    	$this->m_MsoLineStyle = $msoLineStyle;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsMsoPresetTextEffect]
  
 */
class MsoPresetTextEffect
{
    public $m_MsoPresetTextEffect;
    
    function __construct($msoPresetTextEffect)
    {
    	$this->m_MsoPresetTextEffect = $msoPresetTextEffect;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsMsoPresetTextEffectShape]
  
 */
class MsoPresetTextEffectShape
{
    public $m_MsoPresetTextEffectShape;
    
    function __construct($msoPresetTextEffectShape)
    {
    	$this->m_MsoPresetTextEffectShape = $msoPresetTextEffectShape;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsMsoTextFrame]
  
 */
class MsoTextFrame
{
    public $m_MsoTextFrame;
    
    function __construct($msoTextFrame)
    {
    	$this->m_MsoTextFrame = $msoTextFrame;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsMsoTextFrame.getAutoSize()]

      @return boolean
     */
    function getAutoSize()
    {
        return $this->m_MsoTextFrame->getAutoSize();
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoTextFrame.getBottomMarginPt()]

      @return double
     */
    function getBottomMarginPt()
    {
        return $this->m_MsoTextFrame->getBottomMarginPt();
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoTextFrame.getLeftMarginPt()]

      @return double
     */
    function getLeftMarginPt()
    {
        return $this->m_MsoTextFrame->getLeftMarginPt();
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoTextFrame.getRightMarginPt()]

      @return double
     */
    function getRightMarginPt()
    {
        return $this->m_MsoTextFrame->getRightMarginPt();
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoTextFrame.getTopMarginPt()]

      @return double
     */
    function getTopMarginPt()
    {
        return $this->m_MsoTextFrame->getTopMarginPt();
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoTextFrame.isAutoMargin()]

      @return boolean
     */
    function isAutoMargin()
    {
        return $this->m_MsoTextFrame->isAutoMargin();
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoTextFrame.setAutoMargin(boolean)]

      @param pBoolean0  boolean
     */
    function setAutoMargin($pBoolean0)
    {
        $this->m_MsoTextFrame->setAutoMargin($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoTextFrame.setAutoSize(boolean)]

      @param pBoolean0  boolean
     */
    function setAutoSize($pBoolean0)
    {
        $this->m_MsoTextFrame->setAutoSize($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoTextFrame.setBottomMarginPt(double)]

      @param pDouble0  double
     */
    function setBottomMarginPt($pDouble0)
    {
        $this->m_MsoTextFrame->setBottomMarginPt($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoTextFrame.setLeftMarginPt(double)]

      @param pDouble0  double
     */
    function setLeftMarginPt($pDouble0)
    {
        $this->m_MsoTextFrame->setLeftMarginPt($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoTextFrame.setRightMarginPt(double)]

      @param pDouble0  double
     */
    function setRightMarginPt($pDouble0)
    {
        $this->m_MsoTextFrame->setRightMarginPt($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsMsoTextFrame.setTopMarginPt(double)]

      @param pDouble0  double
     */
    function setTopMarginPt($pDouble0)
    {
        $this->m_MsoTextFrame->setTopMarginPt($pDouble0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsMultipleFilterCollection]
  
 */
class MultipleFilterCollection extends CollectionBase
{
    public $m_MultipleFilterCollection;
    
    function __construct($multipleFilterCollection)
    {
    	$this->m_MultipleFilterCollection = $multipleFilterCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsMultipleFilterCollection.get(int)]

      @param pInt0  int
      @return corresponding java type is {java.lang.Object}
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_MultipleFilterCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsMultipleFilterCollection.getMatchBlank()]

      @return boolean
     */
    function getMatchBlank()
    {
        return $this->m_MultipleFilterCollection->getMatchBlank();
    }

    /*
      Wrapper for java version method [com.aspose.cellsMultipleFilterCollection.setMatchBlank(boolean)]

      @param pBoolean0  boolean
     */
    function setMatchBlank($pBoolean0)
    {
        $this->m_MultipleFilterCollection->setMatchBlank($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsName]
  
 */
class Name
{
    public $m_Name;
    
    function __construct($name)
    {
    	$this->m_Name = $name;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsName.getComment()]

      @return String
     */
    function getComment()
    {
        return $this->m_Name->getComment();
    }

    /*
      Wrapper for java version method [com.aspose.cellsName.getR1C1RefersTo()]

      @return String
     */
    function getR1C1RefersTo()
    {
        return $this->m_Name->getR1C1RefersTo();
    }

    /*
      Wrapper for java version method [com.aspose.cellsName.getRange()]

      @return com.aspose.cells.Range
     */
    function getRange()
    {
        return ClassFactory::_t2($this->m_Name->getRange());
    }

    /*
      Wrapper for java version method [com.aspose.cellsName.getRanges()]

      @return com.aspose.cells.Range[]
     */
    function getRanges()
    {
        return ClassFactory::_t2($this->m_Name->getRanges());
    }

    /*
      Wrapper for java version method [com.aspose.cellsName.getRefersTo()]

      @return String
     */
    function getRefersTo()
    {
        return $this->m_Name->getRefersTo();
    }

    /*
      Wrapper for java version method [com.aspose.cellsName.getSheetIndex()]

      @return int
     */
    function getSheetIndex()
    {
        return $this->m_Name->getSheetIndex();
    }

    /*
      Wrapper for java version method [com.aspose.cellsName.getText()]

      @return String
     */
    function getText()
    {
        return $this->m_Name->getText();
    }

    /*
      Wrapper for java version method [com.aspose.cellsName.isReferred()]

      @return boolean
     */
    function isReferred()
    {
        return $this->m_Name->isReferred();
    }

    /*
      Wrapper for java version method [com.aspose.cellsName.isVisible()]

      @return boolean
     */
    function isVisible()
    {
        return $this->m_Name->isVisible();
    }

    /*
      Wrapper for java version method [com.aspose.cellsName.setComment(String)]

      @param oString0  String
     */
    function setComment($oString0)
    {
        $this->m_Name->setComment($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsName.setR1C1RefersTo(String)]

      @param oString0  String
     */
    function setR1C1RefersTo($oString0)
    {
        $this->m_Name->setR1C1RefersTo($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsName.setRefersTo(String)]

      @param oString0  String
     */
    function setRefersTo($oString0)
    {
        $this->m_Name->setRefersTo($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsName.setSheetIndex(int)]

      @param pInt0  int
     */
    function setSheetIndex($pInt0)
    {
        $this->m_Name->setSheetIndex($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsName.setText(String)]

      @param oString0  String
     */
    function setText($oString0)
    {
        $this->m_Name->setText($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsName.setVisible(boolean)]

      @param pBoolean0  boolean
     */
    function setVisible($pBoolean0)
    {
        $this->m_Name->setVisible($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsNameCollection]
  
 */
class NameCollection extends CollectionBase
{
    public $m_NameCollection;
    
    function __construct($nameCollection)
    {
    	$this->m_NameCollection = $nameCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsNameCollection.add(String)]

      @param oString0  String
      @return int
     */
    function add($oString0)
    {
        return $this->m_NameCollection->add($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsNameCollection.clear()]

     */
    function clear()
    {
        $this->m_NameCollection->clear();
    }

    /*
      Wrapper for java version method [com.aspose.cellsNameCollection.get(String)]

      @param oString0  String
      @return com.aspose.cells.Name
     */
    function get($oString0)
    {
        return ClassFactory::_t2($this->m_NameCollection->get($oString0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsNameCollection.get(int)]

      @param pInt0  int
      @return corresponding java type is {java.lang.Object}
     */
    function getI($pInt0)
    {
        return ClassFactory::_t2($this->m_NameCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsNameCollection.remove(String)]

      @param oString0  String
     */
    function remove($oString0)
    {
        $this->m_NameCollection->remove($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsNameCollection.remove(String[])]

      @param arrD1DString0  array, corresponding java type is {String[]}
     */
    function removeS($arrD1DString0)
    {
        $this->m_NameCollection->remove($arrD1DString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsNameCollection.removeAt(int)]

      @param pInt0  int
     */
    function removeAt($pInt0)
    {
        $this->m_NameCollection->removeAt($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsNameCollection.removeDuplicateNames()]

     */
    function removeDuplicateNames()
    {
        $this->m_NameCollection->removeDuplicateNames();
    }

    /*
      Wrapper for java version method [com.aspose.cellsNameCollection.sort()]

     */
    function sort()
    {
        $this->m_NameCollection->sort();
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsOdsSaveOptions]
  
 */
class OdsSaveOptions extends SaveOptions
{
    public $m_OdsSaveOptions;
    
    function __construct($odsSaveOptions)
    {
    	$this->m_OdsSaveOptions = $odsSaveOptions;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsOleFileType]
  
 */
class OleFileType
{
    public $m_OleFileType;
    
    function __construct($oleFileType)
    {
    	$this->m_OleFileType = $oleFileType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsOleObject]
  
 */
class OleObject extends Shape
{
    public $m_OleObject;
    
    function __construct($oleObject)
    {
    	$this->m_OleObject = $oleObject;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsOleObject.getDisplayAsIcon()]

      @return boolean
     */
    function getDisplayAsIcon()
    {
        return $this->m_OleObject->getDisplayAsIcon();
    }

    /*
      Wrapper for java version method [com.aspose.cellsOleObject.getFileType()]

      @return int
     */
    function getFileType()
    {
        return $this->m_OleObject->getFileType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsOleObject.getImageData()]

      @return byte[]
     */
    function getImageData()
    {
        return $this->m_OleObject->getImageData();
    }

    /*
      Wrapper for java version method [com.aspose.cellsOleObject.getImageSourceFullName()]

      @return String
     */
    function getImageSourceFullName()
    {
        return $this->m_OleObject->getImageSourceFullName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsOleObject.getObjectData()]

      @return byte[]
     */
    function getObjectData()
    {
        return $this->m_OleObject->getObjectData();
    }

    /*
      Wrapper for java version method [com.aspose.cellsOleObject.getProgID()]

      @return String
     */
    function getProgID()
    {
        return $this->m_OleObject->getProgID();
    }

    /*
      Wrapper for java version method [com.aspose.cellsOleObject.getSourceFullName()]

      @return String
     */
    function getSourceFullName()
    {
        return $this->m_OleObject->getSourceFullName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsOleObject.isAutoSize()]

      @return boolean
     */
    function isAutoSize()
    {
        return $this->m_OleObject->isAutoSize();
    }

    /*
      Wrapper for java version method [com.aspose.cellsOleObject.isLink()]

      @return boolean
     */
    function isLink()
    {
        return $this->m_OleObject->isLink();
    }

    /*
      Wrapper for java version method [com.aspose.cellsOleObject.setAutoSize(boolean)]

      @param pBoolean0  boolean
     */
    function setAutoSize($pBoolean0)
    {
        $this->m_OleObject->setAutoSize($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsOleObject.setDisplayAsIcon(boolean)]

      @param pBoolean0  boolean
     */
    function setDisplayAsIcon($pBoolean0)
    {
        $this->m_OleObject->setDisplayAsIcon($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsOleObject.setFileType(int)]

      @param pInt0  int
     */
    function setFileType($pInt0)
    {
        $this->m_OleObject->setFileType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsOleObject.setImageSourceFullName(String)]

      @param oString0  String
     */
    function setImageSourceFullName($oString0)
    {
        $this->m_OleObject->setImageSourceFullName($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsOleObject.setNativeSourceFullName(String)]

      @param oString0  String
     */
    function setNativeSourceFullName($oString0)
    {
        $this->m_OleObject->setNativeSourceFullName($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsOleObject.setObjectData(byte[])]

      @param arrP1DByte0  byte[]
     */
    function setObjectData($arrP1DByte0)
    {
        $this->m_OleObject->setObjectData($arrP1DByte0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsOleObject.setProgID(String)]

      @param oString0  String
     */
    function setProgID($oString0)
    {
        $this->m_OleObject->setProgID($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsOleObject.setSourceFullName(String)]

      @param oString0  String
     */
    function setSourceFullName($oString0)
    {
        $this->m_OleObject->setSourceFullName($oString0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsOleObjectCollection]
  
 */
class OleObjectCollection extends CollectionBase
{
    public $m_OleObjectCollection;
    
    function __construct($oleObjectCollection)
    {
    	$this->m_OleObjectCollection = $oleObjectCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsOleObjectCollection.add(int, int, int, int, byte[])]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @param arrP1DByte4  byte[]
      @return int
     */
    function add($pInt0, $pInt1, $pInt2, $pInt3, $arrP1DByte4)
    {
        return $this->m_OleObjectCollection->add($pInt0, $pInt1, $pInt2, $pInt3, $arrP1DByte4);
    }

    /*
      Wrapper for java version method [com.aspose.cellsOleObjectCollection.get(int)]

      @param pInt0  int
      @return corresponding java type is {java.lang.Object}
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_OleObjectCollection->get($pInt0));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsOoxmlSaveOptions]
  
 */
class OoxmlSaveOptions extends SaveOptions
{
    public $m_OoxmlSaveOptions;
    
    function __construct($ooxmlSaveOptions)
    {
    	$this->m_OoxmlSaveOptions = $ooxmlSaveOptions;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsOoxmlSaveOptions.getExportCellName()]

      @return boolean
     */
    function getExportCellName()
    {
        return $this->m_OoxmlSaveOptions->getExportCellName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsOoxmlSaveOptions.setExportCellName(boolean)]

      @param pBoolean0  boolean
     */
    function setExportCellName($pBoolean0)
    {
        $this->m_OoxmlSaveOptions->setExportCellName($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsOperatorType]
  
 */
class OperatorType
{
    public $m_OperatorType;
    
    function __construct($operatorType)
    {
    	$this->m_OperatorType = $operatorType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsOutline]
  
 */
class Outline
{
    public $m_Outline;
    
    function __construct($outline)
    {
    	$this->m_Outline = $outline;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsOval]
  
 */
class Oval extends Shape
{
    public $m_Oval;
    
    function __construct($oval)
    {
    	$this->m_Oval = $oval;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsOval.characters(int, int)]

      @param pInt0  int
      @param pInt1  int
      @return com.aspose.cells.FontSetting
     */
    function characters($pInt0, $pInt1)
    {
        return ClassFactory::_t2($this->m_Oval->characters($pInt0, $pInt1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsOval.getCharacters()]

      @return array, corresponding java type is {java.util.ArrayList}
     */
    function getCharacters()
    {
        return ClassFactory::_t2($this->m_Oval->getCharacters());
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsPageOrientationType]
  
 */
class PageOrientationType
{
    public $m_PageOrientationType;
    
    function __construct($pageOrientationType)
    {
    	$this->m_PageOrientationType = $pageOrientationType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsPageSetup]
  
 */
class PageSetup
{
    public $m_PageSetup;
    
    function __construct($pageSetup)
    {
    	$this->m_PageSetup = $pageSetup;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.clearHeaderFooter()]

     */
    function clearHeaderFooter()
    {
        $this->m_PageSetup->clearHeaderFooter();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getBlackAndWhite()]

      @return boolean
     */
    function getBlackAndWhite()
    {
        return $this->m_PageSetup->getBlackAndWhite();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getBottomMargin()]

      @return double
     */
    function getBottomMargin()
    {
        return $this->m_PageSetup->getBottomMargin();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getBottomMarginInch()]

      @return double
     */
    function getBottomMarginInch()
    {
        return $this->m_PageSetup->getBottomMarginInch();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getCenterHorizontally()]

      @return boolean
     */
    function getCenterHorizontally()
    {
        return $this->m_PageSetup->getCenterHorizontally();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getCenterVertically()]

      @return boolean
     */
    function getCenterVertically()
    {
        return $this->m_PageSetup->getCenterVertically();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getDraft()]

      @return boolean
     */
    function getDraft()
    {
        return $this->m_PageSetup->getDraft();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getEvenFooter(int)]

      @param pInt0  int
      @return String
     */
    function getEvenFooter($pInt0)
    {
        return $this->m_PageSetup->getEvenFooter($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getEvenHeader(int)]

      @param pInt0  int
      @return String
     */
    function getEvenHeader($pInt0)
    {
        return $this->m_PageSetup->getEvenHeader($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getFirstPageFooter(int)]

      @param pInt0  int
      @return String
     */
    function getFirstPageFooter($pInt0)
    {
        return $this->m_PageSetup->getFirstPageFooter($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getFirstPageHeader(int)]

      @param pInt0  int
      @return String
     */
    function getFirstPageHeader($pInt0)
    {
        return $this->m_PageSetup->getFirstPageHeader($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getFirstPageNumber()]

      @return int
     */
    function getFirstPageNumber()
    {
        return $this->m_PageSetup->getFirstPageNumber();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getFitToPagesTall()]

      @return int
     */
    function getFitToPagesTall()
    {
        return $this->m_PageSetup->getFitToPagesTall();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getFitToPagesWide()]

      @return int
     */
    function getFitToPagesWide()
    {
        return $this->m_PageSetup->getFitToPagesWide();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getFooter(int)]

      @param pInt0  int
      @return String
     */
    function getFooter($pInt0)
    {
        return $this->m_PageSetup->getFooter($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getFooterMargin()]

      @return double
     */
    function getFooterMargin()
    {
        return $this->m_PageSetup->getFooterMargin();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getFooterMarginInch()]

      @return double
     */
    function getFooterMarginInch()
    {
        return $this->m_PageSetup->getFooterMarginInch();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getHeader(int)]

      @param pInt0  int
      @return String
     */
    function getHeader($pInt0)
    {
        return $this->m_PageSetup->getHeader($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getHeaderMargin()]

      @return double
     */
    function getHeaderMargin()
    {
        return $this->m_PageSetup->getHeaderMargin();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getHeaderMarginInch()]

      @return double
     */
    function getHeaderMarginInch()
    {
        return $this->m_PageSetup->getHeaderMarginInch();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getLeftMargin()]

      @return double
     */
    function getLeftMargin()
    {
        return $this->m_PageSetup->getLeftMargin();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getLeftMarginInch()]

      @return double
     */
    function getLeftMarginInch()
    {
        return $this->m_PageSetup->getLeftMarginInch();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getOrder()]

      @return int
     */
    function getOrder()
    {
        return $this->m_PageSetup->getOrder();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getOrientation()]

      @return int
     */
    function getOrientation()
    {
        return $this->m_PageSetup->getOrientation();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getPaperSize()]

      @return int
     */
    function getPaperSize()
    {
        return $this->m_PageSetup->getPaperSize();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getPicture(boolean, int)]

      @param pBoolean0  boolean
      @param pInt1  int
      @return com.aspose.cells.Picture
     */
    function getPicture($pBoolean0, $pInt1)
    {
        return ClassFactory::_t2($this->m_PageSetup->getPicture($pBoolean0, $pInt1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getPrintArea()]

      @return String
     */
    function getPrintArea()
    {
        return $this->m_PageSetup->getPrintArea();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getPrintComments()]

      @return int
     */
    function getPrintComments()
    {
        return $this->m_PageSetup->getPrintComments();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getPrintCopies()]

      @return int
     */
    function getPrintCopies()
    {
        return $this->m_PageSetup->getPrintCopies();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getPrintDraft()]

      @return boolean
     */
    function getPrintDraft()
    {
        return $this->m_PageSetup->getPrintDraft();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getPrintErrors()]

      @return int
     */
    function getPrintErrors()
    {
        return $this->m_PageSetup->getPrintErrors();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getPrintGridlines()]

      @return boolean
     */
    function getPrintGridlines()
    {
        return $this->m_PageSetup->getPrintGridlines();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getPrintHeadings()]

      @return boolean
     */
    function getPrintHeadings()
    {
        return $this->m_PageSetup->getPrintHeadings();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getPrintQuality()]

      @return int
     */
    function getPrintQuality()
    {
        return $this->m_PageSetup->getPrintQuality();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getPrintTitleColumns()]

      @return String
     */
    function getPrintTitleColumns()
    {
        return $this->m_PageSetup->getPrintTitleColumns();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getPrintTitleRows()]

      @return String
     */
    function getPrintTitleRows()
    {
        return $this->m_PageSetup->getPrintTitleRows();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getRightMargin()]

      @return double
     */
    function getRightMargin()
    {
        return $this->m_PageSetup->getRightMargin();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getRightMarginInch()]

      @return double
     */
    function getRightMarginInch()
    {
        return $this->m_PageSetup->getRightMarginInch();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getTopMargin()]

      @return double
     */
    function getTopMargin()
    {
        return $this->m_PageSetup->getTopMargin();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getTopMarginInch()]

      @return double
     */
    function getTopMarginInch()
    {
        return $this->m_PageSetup->getTopMarginInch();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.getZoom()]

      @return int
     */
    function getZoom()
    {
        return $this->m_PageSetup->getZoom();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.isHFAlignMargins()]

      @return boolean
     */
    function isHFAlignMargins()
    {
        return $this->m_PageSetup->isHFAlignMargins();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.isHFDiffFirst()]

      @return boolean
     */
    function isHFDiffFirst()
    {
        return $this->m_PageSetup->isHFDiffFirst();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.isHFDiffOddEven()]

      @return boolean
     */
    function isHFDiffOddEven()
    {
        return $this->m_PageSetup->isHFDiffOddEven();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.isHFScaleWithDoc()]

      @return boolean
     */
    function isHFScaleWithDoc()
    {
        return $this->m_PageSetup->isHFScaleWithDoc();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.isPercentScale()]

      @return boolean
     */
    function isPercentScale()
    {
        return $this->m_PageSetup->isPercentScale();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setBlackAndWhite(boolean)]

      @param pBoolean0  boolean
     */
    function setBlackAndWhite($pBoolean0)
    {
        $this->m_PageSetup->setBlackAndWhite($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setBottomMargin(double)]

      @param pDouble0  double
     */
    function setBottomMargin($pDouble0)
    {
        $this->m_PageSetup->setBottomMargin($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setBottomMarginInch(double)]

      @param pDouble0  double
     */
    function setBottomMarginInch($pDouble0)
    {
        $this->m_PageSetup->setBottomMarginInch($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setCenterHorizontally(boolean)]

      @param pBoolean0  boolean
     */
    function setCenterHorizontally($pBoolean0)
    {
        $this->m_PageSetup->setCenterHorizontally($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setCenterVertically(boolean)]

      @param pBoolean0  boolean
     */
    function setCenterVertically($pBoolean0)
    {
        $this->m_PageSetup->setCenterVertically($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setDraft(boolean)]

      @param pBoolean0  boolean
     */
    function setDraft($pBoolean0)
    {
        $this->m_PageSetup->setDraft($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setEvenFooter(int, String)]

      @param pInt0  int
      @param oString1  String
     */
    function setEvenFooter($pInt0, $oString1)
    {
        $this->m_PageSetup->setEvenFooter($pInt0, $oString1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setEvenHeader(int, String)]

      @param pInt0  int
      @param oString1  String
     */
    function setEvenHeader($pInt0, $oString1)
    {
        $this->m_PageSetup->setEvenHeader($pInt0, $oString1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setFirstPageFooter(int, String)]

      @param pInt0  int
      @param oString1  String
     */
    function setFirstPageFooter($pInt0, $oString1)
    {
        $this->m_PageSetup->setFirstPageFooter($pInt0, $oString1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setFirstPageHeader(int, String)]

      @param pInt0  int
      @param oString1  String
     */
    function setFirstPageHeader($pInt0, $oString1)
    {
        $this->m_PageSetup->setFirstPageHeader($pInt0, $oString1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setFirstPageNumber(int)]

      @param pInt0  int
     */
    function setFirstPageNumber($pInt0)
    {
        $this->m_PageSetup->setFirstPageNumber($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setFitToPagesTall(int)]

      @param pInt0  int
     */
    function setFitToPagesTall($pInt0)
    {
        $this->m_PageSetup->setFitToPagesTall($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setFitToPagesWide(int)]

      @param pInt0  int
     */
    function setFitToPagesWide($pInt0)
    {
        $this->m_PageSetup->setFitToPagesWide($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setFooter(int, String)]

      @param pInt0  int
      @param oString1  String
     */
    function setFooter($pInt0, $oString1)
    {
        $this->m_PageSetup->setFooter($pInt0, $oString1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setFooterMargin(double)]

      @param pDouble0  double
     */
    function setFooterMargin($pDouble0)
    {
        $this->m_PageSetup->setFooterMargin($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setFooterMarginInch(double)]

      @param pDouble0  double
     */
    function setFooterMarginInch($pDouble0)
    {
        $this->m_PageSetup->setFooterMarginInch($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setFooterPicture(int, byte[])]

      @param pInt0  int
      @param arrP1DByte1  byte[]
      @return com.aspose.cells.Picture
     */
    function setFooterPicture($pInt0, $arrP1DByte1)
    {
        return ClassFactory::_t2($this->m_PageSetup->setFooterPicture($pInt0, $arrP1DByte1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setHFAlignMargins(boolean)]

      @param pBoolean0  boolean
     */
    function setHFAlignMargins($pBoolean0)
    {
        $this->m_PageSetup->setHFAlignMargins($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setHFDiffFirst(boolean)]

      @param pBoolean0  boolean
     */
    function setHFDiffFirst($pBoolean0)
    {
        $this->m_PageSetup->setHFDiffFirst($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setHFDiffOddEven(boolean)]

      @param pBoolean0  boolean
     */
    function setHFDiffOddEven($pBoolean0)
    {
        $this->m_PageSetup->setHFDiffOddEven($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setHFScaleWithDoc(boolean)]

      @param pBoolean0  boolean
     */
    function setHFScaleWithDoc($pBoolean0)
    {
        $this->m_PageSetup->setHFScaleWithDoc($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setHeader(int, String)]

      @param pInt0  int
      @param oString1  String
     */
    function setHeader($pInt0, $oString1)
    {
        $this->m_PageSetup->setHeader($pInt0, $oString1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setHeaderMargin(double)]

      @param pDouble0  double
     */
    function setHeaderMargin($pDouble0)
    {
        $this->m_PageSetup->setHeaderMargin($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setHeaderMarginInch(double)]

      @param pDouble0  double
     */
    function setHeaderMarginInch($pDouble0)
    {
        $this->m_PageSetup->setHeaderMarginInch($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setHeaderPicture(int, byte[])]

      @param pInt0  int
      @param arrP1DByte1  byte[]
      @return com.aspose.cells.Picture
     */
    function setHeaderPicture($pInt0, $arrP1DByte1)
    {
        return ClassFactory::_t2($this->m_PageSetup->setHeaderPicture($pInt0, $arrP1DByte1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setLeftMargin(double)]

      @param pDouble0  double
     */
    function setLeftMargin($pDouble0)
    {
        $this->m_PageSetup->setLeftMargin($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setLeftMarginInch(double)]

      @param pDouble0  double
     */
    function setLeftMarginInch($pDouble0)
    {
        $this->m_PageSetup->setLeftMarginInch($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setOrder(int)]

      @param pInt0  int
     */
    function setOrder($pInt0)
    {
        $this->m_PageSetup->setOrder($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setOrientation(int)]

      @param pInt0  int
     */
    function setOrientation($pInt0)
    {
        $this->m_PageSetup->setOrientation($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setPaperSize(int)]

      @param pInt0  int
     */
    function setPaperSize($pInt0)
    {
        $this->m_PageSetup->setPaperSize($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setPercentScale(boolean)]

      @param pBoolean0  boolean
     */
    function setPercentScale($pBoolean0)
    {
        $this->m_PageSetup->setPercentScale($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setPrintArea(String)]

      @param oString0  String
     */
    function setPrintArea($oString0)
    {
        $this->m_PageSetup->setPrintArea($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setPrintComments(int)]

      @param pInt0  int
     */
    function setPrintComments($pInt0)
    {
        $this->m_PageSetup->setPrintComments($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setPrintCopies(int)]

      @param pInt0  int
     */
    function setPrintCopies($pInt0)
    {
        $this->m_PageSetup->setPrintCopies($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setPrintDraft(boolean)]

      @param pBoolean0  boolean
     */
    function setPrintDraft($pBoolean0)
    {
        $this->m_PageSetup->setPrintDraft($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setPrintErrors(int)]

      @param pInt0  int
     */
    function setPrintErrors($pInt0)
    {
        $this->m_PageSetup->setPrintErrors($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setPrintGridlines(boolean)]

      @param pBoolean0  boolean
     */
    function setPrintGridlines($pBoolean0)
    {
        $this->m_PageSetup->setPrintGridlines($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setPrintHeadings(boolean)]

      @param pBoolean0  boolean
     */
    function setPrintHeadings($pBoolean0)
    {
        $this->m_PageSetup->setPrintHeadings($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setPrintQuality(int)]

      @param pInt0  int
     */
    function setPrintQuality($pInt0)
    {
        $this->m_PageSetup->setPrintQuality($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setPrintTitleColumns(String)]

      @param oString0  String
     */
    function setPrintTitleColumns($oString0)
    {
        $this->m_PageSetup->setPrintTitleColumns($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setPrintTitleRows(String)]

      @param oString0  String
     */
    function setPrintTitleRows($oString0)
    {
        $this->m_PageSetup->setPrintTitleRows($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setRightMargin(double)]

      @param pDouble0  double
     */
    function setRightMargin($pDouble0)
    {
        $this->m_PageSetup->setRightMargin($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setRightMarginInch(double)]

      @param pDouble0  double
     */
    function setRightMarginInch($pDouble0)
    {
        $this->m_PageSetup->setRightMarginInch($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setTopMargin(double)]

      @param pDouble0  double
     */
    function setTopMargin($pDouble0)
    {
        $this->m_PageSetup->setTopMargin($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setTopMarginInch(double)]

      @param pDouble0  double
     */
    function setTopMarginInch($pDouble0)
    {
        $this->m_PageSetup->setTopMarginInch($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPageSetup.setZoom(int)]

      @param pInt0  int
     */
    function setZoom($pInt0)
    {
        $this->m_PageSetup->setZoom($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsPaneCollection]
  
 */
class PaneCollection
{
    public $m_PaneCollection;
    
    function __construct($paneCollection)
    {
    	$this->m_PaneCollection = $paneCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsPaneCollection.getAcitvePaneType()]

      @return int
     */
    function getAcitvePaneType()
    {
        return $this->m_PaneCollection->getAcitvePaneType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPaneCollection.getFirstVisibleColumnOfRightPane()]

      @return int
     */
    function getFirstVisibleColumnOfRightPane()
    {
        return $this->m_PaneCollection->getFirstVisibleColumnOfRightPane();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPaneCollection.getFirstVisibleRowOfBottomPane()]

      @return int
     */
    function getFirstVisibleRowOfBottomPane()
    {
        return $this->m_PaneCollection->getFirstVisibleRowOfBottomPane();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPaneCollection.setAcitvePaneType(int)]

      @param pInt0  int
     */
    function setAcitvePaneType($pInt0)
    {
        $this->m_PaneCollection->setAcitvePaneType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPaneCollection.setFirstVisibleColumnOfRightPane(int)]

      @param pInt0  int
     */
    function setFirstVisibleColumnOfRightPane($pInt0)
    {
        $this->m_PaneCollection->setFirstVisibleColumnOfRightPane($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPaneCollection.setFirstVisibleRowOfBottomPane(int)]

      @param pInt0  int
     */
    function setFirstVisibleRowOfBottomPane($pInt0)
    {
        $this->m_PaneCollection->setFirstVisibleRowOfBottomPane($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsPaperSizeType]
  
 */
class PaperSizeType
{
    public $m_PaperSizeType;
    
    function __construct($paperSizeType)
    {
    	$this->m_PaperSizeType = $paperSizeType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsPasteOptions]
  
 */
class PasteOptions
{
    public $m_PasteOptions;
    
    function __construct($pasteOptions)
    {
    	$this->m_PasteOptions = $pasteOptions;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsPasteOptions.getPasteType()]

      @return int
     */
    function getPasteType()
    {
        return $this->m_PasteOptions->getPasteType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPasteOptions.getSkipBlanks()]

      @return boolean
     */
    function getSkipBlanks()
    {
        return $this->m_PasteOptions->getSkipBlanks();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPasteOptions.getTranspose()]

      @return boolean
     */
    function getTranspose()
    {
        return $this->m_PasteOptions->getTranspose();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPasteOptions.setPasteType(int)]

      @param pInt0  int
     */
    function setPasteType($pInt0)
    {
        $this->m_PasteOptions->setPasteType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPasteOptions.setSkipBlanks(boolean)]

      @param pBoolean0  boolean
     */
    function setSkipBlanks($pBoolean0)
    {
        $this->m_PasteOptions->setSkipBlanks($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPasteOptions.setTranspose(boolean)]

      @param pBoolean0  boolean
     */
    function setTranspose($pBoolean0)
    {
        $this->m_PasteOptions->setTranspose($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsPasteType]
  
 */
class PasteType
{
    public $m_PasteType;
    
    function __construct($pasteType)
    {
    	$this->m_PasteType = $pasteType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsPdfBookmarkEntry]
  
 */
class PdfBookmarkEntry
{
    public $m_PdfBookmarkEntry;
    
    function __construct($pdfBookmarkEntry)
    {
    	$this->m_PdfBookmarkEntry = $pdfBookmarkEntry;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsPdfBookmarkEntry.getDestination()]

      @return com.aspose.cells.Cell
     */
    function getDestination()
    {
        return ClassFactory::_t2($this->m_PdfBookmarkEntry->getDestination());
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfBookmarkEntry.getSubEntry()]

      @return array, corresponding java type is {java.util.ArrayList}
     */
    function getSubEntry()
    {
        return ClassFactory::_t2($this->m_PdfBookmarkEntry->getSubEntry());
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfBookmarkEntry.getText()]

      @return String
     */
    function getText()
    {
        return $this->m_PdfBookmarkEntry->getText();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfBookmarkEntry.isCollapse()]

      @return boolean
     */
    function isCollapse()
    {
        return $this->m_PdfBookmarkEntry->isCollapse();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfBookmarkEntry.isOpen()]

      @return boolean
     */
    function isOpen()
    {
        return $this->m_PdfBookmarkEntry->isOpen();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfBookmarkEntry.setCollapse(boolean)]

      @param pBoolean0  boolean
     */
    function setCollapse($pBoolean0)
    {
        $this->m_PdfBookmarkEntry->setCollapse($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfBookmarkEntry.setDestination(Cell)]

      @param oCell0  com.aspose.cells.Cell
     */
    function setDestination($oCell0)
    {
        $this->m_PdfBookmarkEntry->setDestination(ClassFactory::_t1($oCell0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfBookmarkEntry.setOpen(boolean)]

      @param pBoolean0  boolean
     */
    function setOpen($pBoolean0)
    {
        $this->m_PdfBookmarkEntry->setOpen($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfBookmarkEntry.setSubEntry(ArrayList)]

      @param arrA1DFromArrayList0  array, corresponding java type is {java.util.ArrayList}
     */
    function setSubEntry($arrA1DFromArrayList0)
    {
        $this->m_PdfBookmarkEntry->setSubEntry(ClassFactory::_t1($arrA1DFromArrayList0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfBookmarkEntry.setText(String)]

      @param oString0  String
     */
    function setText($oString0)
    {
        $this->m_PdfBookmarkEntry->setText($oString0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsPdfCompliance]
  
 */
class PdfCompliance
{
    public $m_PdfCompliance;
    
    function __construct($pdfCompliance)
    {
    	$this->m_PdfCompliance = $pdfCompliance;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsPdfSaveOptions]
  
 */
class PdfSaveOptions extends SaveOptions
{
    public $m_PdfSaveOptions;
    
    function __construct($pdfSaveOptions)
    {
    	$this->m_PdfSaveOptions = $pdfSaveOptions;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsPdfSaveOptions.getBookmark()]

      @return com.aspose.cells.PdfBookmarkEntry
     */
    function getBookmark()
    {
        return ClassFactory::_t2($this->m_PdfSaveOptions->getBookmark());
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfSaveOptions.getCompliance()]

      @return int
     */
    function getCompliance()
    {
        return $this->m_PdfSaveOptions->getCompliance();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfSaveOptions.getDefaultFont()]

      @return String
     */
    function getDefaultFont()
    {
        return $this->m_PdfSaveOptions->getDefaultFont();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfSaveOptions.getOnePagePerSheet()]

      @return boolean
     */
    function getOnePagePerSheet()
    {
        return $this->m_PdfSaveOptions->getOnePagePerSheet();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfSaveOptions.getPrintingPageType()]

      @return int
     */
    function getPrintingPageType()
    {
        return $this->m_PdfSaveOptions->getPrintingPageType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfSaveOptions.getSecurityOptions()]

      @return com.aspose.cells.PdfSecurityOptions
     */
    function getSecurityOptions()
    {
        return ClassFactory::_t2($this->m_PdfSaveOptions->getSecurityOptions());
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfSaveOptions.setBookmark(PdfBookmarkEntry)]

      @param oPdfBookmarkEntry0  com.aspose.cells.PdfBookmarkEntry
     */
    function setBookmark($oPdfBookmarkEntry0)
    {
        $this->m_PdfSaveOptions->setBookmark(ClassFactory::_t1($oPdfBookmarkEntry0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfSaveOptions.setCompliance(int)]

      @param pInt0  int
     */
    function setCompliance($pInt0)
    {
        $this->m_PdfSaveOptions->setCompliance($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfSaveOptions.setDefaultFont(String)]

      @param oString0  String
     */
    function setDefaultFont($oString0)
    {
        $this->m_PdfSaveOptions->setDefaultFont($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfSaveOptions.setOnePagePerSheet(boolean)]

      @param pBoolean0  boolean
     */
    function setOnePagePerSheet($pBoolean0)
    {
        $this->m_PdfSaveOptions->setOnePagePerSheet($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfSaveOptions.setPrintingPageType(int)]

      @param pInt0  int
     */
    function setPrintingPageType($pInt0)
    {
        $this->m_PdfSaveOptions->setPrintingPageType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfSaveOptions.setSecurityOptions(PdfSecurityOptions)]

      @param oPdfSecurityOptions0  com.aspose.cells.PdfSecurityOptions
     */
    function setSecurityOptions($oPdfSecurityOptions0)
    {
        $this->m_PdfSaveOptions->setSecurityOptions(ClassFactory::_t1($oPdfSecurityOptions0));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsPdfSecurityOptions]
  
 */
class PdfSecurityOptions
{
    public $m_PdfSecurityOptions;
    
    function __construct($pdfSecurityOptions)
    {
    	$this->m_PdfSecurityOptions = $pdfSecurityOptions;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsPdfSecurityOptions.getAnnotationsPermission()]

      @return boolean
     */
    function getAnnotationsPermission()
    {
        return $this->m_PdfSecurityOptions->getAnnotationsPermission();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfSecurityOptions.getAssembleDocumentPermission()]

      @return boolean
     */
    function getAssembleDocumentPermission()
    {
        return $this->m_PdfSecurityOptions->getAssembleDocumentPermission();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfSecurityOptions.getExtractContentPermission()]

      @return boolean
     */
    function getExtractContentPermission()
    {
        return $this->m_PdfSecurityOptions->getExtractContentPermission();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfSecurityOptions.getExtractContentPermissionObsolete()]

      @return boolean
     */
    function getExtractContentPermissionObsolete()
    {
        return $this->m_PdfSecurityOptions->getExtractContentPermissionObsolete();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfSecurityOptions.getFillFormsPermission()]

      @return boolean
     */
    function getFillFormsPermission()
    {
        return $this->m_PdfSecurityOptions->getFillFormsPermission();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfSecurityOptions.getFullQualityPrintPermission()]

      @return boolean
     */
    function getFullQualityPrintPermission()
    {
        return $this->m_PdfSecurityOptions->getFullQualityPrintPermission();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfSecurityOptions.getModifyDocumentPermission()]

      @return boolean
     */
    function getModifyDocumentPermission()
    {
        return $this->m_PdfSecurityOptions->getModifyDocumentPermission();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfSecurityOptions.getOwnerPassword()]

      @return String
     */
    function getOwnerPassword()
    {
        return $this->m_PdfSecurityOptions->getOwnerPassword();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfSecurityOptions.getPrintPermission()]

      @return boolean
     */
    function getPrintPermission()
    {
        return $this->m_PdfSecurityOptions->getPrintPermission();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfSecurityOptions.getUserPassword()]

      @return String
     */
    function getUserPassword()
    {
        return $this->m_PdfSecurityOptions->getUserPassword();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfSecurityOptions.setAnnotationsPermission(boolean)]

      @param pBoolean0  boolean
     */
    function setAnnotationsPermission($pBoolean0)
    {
        $this->m_PdfSecurityOptions->setAnnotationsPermission($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfSecurityOptions.setAssembleDocumentPermission(boolean)]

      @param pBoolean0  boolean
     */
    function setAssembleDocumentPermission($pBoolean0)
    {
        $this->m_PdfSecurityOptions->setAssembleDocumentPermission($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfSecurityOptions.setExtractContentPermission(boolean)]

      @param pBoolean0  boolean
     */
    function setExtractContentPermission($pBoolean0)
    {
        $this->m_PdfSecurityOptions->setExtractContentPermission($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfSecurityOptions.setExtractContentPermissionObsolete(boolean)]

      @param pBoolean0  boolean
     */
    function setExtractContentPermissionObsolete($pBoolean0)
    {
        $this->m_PdfSecurityOptions->setExtractContentPermissionObsolete($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfSecurityOptions.setFillFormsPermission(boolean)]

      @param pBoolean0  boolean
     */
    function setFillFormsPermission($pBoolean0)
    {
        $this->m_PdfSecurityOptions->setFillFormsPermission($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfSecurityOptions.setFullQualityPrintPermission(boolean)]

      @param pBoolean0  boolean
     */
    function setFullQualityPrintPermission($pBoolean0)
    {
        $this->m_PdfSecurityOptions->setFullQualityPrintPermission($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfSecurityOptions.setModifyDocumentPermission(boolean)]

      @param pBoolean0  boolean
     */
    function setModifyDocumentPermission($pBoolean0)
    {
        $this->m_PdfSecurityOptions->setModifyDocumentPermission($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfSecurityOptions.setOwnerPassword(String)]

      @param oString0  String
     */
    function setOwnerPassword($oString0)
    {
        $this->m_PdfSecurityOptions->setOwnerPassword($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfSecurityOptions.setPrintPermission(boolean)]

      @param pBoolean0  boolean
     */
    function setPrintPermission($pBoolean0)
    {
        $this->m_PdfSecurityOptions->setPrintPermission($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPdfSecurityOptions.setUserPassword(String)]

      @param oString0  String
     */
    function setUserPassword($oString0)
    {
        $this->m_PdfSecurityOptions->setUserPassword($oString0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsPicture]
  
 */
class Picture extends Shape
{
    public $m_Picture;
    
    function __construct($picture)
    {
    	$this->m_Picture = $picture;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsPicture.alignTopRightCorner(int, int)]

      @param pInt0  int
      @param pInt1  int
     */
    function alignTopRightCorner($pInt0, $pInt1)
    {
        $this->m_Picture->alignTopRightCorner($pInt0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPicture.getBorderLineColor()]

      @return com.aspose.cells.Color
     */
    function getBorderLineColor()
    {
        return ClassFactory::_t2($this->m_Picture->getBorderLineColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsPicture.getBorderWeight()]

      @return double
     */
    function getBorderWeight()
    {
        return $this->m_Picture->getBorderWeight();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPicture.getData()]

      @return byte[]
     */
    function getData()
    {
        return $this->m_Picture->getData();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPicture.getImageFormat()]

      @return com.aspose.cells.ImageFormat
     */
    function getImageFormat()
    {
        return ClassFactory::_t2($this->m_Picture->getImageFormat());
    }

    /*
      Wrapper for java version method [com.aspose.cellsPicture.getOriginalHeight()]

      @return int
     */
    function getOriginalHeight()
    {
        return $this->m_Picture->getOriginalHeight();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPicture.getOriginalWidth()]

      @return int
     */
    function getOriginalWidth()
    {
        return $this->m_Picture->getOriginalWidth();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPicture.getSourceFullName()]

      @return String
     */
    function getSourceFullName()
    {
        return $this->m_Picture->getSourceFullName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPicture.move(int, int)]

      @param pInt0  int
      @param pInt1  int
     */
    function move($pInt0, $pInt1)
    {
        $this->m_Picture->move($pInt0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPicture.setBorderLineColor(Color)]

      @param oColor0  com.aspose.cells.Color
     */
    function setBorderLineColor($oColor0)
    {
        $this->m_Picture->setBorderLineColor(ClassFactory::_t1($oColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsPicture.setBorderWeight(double)]

      @param pDouble0  double
     */
    function setBorderWeight($pDouble0)
    {
        $this->m_Picture->setBorderWeight($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPicture.setData(byte[])]

      @param arrP1DByte0  byte[]
     */
    function setData($arrP1DByte0)
    {
        $this->m_Picture->setData($arrP1DByte0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPicture.setSourceFullName(String)]

      @param oString0  String
     */
    function setSourceFullName($oString0)
    {
        $this->m_Picture->setSourceFullName($oString0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsPictureCollection]
  
 */
class PictureCollection extends CollectionBase
{
    public $m_PictureCollection;
    
    function __construct($pictureCollection)
    {
    	$this->m_PictureCollection = $pictureCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsPictureCollection.add(int, int, InputStream)]

      @param pInt0  int
      @param pInt1  int
      @param oInputStream2  corresponding java type is {java.io.InputStream}
      @return int
     */
    function add($pInt0, $pInt1, $oInputStream2)
    {
        return $this->m_PictureCollection->add($pInt0, $pInt1, ClassFactory::_t1($oInputStream2));
    }

    /*
      Wrapper for java version method [com.aspose.cellsPictureCollection.add(int, int, String)]

      @param pInt0  int
      @param pInt1  int
      @param oString2  String
      @return int
     */
    function addIIS($pInt0, $pInt1, $oString2)
    {
        return $this->m_PictureCollection->add($pInt0, $pInt1, $oString2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPictureCollection.add(int, int, InputStream, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param oInputStream2  corresponding java type is {java.io.InputStream}
      @param pInt3  int
      @param pInt4  int
      @return int
     */
    function addIIIII($pInt0, $pInt1, $oInputStream2, $pInt3, $pInt4)
    {
        return $this->m_PictureCollection->add($pInt0, $pInt1, ClassFactory::_t1($oInputStream2), $pInt3, $pInt4);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPictureCollection.add(int, int, String, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param oString2  String
      @param pInt3  int
      @param pInt4  int
      @return int
     */
    function addIISII($pInt0, $pInt1, $oString2, $pInt3, $pInt4)
    {
        return $this->m_PictureCollection->add($pInt0, $pInt1, $oString2, $pInt3, $pInt4);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPictureCollection.add(int, int, int, int, InputStream)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @param oInputStream4  corresponding java type is {java.io.InputStream}
      @return int
     */
    function addIIIII($pInt0, $pInt1, $pInt2, $pInt3, $oInputStream4)
    {
        return $this->m_PictureCollection->add($pInt0, $pInt1, $pInt2, $pInt3, ClassFactory::_t1($oInputStream4));
    }

    /*
      Wrapper for java version method [com.aspose.cellsPictureCollection.add(int, int, int, int, String)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @param oString4  String
      @return int
     */
    function addIIIIS($pInt0, $pInt1, $pInt2, $pInt3, $oString4)
    {
        return $this->m_PictureCollection->add($pInt0, $pInt1, $pInt2, $pInt3, $oString4);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPictureCollection.clear()]

     */
    function clear()
    {
        $this->m_PictureCollection->clear();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPictureCollection.get(int)]

      @param pInt0  int
      @return com.aspose.cells.Picture
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_PictureCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsPictureCollection.removeAt(int)]

      @param pInt0  int
     */
    function removeAt($pInt0)
    {
        $this->m_PictureCollection->removeAt($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsPivotField]
  
 */
class PivotField
{
    public $m_PivotField;
    
    function __construct($pivotField)
    {
    	$this->m_PivotField = $pivotField;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsPivotField.addCalculatedItem(String, String)]

      @param oString0  String
      @param oString1  String
     */
    function addCalculatedItem($oString0, $oString1)
    {
        $this->m_PivotField->addCalculatedItem($oString0, $oString1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.getAutoShowCount()]

      @return byte
     */
    function getAutoShowCount()
    {
        return $this->m_PivotField->getAutoShowCount();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.getAutoShowField()]

      @return int
     */
    function getAutoShowField()
    {
        return $this->m_PivotField->getAutoShowField();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.getAutoSortField()]

      @return int
     */
    function getAutoSortField()
    {
        return $this->m_PivotField->getAutoSortField();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.getBaseField()]

      @return int
     */
    function getBaseField()
    {
        return $this->m_PivotField->getBaseField();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.getBaseItem()]

      @return int
     */
    function getBaseItem()
    {
        return $this->m_PivotField->getBaseItem();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.getBaseItemPostion()]

      @return int
     */
    function getBaseItemPostion()
    {
        return $this->m_PivotField->getBaseItemPostion();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.getCurrentPageItem()]

      @return short
     */
    function getCurrentPageItem()
    {
        return $this->m_PivotField->getCurrentPageItem();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.getDataDisplayFormat()]

      @return int
     */
    function getDataDisplayFormat()
    {
        return $this->m_PivotField->getDataDisplayFormat();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.getDisplayName()]

      @return String
     */
    function getDisplayName()
    {
        return $this->m_PivotField->getDisplayName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.getDragToColumn()]

      @return boolean
     */
    function getDragToColumn()
    {
        return $this->m_PivotField->getDragToColumn();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.getDragToHide()]

      @return boolean
     */
    function getDragToHide()
    {
        return $this->m_PivotField->getDragToHide();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.getDragToPage()]

      @return boolean
     */
    function getDragToPage()
    {
        return $this->m_PivotField->getDragToPage();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.getDragToRow()]

      @return boolean
     */
    function getDragToRow()
    {
        return $this->m_PivotField->getDragToRow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.getFunction()]

      @return int
     */
    function getFunction()
    {
        return $this->m_PivotField->getFunction();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.getInsertBlankRow()]

      @return boolean
     */
    function getInsertBlankRow()
    {
        return $this->m_PivotField->getInsertBlankRow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.getItemCount()]

      @return int
     */
    function getItemCount()
    {
        return $this->m_PivotField->getItemCount();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.getItems()]

      @return array, corresponding java type is {String[]}
     */
    function getItems()
    {
        return $this->m_PivotField->getItems();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.getName()]

      @return String
     */
    function getName()
    {
        return $this->m_PivotField->getName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.getNumber()]

      @return int
     */
    function getNumber()
    {
        return $this->m_PivotField->getNumber();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.getNumberFormat()]

      @return String
     */
    function getNumberFormat()
    {
        return $this->m_PivotField->getNumberFormat();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.getPivotItems()]

      @return com.aspose.cells.PivotItemCollection
     */
    function getPivotItems()
    {
        return ClassFactory::_t2($this->m_PivotField->getPivotItems());
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.getPosition()]

      @return int
     */
    function getPosition()
    {
        return $this->m_PivotField->getPosition();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.getShowAllItems()]

      @return boolean
     */
    function getShowAllItems()
    {
        return $this->m_PivotField->getShowAllItems();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.getShowCompact()]

      @return boolean
     */
    function getShowCompact()
    {
        return $this->m_PivotField->getShowCompact();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.getShowInOutlineForm()]

      @return boolean
     */
    function getShowInOutlineForm()
    {
        return $this->m_PivotField->getShowInOutlineForm();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.getShowSubtotalAtTop()]

      @return boolean
     */
    function getShowSubtotalAtTop()
    {
        return $this->m_PivotField->getShowSubtotalAtTop();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.getSubtotals(int)]

      @param pInt0  int
      @return boolean
     */
    function getSubtotals($pInt0)
    {
        return $this->m_PivotField->getSubtotals($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.hideDetail(boolean)]

      @param pBoolean0  boolean
     */
    function hideDetail($pBoolean0)
    {
        $this->m_PivotField->hideDetail($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.hideItem(String, boolean)]

      @param oString0  String
      @param pBoolean1  boolean
     */
    function hideItem($oString0, $pBoolean1)
    {
        $this->m_PivotField->hideItem($oString0, $pBoolean1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.hideItem(int, boolean)]

      @param pInt0  int
      @param pBoolean1  boolean
     */
    function hideItemIB($pInt0, $pBoolean1)
    {
        $this->m_PivotField->hideItem($pInt0, $pBoolean1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.hideItemDetail(int, boolean)]

      @param pInt0  int
      @param pBoolean1  boolean
     */
    function hideItemDetail($pInt0, $pBoolean1)
    {
        $this->m_PivotField->hideItemDetail($pInt0, $pBoolean1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.isAscendShow()]

      @return boolean
     */
    function isAscendShow()
    {
        return $this->m_PivotField->isAscendShow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.isAscendSort()]

      @return boolean
     */
    function isAscendSort()
    {
        return $this->m_PivotField->isAscendSort();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.isAutoShow()]

      @return boolean
     */
    function isAutoShow()
    {
        return $this->m_PivotField->isAutoShow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.isAutoSort()]

      @return boolean
     */
    function isAutoSort()
    {
        return $this->m_PivotField->isAutoSort();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.isAutoSubtotals()]

      @return boolean
     */
    function isAutoSubtotals()
    {
        return $this->m_PivotField->isAutoSubtotals();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.isHiddenItem(int)]

      @param pInt0  int
      @return boolean
     */
    function isHiddenItem($pInt0)
    {
        return $this->m_PivotField->isHiddenItem($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.isHiddenItemDetail(int)]

      @param pInt0  int
      @return boolean
     */
    function isHiddenItemDetail($pInt0)
    {
        return $this->m_PivotField->isHiddenItemDetail($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.isMultipleItemSelectionAllowed()]

      @return boolean
     */
    function isMultipleItemSelectionAllowed()
    {
        return $this->m_PivotField->isMultipleItemSelectionAllowed();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.setAscendShow(boolean)]

      @param pBoolean0  boolean
     */
    function setAscendShow($pBoolean0)
    {
        $this->m_PivotField->setAscendShow($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.setAscendSort(boolean)]

      @param pBoolean0  boolean
     */
    function setAscendSort($pBoolean0)
    {
        $this->m_PivotField->setAscendSort($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.setAutoShow(boolean)]

      @param pBoolean0  boolean
     */
    function setAutoShow($pBoolean0)
    {
        $this->m_PivotField->setAutoShow($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.setAutoShowCount(byte)]

      @param pByte0  byte
     */
    function setAutoShowCount($pByte0)
    {
        $this->m_PivotField->setAutoShowCount($pByte0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.setAutoShowField(int)]

      @param pInt0  int
     */
    function setAutoShowField($pInt0)
    {
        $this->m_PivotField->setAutoShowField($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.setAutoSort(boolean)]

      @param pBoolean0  boolean
     */
    function setAutoSort($pBoolean0)
    {
        $this->m_PivotField->setAutoSort($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.setAutoSortField(int)]

      @param pInt0  int
     */
    function setAutoSortField($pInt0)
    {
        $this->m_PivotField->setAutoSortField($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.setAutoSubtotals(boolean)]

      @param pBoolean0  boolean
     */
    function setAutoSubtotals($pBoolean0)
    {
        $this->m_PivotField->setAutoSubtotals($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.setBaseField(int)]

      @param pInt0  int
     */
    function setBaseField($pInt0)
    {
        $this->m_PivotField->setBaseField($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.setBaseItem(int)]

      @param pInt0  int
     */
    function setBaseItem($pInt0)
    {
        $this->m_PivotField->setBaseItem($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.setBaseItemPostion(int)]

      @param pInt0  int
     */
    function setBaseItemPostion($pInt0)
    {
        $this->m_PivotField->setBaseItemPostion($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.setCurrentPageItem(short)]

      @param pShort0  short
     */
    function setCurrentPageItem($pShort0)
    {
        $this->m_PivotField->setCurrentPageItem($pShort0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.setDataDisplayFormat(int)]

      @param pInt0  int
     */
    function setDataDisplayFormat($pInt0)
    {
        $this->m_PivotField->setDataDisplayFormat($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.setDisplayName(String)]

      @param oString0  String
     */
    function setDisplayName($oString0)
    {
        $this->m_PivotField->setDisplayName($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.setDragToColumn(boolean)]

      @param pBoolean0  boolean
     */
    function setDragToColumn($pBoolean0)
    {
        $this->m_PivotField->setDragToColumn($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.setDragToHide(boolean)]

      @param pBoolean0  boolean
     */
    function setDragToHide($pBoolean0)
    {
        $this->m_PivotField->setDragToHide($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.setDragToPage(boolean)]

      @param pBoolean0  boolean
     */
    function setDragToPage($pBoolean0)
    {
        $this->m_PivotField->setDragToPage($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.setDragToRow(boolean)]

      @param pBoolean0  boolean
     */
    function setDragToRow($pBoolean0)
    {
        $this->m_PivotField->setDragToRow($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.setFunction(int)]

      @param pInt0  int
     */
    function setFunction($pInt0)
    {
        $this->m_PivotField->setFunction($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.setInsertBlankRow(boolean)]

      @param pBoolean0  boolean
     */
    function setInsertBlankRow($pBoolean0)
    {
        $this->m_PivotField->setInsertBlankRow($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.setMultipleItemSelectionAllowed(boolean)]

      @param pBoolean0  boolean
     */
    function setMultipleItemSelectionAllowed($pBoolean0)
    {
        $this->m_PivotField->setMultipleItemSelectionAllowed($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.setNumber(int)]

      @param pInt0  int
     */
    function setNumber($pInt0)
    {
        $this->m_PivotField->setNumber($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.setNumberFormat(String)]

      @param oString0  String
     */
    function setNumberFormat($oString0)
    {
        $this->m_PivotField->setNumberFormat($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.setShowAllItems(boolean)]

      @param pBoolean0  boolean
     */
    function setShowAllItems($pBoolean0)
    {
        $this->m_PivotField->setShowAllItems($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.setShowCompact(boolean)]

      @param pBoolean0  boolean
     */
    function setShowCompact($pBoolean0)
    {
        $this->m_PivotField->setShowCompact($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.setShowInOutlineForm(boolean)]

      @param pBoolean0  boolean
     */
    function setShowInOutlineForm($pBoolean0)
    {
        $this->m_PivotField->setShowInOutlineForm($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.setShowSubtotalAtTop(boolean)]

      @param pBoolean0  boolean
     */
    function setShowSubtotalAtTop($pBoolean0)
    {
        $this->m_PivotField->setShowSubtotalAtTop($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotField.setSubtotals(int, boolean)]

      @param pInt0  int
      @param pBoolean1  boolean
     */
    function setSubtotals($pInt0, $pBoolean1)
    {
        $this->m_PivotField->setSubtotals($pInt0, $pBoolean1);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsPivotFieldCollection]
  
 */
class PivotFieldCollection
{
    public $m_PivotFieldCollection;
    
    function __construct($pivotFieldCollection)
    {
    	$this->m_PivotFieldCollection = $pivotFieldCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsPivotFieldCollection.add(PivotField)]

      @param oPivotField0  com.aspose.cells.PivotField
      @return int
     */
    function add($oPivotField0)
    {
        return $this->m_PivotFieldCollection->add(ClassFactory::_t1($oPivotField0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotFieldCollection.addByBaseIndex(int)]

      @param pInt0  int
      @return int
     */
    function addByBaseIndex($pInt0)
    {
        return $this->m_PivotFieldCollection->addByBaseIndex($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotFieldCollection.get(int)]

      @param pInt0  int
      @return com.aspose.cells.PivotField
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_PivotFieldCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotFieldCollection.getCount()]

      @return int
     */
    function getCount()
    {
        return $this->m_PivotFieldCollection->getCount();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotFieldCollection.getType()]

      @return int
     */
    function getType()
    {
        return $this->m_PivotFieldCollection->getType();
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsPivotFieldDataDisplayFormat]
  
 */
class PivotFieldDataDisplayFormat
{
    public $m_PivotFieldDataDisplayFormat;
    
    function __construct($pivotFieldDataDisplayFormat)
    {
    	$this->m_PivotFieldDataDisplayFormat = $pivotFieldDataDisplayFormat;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsPivotFieldSubtotalType]
  
 */
class PivotFieldSubtotalType
{
    public $m_PivotFieldSubtotalType;
    
    function __construct($pivotFieldSubtotalType)
    {
    	$this->m_PivotFieldSubtotalType = $pivotFieldSubtotalType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsPivotFieldType]
  
 */
class PivotFieldType
{
    public $m_PivotFieldType;
    
    function __construct($pivotFieldType)
    {
    	$this->m_PivotFieldType = $pivotFieldType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsPivotGroupByType]
  
 */
class PivotGroupByType
{
    public $m_PivotGroupByType;
    
    function __construct($pivotGroupByType)
    {
    	$this->m_PivotGroupByType = $pivotGroupByType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsPivotItem]
  
 */
class PivotItem
{
    public $m_PivotItem;
    
    function __construct($pivotItem)
    {
    	$this->m_PivotItem = $pivotItem;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsPivotItem.getIndex()]

      @return int
     */
    function getIndex()
    {
        return $this->m_PivotItem->getIndex();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotItem.getName()]

      @return String
     */
    function getName()
    {
        return $this->m_PivotItem->getName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotItem.getValue()]

      @return corresponding java type is {java.lang.Object}
     */
    function getValue()
    {
        return ClassFactory::_t2($this->m_PivotItem->getValue());
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotItem.move(int)]

      @param pInt0  int
     */
    function move($pInt0)
    {
        $this->m_PivotItem->move($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotItem.setIndex(int)]

      @param pInt0  int
     */
    function setIndex($pInt0)
    {
        $this->m_PivotItem->setIndex($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsPivotItemCollection]
  
 */
class PivotItemCollection
{
    public $m_PivotItemCollection;
    
    function __construct($pivotItemCollection)
    {
    	$this->m_PivotItemCollection = $pivotItemCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsPivotItemCollection.changeitemsOrder(int, int)]

      @param pInt0  int
      @param pInt1  int
     */
    function changeitemsOrder($pInt0, $pInt1)
    {
        $this->m_PivotItemCollection->changeitemsOrder($pInt0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotItemCollection.get(String)]

      @param oString0  String
      @return com.aspose.cells.PivotItem
     */
    function get($oString0)
    {
        return ClassFactory::_t2($this->m_PivotItemCollection->get($oString0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotItemCollection.get(int)]

      @param pInt0  int
      @return com.aspose.cells.PivotItem
     */
    function getI($pInt0)
    {
        return ClassFactory::_t2($this->m_PivotItemCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotItemCollection.getCount()]

      @return int
     */
    function getCount()
    {
        return $this->m_PivotItemCollection->getCount();
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsPivotItemPosition]
  
 */
class PivotItemPosition
{
    public $m_PivotItemPosition;
    
    function __construct($pivotItemPosition)
    {
    	$this->m_PivotItemPosition = $pivotItemPosition;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsPivotPageFields]
  
 */
class PivotPageFields
{
    public $m_PivotPageFields;
    
    function __construct($pivotPageFields)
    {
    	$this->m_PivotPageFields = $pivotPageFields;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsPivotPageFields.addIdentify(int, int[])]

      @param pInt0  int
      @param arrP1DInt1  int[]
     */
    function addIdentify($pInt0, $arrP1DInt1)
    {
        $this->m_PivotPageFields->addIdentify($pInt0, $arrP1DInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotPageFields.addPageField(String[])]

      @param arrD1DString0  array, corresponding java type is {String[]}
     */
    function addPageField($arrD1DString0)
    {
        $this->m_PivotPageFields->addPageField($arrD1DString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotPageFields.getPageFieldCount()]

      @return int
     */
    function getPageFieldCount()
    {
        return $this->m_PivotPageFields->getPageFieldCount();
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsPivotTable]
  
 */
class PivotTable
{
    public $m_PivotTable;
    
    function __construct($pivotTable)
    {
    	$this->m_PivotTable = $pivotTable;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.addCalculatedField(String, String)]

      @param oString0  String
      @param oString1  String
     */
    function addCalculatedField($oString0, $oString1)
    {
        $this->m_PivotTable->addCalculatedField($oString0, $oString1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.addCalculatedField(String, String, boolean)]

      @param oString0  String
      @param oString1  String
      @param pBoolean2  boolean
     */
    function addCalculatedFieldSSB($oString0, $oString1, $pBoolean2)
    {
        $this->m_PivotTable->addCalculatedField($oString0, $oString1, $pBoolean2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.addFieldToArea(int, PivotField)]

      @param pInt0  int
      @param oPivotField1  com.aspose.cells.PivotField
      @return int
     */
    function addFieldToArea($pInt0, $oPivotField1)
    {
        return $this->m_PivotTable->addFieldToArea($pInt0, ClassFactory::_t1($oPivotField1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.addFieldToArea(int, String)]

      @param pInt0  int
      @param oString1  String
      @return int
     */
    function addFieldToAreaIS($pInt0, $oString1)
    {
        return $this->m_PivotTable->addFieldToArea($pInt0, $oString1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.addFieldToArea(int, int)]

      @param pInt0  int
      @param pInt1  int
      @return int
     */
    function addFieldToAreaII($pInt0, $pInt1)
    {
        return $this->m_PivotTable->addFieldToArea($pInt0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.calculateData()]

     */
    function calculateData()
    {
        $this->m_PivotTable->calculateData();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.calculateRange()]

     */
    function calculateRange()
    {
        $this->m_PivotTable->calculateRange();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.fields(int)]

      @param pInt0  int
      @return com.aspose.cells.PivotFieldCollection
     */
    function fields($pInt0)
    {
        return ClassFactory::_t2($this->m_PivotTable->fields($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.format(int, int, Style)]

      @param pInt0  int
      @param pInt1  int
      @param oStyle2  com.aspose.cells.Style
     */
    function format($pInt0, $pInt1, $oStyle2)
    {
        $this->m_PivotTable->format($pInt0, $pInt1, ClassFactory::_t1($oStyle2));
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.formatAll(Style)]

      @param oStyle0  com.aspose.cells.Style
     */
    function formatAll($oStyle0)
    {
        $this->m_PivotTable->formatAll(ClassFactory::_t1($oStyle0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getAutoFormatType()]

      @return int
     */
    function getAutoFormatType()
    {
        return $this->m_PivotTable->getAutoFormatType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getBaseFields()]

      @return com.aspose.cells.PivotFieldCollection
     */
    function getBaseFields()
    {
        return ClassFactory::_t2($this->m_PivotTable->getBaseFields());
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getColumnFields()]

      @return com.aspose.cells.PivotFieldCollection
     */
    function getColumnFields()
    {
        return ClassFactory::_t2($this->m_PivotTable->getColumnFields());
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getColumnGrand()]

      @return boolean
     */
    function getColumnGrand()
    {
        return $this->m_PivotTable->getColumnGrand();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getColumnHeaderCaption()]

      @return String
     */
    function getColumnHeaderCaption()
    {
        return $this->m_PivotTable->getColumnHeaderCaption();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getColumnRange()]

      @return com.aspose.cells.CellArea
     */
    function getColumnRange()
    {
        return ClassFactory::_t2($this->m_PivotTable->getColumnRange());
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getCustomListSort()]

      @return boolean
     */
    function getCustomListSort()
    {
        return $this->m_PivotTable->getCustomListSort();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getDataBodyRange()]

      @return com.aspose.cells.CellArea
     */
    function getDataBodyRange()
    {
        return ClassFactory::_t2($this->m_PivotTable->getDataBodyRange());
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getDataField()]

      @return com.aspose.cells.PivotField
     */
    function getDataField()
    {
        return ClassFactory::_t2($this->m_PivotTable->getDataField());
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getDataFields()]

      @return com.aspose.cells.PivotFieldCollection
     */
    function getDataFields()
    {
        return ClassFactory::_t2($this->m_PivotTable->getDataFields());
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getDisplayErrorString()]

      @return boolean
     */
    function getDisplayErrorString()
    {
        return $this->m_PivotTable->getDisplayErrorString();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getDisplayImmediateItems()]

      @return boolean
     */
    function getDisplayImmediateItems()
    {
        return $this->m_PivotTable->getDisplayImmediateItems();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getDisplayNullString()]

      @return boolean
     */
    function getDisplayNullString()
    {
        return $this->m_PivotTable->getDisplayNullString();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getEnableDrilldown()]

      @return boolean
     */
    function getEnableDrilldown()
    {
        return $this->m_PivotTable->getEnableDrilldown();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getEnableFieldDialog()]

      @return boolean
     */
    function getEnableFieldDialog()
    {
        return $this->m_PivotTable->getEnableFieldDialog();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getEnableFieldList()]

      @return boolean
     */
    function getEnableFieldList()
    {
        return $this->m_PivotTable->getEnableFieldList();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getEnableWizard()]

      @return boolean
     */
    function getEnableWizard()
    {
        return $this->m_PivotTable->getEnableWizard();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getErrorString()]

      @return String
     */
    function getErrorString()
    {
        return $this->m_PivotTable->getErrorString();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getItemPrintTitles()]

      @return boolean
     */
    function getItemPrintTitles()
    {
        return $this->m_PivotTable->getItemPrintTitles();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getManualUpdate()]

      @return boolean
     */
    function getManualUpdate()
    {
        return $this->m_PivotTable->getManualUpdate();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getMergeLabels()]

      @return boolean
     */
    function getMergeLabels()
    {
        return $this->m_PivotTable->getMergeLabels();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getName()]

      @return String
     */
    function getName()
    {
        return $this->m_PivotTable->getName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getNullString()]

      @return String
     */
    function getNullString()
    {
        return $this->m_PivotTable->getNullString();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getPageFieldOrder()]

      @return int
     */
    function getPageFieldOrder()
    {
        return $this->m_PivotTable->getPageFieldOrder();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getPageFieldWrapCount()]

      @return int
     */
    function getPageFieldWrapCount()
    {
        return $this->m_PivotTable->getPageFieldWrapCount();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getPageFields()]

      @return com.aspose.cells.PivotFieldCollection
     */
    function getPageFields()
    {
        return ClassFactory::_t2($this->m_PivotTable->getPageFields());
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getPivotTableStyleName()]

      @return String
     */
    function getPivotTableStyleName()
    {
        return $this->m_PivotTable->getPivotTableStyleName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getPivotTableStyleType()]

      @return int
     */
    function getPivotTableStyleType()
    {
        return $this->m_PivotTable->getPivotTableStyleType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getPreserveFormatting()]

      @return boolean
     */
    function getPreserveFormatting()
    {
        return $this->m_PivotTable->getPreserveFormatting();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getPrintTitles()]

      @return boolean
     */
    function getPrintTitles()
    {
        return $this->m_PivotTable->getPrintTitles();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getRefreshDataFlag()]

      @return boolean
     */
    function getRefreshDataFlag()
    {
        return $this->m_PivotTable->getRefreshDataFlag();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getRefreshDataOnOpeningFile()]

      @return boolean
     */
    function getRefreshDataOnOpeningFile()
    {
        return $this->m_PivotTable->getRefreshDataOnOpeningFile();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getRowFields()]

      @return com.aspose.cells.PivotFieldCollection
     */
    function getRowFields()
    {
        return ClassFactory::_t2($this->m_PivotTable->getRowFields());
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getRowGrand()]

      @return boolean
     */
    function getRowGrand()
    {
        return $this->m_PivotTable->getRowGrand();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getRowHeaderCaption()]

      @return String
     */
    function getRowHeaderCaption()
    {
        return $this->m_PivotTable->getRowHeaderCaption();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getRowRange()]

      @return com.aspose.cells.CellArea
     */
    function getRowRange()
    {
        return ClassFactory::_t2($this->m_PivotTable->getRowRange());
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getSaveData()]

      @return boolean
     */
    function getSaveData()
    {
        return $this->m_PivotTable->getSaveData();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getShowDrill()]

      @return boolean
     */
    function getShowDrill()
    {
        return $this->m_PivotTable->getShowDrill();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getShowPivotStyleColumnHeader()]

      @return boolean
     */
    function getShowPivotStyleColumnHeader()
    {
        return $this->m_PivotTable->getShowPivotStyleColumnHeader();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getShowPivotStyleColumnStripes()]

      @return boolean
     */
    function getShowPivotStyleColumnStripes()
    {
        return $this->m_PivotTable->getShowPivotStyleColumnStripes();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getShowPivotStyleLastColumn()]

      @return boolean
     */
    function getShowPivotStyleLastColumn()
    {
        return $this->m_PivotTable->getShowPivotStyleLastColumn();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getShowPivotStyleRowHeader()]

      @return boolean
     */
    function getShowPivotStyleRowHeader()
    {
        return $this->m_PivotTable->getShowPivotStyleRowHeader();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getShowPivotStyleRowStripes()]

      @return boolean
     */
    function getShowPivotStyleRowStripes()
    {
        return $this->m_PivotTable->getShowPivotStyleRowStripes();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getShowRowHeaderCaption()]

      @return boolean
     */
    function getShowRowHeaderCaption()
    {
        return $this->m_PivotTable->getShowRowHeaderCaption();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getSource()]

      @return array, corresponding java type is {String[]}
     */
    function getSource()
    {
        return $this->m_PivotTable->getSource();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getSubtotalHiddenPageItems()]

      @return boolean
     */
    function getSubtotalHiddenPageItems()
    {
        return $this->m_PivotTable->getSubtotalHiddenPageItems();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getTableRange1()]

      @return com.aspose.cells.CellArea
     */
    function getTableRange1()
    {
        return ClassFactory::_t2($this->m_PivotTable->getTableRange1());
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getTableRange2()]

      @return com.aspose.cells.CellArea
     */
    function getTableRange2()
    {
        return ClassFactory::_t2($this->m_PivotTable->getTableRange2());
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.getTag()]

      @return String
     */
    function getTag()
    {
        return $this->m_PivotTable->getTag();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.hasBlankRows()]

      @return boolean
     */
    function hasBlankRows()
    {
        return $this->m_PivotTable->hasBlankRows();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.isAutoFormat()]

      @return boolean
     */
    function isAutoFormat()
    {
        return $this->m_PivotTable->isAutoFormat();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.isGridDropZones()]

      @return boolean
     */
    function isGridDropZones()
    {
        return $this->m_PivotTable->isGridDropZones();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.isSelected()]

      @return boolean
     */
    function isSelected()
    {
        return $this->m_PivotTable->isSelected();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.move(String)]

      @param oString0  String
     */
    function move($oString0)
    {
        $this->m_PivotTable->move($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.move(int, int)]

      @param pInt0  int
      @param pInt1  int
     */
    function moveII($pInt0, $pInt1)
    {
        $this->m_PivotTable->move($pInt0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.refreshData()]

     */
    function refreshData()
    {
        $this->m_PivotTable->refreshData();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.removeField(int, PivotField)]

      @param pInt0  int
      @param oPivotField1  com.aspose.cells.PivotField
     */
    function removeField($pInt0, $oPivotField1)
    {
        $this->m_PivotTable->removeField($pInt0, ClassFactory::_t1($oPivotField1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.removeField(int, String)]

      @param pInt0  int
      @param oString1  String
     */
    function removeFieldIS($pInt0, $oString1)
    {
        $this->m_PivotTable->removeField($pInt0, $oString1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.removeField(int, int)]

      @param pInt0  int
      @param pInt1  int
     */
    function removeFieldII($pInt0, $pInt1)
    {
        $this->m_PivotTable->removeField($pInt0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setAutoFormat(boolean)]

      @param pBoolean0  boolean
     */
    function setAutoFormat($pBoolean0)
    {
        $this->m_PivotTable->setAutoFormat($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setAutoFormatType(int)]

      @param pInt0  int
     */
    function setAutoFormatType($pInt0)
    {
        $this->m_PivotTable->setAutoFormatType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setAutoGroupField(PivotField)]

      @param oPivotField0  com.aspose.cells.PivotField
     */
    function setAutoGroupField($oPivotField0)
    {
        $this->m_PivotTable->setAutoGroupField(ClassFactory::_t1($oPivotField0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setAutoGroupField(int)]

      @param pInt0  int
     */
    function setAutoGroupFieldI($pInt0)
    {
        $this->m_PivotTable->setAutoGroupField($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setColumnGrand(boolean)]

      @param pBoolean0  boolean
     */
    function setColumnGrand($pBoolean0)
    {
        $this->m_PivotTable->setColumnGrand($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setColumnHeaderCaption(String)]

      @param oString0  String
     */
    function setColumnHeaderCaption($oString0)
    {
        $this->m_PivotTable->setColumnHeaderCaption($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setCustomListSort(boolean)]

      @param pBoolean0  boolean
     */
    function setCustomListSort($pBoolean0)
    {
        $this->m_PivotTable->setCustomListSort($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setDisplayErrorString(boolean)]

      @param pBoolean0  boolean
     */
    function setDisplayErrorString($pBoolean0)
    {
        $this->m_PivotTable->setDisplayErrorString($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setDisplayImmediateItems(boolean)]

      @param pBoolean0  boolean
     */
    function setDisplayImmediateItems($pBoolean0)
    {
        $this->m_PivotTable->setDisplayImmediateItems($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setDisplayNullString(boolean)]

      @param pBoolean0  boolean
     */
    function setDisplayNullString($pBoolean0)
    {
        $this->m_PivotTable->setDisplayNullString($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setEnableDrilldown(boolean)]

      @param pBoolean0  boolean
     */
    function setEnableDrilldown($pBoolean0)
    {
        $this->m_PivotTable->setEnableDrilldown($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setEnableFieldDialog(boolean)]

      @param pBoolean0  boolean
     */
    function setEnableFieldDialog($pBoolean0)
    {
        $this->m_PivotTable->setEnableFieldDialog($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setEnableFieldList(boolean)]

      @param pBoolean0  boolean
     */
    function setEnableFieldList($pBoolean0)
    {
        $this->m_PivotTable->setEnableFieldList($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setEnableWizard(boolean)]

      @param pBoolean0  boolean
     */
    function setEnableWizard($pBoolean0)
    {
        $this->m_PivotTable->setEnableWizard($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setErrorString(String)]

      @param oString0  String
     */
    function setErrorString($oString0)
    {
        $this->m_PivotTable->setErrorString($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setGridDropZones(boolean)]

      @param pBoolean0  boolean
     */
    function setGridDropZones($pBoolean0)
    {
        $this->m_PivotTable->setGridDropZones($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setHasBlankRows(boolean)]

      @param pBoolean0  boolean
     */
    function setHasBlankRows($pBoolean0)
    {
        $this->m_PivotTable->setHasBlankRows($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setItemPrintTitles(boolean)]

      @param pBoolean0  boolean
     */
    function setItemPrintTitles($pBoolean0)
    {
        $this->m_PivotTable->setItemPrintTitles($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setManualGroupField(PivotField, DateTime, DateTime, ArrayList, int)]

      @param oPivotField0  com.aspose.cells.PivotField
      @param oDateTime1  com.aspose.cells.DateTime
      @param oDateTime2  com.aspose.cells.DateTime
      @param arrA1DFromArrayList3  array, corresponding java type is {java.util.ArrayList}
      @param pInt4  int
     */
    function setManualGroupField($oPivotField0, $oDateTime1, $oDateTime2, $arrA1DFromArrayList3, $pInt4)
    {
        $this->m_PivotTable->setManualGroupField(ClassFactory::_t1($oPivotField0), ClassFactory::_t1($oDateTime1), ClassFactory::_t1($oDateTime2), ClassFactory::_t1($arrA1DFromArrayList3), $pInt4);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setManualGroupField(PivotField, double, double, ArrayList, double)]

      @param oPivotField0  com.aspose.cells.PivotField
      @param pDouble1  double
      @param pDouble2  double
      @param arrA1DFromArrayList3  array, corresponding java type is {java.util.ArrayList}
      @param pDouble4  double
     */
    function setManualGroupFieldPDDAD($oPivotField0, $pDouble1, $pDouble2, $arrA1DFromArrayList3, $pDouble4)
    {
        $this->m_PivotTable->setManualGroupField(ClassFactory::_t1($oPivotField0), $pDouble1, $pDouble2, ClassFactory::_t1($arrA1DFromArrayList3), $pDouble4);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setManualGroupField(int, DateTime, DateTime, ArrayList, int)]

      @param pInt0  int
      @param oDateTime1  com.aspose.cells.DateTime
      @param oDateTime2  com.aspose.cells.DateTime
      @param arrA1DFromArrayList3  array, corresponding java type is {java.util.ArrayList}
      @param pInt4  int
     */
    function setManualGroupFieldIDDAI($pInt0, $oDateTime1, $oDateTime2, $arrA1DFromArrayList3, $pInt4)
    {
        $this->m_PivotTable->setManualGroupField($pInt0, ClassFactory::_t1($oDateTime1), ClassFactory::_t1($oDateTime2), ClassFactory::_t1($arrA1DFromArrayList3), $pInt4);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setManualGroupField(int, double, double, ArrayList, double)]

      @param pInt0  int
      @param pDouble1  double
      @param pDouble2  double
      @param arrA1DFromArrayList3  array, corresponding java type is {java.util.ArrayList}
      @param pDouble4  double
     */
    function setManualGroupFieldIDDAD($pInt0, $pDouble1, $pDouble2, $arrA1DFromArrayList3, $pDouble4)
    {
        $this->m_PivotTable->setManualGroupField($pInt0, $pDouble1, $pDouble2, ClassFactory::_t1($arrA1DFromArrayList3), $pDouble4);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setManualUpdate(boolean)]

      @param pBoolean0  boolean
     */
    function setManualUpdate($pBoolean0)
    {
        $this->m_PivotTable->setManualUpdate($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setMergeLabels(boolean)]

      @param pBoolean0  boolean
     */
    function setMergeLabels($pBoolean0)
    {
        $this->m_PivotTable->setMergeLabels($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setName(String)]

      @param oString0  String
     */
    function setName($oString0)
    {
        $this->m_PivotTable->setName($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setNullString(String)]

      @param oString0  String
     */
    function setNullString($oString0)
    {
        $this->m_PivotTable->setNullString($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setPageFieldOrder(int)]

      @param pInt0  int
     */
    function setPageFieldOrder($pInt0)
    {
        $this->m_PivotTable->setPageFieldOrder($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setPageFieldWrapCount(int)]

      @param pInt0  int
     */
    function setPageFieldWrapCount($pInt0)
    {
        $this->m_PivotTable->setPageFieldWrapCount($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setPivotTableStyleName(String)]

      @param oString0  String
     */
    function setPivotTableStyleName($oString0)
    {
        $this->m_PivotTable->setPivotTableStyleName($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setPivotTableStyleType(int)]

      @param pInt0  int
     */
    function setPivotTableStyleType($pInt0)
    {
        $this->m_PivotTable->setPivotTableStyleType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setPreserveFormatting(boolean)]

      @param pBoolean0  boolean
     */
    function setPreserveFormatting($pBoolean0)
    {
        $this->m_PivotTable->setPreserveFormatting($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setPrintTitles(boolean)]

      @param pBoolean0  boolean
     */
    function setPrintTitles($pBoolean0)
    {
        $this->m_PivotTable->setPrintTitles($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setRefreshDataFlag(boolean)]

      @param pBoolean0  boolean
     */
    function setRefreshDataFlag($pBoolean0)
    {
        $this->m_PivotTable->setRefreshDataFlag($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setRefreshDataOnOpeningFile(boolean)]

      @param pBoolean0  boolean
     */
    function setRefreshDataOnOpeningFile($pBoolean0)
    {
        $this->m_PivotTable->setRefreshDataOnOpeningFile($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setRowGrand(boolean)]

      @param pBoolean0  boolean
     */
    function setRowGrand($pBoolean0)
    {
        $this->m_PivotTable->setRowGrand($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setRowHeaderCaption(String)]

      @param oString0  String
     */
    function setRowHeaderCaption($oString0)
    {
        $this->m_PivotTable->setRowHeaderCaption($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setSaveData(boolean)]

      @param pBoolean0  boolean
     */
    function setSaveData($pBoolean0)
    {
        $this->m_PivotTable->setSaveData($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setSelected(boolean)]

      @param pBoolean0  boolean
     */
    function setSelected($pBoolean0)
    {
        $this->m_PivotTable->setSelected($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setShowDrill(boolean)]

      @param pBoolean0  boolean
     */
    function setShowDrill($pBoolean0)
    {
        $this->m_PivotTable->setShowDrill($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setShowPivotStyleColumnHeader(boolean)]

      @param pBoolean0  boolean
     */
    function setShowPivotStyleColumnHeader($pBoolean0)
    {
        $this->m_PivotTable->setShowPivotStyleColumnHeader($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setShowPivotStyleColumnStripes(boolean)]

      @param pBoolean0  boolean
     */
    function setShowPivotStyleColumnStripes($pBoolean0)
    {
        $this->m_PivotTable->setShowPivotStyleColumnStripes($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setShowPivotStyleLastColumn(boolean)]

      @param pBoolean0  boolean
     */
    function setShowPivotStyleLastColumn($pBoolean0)
    {
        $this->m_PivotTable->setShowPivotStyleLastColumn($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setShowPivotStyleRowHeader(boolean)]

      @param pBoolean0  boolean
     */
    function setShowPivotStyleRowHeader($pBoolean0)
    {
        $this->m_PivotTable->setShowPivotStyleRowHeader($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setShowPivotStyleRowStripes(boolean)]

      @param pBoolean0  boolean
     */
    function setShowPivotStyleRowStripes($pBoolean0)
    {
        $this->m_PivotTable->setShowPivotStyleRowStripes($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setShowRowHeaderCaption(boolean)]

      @param pBoolean0  boolean
     */
    function setShowRowHeaderCaption($pBoolean0)
    {
        $this->m_PivotTable->setShowRowHeaderCaption($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setSubtotalHiddenPageItems(boolean)]

      @param pBoolean0  boolean
     */
    function setSubtotalHiddenPageItems($pBoolean0)
    {
        $this->m_PivotTable->setSubtotalHiddenPageItems($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setTag(String)]

      @param oString0  String
     */
    function setTag($oString0)
    {
        $this->m_PivotTable->setTag($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setUngroup(PivotField)]

      @param oPivotField0  com.aspose.cells.PivotField
     */
    function setUngroup($oPivotField0)
    {
        $this->m_PivotTable->setUngroup(ClassFactory::_t1($oPivotField0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTable.setUngroup(int)]

      @param pInt0  int
     */
    function setUngroupI($pInt0)
    {
        $this->m_PivotTable->setUngroup($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsPivotTableAutoFormatType]
  
 */
class PivotTableAutoFormatType
{
    public $m_PivotTableAutoFormatType;
    
    function __construct($pivotTableAutoFormatType)
    {
    	$this->m_PivotTableAutoFormatType = $pivotTableAutoFormatType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsPivotTableCollection]
  
 */
class PivotTableCollection extends CollectionBase
{
    public $m_PivotTableCollection;
    
    function __construct($pivotTableCollection)
    {
    	$this->m_PivotTableCollection = $pivotTableCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsPivotTableCollection.add(PivotTable, String, String)]

      @param oPivotTable0  com.aspose.cells.PivotTable
      @param oString1  String
      @param oString2  String
      @return int
     */
    function add($oPivotTable0, $oString1, $oString2)
    {
        return $this->m_PivotTableCollection->add(ClassFactory::_t1($oPivotTable0), $oString1, $oString2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTableCollection.add(String, String, String)]

      @param oString0  String
      @param oString1  String
      @param oString2  String
      @return int
     */
    function addSSS($oString0, $oString1, $oString2)
    {
        return $this->m_PivotTableCollection->add($oString0, $oString1, $oString2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTableCollection.add(PivotTable, int, int, String)]

      @param oPivotTable0  com.aspose.cells.PivotTable
      @param pInt1  int
      @param pInt2  int
      @param oString3  String
      @return int
     */
    function addPIIS($oPivotTable0, $pInt1, $pInt2, $oString3)
    {
        return $this->m_PivotTableCollection->add(ClassFactory::_t1($oPivotTable0), $pInt1, $pInt2, $oString3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTableCollection.add(String, String, String, boolean)]

      @param oString0  String
      @param oString1  String
      @param oString2  String
      @param pBoolean3  boolean
      @return int
     */
    function addSSSB($oString0, $oString1, $oString2, $pBoolean3)
    {
        return $this->m_PivotTableCollection->add($oString0, $oString1, $oString2, $pBoolean3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTableCollection.add(String, int, int, String)]

      @param oString0  String
      @param pInt1  int
      @param pInt2  int
      @param oString3  String
      @return int
     */
    function addSIIS($oString0, $pInt1, $pInt2, $oString3)
    {
        return $this->m_PivotTableCollection->add($oString0, $pInt1, $pInt2, $oString3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTableCollection.add(String, int, int, String, boolean)]

      @param oString0  String
      @param pInt1  int
      @param pInt2  int
      @param oString3  String
      @param pBoolean4  boolean
      @return int
     */
    function addSIISB($oString0, $pInt1, $pInt2, $oString3, $pBoolean4)
    {
        return $this->m_PivotTableCollection->add($oString0, $pInt1, $pInt2, $oString3, $pBoolean4);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTableCollection.add(String[], boolean, PivotPageFields, String, String)]

      @param arrD1DString0  array, corresponding java type is {String[]}
      @param pBoolean1  boolean
      @param oPivotPageFields2  com.aspose.cells.PivotPageFields
      @param oString3  String
      @param oString4  String
      @return int
     */
    function addSBPSS($arrD1DString0, $pBoolean1, $oPivotPageFields2, $oString3, $oString4)
    {
        return $this->m_PivotTableCollection->add($arrD1DString0, $pBoolean1, ClassFactory::_t1($oPivotPageFields2), $oString3, $oString4);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTableCollection.add(String[], boolean, PivotPageFields, int, int, String)]

      @param arrD1DString0  array, corresponding java type is {String[]}
      @param pBoolean1  boolean
      @param oPivotPageFields2  com.aspose.cells.PivotPageFields
      @param pInt3  int
      @param pInt4  int
      @param oString5  String
      @return int
     */
    function addSBPIIS($arrD1DString0, $pBoolean1, $oPivotPageFields2, $pInt3, $pInt4, $oString5)
    {
        return $this->m_PivotTableCollection->add($arrD1DString0, $pBoolean1, ClassFactory::_t1($oPivotPageFields2), $pInt3, $pInt4, $oString5);
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTableCollection.clear()]

     */
    function clear()
    {
        $this->m_PivotTableCollection->clear();
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTableCollection.get(int)]

      @param pInt0  int
      @return corresponding java type is {java.lang.Object}
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_PivotTableCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTableCollection.remove(Object)]

      @param oObject0  corresponding java type is {java.lang.Object}
     */
    function remove($oObject0)
    {
        $this->m_PivotTableCollection->remove(ClassFactory::_t1($oObject0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsPivotTableCollection.removeAt(int)]

      @param pInt0  int
     */
    function removeAt($pInt0)
    {
        $this->m_PivotTableCollection->removeAt($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsPivotTableSourceType]
  
 */
class PivotTableSourceType
{
    public $m_PivotTableSourceType;
    
    function __construct($pivotTableSourceType)
    {
    	$this->m_PivotTableSourceType = $pivotTableSourceType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsPivotTableStyleType]
  
 */
class PivotTableStyleType
{
    public $m_PivotTableStyleType;
    
    function __construct($pivotTableStyleType)
    {
    	$this->m_PivotTableStyleType = $pivotTableStyleType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsPlacementType]
  
 */
class PlacementType
{
    public $m_PlacementType;
    
    function __construct($placementType)
    {
    	$this->m_PlacementType = $placementType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsPlotEmptyCellsType]
  
 */
class PlotEmptyCellsType
{
    public $m_PlotEmptyCellsType;
    
    function __construct($plotEmptyCellsType)
    {
    	$this->m_PlotEmptyCellsType = $plotEmptyCellsType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsPresetMaterialType]
  
 */
class PresetMaterialType
{
    public $m_PresetMaterialType;
    
    function __construct($presetMaterialType)
    {
    	$this->m_PresetMaterialType = $presetMaterialType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsPresetShadowType]
  
 */
class PresetShadowType
{
    public $m_PresetShadowType;
    
    function __construct($presetShadowType)
    {
    	$this->m_PresetShadowType = $presetShadowType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsPrintCommentsType]
  
 */
class PrintCommentsType
{
    public $m_PrintCommentsType;
    
    function __construct($printCommentsType)
    {
    	$this->m_PrintCommentsType = $printCommentsType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsPrintErrorsType]
  
 */
class PrintErrorsType
{
    public $m_PrintErrorsType;
    
    function __construct($printErrorsType)
    {
    	$this->m_PrintErrorsType = $printErrorsType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsPrintingPageType]
  
 */
class PrintingPageType
{
    public $m_PrintingPageType;
    
    function __construct($printingPageType)
    {
    	$this->m_PrintingPageType = $printingPageType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsPrintOrderType]
  
 */
class PrintOrderType
{
    public $m_PrintOrderType;
    
    function __construct($printOrderType)
    {
    	$this->m_PrintOrderType = $printOrderType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsPrintSizeType]
  
 */
class PrintSizeType
{
    public $m_PrintSizeType;
    
    function __construct($printSizeType)
    {
    	$this->m_PrintSizeType = $printSizeType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsPropertyType]
  
 */
class PropertyType
{
    public $m_PropertyType;
    
    function __construct($propertyType)
    {
    	$this->m_PropertyType = $propertyType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsProtectedRange]
  
 */
class ProtectedRange
{
    public $m_ProtectedRange;
    
    function __construct($protectedRange)
    {
    	$this->m_ProtectedRange = $protectedRange;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsProtectedRange.addArea(int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
     */
    function addArea($pInt0, $pInt1, $pInt2, $pInt3)
    {
        $this->m_ProtectedRange->addArea($pInt0, $pInt1, $pInt2, $pInt3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtectedRange.getAreas()]

      @return com.aspose.cells.CellArea[]
     */
    function getAreas()
    {
        return ClassFactory::_t2($this->m_ProtectedRange->getAreas());
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtectedRange.getCellArea()]

      @return com.aspose.cells.CellArea
     */
    function getCellArea()
    {
        return ClassFactory::_t2($this->m_ProtectedRange->getCellArea());
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtectedRange.getName()]

      @return String
     */
    function getName()
    {
        return $this->m_ProtectedRange->getName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtectedRange.getPassword()]

      @return String
     */
    function getPassword()
    {
        return $this->m_ProtectedRange->getPassword();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtectedRange.setName(String)]

      @param oString0  String
     */
    function setName($oString0)
    {
        $this->m_ProtectedRange->setName($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtectedRange.setPassword(String)]

      @param oString0  String
     */
    function setPassword($oString0)
    {
        $this->m_ProtectedRange->setPassword($oString0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsProtectedRangeCollection]
  
 */
class ProtectedRangeCollection extends CollectionBase
{
    public $m_ProtectedRangeCollection;
    
    function __construct($protectedRangeCollection)
    {
    	$this->m_ProtectedRangeCollection = $protectedRangeCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsProtectedRangeCollection.add(String, int, int, int, int)]

      @param oString0  String
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @param pInt4  int
      @return int
     */
    function add($oString0, $pInt1, $pInt2, $pInt3, $pInt4)
    {
        return $this->m_ProtectedRangeCollection->add($oString0, $pInt1, $pInt2, $pInt3, $pInt4);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtectedRangeCollection.get(int)]

      @param pInt0  int
      @return corresponding java type is {java.lang.Object}
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_ProtectedRangeCollection->get($pInt0));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsProtection]
  
 */
class Protection
{
    public $m_Protection;
    
    function __construct($protection)
    {
    	$this->m_Protection = $protection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsProtection.copy(Protection)]

      @param oProtection0  com.aspose.cells.Protection
     */
    function copy($oProtection0)
    {
        $this->m_Protection->copy(ClassFactory::_t1($oProtection0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.getAllowDeletingColumn()]

      @return boolean
     */
    function getAllowDeletingColumn()
    {
        return $this->m_Protection->getAllowDeletingColumn();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.getAllowDeletingRow()]

      @return boolean
     */
    function getAllowDeletingRow()
    {
        return $this->m_Protection->getAllowDeletingRow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.getAllowEditingContent()]

      @return boolean
     */
    function getAllowEditingContent()
    {
        return $this->m_Protection->getAllowEditingContent();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.getAllowEditingObject()]

      @return boolean
     */
    function getAllowEditingObject()
    {
        return $this->m_Protection->getAllowEditingObject();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.getAllowEditingScenario()]

      @return boolean
     */
    function getAllowEditingScenario()
    {
        return $this->m_Protection->getAllowEditingScenario();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.getAllowFiltering()]

      @return boolean
     */
    function getAllowFiltering()
    {
        return $this->m_Protection->getAllowFiltering();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.getAllowFormattingCell()]

      @return boolean
     */
    function getAllowFormattingCell()
    {
        return $this->m_Protection->getAllowFormattingCell();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.getAllowFormattingColumn()]

      @return boolean
     */
    function getAllowFormattingColumn()
    {
        return $this->m_Protection->getAllowFormattingColumn();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.getAllowFormattingRow()]

      @return boolean
     */
    function getAllowFormattingRow()
    {
        return $this->m_Protection->getAllowFormattingRow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.getAllowInsertingColumn()]

      @return boolean
     */
    function getAllowInsertingColumn()
    {
        return $this->m_Protection->getAllowInsertingColumn();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.getAllowInsertingHyperlink()]

      @return boolean
     */
    function getAllowInsertingHyperlink()
    {
        return $this->m_Protection->getAllowInsertingHyperlink();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.getAllowInsertingRow()]

      @return boolean
     */
    function getAllowInsertingRow()
    {
        return $this->m_Protection->getAllowInsertingRow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.getAllowSelectingLockedCell()]

      @return boolean
     */
    function getAllowSelectingLockedCell()
    {
        return $this->m_Protection->getAllowSelectingLockedCell();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.getAllowSelectingUnlockedCell()]

      @return boolean
     */
    function getAllowSelectingUnlockedCell()
    {
        return $this->m_Protection->getAllowSelectingUnlockedCell();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.getAllowSorting()]

      @return boolean
     */
    function getAllowSorting()
    {
        return $this->m_Protection->getAllowSorting();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.getAllowUsingPivotTable()]

      @return boolean
     */
    function getAllowUsingPivotTable()
    {
        return $this->m_Protection->getAllowUsingPivotTable();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.getPassword()]

      @return String
     */
    function getPassword()
    {
        return $this->m_Protection->getPassword();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.isDeletingColumnsAllowed()]

      @return boolean
     */
    function isDeletingColumnsAllowed()
    {
        return $this->m_Protection->isDeletingColumnsAllowed();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.isDeletingRowsAllowed()]

      @return boolean
     */
    function isDeletingRowsAllowed()
    {
        return $this->m_Protection->isDeletingRowsAllowed();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.isEditingContentsAllowed()]

      @return boolean
     */
    function isEditingContentsAllowed()
    {
        return $this->m_Protection->isEditingContentsAllowed();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.isEditingObjectsAllowed()]

      @return boolean
     */
    function isEditingObjectsAllowed()
    {
        return $this->m_Protection->isEditingObjectsAllowed();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.isEditingScenariosAllowed()]

      @return boolean
     */
    function isEditingScenariosAllowed()
    {
        return $this->m_Protection->isEditingScenariosAllowed();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.isFilteringAllowed()]

      @return boolean
     */
    function isFilteringAllowed()
    {
        return $this->m_Protection->isFilteringAllowed();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.isFormattingCellsAllowed()]

      @return boolean
     */
    function isFormattingCellsAllowed()
    {
        return $this->m_Protection->isFormattingCellsAllowed();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.isFormattingColumnsAllowed()]

      @return boolean
     */
    function isFormattingColumnsAllowed()
    {
        return $this->m_Protection->isFormattingColumnsAllowed();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.isFormattingRowsAllowed()]

      @return boolean
     */
    function isFormattingRowsAllowed()
    {
        return $this->m_Protection->isFormattingRowsAllowed();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.isInsertingColumnsAllowed()]

      @return boolean
     */
    function isInsertingColumnsAllowed()
    {
        return $this->m_Protection->isInsertingColumnsAllowed();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.isInsertingHyperlinksAllowed()]

      @return boolean
     */
    function isInsertingHyperlinksAllowed()
    {
        return $this->m_Protection->isInsertingHyperlinksAllowed();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.isInsertingRowsAllowed()]

      @return boolean
     */
    function isInsertingRowsAllowed()
    {
        return $this->m_Protection->isInsertingRowsAllowed();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.isSelectingLockedCellsAllowed()]

      @return boolean
     */
    function isSelectingLockedCellsAllowed()
    {
        return $this->m_Protection->isSelectingLockedCellsAllowed();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.isSelectingUnlockedCellsAllowed()]

      @return boolean
     */
    function isSelectingUnlockedCellsAllowed()
    {
        return $this->m_Protection->isSelectingUnlockedCellsAllowed();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.isSortingAllowed()]

      @return boolean
     */
    function isSortingAllowed()
    {
        return $this->m_Protection->isSortingAllowed();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.isUsingPivotTablesAllowed()]

      @return boolean
     */
    function isUsingPivotTablesAllowed()
    {
        return $this->m_Protection->isUsingPivotTablesAllowed();
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setAllowDeletingColumn(boolean)]

      @param pBoolean0  boolean
     */
    function setAllowDeletingColumn($pBoolean0)
    {
        $this->m_Protection->setAllowDeletingColumn($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setAllowDeletingRow(boolean)]

      @param pBoolean0  boolean
     */
    function setAllowDeletingRow($pBoolean0)
    {
        $this->m_Protection->setAllowDeletingRow($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setAllowEditingContent(boolean)]

      @param pBoolean0  boolean
     */
    function setAllowEditingContent($pBoolean0)
    {
        $this->m_Protection->setAllowEditingContent($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setAllowEditingObject(boolean)]

      @param pBoolean0  boolean
     */
    function setAllowEditingObject($pBoolean0)
    {
        $this->m_Protection->setAllowEditingObject($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setAllowEditingScenario(boolean)]

      @param pBoolean0  boolean
     */
    function setAllowEditingScenario($pBoolean0)
    {
        $this->m_Protection->setAllowEditingScenario($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setAllowFiltering(boolean)]

      @param pBoolean0  boolean
     */
    function setAllowFiltering($pBoolean0)
    {
        $this->m_Protection->setAllowFiltering($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setAllowFormattingCell(boolean)]

      @param pBoolean0  boolean
     */
    function setAllowFormattingCell($pBoolean0)
    {
        $this->m_Protection->setAllowFormattingCell($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setAllowFormattingColumn(boolean)]

      @param pBoolean0  boolean
     */
    function setAllowFormattingColumn($pBoolean0)
    {
        $this->m_Protection->setAllowFormattingColumn($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setAllowFormattingRow(boolean)]

      @param pBoolean0  boolean
     */
    function setAllowFormattingRow($pBoolean0)
    {
        $this->m_Protection->setAllowFormattingRow($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setAllowInsertingColumn(boolean)]

      @param pBoolean0  boolean
     */
    function setAllowInsertingColumn($pBoolean0)
    {
        $this->m_Protection->setAllowInsertingColumn($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setAllowInsertingHyperlink(boolean)]

      @param pBoolean0  boolean
     */
    function setAllowInsertingHyperlink($pBoolean0)
    {
        $this->m_Protection->setAllowInsertingHyperlink($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setAllowInsertingRow(boolean)]

      @param pBoolean0  boolean
     */
    function setAllowInsertingRow($pBoolean0)
    {
        $this->m_Protection->setAllowInsertingRow($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setAllowSelectingLockedCell(boolean)]

      @param pBoolean0  boolean
     */
    function setAllowSelectingLockedCell($pBoolean0)
    {
        $this->m_Protection->setAllowSelectingLockedCell($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setAllowSelectingUnlockedCell(boolean)]

      @param pBoolean0  boolean
     */
    function setAllowSelectingUnlockedCell($pBoolean0)
    {
        $this->m_Protection->setAllowSelectingUnlockedCell($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setAllowSorting(boolean)]

      @param pBoolean0  boolean
     */
    function setAllowSorting($pBoolean0)
    {
        $this->m_Protection->setAllowSorting($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setAllowUsingPivotTable(boolean)]

      @param pBoolean0  boolean
     */
    function setAllowUsingPivotTable($pBoolean0)
    {
        $this->m_Protection->setAllowUsingPivotTable($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setDeletingColumnsAllowed(boolean)]

      @param pBoolean0  boolean
     */
    function setDeletingColumnsAllowed($pBoolean0)
    {
        $this->m_Protection->setDeletingColumnsAllowed($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setDeletingRowsAllowed(boolean)]

      @param pBoolean0  boolean
     */
    function setDeletingRowsAllowed($pBoolean0)
    {
        $this->m_Protection->setDeletingRowsAllowed($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setEditingContentsAllowed(boolean)]

      @param pBoolean0  boolean
     */
    function setEditingContentsAllowed($pBoolean0)
    {
        $this->m_Protection->setEditingContentsAllowed($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setEditingObjectsAllowed(boolean)]

      @param pBoolean0  boolean
     */
    function setEditingObjectsAllowed($pBoolean0)
    {
        $this->m_Protection->setEditingObjectsAllowed($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setEditingScenariosAllowed(boolean)]

      @param pBoolean0  boolean
     */
    function setEditingScenariosAllowed($pBoolean0)
    {
        $this->m_Protection->setEditingScenariosAllowed($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setFilteringAllowed(boolean)]

      @param pBoolean0  boolean
     */
    function setFilteringAllowed($pBoolean0)
    {
        $this->m_Protection->setFilteringAllowed($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setFormattingCellsAllowed(boolean)]

      @param pBoolean0  boolean
     */
    function setFormattingCellsAllowed($pBoolean0)
    {
        $this->m_Protection->setFormattingCellsAllowed($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setFormattingColumnsAllowed(boolean)]

      @param pBoolean0  boolean
     */
    function setFormattingColumnsAllowed($pBoolean0)
    {
        $this->m_Protection->setFormattingColumnsAllowed($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setFormattingRowsAllowed(boolean)]

      @param pBoolean0  boolean
     */
    function setFormattingRowsAllowed($pBoolean0)
    {
        $this->m_Protection->setFormattingRowsAllowed($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setInsertingColumnsAllowed(boolean)]

      @param pBoolean0  boolean
     */
    function setInsertingColumnsAllowed($pBoolean0)
    {
        $this->m_Protection->setInsertingColumnsAllowed($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setInsertingHyperlinksAllowed(boolean)]

      @param pBoolean0  boolean
     */
    function setInsertingHyperlinksAllowed($pBoolean0)
    {
        $this->m_Protection->setInsertingHyperlinksAllowed($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setInsertingRowsAllowed(boolean)]

      @param pBoolean0  boolean
     */
    function setInsertingRowsAllowed($pBoolean0)
    {
        $this->m_Protection->setInsertingRowsAllowed($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setPassword(String)]

      @param oString0  String
     */
    function setPassword($oString0)
    {
        $this->m_Protection->setPassword($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setSelectingLockedCellsAllowed(boolean)]

      @param pBoolean0  boolean
     */
    function setSelectingLockedCellsAllowed($pBoolean0)
    {
        $this->m_Protection->setSelectingLockedCellsAllowed($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setSelectingUnlockedCellsAllowed(boolean)]

      @param pBoolean0  boolean
     */
    function setSelectingUnlockedCellsAllowed($pBoolean0)
    {
        $this->m_Protection->setSelectingUnlockedCellsAllowed($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setSortingAllowed(boolean)]

      @param pBoolean0  boolean
     */
    function setSortingAllowed($pBoolean0)
    {
        $this->m_Protection->setSortingAllowed($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsProtection.setUsingPivotTablesAllowed(boolean)]

      @param pBoolean0  boolean
     */
    function setUsingPivotTablesAllowed($pBoolean0)
    {
        $this->m_Protection->setUsingPivotTablesAllowed($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsProtectionType]
  
 */
class ProtectionType
{
    public $m_ProtectionType;
    
    function __construct($protectionType)
    {
    	$this->m_ProtectionType = $protectionType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsRadioButton]
  
 */
class RadioButton extends Shape
{
    public $m_RadioButton;
    
    function __construct($radioButton)
    {
    	$this->m_RadioButton = $radioButton;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsRadioButton.getLinkedCell()]

      @return String
     */
    function getLinkedCell()
    {
        return $this->m_RadioButton->getLinkedCell();
    }

    /*
      Wrapper for java version method [com.aspose.cellsRadioButton.getShadow()]

      @return boolean
     */
    function getShadow()
    {
        return $this->m_RadioButton->getShadow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsRadioButton.isChecked()]

      @return boolean
     */
    function isChecked()
    {
        return $this->m_RadioButton->isChecked();
    }

    /*
      Wrapper for java version method [com.aspose.cellsRadioButton.setChecked(boolean)]

      @param pBoolean0  boolean
     */
    function setChecked($pBoolean0)
    {
        $this->m_RadioButton->setChecked($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsRadioButton.setLinkedCell(String)]

      @param oString0  String
     */
    function setLinkedCell($oString0)
    {
        $this->m_RadioButton->setLinkedCell($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsRadioButton.setShadow(boolean)]

      @param pBoolean0  boolean
     */
    function setShadow($pBoolean0)
    {
        $this->m_RadioButton->setShadow($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsRange]
  
 */
class Range
{
    public $m_Range;
    
    function __construct($range)
    {
    	$this->m_Range = $range;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsRange.applyStyle(Style, StyleFlag)]

      @param oStyle0  com.aspose.cells.Style
      @param oStyleFlag1  com.aspose.cells.StyleFlag
     */
    function applyStyle($oStyle0, $oStyleFlag1)
    {
        $this->m_Range->applyStyle(ClassFactory::_t1($oStyle0), ClassFactory::_t1($oStyleFlag1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.copy(Range)]

      @param oRange0  com.aspose.cells.Range
     */
    function copy($oRange0)
    {
        $this->m_Range->copy(ClassFactory::_t1($oRange0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.copy(Range, PasteOptions)]

      @param oRange0  com.aspose.cells.Range
      @param oPasteOptions1  com.aspose.cells.PasteOptions
     */
    function copyRP($oRange0, $oPasteOptions1)
    {
        $this->m_Range->copy(ClassFactory::_t1($oRange0), ClassFactory::_t1($oPasteOptions1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.copyData(Range)]

      @param oRange0  com.aspose.cells.Range
     */
    function copyData($oRange0)
    {
        $this->m_Range->copyData(ClassFactory::_t1($oRange0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.copyStyle(Range)]

      @param oRange0  com.aspose.cells.Range
     */
    function copyStyle($oRange0)
    {
        $this->m_Range->copyStyle(ClassFactory::_t1($oRange0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.copyValue(Range)]

      @param oRange0  com.aspose.cells.Range
     */
    function copyValue($oRange0)
    {
        $this->m_Range->copyValue(ClassFactory::_t1($oRange0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.get(int, int)]

      @param pInt0  int
      @param pInt1  int
      @return com.aspose.cells.Cell
     */
    function get($pInt0, $pInt1)
    {
        return ClassFactory::_t2($this->m_Range->get($pInt0, $pInt1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.getCellOrNull(int, int)]

      @param pInt0  int
      @param pInt1  int
      @return com.aspose.cells.Cell
     */
    function getCellOrNull($pInt0, $pInt1)
    {
        return ClassFactory::_t2($this->m_Range->getCellOrNull($pInt0, $pInt1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.getColumnCount()]

      @return int
     */
    function getColumnCount()
    {
        return $this->m_Range->getColumnCount();
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.getColumnWidth()]

      @return double
     */
    function getColumnWidth()
    {
        return $this->m_Range->getColumnWidth();
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.getFirstColumn()]

      @return int
     */
    function getFirstColumn()
    {
        return $this->m_Range->getFirstColumn();
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.getFirstRow()]

      @return int
     */
    function getFirstRow()
    {
        return $this->m_Range->getFirstRow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.getName()]

      @return String
     */
    function getName()
    {
        return $this->m_Range->getName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.getRowCount()]

      @return int
     */
    function getRowCount()
    {
        return $this->m_Range->getRowCount();
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.getRowHeight()]

      @return double
     */
    function getRowHeight()
    {
        return $this->m_Range->getRowHeight();
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.getStyle()]

      @return com.aspose.cells.Style
     */
    function getStyle()
    {
        return ClassFactory::_t2($this->m_Range->getStyle());
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.getValue()]

      @return corresponding java type is {java.lang.Object}
     */
    function getValue()
    {
        return ClassFactory::_t2($this->m_Range->getValue());
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.getWorksheet()]

      @return com.aspose.cells.Worksheet
     */
    function getWorksheet()
    {
        return ClassFactory::_t2($this->m_Range->getWorksheet());
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.intersect(Range)]

      @param oRange0  com.aspose.cells.Range
      @return com.aspose.cells.Range
     */
    function intersect($oRange0)
    {
        return ClassFactory::_t2($this->m_Range->intersect(ClassFactory::_t1($oRange0)));
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.isIntersect(Range)]

      @param oRange0  com.aspose.cells.Range
      @return boolean
     */
    function isIntersect($oRange0)
    {
        return $this->m_Range->isIntersect(ClassFactory::_t1($oRange0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.iterator()]

      @return corresponding java type is {java.util.Iterator}
     */
    function iterator()
    {
        return ClassFactory::_t2($this->m_Range->iterator());
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.merge()]

     */
    function merge()
    {
        $this->m_Range->merge();
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.moveTo(int, int)]

      @param pInt0  int
      @param pInt1  int
     */
    function moveTo($pInt0, $pInt1)
    {
        $this->m_Range->moveTo($pInt0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.setColumnWidth(double)]

      @param pDouble0  double
     */
    function setColumnWidth($pDouble0)
    {
        $this->m_Range->setColumnWidth($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.setName(String)]

      @param oString0  String
     */
    function setName($oString0)
    {
        $this->m_Range->setName($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.setOutlineBorder(int, int, Color)]

      @param pInt0  int
      @param pInt1  int
      @param oColor2  com.aspose.cells.Color
     */
    function setOutlineBorder($pInt0, $pInt1, $oColor2)
    {
        $this->m_Range->setOutlineBorder($pInt0, $pInt1, ClassFactory::_t1($oColor2));
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.setOutlineBorders(int, Color)]

      @param pInt0  int
      @param oColor1  com.aspose.cells.Color
     */
    function setOutlineBorders($pInt0, $oColor1)
    {
        $this->m_Range->setOutlineBorders($pInt0, ClassFactory::_t1($oColor1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.setOutlineBorders(int[], Color[])]

      @param arrP1DInt0  int[]
      @param arrO1DColor1  com.aspose.cells.Color[]
     */
    function setOutlineBordersIC($arrP1DInt0, $arrO1DColor1)
    {
        $this->m_Range->setOutlineBorders($arrP1DInt0, ClassFactory::_t1($arrO1DColor1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.setRowHeight(double)]

      @param pDouble0  double
     */
    function setRowHeight($pDouble0)
    {
        $this->m_Range->setRowHeight($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.setStyle(Style)]

      @param oStyle0  com.aspose.cells.Style
     */
    function setStyle($oStyle0)
    {
        $this->m_Range->setStyle(ClassFactory::_t1($oStyle0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.setValue(Object)]

      @param oObject0  corresponding java type is {java.lang.Object}
     */
    function setValue($oObject0)
    {
        $this->m_Range->setValue(ClassFactory::_t1($oObject0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.unMerge()]

     */
    function unMerge()
    {
        $this->m_Range->unMerge();
    }

    /*
      Wrapper for java version method [com.aspose.cellsRange.union(Range)]

      @param oRange0  com.aspose.cells.Range
      @return array, corresponding java type is {java.util.ArrayList}
     */
    function union($oRange0)
    {
        return ClassFactory::_t2($this->m_Range->union(ClassFactory::_t1($oRange0)));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsRangeCollection]
  
 */
class RangeCollection extends CollectionBase
{
    public $m_RangeCollection;
    
    function __construct($rangeCollection)
    {
    	$this->m_RangeCollection = $rangeCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsRangeCollection.get(int)]

      @param pInt0  int
      @return com.aspose.cells.Range
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_RangeCollection->get($pInt0));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsRectangleAlignmentType]
  
 */
class RectangleAlignmentType
{
    public $m_RectangleAlignmentType;
    
    function __construct($rectangleAlignmentType)
    {
    	$this->m_RectangleAlignmentType = $rectangleAlignmentType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsRectangleShape]
  
 */
class RectangleShape extends Shape
{
    public $m_RectangleShape;
    
    function __construct($rectangleShape)
    {
    	$this->m_RectangleShape = $rectangleShape;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsRectangleShape.characters(int, int)]

      @param pInt0  int
      @param pInt1  int
      @return com.aspose.cells.FontSetting
     */
    function characters($pInt0, $pInt1)
    {
        return ClassFactory::_t2($this->m_RectangleShape->characters($pInt0, $pInt1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsRectangleShape.getCharacters()]

      @return array, corresponding java type is {java.util.ArrayList}
     */
    function getCharacters()
    {
        return ClassFactory::_t2($this->m_RectangleShape->getCharacters());
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsReferredArea]
  
 */
class ReferredArea
{
    public $m_ReferredArea;
    
    function __construct($referredArea)
    {
    	$this->m_ReferredArea = $referredArea;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsReferredArea.getEndColumn()]

      @return int
     */
    function getEndColumn()
    {
        return $this->m_ReferredArea->getEndColumn();
    }

    /*
      Wrapper for java version method [com.aspose.cellsReferredArea.getEndRow()]

      @return int
     */
    function getEndRow()
    {
        return $this->m_ReferredArea->getEndRow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsReferredArea.getExternalFileName()]

      @return String
     */
    function getExternalFileName()
    {
        return $this->m_ReferredArea->getExternalFileName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsReferredArea.getSheetName()]

      @return String
     */
    function getSheetName()
    {
        return $this->m_ReferredArea->getSheetName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsReferredArea.getStartColumn()]

      @return int
     */
    function getStartColumn()
    {
        return $this->m_ReferredArea->getStartColumn();
    }

    /*
      Wrapper for java version method [com.aspose.cellsReferredArea.getStartRow()]

      @return int
     */
    function getStartRow()
    {
        return $this->m_ReferredArea->getStartRow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsReferredArea.isArea()]

      @return boolean
     */
    function isArea()
    {
        return $this->m_ReferredArea->isArea();
    }

    /*
      Wrapper for java version method [com.aspose.cellsReferredArea.isExternalLink()]

      @return boolean
     */
    function isExternalLink()
    {
        return $this->m_ReferredArea->isExternalLink();
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsReferredAreaCollection]
  
 */
class ReferredAreaCollection extends CollectionBase
{
    public $m_ReferredAreaCollection;
    
    function __construct($referredAreaCollection)
    {
    	$this->m_ReferredAreaCollection = $referredAreaCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsReferredAreaCollection.get(int)]

      @param pInt0  int
      @return com.aspose.cells.ReferredArea
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_ReferredAreaCollection->get($pInt0));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsReplaceOptions]
  
 */
class ReplaceOptions
{
    public $m_ReplaceOptions;
    
    function __construct($replaceOptions)
    {
    	$this->m_ReplaceOptions = $replaceOptions;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsReplaceOptions.getCaseSensitive()]

      @return boolean
     */
    function getCaseSensitive()
    {
        return $this->m_ReplaceOptions->getCaseSensitive();
    }

    /*
      Wrapper for java version method [com.aspose.cellsReplaceOptions.getMatchEntireCellContents()]

      @return boolean
     */
    function getMatchEntireCellContents()
    {
        return $this->m_ReplaceOptions->getMatchEntireCellContents();
    }

    /*
      Wrapper for java version method [com.aspose.cellsReplaceOptions.setCaseSensitive(boolean)]

      @param pBoolean0  boolean
     */
    function setCaseSensitive($pBoolean0)
    {
        $this->m_ReplaceOptions->setCaseSensitive($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsReplaceOptions.setMatchEntireCellContents(boolean)]

      @param pBoolean0  boolean
     */
    function setMatchEntireCellContents($pBoolean0)
    {
        $this->m_ReplaceOptions->setMatchEntireCellContents($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsRow]
  
 */
class Row
{
    public $m_Row;
    
    function __construct($row)
    {
    	$this->m_Row = $row;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsRow.applyStyle(Style, StyleFlag)]

      @param oStyle0  com.aspose.cells.Style
      @param oStyleFlag1  com.aspose.cells.StyleFlag
     */
    function applyStyle($oStyle0, $oStyleFlag1)
    {
        $this->m_Row->applyStyle(ClassFactory::_t1($oStyle0), ClassFactory::_t1($oStyleFlag1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsRow.get(int)]

      @param pInt0  int
      @return com.aspose.cells.Cell
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_Row->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsRow.getCellOrNull(int)]

      @param pInt0  int
      @return com.aspose.cells.Cell
     */
    function getCellOrNull($pInt0)
    {
        return ClassFactory::_t2($this->m_Row->getCellOrNull($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsRow.getGroupLevel()]

      @return byte
     */
    function getGroupLevel()
    {
        return $this->m_Row->getGroupLevel();
    }

    /*
      Wrapper for java version method [com.aspose.cellsRow.getHeight()]

      @return double
     */
    function getHeight()
    {
        return $this->m_Row->getHeight();
    }

    /*
      Wrapper for java version method [com.aspose.cellsRow.getIndex()]

      @return int
     */
    function getIndex()
    {
        return $this->m_Row->getIndex();
    }

    /*
      Wrapper for java version method [com.aspose.cellsRow.getStyle()]

      @return com.aspose.cells.Style
     */
    function getStyle()
    {
        return ClassFactory::_t2($this->m_Row->getStyle());
    }

    /*
      Wrapper for java version method [com.aspose.cellsRow.isBlank()]

      @return boolean
     */
    function isBlank()
    {
        return $this->m_Row->isBlank();
    }

    /*
      Wrapper for java version method [com.aspose.cellsRow.isHeightMatched()]

      @return boolean
     */
    function isHeightMatched()
    {
        return $this->m_Row->isHeightMatched();
    }

    /*
      Wrapper for java version method [com.aspose.cellsRow.isHidden()]

      @return boolean
     */
    function isHidden()
    {
        return $this->m_Row->isHidden();
    }

    /*
      Wrapper for java version method [com.aspose.cellsRow.iterator()]

      @return corresponding java type is {java.util.Iterator}
     */
    function iterator()
    {
        return ClassFactory::_t2($this->m_Row->iterator());
    }

    /*
      Wrapper for java version method [com.aspose.cellsRow.setHeight(double)]

      @param pDouble0  double
     */
    function setHeight($pDouble0)
    {
        $this->m_Row->setHeight($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsRow.setHeightMatched(boolean)]

      @param pBoolean0  boolean
     */
    function setHeightMatched($pBoolean0)
    {
        $this->m_Row->setHeightMatched($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsRow.setHidden(boolean)]

      @param pBoolean0  boolean
     */
    function setHidden($pBoolean0)
    {
        $this->m_Row->setHidden($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsRowCollection]
  
 */
class RowCollection extends CollectionBase
{
    public $m_RowCollection;
    
    function __construct($rowCollection)
    {
    	$this->m_RowCollection = $rowCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsRowCollection.clear()]

     */
    function clear()
    {
        $this->m_RowCollection->clear();
    }

    /*
      Wrapper for java version method [com.aspose.cellsRowCollection.get(int)]

      @param pInt0  int
      @return corresponding java type is {java.lang.Object}
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_RowCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsRowCollection.getRowByIndex(int)]

      @param pInt0  int
      @return com.aspose.cells.Row
     */
    function getRowByIndex($pInt0)
    {
        return ClassFactory::_t2($this->m_RowCollection->getRowByIndex($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsRowCollection.removeAt(int)]

      @param pInt0  int
     */
    function removeAt($pInt0)
    {
        $this->m_RowCollection->removeAt($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsSaveFormat]
  
 */
class SaveFormat
{
    public $m_SaveFormat;
    
    function __construct($saveFormat)
    {
    	$this->m_SaveFormat = $saveFormat;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsSaveOptions]
  
 */
class SaveOptions
{
    public $m_SaveOptions;
    
    function __construct($saveOptions)
    {
    	$this->m_SaveOptions = $saveOptions;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsSaveOptions.getAttachedFilesDirectory()]

      @return String
     */
    function getAttachedFilesDirectory()
    {
        return $this->m_SaveOptions->getAttachedFilesDirectory();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSaveOptions.getAttachedFilesUrlPrefix()]

      @return String
     */
    function getAttachedFilesUrlPrefix()
    {
        return $this->m_SaveOptions->getAttachedFilesUrlPrefix();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSaveOptions.getCachedFileFolder()]

      @return String
     */
    function getCachedFileFolder()
    {
        return $this->m_SaveOptions->getCachedFileFolder();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSaveOptions.getClearData()]

      @return boolean
     */
    function getClearData()
    {
        return $this->m_SaveOptions->getClearData();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSaveOptions.getCompliance()]

      @return int
     */
    function getCompliance()
    {
        return $this->m_SaveOptions->getCompliance();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSaveOptions.getCreateDirectory()]

      @return boolean
     */
    function getCreateDirectory()
    {
        return $this->m_SaveOptions->getCreateDirectory();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSaveOptions.getDefaultFont()]

      @return String
     */
    function getDefaultFont()
    {
        return $this->m_SaveOptions->getDefaultFont();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSaveOptions.getDisplayHTMLCrossString()]

      @return boolean
     */
    function getDisplayHTMLCrossString()
    {
        return $this->m_SaveOptions->getDisplayHTMLCrossString();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSaveOptions.getExpCellNameToXLSX()]

      @return boolean
     */
    function getExpCellNameToXLSX()
    {
        return $this->m_SaveOptions->getExpCellNameToXLSX();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSaveOptions.getPageTitle()]

      @return String
     */
    function getPageTitle()
    {
        return $this->m_SaveOptions->getPageTitle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSaveOptions.getPdfBookmark()]

      @return com.aspose.cells.PdfBookmarkEntry
     */
    function getPdfBookmark()
    {
        return ClassFactory::_t2($this->m_SaveOptions->getPdfBookmark());
    }

    /*
      Wrapper for java version method [com.aspose.cellsSaveOptions.getPdfExportImagesFolder()]

      @return String
     */
    function getPdfExportImagesFolder()
    {
        return $this->m_SaveOptions->getPdfExportImagesFolder();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSaveOptions.getSaveFormat()]

      @return int
     */
    function getSaveFormat()
    {
        return $this->m_SaveOptions->getSaveFormat();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSaveOptions.getValidateMergedAreas()]

      @return boolean
     */
    function getValidateMergedAreas()
    {
        return $this->m_SaveOptions->getValidateMergedAreas();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSaveOptions.isExpImageToTempDir()]

      @return boolean
     */
    function isExpImageToTempDir()
    {
        return $this->m_SaveOptions->isExpImageToTempDir();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSaveOptions.setAttachedFilesDirectory(String)]

      @param oString0  String
     */
    function setAttachedFilesDirectory($oString0)
    {
        $this->m_SaveOptions->setAttachedFilesDirectory($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSaveOptions.setAttachedFilesUrlPrefix(String)]

      @param oString0  String
     */
    function setAttachedFilesUrlPrefix($oString0)
    {
        $this->m_SaveOptions->setAttachedFilesUrlPrefix($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSaveOptions.setCachedFileFolder(String)]

      @param oString0  String
     */
    function setCachedFileFolder($oString0)
    {
        $this->m_SaveOptions->setCachedFileFolder($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSaveOptions.setClearData(boolean)]

      @param pBoolean0  boolean
     */
    function setClearData($pBoolean0)
    {
        $this->m_SaveOptions->setClearData($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSaveOptions.setCompliance(int)]

      @param pInt0  int
     */
    function setCompliance($pInt0)
    {
        $this->m_SaveOptions->setCompliance($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSaveOptions.setCreateDirectory(boolean)]

      @param pBoolean0  boolean
     */
    function setCreateDirectory($pBoolean0)
    {
        $this->m_SaveOptions->setCreateDirectory($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSaveOptions.setDefaultFont(String)]

      @param oString0  String
     */
    function setDefaultFont($oString0)
    {
        $this->m_SaveOptions->setDefaultFont($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSaveOptions.setDisplayHTMLCrossString(boolean)]

      @param pBoolean0  boolean
     */
    function setDisplayHTMLCrossString($pBoolean0)
    {
        $this->m_SaveOptions->setDisplayHTMLCrossString($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSaveOptions.setExpCellNameToXLSX(boolean)]

      @param pBoolean0  boolean
     */
    function setExpCellNameToXLSX($pBoolean0)
    {
        $this->m_SaveOptions->setExpCellNameToXLSX($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSaveOptions.setExpImageToTempDir(boolean)]

      @param pBoolean0  boolean
     */
    function setExpImageToTempDir($pBoolean0)
    {
        $this->m_SaveOptions->setExpImageToTempDir($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSaveOptions.setPageTitle(String)]

      @param oString0  String
     */
    function setPageTitle($oString0)
    {
        $this->m_SaveOptions->setPageTitle($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSaveOptions.setPdfBookmark(PdfBookmarkEntry)]

      @param oPdfBookmarkEntry0  com.aspose.cells.PdfBookmarkEntry
     */
    function setPdfBookmark($oPdfBookmarkEntry0)
    {
        $this->m_SaveOptions->setPdfBookmark(ClassFactory::_t1($oPdfBookmarkEntry0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsSaveOptions.setPdfExportImagesFolder(String)]

      @param oString0  String
     */
    function setPdfExportImagesFolder($oString0)
    {
        $this->m_SaveOptions->setPdfExportImagesFolder($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSaveOptions.setSaveFormat(int)]

      @param pInt0  int
     */
    function setSaveFormat($pInt0)
    {
        $this->m_SaveOptions->setSaveFormat($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSaveOptions.setValidateMergedAreas(boolean)]

      @param pBoolean0  boolean
     */
    function setValidateMergedAreas($pBoolean0)
    {
        $this->m_SaveOptions->setValidateMergedAreas($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsSaveType]
  
 */
class SaveType
{
    public $m_SaveType;
    
    function __construct($saveType)
    {
    	$this->m_SaveType = $saveType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsScrollBar]
  
 */
class ScrollBar extends Shape
{
    public $m_ScrollBar;
    
    function __construct($scrollBar)
    {
    	$this->m_ScrollBar = $scrollBar;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsScrollBar.getCurrentValue()]

      @return int
     */
    function getCurrentValue()
    {
        return $this->m_ScrollBar->getCurrentValue();
    }

    /*
      Wrapper for java version method [com.aspose.cellsScrollBar.getIncrementalChange()]

      @return int
     */
    function getIncrementalChange()
    {
        return $this->m_ScrollBar->getIncrementalChange();
    }

    /*
      Wrapper for java version method [com.aspose.cellsScrollBar.getMax()]

      @return int
     */
    function getMax()
    {
        return $this->m_ScrollBar->getMax();
    }

    /*
      Wrapper for java version method [com.aspose.cellsScrollBar.getMin()]

      @return int
     */
    function getMin()
    {
        return $this->m_ScrollBar->getMin();
    }

    /*
      Wrapper for java version method [com.aspose.cellsScrollBar.getPageChange()]

      @return int
     */
    function getPageChange()
    {
        return $this->m_ScrollBar->getPageChange();
    }

    /*
      Wrapper for java version method [com.aspose.cellsScrollBar.getShadow()]

      @return boolean
     */
    function getShadow()
    {
        return $this->m_ScrollBar->getShadow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsScrollBar.isHorizontal()]

      @return boolean
     */
    function isHorizontal()
    {
        return $this->m_ScrollBar->isHorizontal();
    }

    /*
      Wrapper for java version method [com.aspose.cellsScrollBar.setCurrentValue(int)]

      @param pInt0  int
     */
    function setCurrentValue($pInt0)
    {
        $this->m_ScrollBar->setCurrentValue($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsScrollBar.setHorizontal(boolean)]

      @param pBoolean0  boolean
     */
    function setHorizontal($pBoolean0)
    {
        $this->m_ScrollBar->setHorizontal($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsScrollBar.setIncrementalChange(int)]

      @param pInt0  int
     */
    function setIncrementalChange($pInt0)
    {
        $this->m_ScrollBar->setIncrementalChange($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsScrollBar.setMax(int)]

      @param pInt0  int
     */
    function setMax($pInt0)
    {
        $this->m_ScrollBar->setMax($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsScrollBar.setMin(int)]

      @param pInt0  int
     */
    function setMin($pInt0)
    {
        $this->m_ScrollBar->setMin($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsScrollBar.setPageChange(int)]

      @param pInt0  int
     */
    function setPageChange($pInt0)
    {
        $this->m_ScrollBar->setPageChange($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsScrollBar.setShadow(boolean)]

      @param pBoolean0  boolean
     */
    function setShadow($pBoolean0)
    {
        $this->m_ScrollBar->setShadow($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsSelectionType]
  
 */
class SelectionType
{
    public $m_SelectionType;
    
    function __construct($selectionType)
    {
    	$this->m_SelectionType = $selectionType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsSeries]
  
 */
class Series
{
    public $m_Series;
    
    function __construct($series)
    {
    	$this->m_Series = $series;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsSeries.getArea()]

      @return com.aspose.cells.Area
     */
    function getArea()
    {
        return ClassFactory::_t2($this->m_Series->getArea());
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getBar3DShapeType()]

      @return int
     */
    function getBar3DShapeType()
    {
        return $this->m_Series->getBar3DShapeType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getBarShape()]

      @return int
     */
    function getBarShape()
    {
        return $this->m_Series->getBarShape();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getBubbleScale()]

      @return int
     */
    function getBubbleScale()
    {
        return $this->m_Series->getBubbleScale();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getBubbleSizes()]

      @return String
     */
    function getBubbleSizes()
    {
        return $this->m_Series->getBubbleSizes();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getCountOfDataValues()]

      @return int
     */
    function getCountOfDataValues()
    {
        return $this->m_Series->getCountOfDataValues();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getDataLabels()]

      @return com.aspose.cells.DataLabels
     */
    function getDataLabels()
    {
        return ClassFactory::_t2($this->m_Series->getDataLabels());
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getDoughnutHoleSize()]

      @return int
     */
    function getDoughnutHoleSize()
    {
        return $this->m_Series->getDoughnutHoleSize();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getDownBars()]

      @return com.aspose.cells.DropBars
     */
    function getDownBars()
    {
        return ClassFactory::_t2($this->m_Series->getDownBars());
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getDropLines()]

      @return com.aspose.cells.Line
     */
    function getDropLines()
    {
        return ClassFactory::_t2($this->m_Series->getDropLines());
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getExplosion()]

      @return int
     */
    function getExplosion()
    {
        return $this->m_Series->getExplosion();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getFirstSliceAngle()]

      @return short
     */
    function getFirstSliceAngle()
    {
        return $this->m_Series->getFirstSliceAngle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getGapWidth()]

      @return short
     */
    function getGapWidth()
    {
        return $this->m_Series->getGapWidth();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getHas3DEffect()]

      @return boolean
     */
    function getHas3DEffect()
    {
        return $this->m_Series->getHas3DEffect();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getHiLoLines()]

      @return com.aspose.cells.Line
     */
    function getHiLoLines()
    {
        return ClassFactory::_t2($this->m_Series->getHiLoLines());
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getLeaderLines()]

      @return com.aspose.cells.Line
     */
    function getLeaderLines()
    {
        return ClassFactory::_t2($this->m_Series->getLeaderLines());
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getLegendEntry()]

      @return com.aspose.cells.LegendEntry
     */
    function getLegendEntry()
    {
        return ClassFactory::_t2($this->m_Series->getLegendEntry());
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getLine()]

      @return com.aspose.cells.Line
     */
    function getLine()
    {
        return ClassFactory::_t2($this->m_Series->getLine());
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getMarkerBackgroundColor()]

      @return com.aspose.cells.Color
     */
    function getMarkerBackgroundColor()
    {
        return ClassFactory::_t2($this->m_Series->getMarkerBackgroundColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getMarkerBackgroundColorSetType()]

      @return int
     */
    function getMarkerBackgroundColorSetType()
    {
        return $this->m_Series->getMarkerBackgroundColorSetType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getMarkerForegroundColor()]

      @return com.aspose.cells.Color
     */
    function getMarkerForegroundColor()
    {
        return ClassFactory::_t2($this->m_Series->getMarkerForegroundColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getMarkerForegroundColorSetType()]

      @return int
     */
    function getMarkerForegroundColorSetType()
    {
        return $this->m_Series->getMarkerForegroundColorSetType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getMarkerSize()]

      @return int
     */
    function getMarkerSize()
    {
        return $this->m_Series->getMarkerSize();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getMarkerStyle()]

      @return int
     */
    function getMarkerStyle()
    {
        return $this->m_Series->getMarkerStyle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getName()]

      @return String
     */
    function getName()
    {
        return $this->m_Series->getName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getOverlap()]

      @return short
     */
    function getOverlap()
    {
        return $this->m_Series->getOverlap();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getPlotOnSecondAxis()]

      @return boolean
     */
    function getPlotOnSecondAxis()
    {
        return $this->m_Series->getPlotOnSecondAxis();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getPoints()]

      @return com.aspose.cells.ChartPointCollection
     */
    function getPoints()
    {
        return ClassFactory::_t2($this->m_Series->getPoints());
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getSecondPlotSize()]

      @return short
     */
    function getSecondPlotSize()
    {
        return $this->m_Series->getSecondPlotSize();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getSeriesLines()]

      @return com.aspose.cells.Line
     */
    function getSeriesLines()
    {
        return ClassFactory::_t2($this->m_Series->getSeriesLines());
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getShadow()]

      @return boolean
     */
    function getShadow()
    {
        return $this->m_Series->getShadow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getShapeProperties()]

      @return com.aspose.cells.ShapeProperties
     */
    function getShapeProperties()
    {
        return ClassFactory::_t2($this->m_Series->getShapeProperties());
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getShowNegativeBubbles()]

      @return boolean
     */
    function getShowNegativeBubbles()
    {
        return $this->m_Series->getShowNegativeBubbles();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getSizeRepresents()]

      @return int
     */
    function getSizeRepresents()
    {
        return $this->m_Series->getSizeRepresents();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getSmooth()]

      @return boolean
     */
    function getSmooth()
    {
        return $this->m_Series->getSmooth();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getSplitType()]

      @return int
     */
    function getSplitType()
    {
        return $this->m_Series->getSplitType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getSplitValue()]

      @return double
     */
    function getSplitValue()
    {
        return $this->m_Series->getSplitValue();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getTrendLines()]

      @return com.aspose.cells.TrendlineCollection
     */
    function getTrendLines()
    {
        return ClassFactory::_t2($this->m_Series->getTrendLines());
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getType()]

      @return int
     */
    function getType()
    {
        return $this->m_Series->getType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getUpBars()]

      @return com.aspose.cells.DropBars
     */
    function getUpBars()
    {
        return ClassFactory::_t2($this->m_Series->getUpBars());
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getValues()]

      @return String
     */
    function getValues()
    {
        return $this->m_Series->getValues();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getXErrorBar()]

      @return com.aspose.cells.ErrorBar
     */
    function getXErrorBar()
    {
        return ClassFactory::_t2($this->m_Series->getXErrorBar());
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getXValues()]

      @return String
     */
    function getXValues()
    {
        return $this->m_Series->getXValues();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.getYErrorBar()]

      @return com.aspose.cells.ErrorBar
     */
    function getYErrorBar()
    {
        return ClassFactory::_t2($this->m_Series->getYErrorBar());
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.hasDropLines()]

      @return boolean
     */
    function hasDropLines()
    {
        return $this->m_Series->hasDropLines();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.hasHiLoLines()]

      @return boolean
     */
    function hasHiLoLines()
    {
        return $this->m_Series->hasHiLoLines();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.hasLeaderLines()]

      @return boolean
     */
    function hasLeaderLines()
    {
        return $this->m_Series->hasLeaderLines();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.hasRadarAxisLabels()]

      @return boolean
     */
    function hasRadarAxisLabels()
    {
        return $this->m_Series->hasRadarAxisLabels();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.hasSeriesLines()]

      @return boolean
     */
    function hasSeriesLines()
    {
        return $this->m_Series->hasSeriesLines();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.hasUpDownBars()]

      @return boolean
     */
    function hasUpDownBars()
    {
        return $this->m_Series->hasUpDownBars();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.isAutoSplit()]

      @return boolean
     */
    function isAutoSplit()
    {
        return $this->m_Series->isAutoSplit();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.isColorVaried()]

      @return boolean
     */
    function isColorVaried()
    {
        return $this->m_Series->isColorVaried();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.move(int)]

      @param pInt0  int
     */
    function move($pInt0)
    {
        $this->m_Series->move($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setBar3DShapeType(int)]

      @param pInt0  int
     */
    function setBar3DShapeType($pInt0)
    {
        $this->m_Series->setBar3DShapeType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setBarShape(int)]

      @param pInt0  int
     */
    function setBarShape($pInt0)
    {
        $this->m_Series->setBarShape($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setBubbleScale(int)]

      @param pInt0  int
     */
    function setBubbleScale($pInt0)
    {
        $this->m_Series->setBubbleScale($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setBubbleSizes(String)]

      @param oString0  String
     */
    function setBubbleSizes($oString0)
    {
        $this->m_Series->setBubbleSizes($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setColorVaried(boolean)]

      @param pBoolean0  boolean
     */
    function setColorVaried($pBoolean0)
    {
        $this->m_Series->setColorVaried($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setDoughnutHoleSize(int)]

      @param pInt0  int
     */
    function setDoughnutHoleSize($pInt0)
    {
        $this->m_Series->setDoughnutHoleSize($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setExplosion(int)]

      @param pInt0  int
     */
    function setExplosion($pInt0)
    {
        $this->m_Series->setExplosion($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setFirstSliceAngle(short)]

      @param pShort0  short
     */
    function setFirstSliceAngle($pShort0)
    {
        $this->m_Series->setFirstSliceAngle($pShort0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setGapWidth(short)]

      @param pShort0  short
     */
    function setGapWidth($pShort0)
    {
        $this->m_Series->setGapWidth($pShort0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setHas3DEffect(boolean)]

      @param pBoolean0  boolean
     */
    function setHas3DEffect($pBoolean0)
    {
        $this->m_Series->setHas3DEffect($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setHasDropLines(boolean)]

      @param pBoolean0  boolean
     */
    function setHasDropLines($pBoolean0)
    {
        $this->m_Series->setHasDropLines($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setHasHiLoLines(boolean)]

      @param pBoolean0  boolean
     */
    function setHasHiLoLines($pBoolean0)
    {
        $this->m_Series->setHasHiLoLines($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setHasLeaderLines(boolean)]

      @param pBoolean0  boolean
     */
    function setHasLeaderLines($pBoolean0)
    {
        $this->m_Series->setHasLeaderLines($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setHasRadarAxisLabels(boolean)]

      @param pBoolean0  boolean
     */
    function setHasRadarAxisLabels($pBoolean0)
    {
        $this->m_Series->setHasRadarAxisLabels($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setHasSeriesLines(boolean)]

      @param pBoolean0  boolean
     */
    function setHasSeriesLines($pBoolean0)
    {
        $this->m_Series->setHasSeriesLines($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setHasUpDownBars(boolean)]

      @param pBoolean0  boolean
     */
    function setHasUpDownBars($pBoolean0)
    {
        $this->m_Series->setHasUpDownBars($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setMarkerBackgroundColor(Color)]

      @param oColor0  com.aspose.cells.Color
     */
    function setMarkerBackgroundColor($oColor0)
    {
        $this->m_Series->setMarkerBackgroundColor(ClassFactory::_t1($oColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setMarkerBackgroundColorSetType(int)]

      @param pInt0  int
     */
    function setMarkerBackgroundColorSetType($pInt0)
    {
        $this->m_Series->setMarkerBackgroundColorSetType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setMarkerForegroundColor(Color)]

      @param oColor0  com.aspose.cells.Color
     */
    function setMarkerForegroundColor($oColor0)
    {
        $this->m_Series->setMarkerForegroundColor(ClassFactory::_t1($oColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setMarkerForegroundColorSetType(int)]

      @param pInt0  int
     */
    function setMarkerForegroundColorSetType($pInt0)
    {
        $this->m_Series->setMarkerForegroundColorSetType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setMarkerSize(int)]

      @param pInt0  int
     */
    function setMarkerSize($pInt0)
    {
        $this->m_Series->setMarkerSize($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setMarkerStyle(int)]

      @param pInt0  int
     */
    function setMarkerStyle($pInt0)
    {
        $this->m_Series->setMarkerStyle($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setName(String)]

      @param oString0  String
     */
    function setName($oString0)
    {
        $this->m_Series->setName($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setOverlap(short)]

      @param pShort0  short
     */
    function setOverlap($pShort0)
    {
        $this->m_Series->setOverlap($pShort0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setPlotOnSecondAxis(boolean)]

      @param pBoolean0  boolean
     */
    function setPlotOnSecondAxis($pBoolean0)
    {
        $this->m_Series->setPlotOnSecondAxis($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setSecondPlotSize(short)]

      @param pShort0  short
     */
    function setSecondPlotSize($pShort0)
    {
        $this->m_Series->setSecondPlotSize($pShort0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setShadow(boolean)]

      @param pBoolean0  boolean
     */
    function setShadow($pBoolean0)
    {
        $this->m_Series->setShadow($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setShowNegativeBubbles(boolean)]

      @param pBoolean0  boolean
     */
    function setShowNegativeBubbles($pBoolean0)
    {
        $this->m_Series->setShowNegativeBubbles($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setSizeRepresents(int)]

      @param pInt0  int
     */
    function setSizeRepresents($pInt0)
    {
        $this->m_Series->setSizeRepresents($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setSmooth(boolean)]

      @param pBoolean0  boolean
     */
    function setSmooth($pBoolean0)
    {
        $this->m_Series->setSmooth($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setSplitType(int)]

      @param pInt0  int
     */
    function setSplitType($pInt0)
    {
        $this->m_Series->setSplitType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setSplitValue(double)]

      @param pDouble0  double
     */
    function setSplitValue($pDouble0)
    {
        $this->m_Series->setSplitValue($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setType(int)]

      @param pInt0  int
     */
    function setType($pInt0)
    {
        $this->m_Series->setType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setValues(String)]

      @param oString0  String
     */
    function setValues($oString0)
    {
        $this->m_Series->setValues($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeries.setXValues(String)]

      @param oString0  String
     */
    function setXValues($oString0)
    {
        $this->m_Series->setXValues($oString0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsSeriesCollection]
  
 */
class SeriesCollection extends CollectionBase
{
    public $m_SeriesCollection;
    
    function __construct($seriesCollection)
    {
    	$this->m_SeriesCollection = $seriesCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsSeriesCollection.add(String, boolean)]

      @param oString0  String
      @param pBoolean1  boolean
      @return int
     */
    function add($oString0, $pBoolean1)
    {
        return $this->m_SeriesCollection->add($oString0, $pBoolean1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeriesCollection.addR1C1(String, boolean)]

      @param oString0  String
      @param pBoolean1  boolean
      @return int
     */
    function addR1C1($oString0, $pBoolean1)
    {
        return $this->m_SeriesCollection->addR1C1($oString0, $pBoolean1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeriesCollection.changeSeriesOrder(int, int)]

      @param pInt0  int
      @param pInt1  int
     */
    function changeSeriesOrder($pInt0, $pInt1)
    {
        $this->m_SeriesCollection->changeSeriesOrder($pInt0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeriesCollection.get(int)]

      @param pInt0  int
      @return corresponding java type is {java.lang.Object}
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_SeriesCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeriesCollection.getCategoryData()]

      @return String
     */
    function getCategoryData()
    {
        return $this->m_SeriesCollection->getCategoryData();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeriesCollection.getSecondCatergoryData()]

      @return String
     */
    function getSecondCatergoryData()
    {
        return $this->m_SeriesCollection->getSecondCatergoryData();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeriesCollection.isColorVaried()]

      @return boolean
     */
    function isColorVaried()
    {
        return $this->m_SeriesCollection->isColorVaried();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeriesCollection.removeAt(int)]

      @param pInt0  int
     */
    function removeAt($pInt0)
    {
        $this->m_SeriesCollection->removeAt($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeriesCollection.setCategoryData(String)]

      @param oString0  String
     */
    function setCategoryData($oString0)
    {
        $this->m_SeriesCollection->setCategoryData($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeriesCollection.setColorVaried(boolean)]

      @param pBoolean0  boolean
     */
    function setColorVaried($pBoolean0)
    {
        $this->m_SeriesCollection->setColorVaried($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSeriesCollection.setSecondCatergoryData(String)]

      @param oString0  String
     */
    function setSecondCatergoryData($oString0)
    {
        $this->m_SeriesCollection->setSecondCatergoryData($oString0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsShadowEffect]
  
 */
class ShadowEffect
{
    public $m_ShadowEffect;
    
    function __construct($shadowEffect)
    {
    	$this->m_ShadowEffect = $shadowEffect;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsShadowEffect.getAngle()]

      @return double
     */
    function getAngle()
    {
        return $this->m_ShadowEffect->getAngle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShadowEffect.getBlur()]

      @return double
     */
    function getBlur()
    {
        return $this->m_ShadowEffect->getBlur();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShadowEffect.getColor()]

      @return com.aspose.cells.CellsColor
     */
    function getColor()
    {
        return ClassFactory::_t2($this->m_ShadowEffect->getColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsShadowEffect.getDistance()]

      @return double
     */
    function getDistance()
    {
        return $this->m_ShadowEffect->getDistance();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShadowEffect.getPresetType()]

      @return int
     */
    function getPresetType()
    {
        return $this->m_ShadowEffect->getPresetType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShadowEffect.getSize()]

      @return double
     */
    function getSize()
    {
        return $this->m_ShadowEffect->getSize();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShadowEffect.getTransparency()]

      @return double
     */
    function getTransparency()
    {
        return $this->m_ShadowEffect->getTransparency();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShadowEffect.setAngle(double)]

      @param pDouble0  double
     */
    function setAngle($pDouble0)
    {
        $this->m_ShadowEffect->setAngle($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShadowEffect.setBlur(double)]

      @param pDouble0  double
     */
    function setBlur($pDouble0)
    {
        $this->m_ShadowEffect->setBlur($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShadowEffect.setColor(CellsColor)]

      @param oCellsColor0  com.aspose.cells.CellsColor
     */
    function setColor($oCellsColor0)
    {
        $this->m_ShadowEffect->setColor(ClassFactory::_t1($oCellsColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsShadowEffect.setDistance(double)]

      @param pDouble0  double
     */
    function setDistance($pDouble0)
    {
        $this->m_ShadowEffect->setDistance($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShadowEffect.setPresetType(int)]

      @param pInt0  int
     */
    function setPresetType($pInt0)
    {
        $this->m_ShadowEffect->setPresetType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShadowEffect.setSize(double)]

      @param pDouble0  double
     */
    function setSize($pDouble0)
    {
        $this->m_ShadowEffect->setSize($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShadowEffect.setTransparency(double)]

      @param pDouble0  double
     */
    function setTransparency($pDouble0)
    {
        $this->m_ShadowEffect->setTransparency($pDouble0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsShape]
  
 */
class Shape
{
    public $m_Shape;
    
    function __construct($shape)
    {
    	$this->m_Shape = $shape;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsShape.addHyperlink(String)]

      @param oString0  String
      @return com.aspose.cells.Hyperlink
     */
    function addHyperlink($oString0)
    {
        return ClassFactory::_t2($this->m_Shape->addHyperlink($oString0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getActualLowerRightRow()]

      @return int
     */
    function getActualLowerRightRow()
    {
        return $this->m_Shape->getActualLowerRightRow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getAlternativeText()]

      @return String
     */
    function getAlternativeText()
    {
        return $this->m_Shape->getAlternativeText();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getAutoShapeType()]

      @return int
     */
    function getAutoShapeType()
    {
        return $this->m_Shape->getAutoShapeType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getFillFormat()]

      @return com.aspose.cells.MsoFillFormat
     */
    function getFillFormat()
    {
        return ClassFactory::_t2($this->m_Shape->getFillFormat());
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getFont()]

      @return com.aspose.cells.Font
     */
    function getFont()
    {
        return ClassFactory::_t2($this->m_Shape->getFont());
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getFormatPicture()]

      @return com.aspose.cells.MsoFormatPicture
     */
    function getFormatPicture()
    {
        return ClassFactory::_t2($this->m_Shape->getFormatPicture());
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getHeight()]

      @return int
     */
    function getHeight()
    {
        return $this->m_Shape->getHeight();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getHeightCM()]

      @return double
     */
    function getHeightCM()
    {
        return $this->m_Shape->getHeightCM();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getHeightInShape()]

      @return int
     */
    function getHeightInShape()
    {
        return $this->m_Shape->getHeightInShape();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getHeightInch()]

      @return double
     */
    function getHeightInch()
    {
        return $this->m_Shape->getHeightInch();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getHeightPt()]

      @return double
     */
    function getHeightPt()
    {
        return $this->m_Shape->getHeightPt();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getHeightScale()]

      @return int
     */
    function getHeightScale()
    {
        return $this->m_Shape->getHeightScale();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getHtmlText()]

      @return String
     */
    function getHtmlText()
    {
        return $this->m_Shape->getHtmlText();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getHyperlink()]

      @return com.aspose.cells.Hyperlink
     */
    function getHyperlink()
    {
        return ClassFactory::_t2($this->m_Shape->getHyperlink());
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getLeft()]

      @return int
     */
    function getLeft()
    {
        return $this->m_Shape->getLeft();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getLeftCM()]

      @return double
     */
    function getLeftCM()
    {
        return $this->m_Shape->getLeftCM();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getLeftInShape()]

      @return int
     */
    function getLeftInShape()
    {
        return $this->m_Shape->getLeftInShape();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getLeftInch()]

      @return double
     */
    function getLeftInch()
    {
        return $this->m_Shape->getLeftInch();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getLineFormat()]

      @return com.aspose.cells.MsoLineFormat
     */
    function getLineFormat()
    {
        return ClassFactory::_t2($this->m_Shape->getLineFormat());
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getLinkedCell()]

      @return String
     */
    function getLinkedCell()
    {
        return $this->m_Shape->getLinkedCell();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getLowerDeltaX()]

      @return int
     */
    function getLowerDeltaX()
    {
        return $this->m_Shape->getLowerDeltaX();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getLowerDeltaY()]

      @return int
     */
    function getLowerDeltaY()
    {
        return $this->m_Shape->getLowerDeltaY();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getLowerRightColumn()]

      @return int
     */
    function getLowerRightColumn()
    {
        return $this->m_Shape->getLowerRightColumn();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getLowerRightRow()]

      @return int
     */
    function getLowerRightRow()
    {
        return $this->m_Shape->getLowerRightRow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getMsoDrawingType()]

      @return int
     */
    function getMsoDrawingType()
    {
        return $this->m_Shape->getMsoDrawingType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getName()]

      @return String
     */
    function getName()
    {
        return $this->m_Shape->getName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getPlacement()]

      @return int
     */
    function getPlacement()
    {
        return $this->m_Shape->getPlacement();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getRelativeToOriginalPictureSize()]

      @return boolean
     */
    function getRelativeToOriginalPictureSize()
    {
        return $this->m_Shape->getRelativeToOriginalPictureSize();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getRotation()]

      @return int
     */
    function getRotation()
    {
        return $this->m_Shape->getRotation();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getRotationAngle()]

      @return int
     */
    function getRotationAngle()
    {
        return $this->m_Shape->getRotationAngle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getText()]

      @return String
     */
    function getText()
    {
        return $this->m_Shape->getText();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getTextEffect()]

      @return com.aspose.cells.TextEffectFormat
     */
    function getTextEffect()
    {
        return ClassFactory::_t2($this->m_Shape->getTextEffect());
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getTextFrame()]

      @return com.aspose.cells.MsoTextFrame
     */
    function getTextFrame()
    {
        return ClassFactory::_t2($this->m_Shape->getTextFrame());
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getTextHorizontalAlignment()]

      @return int
     */
    function getTextHorizontalAlignment()
    {
        return $this->m_Shape->getTextHorizontalAlignment();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getTextHorizontalOverflow()]

      @return int
     */
    function getTextHorizontalOverflow()
    {
        return $this->m_Shape->getTextHorizontalOverflow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getTextOrientationType()]

      @return int
     */
    function getTextOrientationType()
    {
        return $this->m_Shape->getTextOrientationType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getTextVerticalAlignment()]

      @return int
     */
    function getTextVerticalAlignment()
    {
        return $this->m_Shape->getTextVerticalAlignment();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getTextVerticalOverflow()]

      @return int
     */
    function getTextVerticalOverflow()
    {
        return $this->m_Shape->getTextVerticalOverflow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getTop()]

      @return int
     */
    function getTop()
    {
        return $this->m_Shape->getTop();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getTopCM()]

      @return double
     */
    function getTopCM()
    {
        return $this->m_Shape->getTopCM();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getTopInShape()]

      @return int
     */
    function getTopInShape()
    {
        return $this->m_Shape->getTopInShape();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getTopInch()]

      @return double
     */
    function getTopInch()
    {
        return $this->m_Shape->getTopInch();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getUpperDeltaX()]

      @return int
     */
    function getUpperDeltaX()
    {
        return $this->m_Shape->getUpperDeltaX();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getUpperDeltaY()]

      @return int
     */
    function getUpperDeltaY()
    {
        return $this->m_Shape->getUpperDeltaY();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getUpperLeftColumn()]

      @return int
     */
    function getUpperLeftColumn()
    {
        return $this->m_Shape->getUpperLeftColumn();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getUpperLeftRow()]

      @return int
     */
    function getUpperLeftRow()
    {
        return $this->m_Shape->getUpperLeftRow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getWidth()]

      @return int
     */
    function getWidth()
    {
        return $this->m_Shape->getWidth();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getWidthCM()]

      @return double
     */
    function getWidthCM()
    {
        return $this->m_Shape->getWidthCM();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getWidthInShape()]

      @return int
     */
    function getWidthInShape()
    {
        return $this->m_Shape->getWidthInShape();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getWidthInch()]

      @return double
     */
    function getWidthInch()
    {
        return $this->m_Shape->getWidthInch();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getWidthPt()]

      @return double
     */
    function getWidthPt()
    {
        return $this->m_Shape->getWidthPt();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getWidthScale()]

      @return int
     */
    function getWidthScale()
    {
        return $this->m_Shape->getWidthScale();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getX()]

      @return int
     */
    function getX()
    {
        return $this->m_Shape->getX();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getY()]

      @return int
     */
    function getY()
    {
        return $this->m_Shape->getY();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.getZOrderPosition()]

      @return int
     */
    function getZOrderPosition()
    {
        return $this->m_Shape->getZOrderPosition();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.isGroup()]

      @return boolean
     */
    function isGroup()
    {
        return $this->m_Shape->isGroup();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.isHidden()]

      @return boolean
     */
    function isHidden()
    {
        return $this->m_Shape->isHidden();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.isLockAspectRatio()]

      @return boolean
     */
    function isLockAspectRatio()
    {
        return $this->m_Shape->isLockAspectRatio();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.isLocked()]

      @return boolean
     */
    function isLocked()
    {
        return $this->m_Shape->isLocked();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.isPrintable()]

      @return boolean
     */
    function isPrintable()
    {
        return $this->m_Shape->isPrintable();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.isPrinted()]

      @return boolean
     */
    function isPrinted()
    {
        return $this->m_Shape->isPrinted();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.isTextWrapped()]

      @return boolean
     */
    function isTextWrapped()
    {
        return $this->m_Shape->isTextWrapped();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.isWordArt()]

      @return boolean
     */
    function isWordArt()
    {
        return $this->m_Shape->isWordArt();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.moveToRange(int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
     */
    function moveToRange($pInt0, $pInt1, $pInt2, $pInt3)
    {
        $this->m_Shape->moveToRange($pInt0, $pInt1, $pInt2, $pInt3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.removeHyperlink()]

     */
    function removeHyperlink()
    {
        $this->m_Shape->removeHyperlink();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setAlternativeText(String)]

      @param oString0  String
     */
    function setAlternativeText($oString0)
    {
        $this->m_Shape->setAlternativeText($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setAutoShapeType(int)]

      @param pInt0  int
     */
    function setAutoShapeType($pInt0)
    {
        $this->m_Shape->setAutoShapeType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setHeight(int)]

      @param pInt0  int
     */
    function setHeight($pInt0)
    {
        $this->m_Shape->setHeight($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setHeightCM(double)]

      @param pDouble0  double
     */
    function setHeightCM($pDouble0)
    {
        $this->m_Shape->setHeightCM($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setHeightInShape(int)]

      @param pInt0  int
     */
    function setHeightInShape($pInt0)
    {
        $this->m_Shape->setHeightInShape($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setHeightInch(double)]

      @param pDouble0  double
     */
    function setHeightInch($pDouble0)
    {
        $this->m_Shape->setHeightInch($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setHeightPt(double)]

      @param pDouble0  double
     */
    function setHeightPt($pDouble0)
    {
        $this->m_Shape->setHeightPt($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setHeightScale(int)]

      @param pInt0  int
     */
    function setHeightScale($pInt0)
    {
        $this->m_Shape->setHeightScale($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setHidden(boolean)]

      @param pBoolean0  boolean
     */
    function setHidden($pBoolean0)
    {
        $this->m_Shape->setHidden($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setHtmlText(String)]

      @param oString0  String
     */
    function setHtmlText($oString0)
    {
        $this->m_Shape->setHtmlText($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setLeft(int)]

      @param pInt0  int
     */
    function setLeft($pInt0)
    {
        $this->m_Shape->setLeft($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setLeftCM(double)]

      @param pDouble0  double
     */
    function setLeftCM($pDouble0)
    {
        $this->m_Shape->setLeftCM($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setLeftInShape(int)]

      @param pInt0  int
     */
    function setLeftInShape($pInt0)
    {
        $this->m_Shape->setLeftInShape($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setLeftInch(double)]

      @param pDouble0  double
     */
    function setLeftInch($pDouble0)
    {
        $this->m_Shape->setLeftInch($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setLinkedCell(String)]

      @param oString0  String
     */
    function setLinkedCell($oString0)
    {
        $this->m_Shape->setLinkedCell($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setLockAspectRatio(boolean)]

      @param pBoolean0  boolean
     */
    function setLockAspectRatio($pBoolean0)
    {
        $this->m_Shape->setLockAspectRatio($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setLocked(boolean)]

      @param pBoolean0  boolean
     */
    function setLocked($pBoolean0)
    {
        $this->m_Shape->setLocked($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setLowerDeltaX(int)]

      @param pInt0  int
     */
    function setLowerDeltaX($pInt0)
    {
        $this->m_Shape->setLowerDeltaX($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setLowerDeltaY(int)]

      @param pInt0  int
     */
    function setLowerDeltaY($pInt0)
    {
        $this->m_Shape->setLowerDeltaY($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setLowerRightColumn(int)]

      @param pInt0  int
     */
    function setLowerRightColumn($pInt0)
    {
        $this->m_Shape->setLowerRightColumn($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setLowerRightRow(int)]

      @param pInt0  int
     */
    function setLowerRightRow($pInt0)
    {
        $this->m_Shape->setLowerRightRow($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setName(String)]

      @param oString0  String
     */
    function setName($oString0)
    {
        $this->m_Shape->setName($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setPlacement(int)]

      @param pInt0  int
     */
    function setPlacement($pInt0)
    {
        $this->m_Shape->setPlacement($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setPrintable(boolean)]

      @param pBoolean0  boolean
     */
    function setPrintable($pBoolean0)
    {
        $this->m_Shape->setPrintable($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setPrinted(boolean)]

      @param pBoolean0  boolean
     */
    function setPrinted($pBoolean0)
    {
        $this->m_Shape->setPrinted($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setRelativeToOriginalPictureSize(boolean)]

      @param pBoolean0  boolean
     */
    function setRelativeToOriginalPictureSize($pBoolean0)
    {
        $this->m_Shape->setRelativeToOriginalPictureSize($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setRotation(int)]

      @param pInt0  int
     */
    function setRotation($pInt0)
    {
        $this->m_Shape->setRotation($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setRotationAngle(int)]

      @param pInt0  int
     */
    function setRotationAngle($pInt0)
    {
        $this->m_Shape->setRotationAngle($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setText(String)]

      @param oString0  String
     */
    function setText($oString0)
    {
        $this->m_Shape->setText($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setTextHorizontalAlignment(int)]

      @param pInt0  int
     */
    function setTextHorizontalAlignment($pInt0)
    {
        $this->m_Shape->setTextHorizontalAlignment($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setTextHorizontalOverflow(int)]

      @param pInt0  int
     */
    function setTextHorizontalOverflow($pInt0)
    {
        $this->m_Shape->setTextHorizontalOverflow($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setTextOrientationType(int)]

      @param pInt0  int
     */
    function setTextOrientationType($pInt0)
    {
        $this->m_Shape->setTextOrientationType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setTextVerticalAlignment(int)]

      @param pInt0  int
     */
    function setTextVerticalAlignment($pInt0)
    {
        $this->m_Shape->setTextVerticalAlignment($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setTextVerticalOverflow(int)]

      @param pInt0  int
     */
    function setTextVerticalOverflow($pInt0)
    {
        $this->m_Shape->setTextVerticalOverflow($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setTextWrapped(boolean)]

      @param pBoolean0  boolean
     */
    function setTextWrapped($pBoolean0)
    {
        $this->m_Shape->setTextWrapped($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setTop(int)]

      @param pInt0  int
     */
    function setTop($pInt0)
    {
        $this->m_Shape->setTop($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setTopCM(double)]

      @param pDouble0  double
     */
    function setTopCM($pDouble0)
    {
        $this->m_Shape->setTopCM($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setTopInShape(int)]

      @param pInt0  int
     */
    function setTopInShape($pInt0)
    {
        $this->m_Shape->setTopInShape($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setTopInch(double)]

      @param pDouble0  double
     */
    function setTopInch($pDouble0)
    {
        $this->m_Shape->setTopInch($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setUpperDeltaX(int)]

      @param pInt0  int
     */
    function setUpperDeltaX($pInt0)
    {
        $this->m_Shape->setUpperDeltaX($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setUpperDeltaY(int)]

      @param pInt0  int
     */
    function setUpperDeltaY($pInt0)
    {
        $this->m_Shape->setUpperDeltaY($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setUpperLeftColumn(int)]

      @param pInt0  int
     */
    function setUpperLeftColumn($pInt0)
    {
        $this->m_Shape->setUpperLeftColumn($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setUpperLeftRow(int)]

      @param pInt0  int
     */
    function setUpperLeftRow($pInt0)
    {
        $this->m_Shape->setUpperLeftRow($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setWidth(int)]

      @param pInt0  int
     */
    function setWidth($pInt0)
    {
        $this->m_Shape->setWidth($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setWidthCM(double)]

      @param pDouble0  double
     */
    function setWidthCM($pDouble0)
    {
        $this->m_Shape->setWidthCM($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setWidthInShape(int)]

      @param pInt0  int
     */
    function setWidthInShape($pInt0)
    {
        $this->m_Shape->setWidthInShape($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setWidthInch(double)]

      @param pDouble0  double
     */
    function setWidthInch($pDouble0)
    {
        $this->m_Shape->setWidthInch($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setWidthPt(double)]

      @param pDouble0  double
     */
    function setWidthPt($pDouble0)
    {
        $this->m_Shape->setWidthPt($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setWidthScale(int)]

      @param pInt0  int
     */
    function setWidthScale($pInt0)
    {
        $this->m_Shape->setWidthScale($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setX(int)]

      @param pInt0  int
     */
    function setX($pInt0)
    {
        $this->m_Shape->setX($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setY(int)]

      @param pInt0  int
     */
    function setY($pInt0)
    {
        $this->m_Shape->setY($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.setZOrderPosition(int)]

      @param pInt0  int
     */
    function setZOrderPosition($pInt0)
    {
        $this->m_Shape->setZOrderPosition($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.toImage(OutputStream, ImageFormat)]

      @param oOutputStream0  corresponding java type is {java.io.OutputStream}
      @param oImageFormat1  com.aspose.cells.ImageFormat
     */
    function toImage($oOutputStream0, $oImageFormat1)
    {
        $this->m_Shape->toImage(ClassFactory::_t1($oOutputStream0), ClassFactory::_t1($oImageFormat1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.toImage(OutputStream, ImageOrPrintOptions)]

      @param oOutputStream0  corresponding java type is {java.io.OutputStream}
      @param oImageOrPrintOptions1  com.aspose.cells.ImageOrPrintOptions
     */
    function toImageOI($oOutputStream0, $oImageOrPrintOptions1)
    {
        $this->m_Shape->toImage(ClassFactory::_t1($oOutputStream0), ClassFactory::_t1($oImageOrPrintOptions1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.toImage(String, ImageOrPrintOptions)]

      @param oString0  String
      @param oImageOrPrintOptions1  com.aspose.cells.ImageOrPrintOptions
     */
    function toImageSI($oString0, $oImageOrPrintOptions1)
    {
        $this->m_Shape->toImage($oString0, ClassFactory::_t1($oImageOrPrintOptions1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsShape.updateSelectedValue()]

     */
    function updateSelectedValue()
    {
        $this->m_Shape->updateSelectedValue();
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsShapeCollection]
  
 */
class ShapeCollection extends CollectionBase
{
    public $m_ShapeCollection;
    
    function __construct($shapeCollection)
    {
    	$this->m_ShapeCollection = $shapeCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsShapeCollection.addAutoShape(int, int, int, int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @param pInt4  int
      @param pInt5  int
      @param pInt6  int
      @return com.aspose.cells.Shape
     */
    function addAutoShape($pInt0, $pInt1, $pInt2, $pInt3, $pInt4, $pInt5, $pInt6)
    {
        return ClassFactory::_t2($this->m_ShapeCollection->addAutoShape($pInt0, $pInt1, $pInt2, $pInt3, $pInt4, $pInt5, $pInt6));
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeCollection.addAutoShapeInChart(int, int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @param pInt4  int
      @return com.aspose.cells.Shape
     */
    function addAutoShapeInChart($pInt0, $pInt1, $pInt2, $pInt3, $pInt4)
    {
        return ClassFactory::_t2($this->m_ShapeCollection->addAutoShapeInChart($pInt0, $pInt1, $pInt2, $pInt3, $pInt4));
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeCollection.addCopy(Shape, int, int, int, int)]

      @param oShape0  com.aspose.cells.Shape
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @param pInt4  int
      @return com.aspose.cells.Shape
     */
    function addCopy($oShape0, $pInt1, $pInt2, $pInt3, $pInt4)
    {
        return ClassFactory::_t2($this->m_ShapeCollection->addCopy(ClassFactory::_t1($oShape0), $pInt1, $pInt2, $pInt3, $pInt4));
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeCollection.addFreeFloatingShape(int, int, int, int, int, byte[], boolean)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @param pInt4  int
      @param arrP1DByte5  byte[]
      @param pBoolean6  boolean
      @return com.aspose.cells.Shape
     */
    function addFreeFloatingShape($pInt0, $pInt1, $pInt2, $pInt3, $pInt4, $arrP1DByte5, $pBoolean6)
    {
        return ClassFactory::_t2($this->m_ShapeCollection->addFreeFloatingShape($pInt0, $pInt1, $pInt2, $pInt3, $pInt4, $arrP1DByte5, $pBoolean6));
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeCollection.addLabelInChart(int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @return com.aspose.cells.Label
     */
    function addLabelInChart($pInt0, $pInt1, $pInt2, $pInt3)
    {
        return ClassFactory::_t2($this->m_ShapeCollection->addLabelInChart($pInt0, $pInt1, $pInt2, $pInt3));
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeCollection.addLinkedPicture(int, int, int, int, String)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @param oString4  String
      @return com.aspose.cells.Picture
     */
    function addLinkedPicture($pInt0, $pInt1, $pInt2, $pInt3, $oString4)
    {
        return ClassFactory::_t2($this->m_ShapeCollection->addLinkedPicture($pInt0, $pInt1, $pInt2, $pInt3, $oString4));
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeCollection.addOleObject(int, int, int, int, int, int, byte[])]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @param pInt4  int
      @param pInt5  int
      @param arrP1DByte6  byte[]
      @return com.aspose.cells.OleObject
     */
    function addOleObject($pInt0, $pInt1, $pInt2, $pInt3, $pInt4, $pInt5, $arrP1DByte6)
    {
        return ClassFactory::_t2($this->m_ShapeCollection->addOleObject($pInt0, $pInt1, $pInt2, $pInt3, $pInt4, $pInt5, $arrP1DByte6));
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeCollection.addOleObjectWithLinkedImage(int, int, int, int, String)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @param oString4  String
      @return com.aspose.cells.OleObject
     */
    function addOleObjectWithLinkedImage($pInt0, $pInt1, $pInt2, $pInt3, $oString4)
    {
        return ClassFactory::_t2($this->m_ShapeCollection->addOleObjectWithLinkedImage($pInt0, $pInt1, $pInt2, $pInt3, $oString4));
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeCollection.addPicture(int, int, InputStream, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param oInputStream2  corresponding java type is {java.io.InputStream}
      @param pInt3  int
      @param pInt4  int
      @return com.aspose.cells.Picture
     */
    function addPicture($pInt0, $pInt1, $oInputStream2, $pInt3, $pInt4)
    {
        return ClassFactory::_t2($this->m_ShapeCollection->addPicture($pInt0, $pInt1, ClassFactory::_t1($oInputStream2), $pInt3, $pInt4));
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeCollection.addPictureInChart(int, int, InputStream, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param oInputStream2  corresponding java type is {java.io.InputStream}
      @param pInt3  int
      @param pInt4  int
      @return com.aspose.cells.Picture
     */
    function addPictureInChart($pInt0, $pInt1, $oInputStream2, $pInt3, $pInt4)
    {
        return ClassFactory::_t2($this->m_ShapeCollection->addPictureInChart($pInt0, $pInt1, ClassFactory::_t1($oInputStream2), $pInt3, $pInt4));
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeCollection.addShape(int, int, int, int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @param pInt4  int
      @param pInt5  int
      @param pInt6  int
      @return com.aspose.cells.Shape
     */
    function addShape($pInt0, $pInt1, $pInt2, $pInt3, $pInt4, $pInt5, $pInt6)
    {
        return ClassFactory::_t2($this->m_ShapeCollection->addShape($pInt0, $pInt1, $pInt2, $pInt3, $pInt4, $pInt5, $pInt6));
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeCollection.addShapeInChart(int, int, int, int, int, int, byte[])]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @param pInt4  int
      @param pInt5  int
      @param arrP1DByte6  byte[]
      @return com.aspose.cells.Shape
     */
    function addShapeInChart($pInt0, $pInt1, $pInt2, $pInt3, $pInt4, $pInt5, $arrP1DByte6)
    {
        return ClassFactory::_t2($this->m_ShapeCollection->addShapeInChart($pInt0, $pInt1, $pInt2, $pInt3, $pInt4, $pInt5, $arrP1DByte6));
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeCollection.addTextBoxInChart(int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @return com.aspose.cells.TextBox
     */
    function addTextBoxInChart($pInt0, $pInt1, $pInt2, $pInt3)
    {
        return ClassFactory::_t2($this->m_ShapeCollection->addTextBoxInChart($pInt0, $pInt1, $pInt2, $pInt3));
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeCollection.addTextEffect(int, String, String, int, boolean, boolean, int, int, int, int, int, int)]

      @param pInt0  int
      @param oString1  String
      @param oString2  String
      @param pInt3  int
      @param pBoolean4  boolean
      @param pBoolean5  boolean
      @param pInt6  int
      @param pInt7  int
      @param pInt8  int
      @param pInt9  int
      @param pInt10  int
      @param pInt11  int
      @return com.aspose.cells.Shape
     */
    function addTextEffect($pInt0, $oString1, $oString2, $pInt3, $pBoolean4, $pBoolean5, $pInt6, $pInt7, $pInt8, $pInt9, $pInt10, $pInt11)
    {
        return ClassFactory::_t2($this->m_ShapeCollection->addTextEffect($pInt0, $oString1, $oString2, $pInt3, $pBoolean4, $pBoolean5, $pInt6, $pInt7, $pInt8, $pInt9, $pInt10, $pInt11));
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeCollection.addTextEffectInChart(int, String, String, int, boolean, boolean, int, int, int, int)]

      @param pInt0  int
      @param oString1  String
      @param oString2  String
      @param pInt3  int
      @param pBoolean4  boolean
      @param pBoolean5  boolean
      @param pInt6  int
      @param pInt7  int
      @param pInt8  int
      @param pInt9  int
      @return com.aspose.cells.Shape
     */
    function addTextEffectInChart($pInt0, $oString1, $oString2, $pInt3, $pBoolean4, $pBoolean5, $pInt6, $pInt7, $pInt8, $pInt9)
    {
        return ClassFactory::_t2($this->m_ShapeCollection->addTextEffectInChart($pInt0, $oString1, $oString2, $pInt3, $pBoolean4, $pBoolean5, $pInt6, $pInt7, $pInt8, $pInt9));
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeCollection.copyCommentsInRange(ShapeCollection, CellArea, int, int)]

      @param oShapeCollection0  com.aspose.cells.ShapeCollection
      @param oCellArea1  com.aspose.cells.CellArea
      @param pInt2  int
      @param pInt3  int
     */
    function copyCommentsInRange($oShapeCollection0, $oCellArea1, $pInt2, $pInt3)
    {
        $this->m_ShapeCollection->copyCommentsInRange(ClassFactory::_t1($oShapeCollection0), ClassFactory::_t1($oCellArea1), $pInt2, $pInt3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeCollection.copyInRange(ShapeCollection, CellArea, int, int, boolean)]

      @param oShapeCollection0  com.aspose.cells.ShapeCollection
      @param oCellArea1  com.aspose.cells.CellArea
      @param pInt2  int
      @param pInt3  int
      @param pBoolean4  boolean
     */
    function copyInRange($oShapeCollection0, $oCellArea1, $pInt2, $pInt3, $pBoolean4)
    {
        $this->m_ShapeCollection->copyInRange(ClassFactory::_t1($oShapeCollection0), ClassFactory::_t1($oCellArea1), $pInt2, $pInt3, $pBoolean4);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeCollection.deleteInRange(CellArea)]

      @param oCellArea0  com.aspose.cells.CellArea
     */
    function deleteInRange($oCellArea0)
    {
        $this->m_ShapeCollection->deleteInRange(ClassFactory::_t1($oCellArea0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeCollection.deleteShape(Shape)]

      @param oShape0  com.aspose.cells.Shape
     */
    function deleteShape($oShape0)
    {
        $this->m_ShapeCollection->deleteShape(ClassFactory::_t1($oShape0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeCollection.get(int)]

      @param pInt0  int
      @return corresponding java type is {java.lang.Object}
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_ShapeCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeCollection.group(Shape[])]

      @param arrO1DShape0  com.aspose.cells.Shape[]
      @return com.aspose.cells.GroupShape
     */
    function group($arrO1DShape0)
    {
        return ClassFactory::_t2($this->m_ShapeCollection->group(ClassFactory::_t1($arrO1DShape0)));
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeCollection.remove(Shape)]

      @param oShape0  com.aspose.cells.Shape
     */
    function remove($oShape0)
    {
        $this->m_ShapeCollection->remove(ClassFactory::_t1($oShape0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeCollection.removeAt(int)]

      @param pInt0  int
     */
    function removeAt($pInt0)
    {
        $this->m_ShapeCollection->removeAt($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeCollection.ungroup(GroupShape)]

      @param oGroupShape0  com.aspose.cells.GroupShape
     */
    function ungroup($oGroupShape0)
    {
        $this->m_ShapeCollection->ungroup(ClassFactory::_t1($oGroupShape0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeCollection.updateSelectedValue()]

     */
    function updateSelectedValue()
    {
        $this->m_ShapeCollection->updateSelectedValue();
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsShapeProperties]
  
 */
class ShapeProperties
{
    public $m_ShapeProperties;
    
    function __construct($shapeProperties)
    {
    	$this->m_ShapeProperties = $shapeProperties;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsShapeProperties.clearFormat3D()]

     */
    function clearFormat3D()
    {
        $this->m_ShapeProperties->clearFormat3D();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeProperties.clearGlowEffect()]

     */
    function clearGlowEffect()
    {
        $this->m_ShapeProperties->clearGlowEffect();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeProperties.clearShadowEffect()]

     */
    function clearShadowEffect()
    {
        $this->m_ShapeProperties->clearShadowEffect();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeProperties.getFormat3D()]

      @return com.aspose.cells.Format3D
     */
    function getFormat3D()
    {
        return ClassFactory::_t2($this->m_ShapeProperties->getFormat3D());
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeProperties.getGlowEffect()]

      @return com.aspose.cells.GlowEffect
     */
    function getGlowEffect()
    {
        return ClassFactory::_t2($this->m_ShapeProperties->getGlowEffect());
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeProperties.getShadowEffect()]

      @return com.aspose.cells.ShadowEffect
     */
    function getShadowEffect()
    {
        return ClassFactory::_t2($this->m_ShapeProperties->getShadowEffect());
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeProperties.getSoftEdgeRadius()]

      @return double
     */
    function getSoftEdgeRadius()
    {
        return $this->m_ShapeProperties->getSoftEdgeRadius();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeProperties.hasFormat3D()]

      @return boolean
     */
    function hasFormat3D()
    {
        return $this->m_ShapeProperties->hasFormat3D();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeProperties.hasGlowEffect()]

      @return boolean
     */
    function hasGlowEffect()
    {
        return $this->m_ShapeProperties->hasGlowEffect();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeProperties.hasShadowEffect()]

      @return boolean
     */
    function hasShadowEffect()
    {
        return $this->m_ShapeProperties->hasShadowEffect();
    }

    /*
      Wrapper for java version method [com.aspose.cellsShapeProperties.setSoftEdgeRadius(double)]

      @param pDouble0  double
     */
    function setSoftEdgeRadius($pDouble0)
    {
        $this->m_ShapeProperties->setSoftEdgeRadius($pDouble0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsSheetRender]
  
 */
class SheetRender
{
    public $m_SheetRender;
    
    function __construct($sheetRender)
    {
    	$this->m_SheetRender = $sheetRender;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsSheetRender.getPageCount()]

      @return int
     */
    function getPageCount()
    {
        return $this->m_SheetRender->getPageCount();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSheetRender.setPageCount(int)]

      @param pInt0  int
     */
    function setPageCount($pInt0)
    {
        $this->m_SheetRender->setPageCount($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSheetRender.toImage(int, OutputStream)]

      @param pInt0  int
      @param oOutputStream1  corresponding java type is {java.io.OutputStream}
     */
    function toImage($pInt0, $oOutputStream1)
    {
        $this->m_SheetRender->toImage($pInt0, ClassFactory::_t1($oOutputStream1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsSheetRender.toImage(int, String)]

      @param pInt0  int
      @param oString1  String
     */
    function toImageIS($pInt0, $oString1)
    {
        $this->m_SheetRender->toImage($pInt0, $oString1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSheetRender.toPrinter(String)]

      @param oString0  String
     */
    function toPrinter($oString0)
    {
        $this->m_SheetRender->toPrinter($oString0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsSheetType]
  
 */
class SheetType
{
    public $m_SheetType;
    
    function __construct($sheetType)
    {
    	$this->m_SheetType = $sheetType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsShiftType]
  
 */
class ShiftType
{
    public $m_ShiftType;
    
    function __construct($shiftType)
    {
    	$this->m_ShiftType = $shiftType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsSmartTag]
  
 */
class SmartTag
{
    public $m_SmartTag;
    
    function __construct($smartTag)
    {
    	$this->m_SmartTag = $smartTag;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsSmartTag.getDeleted()]

      @return boolean
     */
    function getDeleted()
    {
        return $this->m_SmartTag->getDeleted();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSmartTag.getName()]

      @return String
     */
    function getName()
    {
        return $this->m_SmartTag->getName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSmartTag.getProperties()]

      @return com.aspose.cells.SmartTagPropertyCollection
     */
    function getProperties()
    {
        return ClassFactory::_t2($this->m_SmartTag->getProperties());
    }

    /*
      Wrapper for java version method [com.aspose.cellsSmartTag.getUri()]

      @return String
     */
    function getUri()
    {
        return $this->m_SmartTag->getUri();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSmartTag.setDeleted(boolean)]

      @param pBoolean0  boolean
     */
    function setDeleted($pBoolean0)
    {
        $this->m_SmartTag->setDeleted($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSmartTag.setLink(String, String)]

      @param oString0  String
      @param oString1  String
     */
    function setLink($oString0, $oString1)
    {
        $this->m_SmartTag->setLink($oString0, $oString1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSmartTag.setProperties(SmartTagPropertyCollection)]

      @param oSmartTagPropertyCollection0  com.aspose.cells.SmartTagPropertyCollection
     */
    function setProperties($oSmartTagPropertyCollection0)
    {
        $this->m_SmartTag->setProperties(ClassFactory::_t1($oSmartTagPropertyCollection0));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsSmartTagCollection]
  
 */
class SmartTagCollection extends CollectionBase
{
    public $m_SmartTagCollection;
    
    function __construct($smartTagCollection)
    {
    	$this->m_SmartTagCollection = $smartTagCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsSmartTagCollection.add(String, String)]

      @param oString0  String
      @param oString1  String
      @return int
     */
    function add($oString0, $oString1)
    {
        return $this->m_SmartTagCollection->add($oString0, $oString1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSmartTagCollection.get(int)]

      @param pInt0  int
      @return com.aspose.cells.SmartTag
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_SmartTagCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsSmartTagCollection.getColumn()]

      @return int
     */
    function getColumn()
    {
        return $this->m_SmartTagCollection->getColumn();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSmartTagCollection.getRow()]

      @return int
     */
    function getRow()
    {
        return $this->m_SmartTagCollection->getRow();
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsSmartTagOptions]
  
 */
class SmartTagOptions
{
    public $m_SmartTagOptions;
    
    function __construct($smartTagOptions)
    {
    	$this->m_SmartTagOptions = $smartTagOptions;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsSmartTagOptions.getEmbedSmartTags()]

      @return boolean
     */
    function getEmbedSmartTags()
    {
        return $this->m_SmartTagOptions->getEmbedSmartTags();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSmartTagOptions.getShowType()]

      @return int
     */
    function getShowType()
    {
        return $this->m_SmartTagOptions->getShowType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSmartTagOptions.setEmbedSmartTags(boolean)]

      @param pBoolean0  boolean
     */
    function setEmbedSmartTags($pBoolean0)
    {
        $this->m_SmartTagOptions->setEmbedSmartTags($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSmartTagOptions.setShowType(int)]

      @param pInt0  int
     */
    function setShowType($pInt0)
    {
        $this->m_SmartTagOptions->setShowType($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsSmartTagProperty]
  
 */
class SmartTagProperty
{
    public $m_SmartTagProperty;
    
    function __construct($smartTagProperty)
    {
    	$this->m_SmartTagProperty = $smartTagProperty;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsSmartTagProperty.getName()]

      @return String
     */
    function getName()
    {
        return $this->m_SmartTagProperty->getName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSmartTagProperty.getValue()]

      @return String
     */
    function getValue()
    {
        return $this->m_SmartTagProperty->getValue();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSmartTagProperty.setName(String)]

      @param oString0  String
     */
    function setName($oString0)
    {
        $this->m_SmartTagProperty->setName($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSmartTagProperty.setValue(String)]

      @param oString0  String
     */
    function setValue($oString0)
    {
        $this->m_SmartTagProperty->setValue($oString0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsSmartTagPropertyCollection]
  
 */
class SmartTagPropertyCollection extends CollectionBase
{
    public $m_SmartTagPropertyCollection;
    
    function __construct($smartTagPropertyCollection)
    {
    	$this->m_SmartTagPropertyCollection = $smartTagPropertyCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsSmartTagPropertyCollection.add(String, String)]

      @param oString0  String
      @param oString1  String
      @return int
     */
    function add($oString0, $oString1)
    {
        return $this->m_SmartTagPropertyCollection->add($oString0, $oString1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSmartTagPropertyCollection.get(String)]

      @param oString0  String
      @return com.aspose.cells.SmartTagProperty
     */
    function get($oString0)
    {
        return ClassFactory::_t2($this->m_SmartTagPropertyCollection->get($oString0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsSmartTagPropertyCollection.get(int)]

      @param pInt0  int
      @return com.aspose.cells.SmartTagProperty
     */
    function getI($pInt0)
    {
        return ClassFactory::_t2($this->m_SmartTagPropertyCollection->get($pInt0));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsSmartTagSetting]
  
 */
class SmartTagSetting extends CollectionBase
{
    public $m_SmartTagSetting;
    
    function __construct($smartTagSetting)
    {
    	$this->m_SmartTagSetting = $smartTagSetting;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsSmartTagSetting.add(String)]

      @param oString0  String
      @return int
     */
    function add($oString0)
    {
        return $this->m_SmartTagSetting->add($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSmartTagSetting.add(int, int)]

      @param pInt0  int
      @param pInt1  int
      @return int
     */
    function addII($pInt0, $pInt1)
    {
        return $this->m_SmartTagSetting->add($pInt0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSmartTagSetting.get(String)]

      @param oString0  String
      @return com.aspose.cells.SmartTagCollection
     */
    function get($oString0)
    {
        return ClassFactory::_t2($this->m_SmartTagSetting->get($oString0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsSmartTagSetting.get(int)]

      @param pInt0  int
      @return com.aspose.cells.SmartTagCollection
     */
    function getI($pInt0)
    {
        return ClassFactory::_t2($this->m_SmartTagSetting->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsSmartTagSetting.get(int, int)]

      @param pInt0  int
      @param pInt1  int
      @return com.aspose.cells.SmartTagCollection
     */
    function getII($pInt0, $pInt1)
    {
        return ClassFactory::_t2($this->m_SmartTagSetting->get($pInt0, $pInt1));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsSmartTagShowType]
  
 */
class SmartTagShowType
{
    public $m_SmartTagShowType;
    
    function __construct($smartTagShowType)
    {
    	$this->m_SmartTagShowType = $smartTagShowType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsSortOrder]
  
 */
class SortOrder
{
    public $m_SortOrder;
    
    function __construct($sortOrder)
    {
    	$this->m_SortOrder = $sortOrder;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsSparkline]
  
 */
class Sparkline
{
    public $m_Sparkline;
    
    function __construct($sparkline)
    {
    	$this->m_Sparkline = $sparkline;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsSparkline.getColumn()]

      @return int
     */
    function getColumn()
    {
        return $this->m_Sparkline->getColumn();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparkline.getDataRange()]

      @return String
     */
    function getDataRange()
    {
        return $this->m_Sparkline->getDataRange();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparkline.getRow()]

      @return int
     */
    function getRow()
    {
        return $this->m_Sparkline->getRow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparkline.setDataRange(String)]

      @param oString0  String
     */
    function setDataRange($oString0)
    {
        $this->m_Sparkline->setDataRange($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparkline.toImage(OutputStream, ImageOrPrintOptions)]

      @param oOutputStream0  corresponding java type is {java.io.OutputStream}
      @param oImageOrPrintOptions1  com.aspose.cells.ImageOrPrintOptions
     */
    function toImage($oOutputStream0, $oImageOrPrintOptions1)
    {
        $this->m_Sparkline->toImage(ClassFactory::_t1($oOutputStream0), ClassFactory::_t1($oImageOrPrintOptions1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparkline.toImage(String, ImageOrPrintOptions)]

      @param oString0  String
      @param oImageOrPrintOptions1  com.aspose.cells.ImageOrPrintOptions
     */
    function toImageSI($oString0, $oImageOrPrintOptions1)
    {
        $this->m_Sparkline->toImage($oString0, ClassFactory::_t1($oImageOrPrintOptions1));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsSparklineAxisMinMaxType]
  
 */
class SparklineAxisMinMaxType
{
    public $m_SparklineAxisMinMaxType;
    
    function __construct($sparklineAxisMinMaxType)
    {
    	$this->m_SparklineAxisMinMaxType = $sparklineAxisMinMaxType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsSparklineCollection]
  
 */
class SparklineCollection extends CollectionBase
{
    public $m_SparklineCollection;
    
    function __construct($sparklineCollection)
    {
    	$this->m_SparklineCollection = $sparklineCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsSparklineCollection.get(int)]

      @param pInt0  int
      @return com.aspose.cells.Sparkline
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_SparklineCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineCollection.remove(Object)]

      @param oObject0  corresponding java type is {java.lang.Object}
     */
    function remove($oObject0)
    {
        $this->m_SparklineCollection->remove(ClassFactory::_t1($oObject0));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsSparklineGroup]
  
 */
class SparklineGroup
{
    public $m_SparklineGroup;
    
    function __construct($sparklineGroup)
    {
    	$this->m_SparklineGroup = $sparklineGroup;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.getDisplayHidden()]

      @return boolean
     */
    function getDisplayHidden()
    {
        return $this->m_SparklineGroup->getDisplayHidden();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.getFirstPointColor()]

      @return com.aspose.cells.CellsColor
     */
    function getFirstPointColor()
    {
        return ClassFactory::_t2($this->m_SparklineGroup->getFirstPointColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.getHighPointColor()]

      @return com.aspose.cells.CellsColor
     */
    function getHighPointColor()
    {
        return ClassFactory::_t2($this->m_SparklineGroup->getHighPointColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.getHorizontalAxisColor()]

      @return com.aspose.cells.CellsColor
     */
    function getHorizontalAxisColor()
    {
        return ClassFactory::_t2($this->m_SparklineGroup->getHorizontalAxisColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.getHorizontalAxisDateRange()]

      @return String
     */
    function getHorizontalAxisDateRange()
    {
        return $this->m_SparklineGroup->getHorizontalAxisDateRange();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.getLastPointColor()]

      @return com.aspose.cells.CellsColor
     */
    function getLastPointColor()
    {
        return ClassFactory::_t2($this->m_SparklineGroup->getLastPointColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.getLineWeight()]

      @return double
     */
    function getLineWeight()
    {
        return $this->m_SparklineGroup->getLineWeight();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.getLowPointColor()]

      @return com.aspose.cells.CellsColor
     */
    function getLowPointColor()
    {
        return ClassFactory::_t2($this->m_SparklineGroup->getLowPointColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.getMarkersColor()]

      @return com.aspose.cells.CellsColor
     */
    function getMarkersColor()
    {
        return ClassFactory::_t2($this->m_SparklineGroup->getMarkersColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.getNegativePointsColor()]

      @return com.aspose.cells.CellsColor
     */
    function getNegativePointsColor()
    {
        return ClassFactory::_t2($this->m_SparklineGroup->getNegativePointsColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.getPlotEmptyCellsType()]

      @return int
     */
    function getPlotEmptyCellsType()
    {
        return $this->m_SparklineGroup->getPlotEmptyCellsType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.getPlotRightToLeft()]

      @return boolean
     */
    function getPlotRightToLeft()
    {
        return $this->m_SparklineGroup->getPlotRightToLeft();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.getPresetStyle()]

      @return int
     */
    function getPresetStyle()
    {
        return $this->m_SparklineGroup->getPresetStyle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.getSeriesColor()]

      @return com.aspose.cells.CellsColor
     */
    function getSeriesColor()
    {
        return ClassFactory::_t2($this->m_SparklineGroup->getSeriesColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.getShowFirstPoint()]

      @return boolean
     */
    function getShowFirstPoint()
    {
        return $this->m_SparklineGroup->getShowFirstPoint();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.getShowHighPoint()]

      @return boolean
     */
    function getShowHighPoint()
    {
        return $this->m_SparklineGroup->getShowHighPoint();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.getShowHorizontalAxis()]

      @return boolean
     */
    function getShowHorizontalAxis()
    {
        return $this->m_SparklineGroup->getShowHorizontalAxis();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.getShowLastPoint()]

      @return boolean
     */
    function getShowLastPoint()
    {
        return $this->m_SparklineGroup->getShowLastPoint();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.getShowLowPoint()]

      @return boolean
     */
    function getShowLowPoint()
    {
        return $this->m_SparklineGroup->getShowLowPoint();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.getShowMarkers()]

      @return boolean
     */
    function getShowMarkers()
    {
        return $this->m_SparklineGroup->getShowMarkers();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.getShowNegativePoints()]

      @return boolean
     */
    function getShowNegativePoints()
    {
        return $this->m_SparklineGroup->getShowNegativePoints();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.getSparklineCollection()]

      @return com.aspose.cells.SparklineCollection
     */
    function getSparklineCollection()
    {
        return ClassFactory::_t2($this->m_SparklineGroup->getSparklineCollection());
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.getType()]

      @return int
     */
    function getType()
    {
        return $this->m_SparklineGroup->getType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.getVerticalAxisMaxValue()]

      @return double
     */
    function getVerticalAxisMaxValue()
    {
        return $this->m_SparklineGroup->getVerticalAxisMaxValue();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.getVerticalAxisMaxValueType()]

      @return int
     */
    function getVerticalAxisMaxValueType()
    {
        return $this->m_SparklineGroup->getVerticalAxisMaxValueType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.getVerticalAxisMinValue()]

      @return double
     */
    function getVerticalAxisMinValue()
    {
        return $this->m_SparklineGroup->getVerticalAxisMinValue();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.getVerticalAxisMinValueType()]

      @return int
     */
    function getVerticalAxisMinValueType()
    {
        return $this->m_SparklineGroup->getVerticalAxisMinValueType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.resetRanges(String, boolean, CellArea)]

      @param oString0  String
      @param pBoolean1  boolean
      @param oCellArea2  com.aspose.cells.CellArea
     */
    function resetRanges($oString0, $pBoolean1, $oCellArea2)
    {
        $this->m_SparklineGroup->resetRanges($oString0, $pBoolean1, ClassFactory::_t1($oCellArea2));
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.setDisplayHidden(boolean)]

      @param pBoolean0  boolean
     */
    function setDisplayHidden($pBoolean0)
    {
        $this->m_SparklineGroup->setDisplayHidden($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.setFirstPointColor(CellsColor)]

      @param oCellsColor0  com.aspose.cells.CellsColor
     */
    function setFirstPointColor($oCellsColor0)
    {
        $this->m_SparklineGroup->setFirstPointColor(ClassFactory::_t1($oCellsColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.setHighPointColor(CellsColor)]

      @param oCellsColor0  com.aspose.cells.CellsColor
     */
    function setHighPointColor($oCellsColor0)
    {
        $this->m_SparklineGroup->setHighPointColor(ClassFactory::_t1($oCellsColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.setHorizontalAxisColor(CellsColor)]

      @param oCellsColor0  com.aspose.cells.CellsColor
     */
    function setHorizontalAxisColor($oCellsColor0)
    {
        $this->m_SparklineGroup->setHorizontalAxisColor(ClassFactory::_t1($oCellsColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.setHorizontalAxisDateRange(String)]

      @param oString0  String
     */
    function setHorizontalAxisDateRange($oString0)
    {
        $this->m_SparklineGroup->setHorizontalAxisDateRange($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.setLastPointColor(CellsColor)]

      @param oCellsColor0  com.aspose.cells.CellsColor
     */
    function setLastPointColor($oCellsColor0)
    {
        $this->m_SparklineGroup->setLastPointColor(ClassFactory::_t1($oCellsColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.setLineWeight(double)]

      @param pDouble0  double
     */
    function setLineWeight($pDouble0)
    {
        $this->m_SparklineGroup->setLineWeight($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.setLowPointColor(CellsColor)]

      @param oCellsColor0  com.aspose.cells.CellsColor
     */
    function setLowPointColor($oCellsColor0)
    {
        $this->m_SparklineGroup->setLowPointColor(ClassFactory::_t1($oCellsColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.setMarkersColor(CellsColor)]

      @param oCellsColor0  com.aspose.cells.CellsColor
     */
    function setMarkersColor($oCellsColor0)
    {
        $this->m_SparklineGroup->setMarkersColor(ClassFactory::_t1($oCellsColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.setNegativePointsColor(CellsColor)]

      @param oCellsColor0  com.aspose.cells.CellsColor
     */
    function setNegativePointsColor($oCellsColor0)
    {
        $this->m_SparklineGroup->setNegativePointsColor(ClassFactory::_t1($oCellsColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.setPlotEmptyCellsType(int)]

      @param pInt0  int
     */
    function setPlotEmptyCellsType($pInt0)
    {
        $this->m_SparklineGroup->setPlotEmptyCellsType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.setPlotRightToLeft(boolean)]

      @param pBoolean0  boolean
     */
    function setPlotRightToLeft($pBoolean0)
    {
        $this->m_SparklineGroup->setPlotRightToLeft($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.setPresetStyle(int)]

      @param pInt0  int
     */
    function setPresetStyle($pInt0)
    {
        $this->m_SparklineGroup->setPresetStyle($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.setSeriesColor(CellsColor)]

      @param oCellsColor0  com.aspose.cells.CellsColor
     */
    function setSeriesColor($oCellsColor0)
    {
        $this->m_SparklineGroup->setSeriesColor(ClassFactory::_t1($oCellsColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.setShowFirstPoint(boolean)]

      @param pBoolean0  boolean
     */
    function setShowFirstPoint($pBoolean0)
    {
        $this->m_SparklineGroup->setShowFirstPoint($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.setShowHighPoint(boolean)]

      @param pBoolean0  boolean
     */
    function setShowHighPoint($pBoolean0)
    {
        $this->m_SparklineGroup->setShowHighPoint($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.setShowHorizontalAxis(boolean)]

      @param pBoolean0  boolean
     */
    function setShowHorizontalAxis($pBoolean0)
    {
        $this->m_SparklineGroup->setShowHorizontalAxis($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.setShowLastPoint(boolean)]

      @param pBoolean0  boolean
     */
    function setShowLastPoint($pBoolean0)
    {
        $this->m_SparklineGroup->setShowLastPoint($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.setShowLowPoint(boolean)]

      @param pBoolean0  boolean
     */
    function setShowLowPoint($pBoolean0)
    {
        $this->m_SparklineGroup->setShowLowPoint($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.setShowMarkers(boolean)]

      @param pBoolean0  boolean
     */
    function setShowMarkers($pBoolean0)
    {
        $this->m_SparklineGroup->setShowMarkers($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.setShowNegativePoints(boolean)]

      @param pBoolean0  boolean
     */
    function setShowNegativePoints($pBoolean0)
    {
        $this->m_SparklineGroup->setShowNegativePoints($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.setType(int)]

      @param pInt0  int
     */
    function setType($pInt0)
    {
        $this->m_SparklineGroup->setType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.setVerticalAxisMaxValue(double)]

      @param pDouble0  double
     */
    function setVerticalAxisMaxValue($pDouble0)
    {
        $this->m_SparklineGroup->setVerticalAxisMaxValue($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.setVerticalAxisMaxValueType(int)]

      @param pInt0  int
     */
    function setVerticalAxisMaxValueType($pInt0)
    {
        $this->m_SparklineGroup->setVerticalAxisMaxValueType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.setVerticalAxisMinValue(double)]

      @param pDouble0  double
     */
    function setVerticalAxisMinValue($pDouble0)
    {
        $this->m_SparklineGroup->setVerticalAxisMinValue($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroup.setVerticalAxisMinValueType(int)]

      @param pInt0  int
     */
    function setVerticalAxisMinValueType($pInt0)
    {
        $this->m_SparklineGroup->setVerticalAxisMinValueType($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsSparklineGroupCollection]
  
 */
class SparklineGroupCollection extends CollectionBase
{
    public $m_SparklineGroupCollection;
    
    function __construct($sparklineGroupCollection)
    {
    	$this->m_SparklineGroupCollection = $sparklineGroupCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroupCollection.add(int, String, boolean, CellArea)]

      @param pInt0  int
      @param oString1  String
      @param pBoolean2  boolean
      @param oCellArea3  com.aspose.cells.CellArea
      @return int
     */
    function add($pInt0, $oString1, $pBoolean2, $oCellArea3)
    {
        return $this->m_SparklineGroupCollection->add($pInt0, $oString1, $pBoolean2, ClassFactory::_t1($oCellArea3));
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroupCollection.clearSparklineGroups(CellArea)]

      @param oCellArea0  com.aspose.cells.CellArea
     */
    function clearSparklineGroups($oCellArea0)
    {
        $this->m_SparklineGroupCollection->clearSparklineGroups(ClassFactory::_t1($oCellArea0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroupCollection.clearSparklines(CellArea)]

      @param oCellArea0  com.aspose.cells.CellArea
     */
    function clearSparklines($oCellArea0)
    {
        $this->m_SparklineGroupCollection->clearSparklines(ClassFactory::_t1($oCellArea0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsSparklineGroupCollection.get(int)]

      @param pInt0  int
      @return corresponding java type is {java.lang.Object}
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_SparklineGroupCollection->get($pInt0));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsSparklinePresetStyleType]
  
 */
class SparklinePresetStyleType
{
    public $m_SparklinePresetStyleType;
    
    function __construct($sparklinePresetStyleType)
    {
    	$this->m_SparklinePresetStyleType = $sparklinePresetStyleType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsSparklineType]
  
 */
class SparklineType
{
    public $m_SparklineType;
    
    function __construct($sparklineType)
    {
    	$this->m_SparklineType = $sparklineType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsSpinner]
  
 */
class Spinner extends Shape
{
    public $m_Spinner;
    
    function __construct($spinner)
    {
    	$this->m_Spinner = $spinner;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsSpinner.getCurrentValue()]

      @return int
     */
    function getCurrentValue()
    {
        return $this->m_Spinner->getCurrentValue();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSpinner.getIncrementalChange()]

      @return int
     */
    function getIncrementalChange()
    {
        return $this->m_Spinner->getIncrementalChange();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSpinner.getMax()]

      @return int
     */
    function getMax()
    {
        return $this->m_Spinner->getMax();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSpinner.getMin()]

      @return int
     */
    function getMin()
    {
        return $this->m_Spinner->getMin();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSpinner.getShadow()]

      @return boolean
     */
    function getShadow()
    {
        return $this->m_Spinner->getShadow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSpinner.setCurrentValue(int)]

      @param pInt0  int
     */
    function setCurrentValue($pInt0)
    {
        $this->m_Spinner->setCurrentValue($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSpinner.setIncrementalChange(int)]

      @param pInt0  int
     */
    function setIncrementalChange($pInt0)
    {
        $this->m_Spinner->setIncrementalChange($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSpinner.setMax(int)]

      @param pInt0  int
     */
    function setMax($pInt0)
    {
        $this->m_Spinner->setMax($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSpinner.setMin(int)]

      @param pInt0  int
     */
    function setMin($pInt0)
    {
        $this->m_Spinner->setMin($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSpinner.setShadow(boolean)]

      @param pBoolean0  boolean
     */
    function setShadow($pBoolean0)
    {
        $this->m_Spinner->setShadow($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsSpreadsheetML2003SaveOptions]
  
 */
class SpreadsheetML2003SaveOptions extends SaveOptions
{
    public $m_SpreadsheetML2003SaveOptions;
    
    function __construct($spreadsheetML2003SaveOptions)
    {
    	$this->m_SpreadsheetML2003SaveOptions = $spreadsheetML2003SaveOptions;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsSpreadsheetML2003SaveOptions.getExportColumnIndexOfCell()]

      @return boolean
     */
    function getExportColumnIndexOfCell()
    {
        return $this->m_SpreadsheetML2003SaveOptions->getExportColumnIndexOfCell();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSpreadsheetML2003SaveOptions.getLimitAsXls()]

      @return boolean
     */
    function getLimitAsXls()
    {
        return $this->m_SpreadsheetML2003SaveOptions->getLimitAsXls();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSpreadsheetML2003SaveOptions.isIndentedFormatting()]

      @return boolean
     */
    function isIndentedFormatting()
    {
        return $this->m_SpreadsheetML2003SaveOptions->isIndentedFormatting();
    }

    /*
      Wrapper for java version method [com.aspose.cellsSpreadsheetML2003SaveOptions.setExportColumnIndexOfCell(boolean)]

      @param pBoolean0  boolean
     */
    function setExportColumnIndexOfCell($pBoolean0)
    {
        $this->m_SpreadsheetML2003SaveOptions->setExportColumnIndexOfCell($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSpreadsheetML2003SaveOptions.setIndentedFormatting(boolean)]

      @param pBoolean0  boolean
     */
    function setIndentedFormatting($pBoolean0)
    {
        $this->m_SpreadsheetML2003SaveOptions->setIndentedFormatting($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsSpreadsheetML2003SaveOptions.setLimitAsXls(boolean)]

      @param pBoolean0  boolean
     */
    function setLimitAsXls($pBoolean0)
    {
        $this->m_SpreadsheetML2003SaveOptions->setLimitAsXls($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsStyle]
  
 */
class Style
{
    public $m_Style;
    
    function __construct($style)
    {
    	$this->m_Style = $style;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsStyle.copy(Style)]

      @param oStyle0  com.aspose.cells.Style
     */
    function copy($oStyle0)
    {
        $this->m_Style->copy(ClassFactory::_t1($oStyle0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.equals(Object)]

      @param oObject0  corresponding java type is {java.lang.Object}
      @return boolean
     */
    function equals($oObject0)
    {
        return $this->m_Style->equals(ClassFactory::_t1($oObject0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.getBackgroundColor()]

      @return com.aspose.cells.Color
     */
    function getBackgroundColor()
    {
        return ClassFactory::_t2($this->m_Style->getBackgroundColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.getBackgroundThemeColor()]

      @return com.aspose.cells.ThemeColor
     */
    function getBackgroundThemeColor()
    {
        return ClassFactory::_t2($this->m_Style->getBackgroundThemeColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.getBorders()]

      @return com.aspose.cells.BorderCollection
     */
    function getBorders()
    {
        return ClassFactory::_t2($this->m_Style->getBorders());
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.getCultureCustom()]

      @return String
     */
    function getCultureCustom()
    {
        return $this->m_Style->getCultureCustom();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.getCustom()]

      @return String
     */
    function getCustom()
    {
        return $this->m_Style->getCustom();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.getFont()]

      @return com.aspose.cells.Font
     */
    function getFont()
    {
        return ClassFactory::_t2($this->m_Style->getFont());
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.getForegroundColor()]

      @return com.aspose.cells.Color
     */
    function getForegroundColor()
    {
        return ClassFactory::_t2($this->m_Style->getForegroundColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.getForegroundThemeColor()]

      @return com.aspose.cells.ThemeColor
     */
    function getForegroundThemeColor()
    {
        return ClassFactory::_t2($this->m_Style->getForegroundThemeColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.getHorizontalAlignment()]

      @return int
     */
    function getHorizontalAlignment()
    {
        return $this->m_Style->getHorizontalAlignment();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.getIndentLevel()]

      @return int
     */
    function getIndentLevel()
    {
        return $this->m_Style->getIndentLevel();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.getName()]

      @return String
     */
    function getName()
    {
        return $this->m_Style->getName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.getNumber()]

      @return int
     */
    function getNumber()
    {
        return $this->m_Style->getNumber();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.getParentStyle()]

      @return com.aspose.cells.Style
     */
    function getParentStyle()
    {
        return ClassFactory::_t2($this->m_Style->getParentStyle());
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.getPattern()]

      @return int
     */
    function getPattern()
    {
        return $this->m_Style->getPattern();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.getRotation()]

      @return int
     */
    function getRotation()
    {
        return $this->m_Style->getRotation();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.getRotationAngle()]

      @return int
     */
    function getRotationAngle()
    {
        return $this->m_Style->getRotationAngle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.getShrinkToFit()]

      @return boolean
     */
    function getShrinkToFit()
    {
        return $this->m_Style->getShrinkToFit();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.getTextDirection()]

      @return int
     */
    function getTextDirection()
    {
        return $this->m_Style->getTextDirection();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.getTwoColorGradient()]

      @return array, corresponding java type is {java.lang.Object[]}
     */
    function getTwoColorGradient()
    {
        return ClassFactory::_t2($this->m_Style->getTwoColorGradient());
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.getVerticalAlignment()]

      @return int
     */
    function getVerticalAlignment()
    {
        return $this->m_Style->getVerticalAlignment();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.hashCode()]

      @return int
     */
    function hashCode()
    {
        return $this->m_Style->hashCode();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.isDateTime()]

      @return boolean
     */
    function isDateTime()
    {
        return $this->m_Style->isDateTime();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.isFormulaHidden()]

      @return boolean
     */
    function isFormulaHidden()
    {
        return $this->m_Style->isFormulaHidden();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.isGradient()]

      @return boolean
     */
    function isGradient()
    {
        return $this->m_Style->isGradient();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.isLocked()]

      @return boolean
     */
    function isLocked()
    {
        return $this->m_Style->isLocked();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.isModified(int)]

      @param pInt0  int
      @return boolean
     */
    function isModified($pInt0)
    {
        return $this->m_Style->isModified($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.isPercent()]

      @return boolean
     */
    function isPercent()
    {
        return $this->m_Style->isPercent();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.isTextWrapped()]

      @return boolean
     */
    function isTextWrapped()
    {
        return $this->m_Style->isTextWrapped();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.setBackgroundColor(Color)]

      @param oColor0  com.aspose.cells.Color
     */
    function setBackgroundColor($oColor0)
    {
        $this->m_Style->setBackgroundColor(ClassFactory::_t1($oColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.setBackgroundThemeColor(ThemeColor)]

      @param oThemeColor0  com.aspose.cells.ThemeColor
     */
    function setBackgroundThemeColor($oThemeColor0)
    {
        $this->m_Style->setBackgroundThemeColor(ClassFactory::_t1($oThemeColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.setBorder(int, int, Color)]

      @param pInt0  int
      @param pInt1  int
      @param oColor2  com.aspose.cells.Color
      @return boolean
     */
    function setBorder($pInt0, $pInt1, $oColor2)
    {
        return $this->m_Style->setBorder($pInt0, $pInt1, ClassFactory::_t1($oColor2));
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.setCultureCustom(String)]

      @param oString0  String
     */
    function setCultureCustom($oString0)
    {
        $this->m_Style->setCultureCustom($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.setCustom(String)]

      @param oString0  String
     */
    function setCustom($oString0)
    {
        $this->m_Style->setCustom($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.setForegroundColor(Color)]

      @param oColor0  com.aspose.cells.Color
     */
    function setForegroundColor($oColor0)
    {
        $this->m_Style->setForegroundColor(ClassFactory::_t1($oColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.setForegroundThemeColor(ThemeColor)]

      @param oThemeColor0  com.aspose.cells.ThemeColor
     */
    function setForegroundThemeColor($oThemeColor0)
    {
        $this->m_Style->setForegroundThemeColor(ClassFactory::_t1($oThemeColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.setFormulaHidden(boolean)]

      @param pBoolean0  boolean
     */
    function setFormulaHidden($pBoolean0)
    {
        $this->m_Style->setFormulaHidden($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.setGradient(boolean)]

      @param pBoolean0  boolean
     */
    function setGradient($pBoolean0)
    {
        $this->m_Style->setGradient($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.setHorizontalAlignment(int)]

      @param pInt0  int
     */
    function setHorizontalAlignment($pInt0)
    {
        $this->m_Style->setHorizontalAlignment($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.setIndentLevel(int)]

      @param pInt0  int
     */
    function setIndentLevel($pInt0)
    {
        $this->m_Style->setIndentLevel($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.setLocked(boolean)]

      @param pBoolean0  boolean
     */
    function setLocked($pBoolean0)
    {
        $this->m_Style->setLocked($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.setName(String)]

      @param oString0  String
     */
    function setName($oString0)
    {
        $this->m_Style->setName($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.setNumber(int)]

      @param pInt0  int
     */
    function setNumber($pInt0)
    {
        $this->m_Style->setNumber($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.setPattern(int)]

      @param pInt0  int
     */
    function setPattern($pInt0)
    {
        $this->m_Style->setPattern($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.setRotation(int)]

      @param pInt0  int
     */
    function setRotation($pInt0)
    {
        $this->m_Style->setRotation($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.setRotationAngle(int)]

      @param pInt0  int
     */
    function setRotationAngle($pInt0)
    {
        $this->m_Style->setRotationAngle($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.setShrinkToFit(boolean)]

      @param pBoolean0  boolean
     */
    function setShrinkToFit($pBoolean0)
    {
        $this->m_Style->setShrinkToFit($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.setTextDirection(int)]

      @param pInt0  int
     */
    function setTextDirection($pInt0)
    {
        $this->m_Style->setTextDirection($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.setTextWrapped(boolean)]

      @param pBoolean0  boolean
     */
    function setTextWrapped($pBoolean0)
    {
        $this->m_Style->setTextWrapped($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.setTwoColorGradient(Color, Color, int, int)]

      @param oColor0  com.aspose.cells.Color
      @param oColor1  com.aspose.cells.Color
      @param pInt2  int
      @param pInt3  int
     */
    function setTwoColorGradient($oColor0, $oColor1, $pInt2, $pInt3)
    {
        $this->m_Style->setTwoColorGradient(ClassFactory::_t1($oColor0), ClassFactory::_t1($oColor1), $pInt2, $pInt3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.setVerticalAlignment(int)]

      @param pInt0  int
     */
    function setVerticalAlignment($pInt0)
    {
        $this->m_Style->setVerticalAlignment($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyle.update()]

     */
    function update()
    {
        $this->m_Style->update();
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsStyleCollection]
  
 */
class StyleCollection
{
    public $m_StyleCollection;
    
    function __construct($styleCollection)
    {
    	$this->m_StyleCollection = $styleCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsStyleCollection.add()]

      @return int
     */
    function add()
    {
        return $this->m_StyleCollection->add();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleCollection.createBuiltinStyle(int)]

      @param pInt0  int
      @return com.aspose.cells.Style
     */
    function createBuiltinStyle($pInt0)
    {
        return ClassFactory::_t2($this->m_StyleCollection->createBuiltinStyle($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleCollection.get(String)]

      @param oString0  String
      @return com.aspose.cells.Style
     */
    function get($oString0)
    {
        return ClassFactory::_t2($this->m_StyleCollection->get($oString0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleCollection.get(int)]

      @param pInt0  int
      @return com.aspose.cells.Style
     */
    function getI($pInt0)
    {
        return ClassFactory::_t2($this->m_StyleCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleCollection.getCount()]

      @return int
     */
    function getCount()
    {
        return $this->m_StyleCollection->getCount();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleCollection.getThemeStyle(int, double)]

      @param pInt0  int
      @param pDouble1  double
      @return com.aspose.cells.Style
     */
    function getThemeStyle($pInt0, $pDouble1)
    {
        return ClassFactory::_t2($this->m_StyleCollection->getThemeStyle($pInt0, $pDouble1));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsStyleFlag]
  
 */
class StyleFlag
{
    public $m_StyleFlag;
    
    function __construct($styleFlag)
    {
    	$this->m_StyleFlag = $styleFlag;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.getAll()]

      @return boolean
     */
    function getAll()
    {
        return $this->m_StyleFlag->getAll();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.getBorders()]

      @return boolean
     */
    function getBorders()
    {
        return $this->m_StyleFlag->getBorders();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.getBottomBorder()]

      @return boolean
     */
    function getBottomBorder()
    {
        return $this->m_StyleFlag->getBottomBorder();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.getCellShading()]

      @return boolean
     */
    function getCellShading()
    {
        return $this->m_StyleFlag->getCellShading();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.getDiagonalDownBorder()]

      @return boolean
     */
    function getDiagonalDownBorder()
    {
        return $this->m_StyleFlag->getDiagonalDownBorder();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.getDiagonalUpBorder()]

      @return boolean
     */
    function getDiagonalUpBorder()
    {
        return $this->m_StyleFlag->getDiagonalUpBorder();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.getFont()]

      @return boolean
     */
    function getFont()
    {
        return $this->m_StyleFlag->getFont();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.getFontBold()]

      @return boolean
     */
    function getFontBold()
    {
        return $this->m_StyleFlag->getFontBold();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.getFontColor()]

      @return boolean
     */
    function getFontColor()
    {
        return $this->m_StyleFlag->getFontColor();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.getFontItalic()]

      @return boolean
     */
    function getFontItalic()
    {
        return $this->m_StyleFlag->getFontItalic();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.getFontName()]

      @return boolean
     */
    function getFontName()
    {
        return $this->m_StyleFlag->getFontName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.getFontScript()]

      @return boolean
     */
    function getFontScript()
    {
        return $this->m_StyleFlag->getFontScript();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.getFontSize()]

      @return boolean
     */
    function getFontSize()
    {
        return $this->m_StyleFlag->getFontSize();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.getFontStrike()]

      @return boolean
     */
    function getFontStrike()
    {
        return $this->m_StyleFlag->getFontStrike();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.getFontUnderline()]

      @return boolean
     */
    function getFontUnderline()
    {
        return $this->m_StyleFlag->getFontUnderline();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.getHideFormula()]

      @return boolean
     */
    function getHideFormula()
    {
        return $this->m_StyleFlag->getHideFormula();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.getHorizontalAlignment()]

      @return boolean
     */
    function getHorizontalAlignment()
    {
        return $this->m_StyleFlag->getHorizontalAlignment();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.getIndent()]

      @return boolean
     */
    function getIndent()
    {
        return $this->m_StyleFlag->getIndent();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.getLeftBorder()]

      @return boolean
     */
    function getLeftBorder()
    {
        return $this->m_StyleFlag->getLeftBorder();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.getLocked()]

      @return boolean
     */
    function getLocked()
    {
        return $this->m_StyleFlag->getLocked();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.getNumberFormat()]

      @return boolean
     */
    function getNumberFormat()
    {
        return $this->m_StyleFlag->getNumberFormat();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.getRightBorder()]

      @return boolean
     */
    function getRightBorder()
    {
        return $this->m_StyleFlag->getRightBorder();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.getRotation()]

      @return boolean
     */
    function getRotation()
    {
        return $this->m_StyleFlag->getRotation();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.getShrinkToFit()]

      @return boolean
     */
    function getShrinkToFit()
    {
        return $this->m_StyleFlag->getShrinkToFit();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.getTextDirection()]

      @return boolean
     */
    function getTextDirection()
    {
        return $this->m_StyleFlag->getTextDirection();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.getTopBorder()]

      @return boolean
     */
    function getTopBorder()
    {
        return $this->m_StyleFlag->getTopBorder();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.getVerticalAlignment()]

      @return boolean
     */
    function getVerticalAlignment()
    {
        return $this->m_StyleFlag->getVerticalAlignment();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.getWrapText()]

      @return boolean
     */
    function getWrapText()
    {
        return $this->m_StyleFlag->getWrapText();
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.setAll(boolean)]

      @param pBoolean0  boolean
     */
    function setAll($pBoolean0)
    {
        $this->m_StyleFlag->setAll($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.setBorders(boolean)]

      @param pBoolean0  boolean
     */
    function setBorders($pBoolean0)
    {
        $this->m_StyleFlag->setBorders($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.setBottomBorder(boolean)]

      @param pBoolean0  boolean
     */
    function setBottomBorder($pBoolean0)
    {
        $this->m_StyleFlag->setBottomBorder($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.setCellShading(boolean)]

      @param pBoolean0  boolean
     */
    function setCellShading($pBoolean0)
    {
        $this->m_StyleFlag->setCellShading($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.setDiagonalDownBorder(boolean)]

      @param pBoolean0  boolean
     */
    function setDiagonalDownBorder($pBoolean0)
    {
        $this->m_StyleFlag->setDiagonalDownBorder($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.setDiagonalUpBorder(boolean)]

      @param pBoolean0  boolean
     */
    function setDiagonalUpBorder($pBoolean0)
    {
        $this->m_StyleFlag->setDiagonalUpBorder($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.setFont(boolean)]

      @param pBoolean0  boolean
     */
    function setFont($pBoolean0)
    {
        $this->m_StyleFlag->setFont($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.setFontBold(boolean)]

      @param pBoolean0  boolean
     */
    function setFontBold($pBoolean0)
    {
        $this->m_StyleFlag->setFontBold($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.setFontColor(boolean)]

      @param pBoolean0  boolean
     */
    function setFontColor($pBoolean0)
    {
        $this->m_StyleFlag->setFontColor($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.setFontItalic(boolean)]

      @param pBoolean0  boolean
     */
    function setFontItalic($pBoolean0)
    {
        $this->m_StyleFlag->setFontItalic($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.setFontName(boolean)]

      @param pBoolean0  boolean
     */
    function setFontName($pBoolean0)
    {
        $this->m_StyleFlag->setFontName($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.setFontScript(boolean)]

      @param pBoolean0  boolean
     */
    function setFontScript($pBoolean0)
    {
        $this->m_StyleFlag->setFontScript($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.setFontSize(boolean)]

      @param pBoolean0  boolean
     */
    function setFontSize($pBoolean0)
    {
        $this->m_StyleFlag->setFontSize($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.setFontStrike(boolean)]

      @param pBoolean0  boolean
     */
    function setFontStrike($pBoolean0)
    {
        $this->m_StyleFlag->setFontStrike($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.setFontUnderline(boolean)]

      @param pBoolean0  boolean
     */
    function setFontUnderline($pBoolean0)
    {
        $this->m_StyleFlag->setFontUnderline($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.setHideFormula(boolean)]

      @param pBoolean0  boolean
     */
    function setHideFormula($pBoolean0)
    {
        $this->m_StyleFlag->setHideFormula($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.setHorizontalAlignment(boolean)]

      @param pBoolean0  boolean
     */
    function setHorizontalAlignment($pBoolean0)
    {
        $this->m_StyleFlag->setHorizontalAlignment($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.setIndent(boolean)]

      @param pBoolean0  boolean
     */
    function setIndent($pBoolean0)
    {
        $this->m_StyleFlag->setIndent($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.setLeftBorder(boolean)]

      @param pBoolean0  boolean
     */
    function setLeftBorder($pBoolean0)
    {
        $this->m_StyleFlag->setLeftBorder($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.setLocked(boolean)]

      @param pBoolean0  boolean
     */
    function setLocked($pBoolean0)
    {
        $this->m_StyleFlag->setLocked($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.setNumberFormat(boolean)]

      @param pBoolean0  boolean
     */
    function setNumberFormat($pBoolean0)
    {
        $this->m_StyleFlag->setNumberFormat($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.setRightBorder(boolean)]

      @param pBoolean0  boolean
     */
    function setRightBorder($pBoolean0)
    {
        $this->m_StyleFlag->setRightBorder($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.setRotation(boolean)]

      @param pBoolean0  boolean
     */
    function setRotation($pBoolean0)
    {
        $this->m_StyleFlag->setRotation($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.setShrinkToFit(boolean)]

      @param pBoolean0  boolean
     */
    function setShrinkToFit($pBoolean0)
    {
        $this->m_StyleFlag->setShrinkToFit($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.setTextDirection(boolean)]

      @param pBoolean0  boolean
     */
    function setTextDirection($pBoolean0)
    {
        $this->m_StyleFlag->setTextDirection($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.setTopBorder(boolean)]

      @param pBoolean0  boolean
     */
    function setTopBorder($pBoolean0)
    {
        $this->m_StyleFlag->setTopBorder($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.setVerticalAlignment(boolean)]

      @param pBoolean0  boolean
     */
    function setVerticalAlignment($pBoolean0)
    {
        $this->m_StyleFlag->setVerticalAlignment($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsStyleFlag.setWrapText(boolean)]

      @param pBoolean0  boolean
     */
    function setWrapText($pBoolean0)
    {
        $this->m_StyleFlag->setWrapText($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsStyleModifyFlag]
  
 */
class StyleModifyFlag
{
    public $m_StyleModifyFlag;
    
    function __construct($styleModifyFlag)
    {
    	$this->m_StyleModifyFlag = $styleModifyFlag;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsTableStyle]
  
 */
class TableStyle
{
    public $m_TableStyle;
    
    function __construct($tableStyle)
    {
    	$this->m_TableStyle = $tableStyle;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsTableStyle.getName()]

      @return String
     */
    function getName()
    {
        return $this->m_TableStyle->getName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTableStyle.getTableStyleElements()]

      @return com.aspose.cells.TableStyleElementCollection
     */
    function getTableStyleElements()
    {
        return ClassFactory::_t2($this->m_TableStyle->getTableStyleElements());
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsTableStyleCollection]
  
 */
class TableStyleCollection extends CollectionBase
{
    public $m_TableStyleCollection;
    
    function __construct($tableStyleCollection)
    {
    	$this->m_TableStyleCollection = $tableStyleCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsTableStyleCollection.addPivotTableStyle(String)]

      @param oString0  String
      @return int
     */
    function addPivotTableStyle($oString0)
    {
        return $this->m_TableStyleCollection->addPivotTableStyle($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTableStyleCollection.addTableStyle(String)]

      @param oString0  String
      @return int
     */
    function addTableStyle($oString0)
    {
        return $this->m_TableStyleCollection->addTableStyle($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTableStyleCollection.get(String)]

      @param oString0  String
      @return com.aspose.cells.TableStyle
     */
    function get($oString0)
    {
        return ClassFactory::_t2($this->m_TableStyleCollection->get($oString0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsTableStyleCollection.get(int)]

      @param pInt0  int
      @return corresponding java type is {java.lang.Object}
     */
    function getI($pInt0)
    {
        return ClassFactory::_t2($this->m_TableStyleCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsTableStyleCollection.getBuiltinTableStyle(int)]

      @param pInt0  int
      @return com.aspose.cells.TableStyle
     */
    function getBuiltinTableStyle($pInt0)
    {
        return ClassFactory::_t2($this->m_TableStyleCollection->getBuiltinTableStyle($pInt0));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsTableStyleElement]
  
 */
class TableStyleElement
{
    public $m_TableStyleElement;
    
    function __construct($tableStyleElement)
    {
    	$this->m_TableStyleElement = $tableStyleElement;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsTableStyleElement.getElementStyle()]

      @return com.aspose.cells.Style
     */
    function getElementStyle()
    {
        return ClassFactory::_t2($this->m_TableStyleElement->getElementStyle());
    }

    /*
      Wrapper for java version method [com.aspose.cellsTableStyleElement.getSize()]

      @return int
     */
    function getSize()
    {
        return $this->m_TableStyleElement->getSize();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTableStyleElement.getType()]

      @return int
     */
    function getType()
    {
        return $this->m_TableStyleElement->getType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTableStyleElement.setElementStyle(Style)]

      @param oStyle0  com.aspose.cells.Style
     */
    function setElementStyle($oStyle0)
    {
        $this->m_TableStyleElement->setElementStyle(ClassFactory::_t1($oStyle0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsTableStyleElement.setSize(int)]

      @param pInt0  int
     */
    function setSize($pInt0)
    {
        $this->m_TableStyleElement->setSize($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsTableStyleElementCollection]
  
 */
class TableStyleElementCollection extends CollectionBase
{
    public $m_TableStyleElementCollection;
    
    function __construct($tableStyleElementCollection)
    {
    	$this->m_TableStyleElementCollection = $tableStyleElementCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsTableStyleElementCollection.add(int)]

      @param pInt0  int
      @return int
     */
    function add($pInt0)
    {
        return $this->m_TableStyleElementCollection->add($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTableStyleElementCollection.get(int)]

      @param pInt0  int
      @return com.aspose.cells.TableStyleElement
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_TableStyleElementCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsTableStyleElementCollection.getByTableStyleElementType(int)]

      @param pInt0  int
      @return com.aspose.cells.TableStyleElement
     */
    function getByTableStyleElementType($pInt0)
    {
        return ClassFactory::_t2($this->m_TableStyleElementCollection->getByTableStyleElementType($pInt0));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsTableStyleElementType]
  
 */
class TableStyleElementType
{
    public $m_TableStyleElementType;
    
    function __construct($tableStyleElementType)
    {
    	$this->m_TableStyleElementType = $tableStyleElementType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsTableStyleType]
  
 */
class TableStyleType
{
    public $m_TableStyleType;
    
    function __construct($tableStyleType)
    {
    	$this->m_TableStyleType = $tableStyleType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsTextAlignmentType]
  
 */
class TextAlignmentType
{
    public $m_TextAlignmentType;
    
    function __construct($textAlignmentType)
    {
    	$this->m_TextAlignmentType = $textAlignmentType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsTextBox]
  
 */
class TextBox extends Shape
{
    public $m_TextBox;
    
    function __construct($textBox)
    {
    	$this->m_TextBox = $textBox;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsTextBox.characters(int, int)]

      @param pInt0  int
      @param pInt1  int
      @return com.aspose.cells.FontSetting
     */
    function characters($pInt0, $pInt1)
    {
        return ClassFactory::_t2($this->m_TextBox->characters($pInt0, $pInt1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsTextBox.getCharacters()]

      @return array, corresponding java type is {java.util.ArrayList}
     */
    function getCharacters()
    {
        return ClassFactory::_t2($this->m_TextBox->getCharacters());
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsTextBoxCollection]
  
 */
class TextBoxCollection extends CollectionBase
{
    public $m_TextBoxCollection;
    
    function __construct($textBoxCollection)
    {
    	$this->m_TextBoxCollection = $textBoxCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsTextBoxCollection.add(int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @return int
     */
    function add($pInt0, $pInt1, $pInt2, $pInt3)
    {
        return $this->m_TextBoxCollection->add($pInt0, $pInt1, $pInt2, $pInt3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTextBoxCollection.get(int)]

      @param pInt0  int
      @return com.aspose.cells.TextBox
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_TextBoxCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsTextBoxCollection.removeAt(int)]

      @param pInt0  int
     */
    function removeAt($pInt0)
    {
        $this->m_TextBoxCollection->removeAt($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsTextDirectionType]
  
 */
class TextDirectionType
{
    public $m_TextDirectionType;
    
    function __construct($textDirectionType)
    {
    	$this->m_TextDirectionType = $textDirectionType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsTextEffectFormat]
  
 */
class TextEffectFormat
{
    public $m_TextEffectFormat;
    
    function __construct($textEffectFormat)
    {
    	$this->m_TextEffectFormat = $textEffectFormat;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsTextEffectFormat.getFontBold()]

      @return boolean
     */
    function getFontBold()
    {
        return $this->m_TextEffectFormat->getFontBold();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTextEffectFormat.getFontItalic()]

      @return boolean
     */
    function getFontItalic()
    {
        return $this->m_TextEffectFormat->getFontItalic();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTextEffectFormat.getFontName()]

      @return String
     */
    function getFontName()
    {
        return $this->m_TextEffectFormat->getFontName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTextEffectFormat.getFontSize()]

      @return int
     */
    function getFontSize()
    {
        return $this->m_TextEffectFormat->getFontSize();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTextEffectFormat.getPresetShape()]

      @return int
     */
    function getPresetShape()
    {
        return $this->m_TextEffectFormat->getPresetShape();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTextEffectFormat.getRotatedChars()]

      @return boolean
     */
    function getRotatedChars()
    {
        return $this->m_TextEffectFormat->getRotatedChars();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTextEffectFormat.getText()]

      @return String
     */
    function getText()
    {
        return $this->m_TextEffectFormat->getText();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTextEffectFormat.setFontBold(boolean)]

      @param pBoolean0  boolean
     */
    function setFontBold($pBoolean0)
    {
        $this->m_TextEffectFormat->setFontBold($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTextEffectFormat.setFontItalic(boolean)]

      @param pBoolean0  boolean
     */
    function setFontItalic($pBoolean0)
    {
        $this->m_TextEffectFormat->setFontItalic($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTextEffectFormat.setFontName(String)]

      @param oString0  String
     */
    function setFontName($oString0)
    {
        $this->m_TextEffectFormat->setFontName($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTextEffectFormat.setFontSize(int)]

      @param pInt0  int
     */
    function setFontSize($pInt0)
    {
        $this->m_TextEffectFormat->setFontSize($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTextEffectFormat.setPresetShape(int)]

      @param pInt0  int
     */
    function setPresetShape($pInt0)
    {
        $this->m_TextEffectFormat->setPresetShape($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTextEffectFormat.setRotatedChars(boolean)]

      @param pBoolean0  boolean
     */
    function setRotatedChars($pBoolean0)
    {
        $this->m_TextEffectFormat->setRotatedChars($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTextEffectFormat.setText(String)]

      @param oString0  String
     */
    function setText($oString0)
    {
        $this->m_TextEffectFormat->setText($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTextEffectFormat.setTextEffect(int)]

      @param pInt0  int
     */
    function setTextEffect($pInt0)
    {
        $this->m_TextEffectFormat->setTextEffect($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsTextOrientationType]
  
 */
class TextOrientationType
{
    public $m_TextOrientationType;
    
    function __construct($textOrientationType)
    {
    	$this->m_TextOrientationType = $textOrientationType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsTextOverflowType]
  
 */
class TextOverflowType
{
    public $m_TextOverflowType;
    
    function __construct($textOverflowType)
    {
    	$this->m_TextOverflowType = $textOverflowType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsTextureType]
  
 */
class TextureType
{
    public $m_TextureType;
    
    function __construct($textureType)
    {
    	$this->m_TextureType = $textureType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsThemeColor]
  
 */
class ThemeColor
{
    public $m_ThemeColor;
    
    function __construct($themeColor)
    {
    	$this->m_ThemeColor = $themeColor;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsThemeColor.getColorType()]

      @return int
     */
    function getColorType()
    {
        return $this->m_ThemeColor->getColorType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsThemeColor.getTint()]

      @return double
     */
    function getTint()
    {
        return $this->m_ThemeColor->getTint();
    }

    /*
      Wrapper for java version method [com.aspose.cellsThemeColor.setColorType(int)]

      @param pInt0  int
     */
    function setColorType($pInt0)
    {
        $this->m_ThemeColor->setColorType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsThemeColor.setTint(double)]

      @param pDouble0  double
     */
    function setTint($pDouble0)
    {
        $this->m_ThemeColor->setTint($pDouble0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsThemeColorType]
  
 */
class ThemeColorType
{
    public $m_ThemeColorType;
    
    function __construct($themeColorType)
    {
    	$this->m_ThemeColorType = $themeColorType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsTickLabelPositionType]
  
 */
class TickLabelPositionType
{
    public $m_TickLabelPositionType;
    
    function __construct($tickLabelPositionType)
    {
    	$this->m_TickLabelPositionType = $tickLabelPositionType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsTickLabels]
  
 */
class TickLabels
{
    public $m_TickLabels;
    
    function __construct($tickLabels)
    {
    	$this->m_TickLabels = $tickLabels;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsTickLabels.getAutoScaleFont()]

      @return boolean
     */
    function getAutoScaleFont()
    {
        return $this->m_TickLabels->getAutoScaleFont();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTickLabels.getBackground()]

      @return int
     */
    function getBackground()
    {
        return $this->m_TickLabels->getBackground();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTickLabels.getFont()]

      @return com.aspose.cells.Font
     */
    function getFont()
    {
        return ClassFactory::_t2($this->m_TickLabels->getFont());
    }

    /*
      Wrapper for java version method [com.aspose.cellsTickLabels.getNumber()]

      @return int
     */
    function getNumber()
    {
        return $this->m_TickLabels->getNumber();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTickLabels.getNumberFormat()]

      @return String
     */
    function getNumberFormat()
    {
        return $this->m_TickLabels->getNumberFormat();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTickLabels.getNumberFormatLinked()]

      @return boolean
     */
    function getNumberFormatLinked()
    {
        return $this->m_TickLabels->getNumberFormatLinked();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTickLabels.getOffset()]

      @return int
     */
    function getOffset()
    {
        return $this->m_TickLabels->getOffset();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTickLabels.getRotation()]

      @return int
     */
    function getRotation()
    {
        return $this->m_TickLabels->getRotation();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTickLabels.getRotationAngle()]

      @return int
     */
    function getRotationAngle()
    {
        return $this->m_TickLabels->getRotationAngle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTickLabels.getTextDirection()]

      @return int
     */
    function getTextDirection()
    {
        return $this->m_TickLabels->getTextDirection();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTickLabels.setAutoScaleFont(boolean)]

      @param pBoolean0  boolean
     */
    function setAutoScaleFont($pBoolean0)
    {
        $this->m_TickLabels->setAutoScaleFont($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTickLabels.setBackground(int)]

      @param pInt0  int
     */
    function setBackground($pInt0)
    {
        $this->m_TickLabels->setBackground($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTickLabels.setNumber(int)]

      @param pInt0  int
     */
    function setNumber($pInt0)
    {
        $this->m_TickLabels->setNumber($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTickLabels.setNumberFormat(String)]

      @param oString0  String
     */
    function setNumberFormat($oString0)
    {
        $this->m_TickLabels->setNumberFormat($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTickLabels.setNumberFormatLinked(boolean)]

      @param pBoolean0  boolean
     */
    function setNumberFormatLinked($pBoolean0)
    {
        $this->m_TickLabels->setNumberFormatLinked($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTickLabels.setOffset(int)]

      @param pInt0  int
     */
    function setOffset($pInt0)
    {
        $this->m_TickLabels->setOffset($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTickLabels.setRotation(int)]

      @param pInt0  int
     */
    function setRotation($pInt0)
    {
        $this->m_TickLabels->setRotation($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTickLabels.setRotationAngle(int)]

      @param pInt0  int
     */
    function setRotationAngle($pInt0)
    {
        $this->m_TickLabels->setRotationAngle($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTickLabels.setTextDirection(int)]

      @param pInt0  int
     */
    function setTextDirection($pInt0)
    {
        $this->m_TickLabels->setTextDirection($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsTickMarkType]
  
 */
class TickMarkType
{
    public $m_TickMarkType;
    
    function __construct($tickMarkType)
    {
    	$this->m_TickMarkType = $tickMarkType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsTiffCompression]
  
 */
class TiffCompression
{
    public $m_TiffCompression;
    
    function __construct($tiffCompression)
    {
    	$this->m_TiffCompression = $tiffCompression;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsTimePeriodType]
  
 */
class TimePeriodType
{
    public $m_TimePeriodType;
    
    function __construct($timePeriodType)
    {
    	$this->m_TimePeriodType = $timePeriodType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsTimeUnit]
  
 */
class TimeUnit
{
    public $m_TimeUnit;
    
    function __construct($timeUnit)
    {
    	$this->m_TimeUnit = $timeUnit;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsTitle]
  
 */
class Title extends ChartFrame
{
    public $m_Title;
    
    function __construct($title)
    {
    	$this->m_Title = $title;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsTitle.characters(int, int)]

      @param pInt0  int
      @param pInt1  int
      @return com.aspose.cells.FontSetting
     */
    function characters($pInt0, $pInt1)
    {
        return ClassFactory::_t2($this->m_Title->characters($pInt0, $pInt1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsTitle.getLinkedSource()]

      @return String
     */
    function getLinkedSource()
    {
        return $this->m_Title->getLinkedSource();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTitle.getRotation()]

      @return int
     */
    function getRotation()
    {
        return $this->m_Title->getRotation();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTitle.getRotationAngle()]

      @return int
     */
    function getRotationAngle()
    {
        return $this->m_Title->getRotationAngle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTitle.getText()]

      @return String
     */
    function getText()
    {
        return $this->m_Title->getText();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTitle.getTextDirection()]

      @return int
     */
    function getTextDirection()
    {
        return $this->m_Title->getTextDirection();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTitle.getTextHorizontalAlignment()]

      @return int
     */
    function getTextHorizontalAlignment()
    {
        return $this->m_Title->getTextHorizontalAlignment();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTitle.getTextVerticalAlignment()]

      @return int
     */
    function getTextVerticalAlignment()
    {
        return $this->m_Title->getTextVerticalAlignment();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTitle.getX()]

      @return int
     */
    function getX()
    {
        return $this->m_Title->getX();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTitle.getY()]

      @return int
     */
    function getY()
    {
        return $this->m_Title->getY();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTitle.removeCharacters()]

     */
    function removeCharacters()
    {
        $this->m_Title->removeCharacters();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTitle.setLinkedSource(String)]

      @param oString0  String
     */
    function setLinkedSource($oString0)
    {
        $this->m_Title->setLinkedSource($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTitle.setRotation(int)]

      @param pInt0  int
     */
    function setRotation($pInt0)
    {
        $this->m_Title->setRotation($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTitle.setRotationAngle(int)]

      @param pInt0  int
     */
    function setRotationAngle($pInt0)
    {
        $this->m_Title->setRotationAngle($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTitle.setText(String)]

      @param oString0  String
     */
    function setText($oString0)
    {
        $this->m_Title->setText($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTitle.setTextDirection(int)]

      @param pInt0  int
     */
    function setTextDirection($pInt0)
    {
        $this->m_Title->setTextDirection($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTitle.setTextHorizontalAlignment(int)]

      @param pInt0  int
     */
    function setTextHorizontalAlignment($pInt0)
    {
        $this->m_Title->setTextHorizontalAlignment($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTitle.setTextVerticalAlignment(int)]

      @param pInt0  int
     */
    function setTextVerticalAlignment($pInt0)
    {
        $this->m_Title->setTextVerticalAlignment($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTitle.setX(int)]

      @param pInt0  int
     */
    function setX($pInt0)
    {
        $this->m_Title->setX($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTitle.setY(int)]

      @param pInt0  int
     */
    function setY($pInt0)
    {
        $this->m_Title->setY($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsTop10]
  
 */
class Top10
{
    public $m_Top10;
    
    function __construct($top10)
    {
    	$this->m_Top10 = $top10;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsTop10.getRank()]

      @return int
     */
    function getRank()
    {
        return $this->m_Top10->getRank();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTop10.isBottom()]

      @return boolean
     */
    function isBottom()
    {
        return $this->m_Top10->isBottom();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTop10.isPercent()]

      @return boolean
     */
    function isPercent()
    {
        return $this->m_Top10->isPercent();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTop10.setBottom(boolean)]

      @param pBoolean0  boolean
     */
    function setBottom($pBoolean0)
    {
        $this->m_Top10->setBottom($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTop10.setPercent(boolean)]

      @param pBoolean0  boolean
     */
    function setPercent($pBoolean0)
    {
        $this->m_Top10->setPercent($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTop10.setRank(int)]

      @param pInt0  int
     */
    function setRank($pInt0)
    {
        $this->m_Top10->setRank($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsTop10Filter]
  
 */
class Top10Filter
{
    public $m_Top10Filter;
    
    function __construct($top10Filter)
    {
    	$this->m_Top10Filter = $top10Filter;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsTop10Filter.getCriteria()]

      @return corresponding java type is {java.lang.Object}
     */
    function getCriteria()
    {
        return ClassFactory::_t2($this->m_Top10Filter->getCriteria());
    }

    /*
      Wrapper for java version method [com.aspose.cellsTop10Filter.getItems()]

      @return int
     */
    function getItems()
    {
        return $this->m_Top10Filter->getItems();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTop10Filter.isPercent()]

      @return boolean
     */
    function isPercent()
    {
        return $this->m_Top10Filter->isPercent();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTop10Filter.isTop()]

      @return boolean
     */
    function isTop()
    {
        return $this->m_Top10Filter->isTop();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTop10Filter.setCriteria(Object)]

      @param oObject0  corresponding java type is {java.lang.Object}
     */
    function setCriteria($oObject0)
    {
        $this->m_Top10Filter->setCriteria(ClassFactory::_t1($oObject0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsTop10Filter.setItems(int)]

      @param pInt0  int
     */
    function setItems($pInt0)
    {
        $this->m_Top10Filter->setItems($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTop10Filter.setPercent(boolean)]

      @param pBoolean0  boolean
     */
    function setPercent($pBoolean0)
    {
        $this->m_Top10Filter->setPercent($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTop10Filter.setTop(boolean)]

      @param pBoolean0  boolean
     */
    function setTop($pBoolean0)
    {
        $this->m_Top10Filter->setTop($pBoolean0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsTotalsCalculation]
  
 */
class TotalsCalculation
{
    public $m_TotalsCalculation;
    
    function __construct($totalsCalculation)
    {
    	$this->m_TotalsCalculation = $totalsCalculation;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsTrendline]
  
 */
class Trendline extends Line
{
    public $m_Trendline;
    
    function __construct($trendline)
    {
    	$this->m_Trendline = $trendline;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsTrendline.getBackward()]

      @return double
     */
    function getBackward()
    {
        return $this->m_Trendline->getBackward();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTrendline.getDataLabels()]

      @return com.aspose.cells.DataLabels
     */
    function getDataLabels()
    {
        return ClassFactory::_t2($this->m_Trendline->getDataLabels());
    }

    /*
      Wrapper for java version method [com.aspose.cellsTrendline.getDisplayEquation()]

      @return boolean
     */
    function getDisplayEquation()
    {
        return $this->m_Trendline->getDisplayEquation();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTrendline.getDisplayRSquared()]

      @return boolean
     */
    function getDisplayRSquared()
    {
        return $this->m_Trendline->getDisplayRSquared();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTrendline.getForward()]

      @return double
     */
    function getForward()
    {
        return $this->m_Trendline->getForward();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTrendline.getIntercept()]

      @return double
     */
    function getIntercept()
    {
        return $this->m_Trendline->getIntercept();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTrendline.getLegendEntry()]

      @return com.aspose.cells.LegendEntry
     */
    function getLegendEntry()
    {
        return ClassFactory::_t2($this->m_Trendline->getLegendEntry());
    }

    /*
      Wrapper for java version method [com.aspose.cellsTrendline.getName()]

      @return String
     */
    function getName()
    {
        return $this->m_Trendline->getName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTrendline.getOrder()]

      @return int
     */
    function getOrder()
    {
        return $this->m_Trendline->getOrder();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTrendline.getPeriod()]

      @return int
     */
    function getPeriod()
    {
        return $this->m_Trendline->getPeriod();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTrendline.getType()]

      @return int
     */
    function getType()
    {
        return $this->m_Trendline->getType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTrendline.isNameAuto()]

      @return boolean
     */
    function isNameAuto()
    {
        return $this->m_Trendline->isNameAuto();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTrendline.setBackward(double)]

      @param pDouble0  double
     */
    function setBackward($pDouble0)
    {
        $this->m_Trendline->setBackward($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTrendline.setDisplayEquation(boolean)]

      @param pBoolean0  boolean
     */
    function setDisplayEquation($pBoolean0)
    {
        $this->m_Trendline->setDisplayEquation($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTrendline.setDisplayRSquared(boolean)]

      @param pBoolean0  boolean
     */
    function setDisplayRSquared($pBoolean0)
    {
        $this->m_Trendline->setDisplayRSquared($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTrendline.setForward(double)]

      @param pDouble0  double
     */
    function setForward($pDouble0)
    {
        $this->m_Trendline->setForward($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTrendline.setIntercept(double)]

      @param pDouble0  double
     */
    function setIntercept($pDouble0)
    {
        $this->m_Trendline->setIntercept($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTrendline.setName(String)]

      @param oString0  String
     */
    function setName($oString0)
    {
        $this->m_Trendline->setName($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTrendline.setNameAuto(boolean)]

      @param pBoolean0  boolean
     */
    function setNameAuto($pBoolean0)
    {
        $this->m_Trendline->setNameAuto($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTrendline.setOrder(int)]

      @param pInt0  int
     */
    function setOrder($pInt0)
    {
        $this->m_Trendline->setOrder($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTrendline.setPeriod(int)]

      @param pInt0  int
     */
    function setPeriod($pInt0)
    {
        $this->m_Trendline->setPeriod($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsTrendlineCollection]
  
 */
class TrendlineCollection extends CollectionBase
{
    public $m_TrendlineCollection;
    
    function __construct($trendlineCollection)
    {
    	$this->m_TrendlineCollection = $trendlineCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsTrendlineCollection.add(int)]

      @param pInt0  int
      @return int
     */
    function add($pInt0)
    {
        return $this->m_TrendlineCollection->add($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTrendlineCollection.add(int, String)]

      @param pInt0  int
      @param oString1  String
      @return int
     */
    function addIS($pInt0, $oString1)
    {
        return $this->m_TrendlineCollection->add($pInt0, $oString1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTrendlineCollection.get(int)]

      @param pInt0  int
      @return corresponding java type is {java.lang.Object}
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_TrendlineCollection->get($pInt0));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsTrendlineType]
  
 */
class TrendlineType
{
    public $m_TrendlineType;
    
    function __construct($trendlineType)
    {
    	$this->m_TrendlineType = $trendlineType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsTxtLoadOptions]
  
 */
class TxtLoadOptions extends LoadOptions
{
    public $m_TxtLoadOptions;
    
    function __construct($txtLoadOptions)
    {
    	$this->m_TxtLoadOptions = $txtLoadOptions;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsTxtLoadOptions.getEncoding()]

      @return com.aspose.cells.Encoding
     */
    function getEncoding()
    {
        return ClassFactory::_t2($this->m_TxtLoadOptions->getEncoding());
    }

    /*
      Wrapper for java version method [com.aspose.cellsTxtLoadOptions.getSeparator()]

      @return char
     */
    function getSeparator()
    {
        return $this->m_TxtLoadOptions->getSeparator();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTxtLoadOptions.getSeparatorString()]

      @return String
     */
    function getSeparatorString()
    {
        return $this->m_TxtLoadOptions->getSeparatorString();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTxtLoadOptions.setEncoding(Encoding)]

      @param oEncoding0  com.aspose.cells.Encoding
     */
    function setEncoding($oEncoding0)
    {
        $this->m_TxtLoadOptions->setEncoding(ClassFactory::_t1($oEncoding0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsTxtLoadOptions.setSeparator(char)]

      @param pChar0  char
     */
    function setSeparator($pChar0)
    {
        $this->m_TxtLoadOptions->setSeparator($pChar0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTxtLoadOptions.setSeparatorString(String)]

      @param oString0  String
     */
    function setSeparatorString($oString0)
    {
        $this->m_TxtLoadOptions->setSeparatorString($oString0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsTxtSaveOptions]
  
 */
class TxtSaveOptions extends SaveOptions
{
    public $m_TxtSaveOptions;
    
    function __construct($txtSaveOptions)
    {
    	$this->m_TxtSaveOptions = $txtSaveOptions;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsTxtSaveOptions.getSeparator()]

      @return char
     */
    function getSeparator()
    {
        return $this->m_TxtSaveOptions->getSeparator();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTxtSaveOptions.getSeparatorString()]

      @return String
     */
    function getSeparatorString()
    {
        return $this->m_TxtSaveOptions->getSeparatorString();
    }

    /*
      Wrapper for java version method [com.aspose.cellsTxtSaveOptions.setSeparator(char)]

      @param pChar0  char
     */
    function setSeparator($pChar0)
    {
        $this->m_TxtSaveOptions->setSeparator($pChar0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsTxtSaveOptions.setSeparatorString(String)]

      @param oString0  String
     */
    function setSeparatorString($oString0)
    {
        $this->m_TxtSaveOptions->setSeparatorString($oString0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsValidation]
  
 */
class Validation
{
    public $m_Validation;
    
    function __construct($validation)
    {
    	$this->m_Validation = $validation;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsValidation.addArea(CellArea)]

      @param oCellArea0  com.aspose.cells.CellArea
     */
    function addArea($oCellArea0)
    {
        $this->m_Validation->addArea(ClassFactory::_t1($oCellArea0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidation.getAlertStyle()]

      @return int
     */
    function getAlertStyle()
    {
        return $this->m_Validation->getAlertStyle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidation.getAreaList()]

      @return array, corresponding java type is {java.util.ArrayList}
     */
    function getAreaList()
    {
        return ClassFactory::_t2($this->m_Validation->getAreaList());
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidation.getErrorMessage()]

      @return String
     */
    function getErrorMessage()
    {
        return $this->m_Validation->getErrorMessage();
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidation.getErrorTitle()]

      @return String
     */
    function getErrorTitle()
    {
        return $this->m_Validation->getErrorTitle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidation.getFormula1()]

      @return String
     */
    function getFormula1()
    {
        return $this->m_Validation->getFormula1();
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidation.getFormula2()]

      @return String
     */
    function getFormula2()
    {
        return $this->m_Validation->getFormula2();
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidation.getIgnoreBlank()]

      @return boolean
     */
    function getIgnoreBlank()
    {
        return $this->m_Validation->getIgnoreBlank();
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidation.getInCellDropDown()]

      @return boolean
     */
    function getInCellDropDown()
    {
        return $this->m_Validation->getInCellDropDown();
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidation.getInputMessage()]

      @return String
     */
    function getInputMessage()
    {
        return $this->m_Validation->getInputMessage();
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidation.getInputTitle()]

      @return String
     */
    function getInputTitle()
    {
        return $this->m_Validation->getInputTitle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidation.getOperator()]

      @return int
     */
    function getOperator()
    {
        return $this->m_Validation->getOperator();
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidation.getShowError()]

      @return boolean
     */
    function getShowError()
    {
        return $this->m_Validation->getShowError();
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidation.getShowInput()]

      @return boolean
     */
    function getShowInput()
    {
        return $this->m_Validation->getShowInput();
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidation.getType()]

      @return int
     */
    function getType()
    {
        return $this->m_Validation->getType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidation.removeACell(int, int)]

      @param pInt0  int
      @param pInt1  int
     */
    function removeACell($pInt0, $pInt1)
    {
        $this->m_Validation->removeACell($pInt0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidation.removeArea(CellArea)]

      @param oCellArea0  com.aspose.cells.CellArea
     */
    function removeArea($oCellArea0)
    {
        $this->m_Validation->removeArea(ClassFactory::_t1($oCellArea0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidation.setAlertStyle(int)]

      @param pInt0  int
     */
    function setAlertStyle($pInt0)
    {
        $this->m_Validation->setAlertStyle($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidation.setErrorMessage(String)]

      @param oString0  String
     */
    function setErrorMessage($oString0)
    {
        $this->m_Validation->setErrorMessage($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidation.setErrorTitle(String)]

      @param oString0  String
     */
    function setErrorTitle($oString0)
    {
        $this->m_Validation->setErrorTitle($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidation.setFormula1(String)]

      @param oString0  String
     */
    function setFormula1($oString0)
    {
        $this->m_Validation->setFormula1($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidation.setFormula2(String)]

      @param oString0  String
     */
    function setFormula2($oString0)
    {
        $this->m_Validation->setFormula2($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidation.setIgnoreBlank(boolean)]

      @param pBoolean0  boolean
     */
    function setIgnoreBlank($pBoolean0)
    {
        $this->m_Validation->setIgnoreBlank($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidation.setInCellDropDown(boolean)]

      @param pBoolean0  boolean
     */
    function setInCellDropDown($pBoolean0)
    {
        $this->m_Validation->setInCellDropDown($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidation.setInputMessage(String)]

      @param oString0  String
     */
    function setInputMessage($oString0)
    {
        $this->m_Validation->setInputMessage($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidation.setInputTitle(String)]

      @param oString0  String
     */
    function setInputTitle($oString0)
    {
        $this->m_Validation->setInputTitle($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidation.setOperator(int)]

      @param pInt0  int
     */
    function setOperator($pInt0)
    {
        $this->m_Validation->setOperator($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidation.setShowError(boolean)]

      @param pBoolean0  boolean
     */
    function setShowError($pBoolean0)
    {
        $this->m_Validation->setShowError($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidation.setShowInput(boolean)]

      @param pBoolean0  boolean
     */
    function setShowInput($pBoolean0)
    {
        $this->m_Validation->setShowInput($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidation.setType(int)]

      @param pInt0  int
     */
    function setType($pInt0)
    {
        $this->m_Validation->setType($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsValidationAlertType]
  
 */
class ValidationAlertType
{
    public $m_ValidationAlertType;
    
    function __construct($validationAlertType)
    {
    	$this->m_ValidationAlertType = $validationAlertType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsValidationCollection]
  
 */
class ValidationCollection extends CollectionBase
{
    public $m_ValidationCollection;
    
    function __construct($validationCollection)
    {
    	$this->m_ValidationCollection = $validationCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsValidationCollection.add()]

      @return int
     */
    function add()
    {
        return $this->m_ValidationCollection->add();
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidationCollection.add(Validation)]

      @param oValidation0  com.aspose.cells.Validation
      @return int
     */
    function addV($oValidation0)
    {
        return $this->m_ValidationCollection->add(ClassFactory::_t1($oValidation0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidationCollection.get(int)]

      @param pInt0  int
      @return com.aspose.cells.Validation
     */
    function get($pInt0)
    {
        return ClassFactory::_t2($this->m_ValidationCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidationCollection.getValidationInCell(int, int)]

      @param pInt0  int
      @param pInt1  int
      @return com.aspose.cells.Validation
     */
    function getValidationInCell($pInt0, $pInt1)
    {
        return ClassFactory::_t2($this->m_ValidationCollection->getValidationInCell($pInt0, $pInt1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidationCollection.removeACell(int, int)]

      @param pInt0  int
      @param pInt1  int
     */
    function removeACell($pInt0, $pInt1)
    {
        $this->m_ValidationCollection->removeACell($pInt0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsValidationCollection.removeArea(CellArea)]

      @param oCellArea0  com.aspose.cells.CellArea
     */
    function removeArea($oCellArea0)
    {
        $this->m_ValidationCollection->removeArea(ClassFactory::_t1($oCellArea0));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsValidationType]
  
 */
class ValidationType
{
    public $m_ValidationType;
    
    function __construct($validationType)
    {
    	$this->m_ValidationType = $validationType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsVerticalPageBreak]
  
 */
class VerticalPageBreak
{
    public $m_VerticalPageBreak;
    
    function __construct($verticalPageBreak)
    {
    	$this->m_VerticalPageBreak = $verticalPageBreak;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsVerticalPageBreak.getColumn()]

      @return int
     */
    function getColumn()
    {
        return $this->m_VerticalPageBreak->getColumn();
    }

    /*
      Wrapper for java version method [com.aspose.cellsVerticalPageBreak.getEndRow()]

      @return int
     */
    function getEndRow()
    {
        return $this->m_VerticalPageBreak->getEndRow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsVerticalPageBreak.getStartRow()]

      @return int
     */
    function getStartRow()
    {
        return $this->m_VerticalPageBreak->getStartRow();
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsVerticalPageBreakCollection]
  
 */
class VerticalPageBreakCollection extends CollectionBase
{
    public $m_VerticalPageBreakCollection;
    
    function __construct($verticalPageBreakCollection)
    {
    	$this->m_VerticalPageBreakCollection = $verticalPageBreakCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsVerticalPageBreakCollection.add(String)]

      @param oString0  String
      @return int
     */
    function add($oString0)
    {
        return $this->m_VerticalPageBreakCollection->add($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsVerticalPageBreakCollection.add(int)]

      @param pInt0  int
      @return int
     */
    function addI($pInt0)
    {
        return $this->m_VerticalPageBreakCollection->add($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsVerticalPageBreakCollection.add(int, int)]

      @param pInt0  int
      @param pInt1  int
      @return int
     */
    function addII($pInt0, $pInt1)
    {
        return $this->m_VerticalPageBreakCollection->add($pInt0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsVerticalPageBreakCollection.add(int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @return int
     */
    function addIII($pInt0, $pInt1, $pInt2)
    {
        return $this->m_VerticalPageBreakCollection->add($pInt0, $pInt1, $pInt2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsVerticalPageBreakCollection.get(String)]

      @param oString0  String
      @return com.aspose.cells.VerticalPageBreak
     */
    function get($oString0)
    {
        return ClassFactory::_t2($this->m_VerticalPageBreakCollection->get($oString0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsVerticalPageBreakCollection.get(int)]

      @param pInt0  int
      @return com.aspose.cells.VerticalPageBreak
     */
    function getI($pInt0)
    {
        return ClassFactory::_t2($this->m_VerticalPageBreakCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsVerticalPageBreakCollection.removeAt(int)]

      @param pInt0  int
     */
    function removeAt($pInt0)
    {
        $this->m_VerticalPageBreakCollection->removeAt($pInt0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsViewType]
  
 */
class ViewType
{
    public $m_ViewType;
    
    function __construct($viewType)
    {
    	$this->m_ViewType = $viewType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsVisibilityType]
  
 */
class VisibilityType
{
    public $m_VisibilityType;
    
    function __construct($visibilityType)
    {
    	$this->m_VisibilityType = $visibilityType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsWalls]
  
 */
class Walls extends Floor
{
    public $m_Walls;
    
    function __construct($walls)
    {
    	$this->m_Walls = $walls;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsWeightType]
  
 */
class WeightType
{
    public $m_WeightType;
    
    function __construct($weightType)
    {
    	$this->m_WeightType = $weightType;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsWorkbook]
  
 */
class Workbook
{
    public $m_Workbook;
    
    function __construct($workbook)
    {
    	$this->m_Workbook = $workbook;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.acceptAllRevisions()]

     */
    function acceptAllRevisions()
    {
        $this->m_Workbook->acceptAllRevisions();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.calculateFormula()]

     */
    function calculateFormula()
    {
        $this->m_Workbook->calculateFormula();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.calculateFormula(boolean)]

      @param pBoolean0  boolean
     */
    function calculateFormulaB($pBoolean0)
    {
        $this->m_Workbook->calculateFormula($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.calculateFormula(boolean, ICustomFunction)]

      @param pBoolean0  boolean
      @param oICustomFunction1  com.aspose.cells.ICustomFunction
     */
    function calculateFormulaBI($pBoolean0, $oICustomFunction1)
    {
        $this->m_Workbook->calculateFormula($pBoolean0, ClassFactory::_t1($oICustomFunction1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.changePalette(Color, int)]

      @param oColor0  com.aspose.cells.Color
      @param pInt1  int
     */
    function changePalette($oColor0, $pInt1)
    {
        $this->m_Workbook->changePalette(ClassFactory::_t1($oColor0), $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.combine(Workbook)]

      @param oWorkbook0  com.aspose.cells.Workbook
     */
    function combine($oWorkbook0)
    {
        $this->m_Workbook->combine(ClassFactory::_t1($oWorkbook0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.copy(Workbook)]

      @param oWorkbook0  com.aspose.cells.Workbook
     */
    function copy($oWorkbook0)
    {
        $this->m_Workbook->copy(ClassFactory::_t1($oWorkbook0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.createCellsColor()]

      @return com.aspose.cells.CellsColor
     */
    function createCellsColor()
    {
        return ClassFactory::_t2($this->m_Workbook->createCellsColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.createStyle()]

      @return com.aspose.cells.Style
     */
    function createStyle()
    {
        return ClassFactory::_t2($this->m_Workbook->createStyle());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.customTheme(String, Color[])]

      @param oString0  String
      @param arrO1DColor1  com.aspose.cells.Color[]
     */
    function customTheme($oString0, $arrO1DColor1)
    {
        $this->m_Workbook->customTheme($oString0, ClassFactory::_t1($arrO1DColor1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.decrypt(String)]

      @param oString0  String
     */
    function decrypt($oString0)
    {
        $this->m_Workbook->decrypt($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getAttachedFilesDirectory()]

      @return String
     */
    function getAttachedFilesDirectory()
    {
        return $this->m_Workbook->getAttachedFilesDirectory();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getAttachedFilesUrlPrefix()]

      @return String
     */
    function getAttachedFilesUrlPrefix()
    {
        return $this->m_Workbook->getAttachedFilesUrlPrefix();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getBuiltInDocumentProperties()]

      @return com.aspose.cells.BuiltInDocumentPropertyCollection
     */
    function getBuiltInDocumentProperties()
    {
        return ClassFactory::_t2($this->m_Workbook->getBuiltInDocumentProperties());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getCalcMode()]

      @return int
     */
    function getCalcMode()
    {
        return $this->m_Workbook->getCalcMode();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getColors()]

      @return com.aspose.cells.Color[]
     */
    function getColors()
    {
        return ClassFactory::_t2($this->m_Workbook->getColors());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getConvertNumericData()]

      @return boolean
     */
    function getConvertNumericData()
    {
        return $this->m_Workbook->getConvertNumericData();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getCustomDocumentProperties()]

      @return com.aspose.cells.CustomDocumentPropertyCollection
     */
    function getCustomDocumentProperties()
    {
        return ClassFactory::_t2($this->m_Workbook->getCustomDocumentProperties());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getDataSorter()]

      @return com.aspose.cells.DataSorter
     */
    function getDataSorter()
    {
        return ClassFactory::_t2($this->m_Workbook->getDataSorter());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getDate1904()]

      @return boolean
     */
    function getDate1904()
    {
        return $this->m_Workbook->getDate1904();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getDefaultStyle()]

      @return com.aspose.cells.Style
     */
    function getDefaultStyle()
    {
        return ClassFactory::_t2($this->m_Workbook->getDefaultStyle());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getDisplayDrawingObjects()]

      @return int
     */
    function getDisplayDrawingObjects()
    {
        return $this->m_Workbook->getDisplayDrawingObjects();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getDisplayHTMLCrossString()]

      @return boolean
     */
    function getDisplayHTMLCrossString()
    {
        return $this->m_Workbook->getDisplayHTMLCrossString();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getEncoding()]

      @return com.aspose.cells.Encoding
     */
    function getEncoding()
    {
        return ClassFactory::_t2($this->m_Workbook->getEncoding());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getFileFormat()]

      @return int
     */
    function getFileFormat()
    {
        return $this->m_Workbook->getFileFormat();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getFileName()]

      @return String
     */
    function getFileName()
    {
        return $this->m_Workbook->getFileName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getFirstVisibleTab()]

      @return int
     */
    function getFirstVisibleTab()
    {
        return $this->m_Workbook->getFirstVisibleTab();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getInterruptMonitor()]

      @return com.aspose.cells.InterruptMonitor
     */
    function getInterruptMonitor()
    {
        return ClassFactory::_t2($this->m_Workbook->getInterruptMonitor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getIteration()]

      @return boolean
     */
    function getIteration()
    {
        return $this->m_Workbook->getIteration();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getLanguage()]

      @return int
     */
    function getLanguage()
    {
        return $this->m_Workbook->getLanguage();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getMatchingColor(Color)]

      @param oColor0  com.aspose.cells.Color
      @return com.aspose.cells.Color
     */
    function getMatchingColor($oColor0)
    {
        return ClassFactory::_t2($this->m_Workbook->getMatchingColor(ClassFactory::_t1($oColor0)));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getMaxChange()]

      @return double
     */
    function getMaxChange()
    {
        return $this->m_Workbook->getMaxChange();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getMaxIteration()]

      @return int
     */
    function getMaxIteration()
    {
        return $this->m_Workbook->getMaxIteration();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getPageTitle()]

      @return String
     */
    function getPageTitle()
    {
        return $this->m_Workbook->getPageTitle();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getPassword()]

      @return String
     */
    function getPassword()
    {
        return $this->m_Workbook->getPassword();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getPdfExportImagesFolder()]

      @return String
     */
    function getPdfExportImagesFolder()
    {
        return $this->m_Workbook->getPdfExportImagesFolder();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getPrecisionAsDisplayed()]

      @return boolean
     */
    function getPrecisionAsDisplayed()
    {
        return $this->m_Workbook->getPrecisionAsDisplayed();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getReCalcOnOpen()]

      @return boolean
     */
    function getReCalcOnOpen()
    {
        return $this->m_Workbook->getReCalcOnOpen();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getRecalculateBeforeSave()]

      @return boolean
     */
    function getRecalculateBeforeSave()
    {
        return $this->m_Workbook->getRecalculateBeforeSave();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getRegion()]

      @return int
     */
    function getRegion()
    {
        return $this->m_Workbook->getRegion();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getSaveOptions()]

      @return com.aspose.cells.SaveOptions
     */
    function getSaveOptions()
    {
        return ClassFactory::_t2($this->m_Workbook->getSaveOptions());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getSettings()]

      @return com.aspose.cells.WorkbookSettings
     */
    function getSettings()
    {
        return ClassFactory::_t2($this->m_Workbook->getSettings());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getShared()]

      @return boolean
     */
    function getShared()
    {
        return $this->m_Workbook->getShared();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getShowTabs()]

      @return boolean
     */
    function getShowTabs()
    {
        return $this->m_Workbook->getShowTabs();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getStyles()]

      @return com.aspose.cells.StyleCollection
     */
    function getStyles()
    {
        return ClassFactory::_t2($this->m_Workbook->getStyles());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getTheme()]

      @return String
     */
    function getTheme()
    {
        return $this->m_Workbook->getTheme();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getThemeColor(int)]

      @param pInt0  int
      @return com.aspose.cells.Color
     */
    function getThemeColor($pInt0)
    {
        return ClassFactory::_t2($this->m_Workbook->getThemeColor($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.getWorksheets()]

      @return com.aspose.cells.WorksheetCollection
     */
    function getWorksheets()
    {
        return ClassFactory::_t2($this->m_Workbook->getWorksheets());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.hasExernalLinks()]

      @return boolean
     */
    function hasExernalLinks()
    {
        return $this->m_Workbook->hasExernalLinks();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.hasMacro()]

      @return boolean
     */
    function hasMacro()
    {
        return $this->m_Workbook->hasMacro();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.hasRevisions()]

      @return boolean
     */
    function hasRevisions()
    {
        return $this->m_Workbook->hasRevisions();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.initialize()]

     */
    function initialize()
    {
        $this->m_Workbook->initialize();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.isColorInPalette(Color)]

      @param oColor0  com.aspose.cells.Color
      @return boolean
     */
    function isColorInPalette($oColor0)
    {
        return $this->m_Workbook->isColorInPalette(ClassFactory::_t1($oColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.isDigitallySigned()]

      @return boolean
     */
    function isDigitallySigned()
    {
        return $this->m_Workbook->isDigitallySigned();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.isHScrollBarVisible()]

      @return boolean
     */
    function isHScrollBarVisible()
    {
        return $this->m_Workbook->isHScrollBarVisible();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.isProtected()]

      @return boolean
     */
    function isProtected()
    {
        return $this->m_Workbook->isProtected();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.isVScrollBarVisible()]

      @return boolean
     */
    function isVScrollBarVisible()
    {
        return $this->m_Workbook->isVScrollBarVisible();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.protect(int, String)]

      @param pInt0  int
      @param oString1  String
     */
    function protect($pInt0, $oString1)
    {
        $this->m_Workbook->protect($pInt0, $oString1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.removeDigitallySign()]

     */
    function removeDigitallySign()
    {
        $this->m_Workbook->removeDigitallySign();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.removeExternalLinks()]

     */
    function removeExternalLinks()
    {
        $this->m_Workbook->removeExternalLinks();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.removeMacro()]

     */
    function removeMacro()
    {
        $this->m_Workbook->removeMacro();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.replace(String, String)]

      @param oString0  String
      @param oString1  String
     */
    function replace($oString0, $oString1)
    {
        $this->m_Workbook->replace($oString0, $oString1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.replace(String, double)]

      @param oString0  String
      @param pDouble1  double
     */
    function replaceSD($oString0, $pDouble1)
    {
        $this->m_Workbook->replace($oString0, $pDouble1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.replace(String, int)]

      @param oString0  String
      @param pInt1  int
     */
    function replaceSI($oString0, $pInt1)
    {
        $this->m_Workbook->replace($oString0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.replace(boolean, Object)]

      @param pBoolean0  boolean
      @param oObject1  corresponding java type is {java.lang.Object}
     */
    function replaceBO($pBoolean0, $oObject1)
    {
        $this->m_Workbook->replace($pBoolean0, ClassFactory::_t1($oObject1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.replace(int, Object)]

      @param pInt0  int
      @param oObject1  corresponding java type is {java.lang.Object}
     */
    function replaceIO($pInt0, $oObject1)
    {
        $this->m_Workbook->replace($pInt0, ClassFactory::_t1($oObject1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.replace(String, String, ReplaceOptions)]

      @param oString0  String
      @param oString1  String
      @param oReplaceOptions2  com.aspose.cells.ReplaceOptions
     */
    function replaceSSR($oString0, $oString1, $oReplaceOptions2)
    {
        $this->m_Workbook->replace($oString0, $oString1, ClassFactory::_t1($oReplaceOptions2));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.replace(String, String[], boolean)]

      @param oString0  String
      @param arrD1DString1  array, corresponding java type is {String[]}
      @param pBoolean2  boolean
     */
    function replaceSSB($oString0, $arrD1DString1, $pBoolean2)
    {
        $this->m_Workbook->replace($oString0, $arrD1DString1, $pBoolean2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.replace(String, double[], boolean)]

      @param oString0  String
      @param arrP1DDouble1  double[]
      @param pBoolean2  boolean
     */
    function replaceSDB($oString0, $arrP1DDouble1, $pBoolean2)
    {
        $this->m_Workbook->replace($oString0, $arrP1DDouble1, $pBoolean2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.replace(String, int[], boolean)]

      @param oString0  String
      @param arrP1DInt1  int[]
      @param pBoolean2  boolean
     */
    function replaceSIB($oString0, $arrP1DInt1, $pBoolean2)
    {
        $this->m_Workbook->replace($oString0, $arrP1DInt1, $pBoolean2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.save(String)]

      @param oString0  String
     */
    function save($oString0)
    {
        $this->m_Workbook->save($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.save(OutputStream, SaveOptions)]

      @param oOutputStream0  corresponding java type is {java.io.OutputStream}
      @param oSaveOptions1  com.aspose.cells.SaveOptions
     */
    function saveOS($oOutputStream0, $oSaveOptions1)
    {
        $this->m_Workbook->save(ClassFactory::_t1($oOutputStream0), ClassFactory::_t1($oSaveOptions1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.save(OutputStream, int)]

      @param oOutputStream0  corresponding java type is {java.io.OutputStream}
      @param pInt1  int
     */
    function saveOI($oOutputStream0, $pInt1)
    {
        $this->m_Workbook->save(ClassFactory::_t1($oOutputStream0), $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.save(String, SaveOptions)]

      @param oString0  String
      @param oSaveOptions1  com.aspose.cells.SaveOptions
     */
    function saveSS($oString0, $oSaveOptions1)
    {
        $this->m_Workbook->save($oString0, ClassFactory::_t1($oSaveOptions1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.save(String, int)]

      @param oString0  String
      @param pInt1  int
     */
    function saveSI($oString0, $pInt1)
    {
        $this->m_Workbook->save($oString0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.setAttachedFilesDirectory(String)]

      @param oString0  String
     */
    function setAttachedFilesDirectory($oString0)
    {
        $this->m_Workbook->setAttachedFilesDirectory($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.setAttachedFilesUrlPrefix(String)]

      @param oString0  String
     */
    function setAttachedFilesUrlPrefix($oString0)
    {
        $this->m_Workbook->setAttachedFilesUrlPrefix($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.setCalcMode(int)]

      @param pInt0  int
     */
    function setCalcMode($pInt0)
    {
        $this->m_Workbook->setCalcMode($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.setConvertNumericData(boolean)]

      @param pBoolean0  boolean
     */
    function setConvertNumericData($pBoolean0)
    {
        $this->m_Workbook->setConvertNumericData($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.setDate1904(boolean)]

      @param pBoolean0  boolean
     */
    function setDate1904($pBoolean0)
    {
        $this->m_Workbook->setDate1904($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.setDefaultStyle(Style)]

      @param oStyle0  com.aspose.cells.Style
     */
    function setDefaultStyle($oStyle0)
    {
        $this->m_Workbook->setDefaultStyle(ClassFactory::_t1($oStyle0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.setDisplayDrawingObjects(int)]

      @param pInt0  int
     */
    function setDisplayDrawingObjects($pInt0)
    {
        $this->m_Workbook->setDisplayDrawingObjects($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.setDisplayHTMLCrossString(boolean)]

      @param pBoolean0  boolean
     */
    function setDisplayHTMLCrossString($pBoolean0)
    {
        $this->m_Workbook->setDisplayHTMLCrossString($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.setEncoding(Encoding)]

      @param oEncoding0  com.aspose.cells.Encoding
     */
    function setEncoding($oEncoding0)
    {
        $this->m_Workbook->setEncoding(ClassFactory::_t1($oEncoding0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.setEncryptionOptions(int, int)]

      @param pInt0  int
      @param pInt1  int
     */
    function setEncryptionOptions($pInt0, $pInt1)
    {
        $this->m_Workbook->setEncryptionOptions($pInt0, $pInt1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.setFileFormat(int)]

      @param pInt0  int
     */
    function setFileFormat($pInt0)
    {
        $this->m_Workbook->setFileFormat($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.setFileName(String)]

      @param oString0  String
     */
    function setFileName($oString0)
    {
        $this->m_Workbook->setFileName($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.setFirstVisibleTab(int)]

      @param pInt0  int
     */
    function setFirstVisibleTab($pInt0)
    {
        $this->m_Workbook->setFirstVisibleTab($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.setHScrollBarVisible(boolean)]

      @param pBoolean0  boolean
     */
    function setHScrollBarVisible($pBoolean0)
    {
        $this->m_Workbook->setHScrollBarVisible($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.setInterruptMonitor(InterruptMonitor)]

      @param oInterruptMonitor0  com.aspose.cells.InterruptMonitor
     */
    function setInterruptMonitor($oInterruptMonitor0)
    {
        $this->m_Workbook->setInterruptMonitor(ClassFactory::_t1($oInterruptMonitor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.setIteration(boolean)]

      @param pBoolean0  boolean
     */
    function setIteration($pBoolean0)
    {
        $this->m_Workbook->setIteration($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.setLanguage(int)]

      @param pInt0  int
     */
    function setLanguage($pInt0)
    {
        $this->m_Workbook->setLanguage($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.setMaxChange(double)]

      @param pDouble0  double
     */
    function setMaxChange($pDouble0)
    {
        $this->m_Workbook->setMaxChange($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.setMaxIteration(int)]

      @param pInt0  int
     */
    function setMaxIteration($pInt0)
    {
        $this->m_Workbook->setMaxIteration($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.setPageTitle(String)]

      @param oString0  String
     */
    function setPageTitle($oString0)
    {
        $this->m_Workbook->setPageTitle($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.setPassword(String)]

      @param oString0  String
     */
    function setPassword($oString0)
    {
        $this->m_Workbook->setPassword($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.setPdfExportImagesFolder(String)]

      @param oString0  String
     */
    function setPdfExportImagesFolder($oString0)
    {
        $this->m_Workbook->setPdfExportImagesFolder($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.setPrecisionAsDisplayed(boolean)]

      @param pBoolean0  boolean
     */
    function setPrecisionAsDisplayed($pBoolean0)
    {
        $this->m_Workbook->setPrecisionAsDisplayed($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.setReCalcOnOpen(boolean)]

      @param pBoolean0  boolean
     */
    function setReCalcOnOpen($pBoolean0)
    {
        $this->m_Workbook->setReCalcOnOpen($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.setRecalculateBeforeSave(boolean)]

      @param pBoolean0  boolean
     */
    function setRecalculateBeforeSave($pBoolean0)
    {
        $this->m_Workbook->setRecalculateBeforeSave($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.setRegion(int)]

      @param pInt0  int
     */
    function setRegion($pInt0)
    {
        $this->m_Workbook->setRegion($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.setSettings(WorkbookSettings)]

      @param oWorkbookSettings0  com.aspose.cells.WorkbookSettings
     */
    function setSettings($oWorkbookSettings0)
    {
        $this->m_Workbook->setSettings(ClassFactory::_t1($oWorkbookSettings0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.setShared(boolean)]

      @param pBoolean0  boolean
     */
    function setShared($pBoolean0)
    {
        $this->m_Workbook->setShared($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.setShowTabs(boolean)]

      @param pBoolean0  boolean
     */
    function setShowTabs($pBoolean0)
    {
        $this->m_Workbook->setShowTabs($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.setThemeColor(int, Color)]

      @param pInt0  int
      @param oColor1  com.aspose.cells.Color
     */
    function setThemeColor($pInt0, $oColor1)
    {
        $this->m_Workbook->setThemeColor($pInt0, ClassFactory::_t1($oColor1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.setVScrollBarVisible(boolean)]

      @param pBoolean0  boolean
     */
    function setVScrollBarVisible($pBoolean0)
    {
        $this->m_Workbook->setVScrollBarVisible($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.unprotect(String)]

      @param oString0  String
     */
    function unprotect($oString0)
    {
        $this->m_Workbook->unprotect($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.updateLinkedDataSource(Workbook[])]

      @param arrO1DWorkbook0  com.aspose.cells.Workbook[]
     */
    function updateLinkedDataSource($arrO1DWorkbook0)
    {
        $this->m_Workbook->updateLinkedDataSource(ClassFactory::_t1($arrO1DWorkbook0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbook.validateFormula(String)]

      @param oString0  String
      @return boolean
     */
    function validateFormula($oString0)
    {
        return $this->m_Workbook->validateFormula($oString0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsWorkbookDesigner]
  
 */
class WorkbookDesigner
{
    public $m_WorkbookDesigner;
    
    function __construct($workbookDesigner)
    {
    	$this->m_WorkbookDesigner = $workbookDesigner;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsWorkbookDesigner.clearDataSource()]

     */
    function clearDataSource()
    {
        $this->m_WorkbookDesigner->clearDataSource();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookDesigner.clearDataSource(String)]

      @param oString0  String
     */
    function clearDataSourceS($oString0)
    {
        $this->m_WorkbookDesigner->clearDataSource($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookDesigner.getSmartMarkers(int)]

      @param pInt0  int
      @return array, corresponding java type is {String[]}
     */
    function getSmartMarkers($pInt0)
    {
        return $this->m_WorkbookDesigner->getSmartMarkers($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookDesigner.getWorkbook()]

      @return com.aspose.cells.Workbook
     */
    function getWorkbook()
    {
        return ClassFactory::_t2($this->m_WorkbookDesigner->getWorkbook());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookDesigner.process()]

     */
    function process()
    {
        $this->m_WorkbookDesigner->process();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookDesigner.process(boolean)]

      @param pBoolean0  boolean
     */
    function processB($pBoolean0)
    {
        $this->m_WorkbookDesigner->process($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookDesigner.process(int, boolean)]

      @param pInt0  int
      @param pBoolean1  boolean
     */
    function processIB($pInt0, $pBoolean1)
    {
        $this->m_WorkbookDesigner->process($pInt0, $pBoolean1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookDesigner.setDataSource(ResultSet)]

      @param oResultSet0  corresponding java type is {java.sql.ResultSet}
     */
    function setDataSource($oResultSet0)
    {
        $this->m_WorkbookDesigner->setDataSource(ClassFactory::_t1($oResultSet0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookDesigner.setDataSource(String, AsposeDataTable)]

      @param oString0  String
      @param oAsposeDataTable1  com.aspose.cells.AsposeDataTable
     */
    function setDataSourceSA($oString0, $oAsposeDataTable1)
    {
        $this->m_WorkbookDesigner->setDataSource($oString0, ClassFactory::_t1($oAsposeDataTable1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookDesigner.setDataSource(String, Object)]

      @param oString0  String
      @param oObject1  corresponding java type is {java.lang.Object}
     */
    function setDataSourceSO($oString0, $oObject1)
    {
        $this->m_WorkbookDesigner->setDataSource($oString0, ClassFactory::_t1($oObject1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookDesigner.setDataSource(String, Object[])]

      @param oString0  String
      @param arrO1DObject1  array, corresponding java type is {java.lang.Object[]}
     */
    function setDataSourceSO1($oString0, $arrO1DObject1)
    {
        $this->m_WorkbookDesigner->setDataSource($oString0, ClassFactory::_t1($arrO1DObject1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookDesigner.setDataSource(String, ResultSet)]

      @param oString0  String
      @param oResultSet1  corresponding java type is {java.sql.ResultSet}
     */
    function setDataSourceSR($oString0, $oResultSet1)
    {
        $this->m_WorkbookDesigner->setDataSource($oString0, ClassFactory::_t1($oResultSet1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookDesigner.setDataSource(String, ResultSet, int)]

      @param oString0  String
      @param oResultSet1  corresponding java type is {java.sql.ResultSet}
      @param pInt2  int
     */
    function setDataSourceSRI($oString0, $oResultSet1, $pInt2)
    {
        $this->m_WorkbookDesigner->setDataSource($oString0, ClassFactory::_t1($oResultSet1), $pInt2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookDesigner.setDataSource(String, ResultSet, int, int)]

      @param oString0  String
      @param oResultSet1  corresponding java type is {java.sql.ResultSet}
      @param pInt2  int
      @param pInt3  int
     */
    function setDataSourceSRII($oString0, $oResultSet1, $pInt2, $pInt3)
    {
        $this->m_WorkbookDesigner->setDataSource($oString0, ClassFactory::_t1($oResultSet1), $pInt2, $pInt3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookDesigner.setWorkbook(Workbook)]

      @param oWorkbook0  com.aspose.cells.Workbook
     */
    function setWorkbook($oWorkbook0)
    {
        $this->m_WorkbookDesigner->setWorkbook(ClassFactory::_t1($oWorkbook0));
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsWorkbookRender]
  
 */
class WorkbookRender
{
    public $m_WorkbookRender;
    
    function __construct($workbookRender)
    {
    	$this->m_WorkbookRender = $workbookRender;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsWorkbookRender.getPageCount()]

      @return int
     */
    function getPageCount()
    {
        return $this->m_WorkbookRender->getPageCount();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookRender.toImage(OutputStream)]

      @param oOutputStream0  corresponding java type is {java.io.OutputStream}
     */
    function toImage($oOutputStream0)
    {
        $this->m_WorkbookRender->toImage(ClassFactory::_t1($oOutputStream0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookRender.toImage(String)]

      @param oString0  String
     */
    function toImageS($oString0)
    {
        $this->m_WorkbookRender->toImage($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookRender.toPrinter(String)]

      @param oString0  String
     */
    function toPrinter($oString0)
    {
        $this->m_WorkbookRender->toPrinter($oString0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsWorkbookSettings]
  
 */
class WorkbookSettings
{
    public $m_WorkbookSettings;
    
    function __construct($workbookSettings)
    {
    	$this->m_WorkbookSettings = $workbookSettings;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.getCalcMode()]

      @return int
     */
    function getCalcMode()
    {
        return $this->m_WorkbookSettings->getCalcMode();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.getConvertNumericData()]

      @return boolean
     */
    function getConvertNumericData()
    {
        return $this->m_WorkbookSettings->getConvertNumericData();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.getDate1904()]

      @return boolean
     */
    function getDate1904()
    {
        return $this->m_WorkbookSettings->getDate1904();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.getDisplayDrawingObjects()]

      @return int
     */
    function getDisplayDrawingObjects()
    {
        return $this->m_WorkbookSettings->getDisplayDrawingObjects();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.getEncoding()]

      @return com.aspose.cells.Encoding
     */
    function getEncoding()
    {
        return ClassFactory::_t2($this->m_WorkbookSettings->getEncoding());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.getFirstVisibleTab()]

      @return int
     */
    function getFirstVisibleTab()
    {
        return $this->m_WorkbookSettings->getFirstVisibleTab();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.getIteration()]

      @return boolean
     */
    function getIteration()
    {
        return $this->m_WorkbookSettings->getIteration();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.getLanguage()]

      @return int
     */
    function getLanguage()
    {
        return $this->m_WorkbookSettings->getLanguage();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.getLanguageCode()]

      @return int
     */
    function getLanguageCode()
    {
        return $this->m_WorkbookSettings->getLanguageCode();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.getMaxChange()]

      @return double
     */
    function getMaxChange()
    {
        return $this->m_WorkbookSettings->getMaxChange();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.getMaxIteration()]

      @return int
     */
    function getMaxIteration()
    {
        return $this->m_WorkbookSettings->getMaxIteration();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.getParsingFormulaOnOpen()]

      @return boolean
     */
    function getParsingFormulaOnOpen()
    {
        return $this->m_WorkbookSettings->getParsingFormulaOnOpen();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.getPassword()]

      @return String
     */
    function getPassword()
    {
        return $this->m_WorkbookSettings->getPassword();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.getPrecisionAsDisplayed()]

      @return boolean
     */
    function getPrecisionAsDisplayed()
    {
        return $this->m_WorkbookSettings->getPrecisionAsDisplayed();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.getProtectionType()]

      @return int
     */
    function getProtectionType()
    {
        return $this->m_WorkbookSettings->getProtectionType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.getReCalcOnOpen()]

      @return boolean
     */
    function getReCalcOnOpen()
    {
        return $this->m_WorkbookSettings->getReCalcOnOpen();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.getReCalculateOnOpen()]

      @return boolean
     */
    function getReCalculateOnOpen()
    {
        return $this->m_WorkbookSettings->getReCalculateOnOpen();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.getRecalculateBeforeSave()]

      @return boolean
     */
    function getRecalculateBeforeSave()
    {
        return $this->m_WorkbookSettings->getRecalculateBeforeSave();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.getRecommendReadOnly()]

      @return boolean
     */
    function getRecommendReadOnly()
    {
        return $this->m_WorkbookSettings->getRecommendReadOnly();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.getRegion()]

      @return int
     */
    function getRegion()
    {
        return $this->m_WorkbookSettings->getRegion();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.getShared()]

      @return boolean
     */
    function getShared()
    {
        return $this->m_WorkbookSettings->getShared();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.getShowTabs()]

      @return boolean
     */
    function getShowTabs()
    {
        return $this->m_WorkbookSettings->getShowTabs();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.isHScrollBarVisible()]

      @return boolean
     */
    function isHScrollBarVisible()
    {
        return $this->m_WorkbookSettings->isHScrollBarVisible();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.isProtected()]

      @return boolean
     */
    function isProtected()
    {
        return $this->m_WorkbookSettings->isProtected();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.isVScrollBarVisible()]

      @return boolean
     */
    function isVScrollBarVisible()
    {
        return $this->m_WorkbookSettings->isVScrollBarVisible();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.isWriteProtected()]

      @return boolean
     */
    function isWriteProtected()
    {
        return $this->m_WorkbookSettings->isWriteProtected();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.setCalcMode(int)]

      @param pInt0  int
     */
    function setCalcMode($pInt0)
    {
        $this->m_WorkbookSettings->setCalcMode($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.setConvertNumericData(boolean)]

      @param pBoolean0  boolean
     */
    function setConvertNumericData($pBoolean0)
    {
        $this->m_WorkbookSettings->setConvertNumericData($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.setDate1904(boolean)]

      @param pBoolean0  boolean
     */
    function setDate1904($pBoolean0)
    {
        $this->m_WorkbookSettings->setDate1904($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.setDisplayDrawingObjects(int)]

      @param pInt0  int
     */
    function setDisplayDrawingObjects($pInt0)
    {
        $this->m_WorkbookSettings->setDisplayDrawingObjects($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.setEncoding(Encoding)]

      @param oEncoding0  com.aspose.cells.Encoding
     */
    function setEncoding($oEncoding0)
    {
        $this->m_WorkbookSettings->setEncoding(ClassFactory::_t1($oEncoding0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.setFirstVisibleTab(int)]

      @param pInt0  int
     */
    function setFirstVisibleTab($pInt0)
    {
        $this->m_WorkbookSettings->setFirstVisibleTab($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.setHScrollBarVisible(boolean)]

      @param pBoolean0  boolean
     */
    function setHScrollBarVisible($pBoolean0)
    {
        $this->m_WorkbookSettings->setHScrollBarVisible($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.setIteration(boolean)]

      @param pBoolean0  boolean
     */
    function setIteration($pBoolean0)
    {
        $this->m_WorkbookSettings->setIteration($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.setLanguage(int)]

      @param pInt0  int
     */
    function setLanguage($pInt0)
    {
        $this->m_WorkbookSettings->setLanguage($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.setLanguageCode(int)]

      @param pInt0  int
     */
    function setLanguageCode($pInt0)
    {
        $this->m_WorkbookSettings->setLanguageCode($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.setMaxChange(double)]

      @param pDouble0  double
     */
    function setMaxChange($pDouble0)
    {
        $this->m_WorkbookSettings->setMaxChange($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.setMaxIteration(int)]

      @param pInt0  int
     */
    function setMaxIteration($pInt0)
    {
        $this->m_WorkbookSettings->setMaxIteration($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.setParsingFormulaOnOpen(boolean)]

      @param pBoolean0  boolean
     */
    function setParsingFormulaOnOpen($pBoolean0)
    {
        $this->m_WorkbookSettings->setParsingFormulaOnOpen($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.setPassword(String)]

      @param oString0  String
     */
    function setPassword($oString0)
    {
        $this->m_WorkbookSettings->setPassword($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.setPrecisionAsDisplayed(boolean)]

      @param pBoolean0  boolean
     */
    function setPrecisionAsDisplayed($pBoolean0)
    {
        $this->m_WorkbookSettings->setPrecisionAsDisplayed($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.setReCalcOnOpen(boolean)]

      @param pBoolean0  boolean
     */
    function setReCalcOnOpen($pBoolean0)
    {
        $this->m_WorkbookSettings->setReCalcOnOpen($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.setReCalculateOnOpen(boolean)]

      @param pBoolean0  boolean
     */
    function setReCalculateOnOpen($pBoolean0)
    {
        $this->m_WorkbookSettings->setReCalculateOnOpen($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.setRecalculateBeforeSave(boolean)]

      @param pBoolean0  boolean
     */
    function setRecalculateBeforeSave($pBoolean0)
    {
        $this->m_WorkbookSettings->setRecalculateBeforeSave($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.setRecommendReadOnly(boolean)]

      @param pBoolean0  boolean
     */
    function setRecommendReadOnly($pBoolean0)
    {
        $this->m_WorkbookSettings->setRecommendReadOnly($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.setRegion(int)]

      @param pInt0  int
     */
    function setRegion($pInt0)
    {
        $this->m_WorkbookSettings->setRegion($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.setShared(boolean)]

      @param pBoolean0  boolean
     */
    function setShared($pBoolean0)
    {
        $this->m_WorkbookSettings->setShared($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.setShowTabs(boolean)]

      @param pBoolean0  boolean
     */
    function setShowTabs($pBoolean0)
    {
        $this->m_WorkbookSettings->setShowTabs($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.setVScrollBarVisible(boolean)]

      @param pBoolean0  boolean
     */
    function setVScrollBarVisible($pBoolean0)
    {
        $this->m_WorkbookSettings->setVScrollBarVisible($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.setWriteProtected(boolean)]

      @param pBoolean0  boolean
     */
    function setWriteProtected($pBoolean0)
    {
        $this->m_WorkbookSettings->setWriteProtected($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorkbookSettings.setWriteProtectedPassword(String)]

      @param oString0  String
     */
    function setWriteProtectedPassword($oString0)
    {
        $this->m_WorkbookSettings->setWriteProtectedPassword($oString0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsWorksheet]
  
 */
class Worksheet
{
    public $m_Worksheet;
    
    function __construct($worksheet)
    {
    	$this->m_Worksheet = $worksheet;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.addPageBreaks(String)]

      @param oString0  String
     */
    function addPageBreaks($oString0)
    {
        $this->m_Worksheet->addPageBreaks($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.autoFitColumn(int)]

      @param pInt0  int
     */
    function autoFitColumn($pInt0)
    {
        $this->m_Worksheet->autoFitColumn($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.autoFitColumn(int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
     */
    function autoFitColumnIII($pInt0, $pInt1, $pInt2)
    {
        $this->m_Worksheet->autoFitColumn($pInt0, $pInt1, $pInt2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.autoFitColumns()]

     */
    function autoFitColumns()
    {
        $this->m_Worksheet->autoFitColumns();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.autoFitRow(int)]

      @param pInt0  int
     */
    function autoFitRow($pInt0)
    {
        $this->m_Worksheet->autoFitRow($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.autoFitRow(int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
     */
    function autoFitRowIII($pInt0, $pInt1, $pInt2)
    {
        $this->m_Worksheet->autoFitRow($pInt0, $pInt1, $pInt2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.autoFitRow(int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
     */
    function autoFitRowIIII($pInt0, $pInt1, $pInt2, $pInt3)
    {
        $this->m_Worksheet->autoFitRow($pInt0, $pInt1, $pInt2, $pInt3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.autoFitRows()]

     */
    function autoFitRows()
    {
        $this->m_Worksheet->autoFitRows();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.autoFitRows(AutoFitterOptions)]

      @param oAutoFitterOptions0  com.aspose.cells.AutoFitterOptions
     */
    function autoFitRowsA($oAutoFitterOptions0)
    {
        $this->m_Worksheet->autoFitRows(ClassFactory::_t1($oAutoFitterOptions0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.autoFitRows(boolean)]

      @param pBoolean0  boolean
     */
    function autoFitRowsB($pBoolean0)
    {
        $this->m_Worksheet->autoFitRows($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.clearComments()]

     */
    function clearComments()
    {
        $this->m_Worksheet->clearComments();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.copy(Worksheet)]

      @param oWorksheet0  com.aspose.cells.Worksheet
     */
    function copy($oWorksheet0)
    {
        $this->m_Worksheet->copy(ClassFactory::_t1($oWorksheet0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.copyConditionalFormatting(int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
     */
    function copyConditionalFormatting($pInt0, $pInt1, $pInt2, $pInt3)
    {
        $this->m_Worksheet->copyConditionalFormatting($pInt0, $pInt1, $pInt2, $pInt3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.freezePanes(String, int, int)]

      @param oString0  String
      @param pInt1  int
      @param pInt2  int
     */
    function freezePanes($oString0, $pInt1, $pInt2)
    {
        $this->m_Worksheet->freezePanes($oString0, $pInt1, $pInt2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.freezePanes(int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
     */
    function freezePanesIIII($pInt0, $pInt1, $pInt2, $pInt3)
    {
        $this->m_Worksheet->freezePanes($pInt0, $pInt1, $pInt2, $pInt3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getActiveCell()]

      @return String
     */
    function getActiveCell()
    {
        return $this->m_Worksheet->getActiveCell();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getAllowEditRanges()]

      @return com.aspose.cells.ProtectedRangeCollection
     */
    function getAllowEditRanges()
    {
        return ClassFactory::_t2($this->m_Worksheet->getAllowEditRanges());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getAutoFilter()]

      @return com.aspose.cells.AutoFilter
     */
    function getAutoFilter()
    {
        return ClassFactory::_t2($this->m_Worksheet->getAutoFilter());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getCells()]

      @return com.aspose.cells.Cells
     */
    function getCells()
    {
        return ClassFactory::_t2($this->m_Worksheet->getCells());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getCharts()]

      @return com.aspose.cells.ChartCollection
     */
    function getCharts()
    {
        return ClassFactory::_t2($this->m_Worksheet->getCharts());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getCheckBoxes()]

      @return com.aspose.cells.CheckBoxCollection
     */
    function getCheckBoxes()
    {
        return ClassFactory::_t2($this->m_Worksheet->getCheckBoxes());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getCodeName()]

      @return String
     */
    function getCodeName()
    {
        return $this->m_Worksheet->getCodeName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getComments()]

      @return com.aspose.cells.CommentCollection
     */
    function getComments()
    {
        return ClassFactory::_t2($this->m_Worksheet->getComments());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getConditionalFormattings()]

      @return com.aspose.cells.ConditionalFormattingCollection
     */
    function getConditionalFormattings()
    {
        return ClassFactory::_t2($this->m_Worksheet->getConditionalFormattings());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getCustomProperties()]

      @return com.aspose.cells.CustomPropertyCollection
     */
    function getCustomProperties()
    {
        return ClassFactory::_t2($this->m_Worksheet->getCustomProperties());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getDisplayRightToLeft()]

      @return boolean
     */
    function getDisplayRightToLeft()
    {
        return $this->m_Worksheet->getDisplayRightToLeft();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getDisplayZeros()]

      @return boolean
     */
    function getDisplayZeros()
    {
        return $this->m_Worksheet->getDisplayZeros();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getErrorCheckOptions()]

      @return com.aspose.cells.ErrorCheckOptionCollection
     */
    function getErrorCheckOptions()
    {
        return ClassFactory::_t2($this->m_Worksheet->getErrorCheckOptions());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getFirstVisibleColumn()]

      @return int
     */
    function getFirstVisibleColumn()
    {
        return $this->m_Worksheet->getFirstVisibleColumn();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getFirstVisibleRow()]

      @return int
     */
    function getFirstVisibleRow()
    {
        return $this->m_Worksheet->getFirstVisibleRow();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getFreezedPanes()]

      @return int[]
     */
    function getFreezedPanes()
    {
        return $this->m_Worksheet->getFreezedPanes();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getHPageBreaks()]

      @return com.aspose.cells.HorizontalPageBreakCollection
     */
    function getHPageBreaks()
    {
        return ClassFactory::_t2($this->m_Worksheet->getHPageBreaks());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getHorizontalPageBreaks()]

      @return com.aspose.cells.HorizontalPageBreakCollection
     */
    function getHorizontalPageBreaks()
    {
        return ClassFactory::_t2($this->m_Worksheet->getHorizontalPageBreaks());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getHyperlinks()]

      @return com.aspose.cells.HyperlinkCollection
     */
    function getHyperlinks()
    {
        return ClassFactory::_t2($this->m_Worksheet->getHyperlinks());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getIndex()]

      @return int
     */
    function getIndex()
    {
        return $this->m_Worksheet->getIndex();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getListObjects()]

      @return com.aspose.cells.ListObjectCollection
     */
    function getListObjects()
    {
        return ClassFactory::_t2($this->m_Worksheet->getListObjects());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getName()]

      @return String
     */
    function getName()
    {
        return $this->m_Worksheet->getName();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getOleObjects()]

      @return com.aspose.cells.OleObjectCollection
     */
    function getOleObjects()
    {
        return ClassFactory::_t2($this->m_Worksheet->getOleObjects());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getOutline()]

      @return com.aspose.cells.Outline
     */
    function getOutline()
    {
        return ClassFactory::_t2($this->m_Worksheet->getOutline());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getPageSetup()]

      @return com.aspose.cells.PageSetup
     */
    function getPageSetup()
    {
        return ClassFactory::_t2($this->m_Worksheet->getPageSetup());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getPanes()]

      @return com.aspose.cells.PaneCollection
     */
    function getPanes()
    {
        return ClassFactory::_t2($this->m_Worksheet->getPanes());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getPictures()]

      @return com.aspose.cells.PictureCollection
     */
    function getPictures()
    {
        return ClassFactory::_t2($this->m_Worksheet->getPictures());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getPivotTables()]

      @return com.aspose.cells.PivotTableCollection
     */
    function getPivotTables()
    {
        return ClassFactory::_t2($this->m_Worksheet->getPivotTables());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getProtection()]

      @return com.aspose.cells.Protection
     */
    function getProtection()
    {
        return ClassFactory::_t2($this->m_Worksheet->getProtection());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getSelectedRanges()]

      @return array, corresponding java type is {java.util.ArrayList}
     */
    function getSelectedRanges()
    {
        return ClassFactory::_t2($this->m_Worksheet->getSelectedRanges());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getShapes()]

      @return com.aspose.cells.ShapeCollection
     */
    function getShapes()
    {
        return ClassFactory::_t2($this->m_Worksheet->getShapes());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getSmartTagSetting()]

      @return com.aspose.cells.SmartTagSetting
     */
    function getSmartTagSetting()
    {
        return ClassFactory::_t2($this->m_Worksheet->getSmartTagSetting());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getSparklineGroupCollection()]

      @return com.aspose.cells.SparklineGroupCollection
     */
    function getSparklineGroupCollection()
    {
        return ClassFactory::_t2($this->m_Worksheet->getSparklineGroupCollection());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getTabColor()]

      @return com.aspose.cells.Color
     */
    function getTabColor()
    {
        return ClassFactory::_t2($this->m_Worksheet->getTabColor());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getTextBoxes()]

      @return com.aspose.cells.TextBoxCollection
     */
    function getTextBoxes()
    {
        return ClassFactory::_t2($this->m_Worksheet->getTextBoxes());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getType()]

      @return int
     */
    function getType()
    {
        return $this->m_Worksheet->getType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getVPageBreaks()]

      @return com.aspose.cells.VerticalPageBreakCollection
     */
    function getVPageBreaks()
    {
        return ClassFactory::_t2($this->m_Worksheet->getVPageBreaks());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getValidations()]

      @return com.aspose.cells.ValidationCollection
     */
    function getValidations()
    {
        return ClassFactory::_t2($this->m_Worksheet->getValidations());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getVerticalPageBreaks()]

      @return com.aspose.cells.VerticalPageBreakCollection
     */
    function getVerticalPageBreaks()
    {
        return ClassFactory::_t2($this->m_Worksheet->getVerticalPageBreaks());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getViewType()]

      @return int
     */
    function getViewType()
    {
        return $this->m_Worksheet->getViewType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getVisibilityType()]

      @return int
     */
    function getVisibilityType()
    {
        return $this->m_Worksheet->getVisibilityType();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getWorkbook()]

      @return com.aspose.cells.Workbook
     */
    function getWorkbook()
    {
        return ClassFactory::_t2($this->m_Worksheet->getWorkbook());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.getZoom()]

      @return int
     */
    function getZoom()
    {
        return $this->m_Worksheet->getZoom();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.isGridlinesVisible()]

      @return boolean
     */
    function isGridlinesVisible()
    {
        return $this->m_Worksheet->isGridlinesVisible();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.isPageBreakPreview()]

      @return boolean
     */
    function isPageBreakPreview()
    {
        return $this->m_Worksheet->isPageBreakPreview();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.isProtected()]

      @return boolean
     */
    function isProtected()
    {
        return $this->m_Worksheet->isProtected();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.isRowColumnHeadersVisible()]

      @return boolean
     */
    function isRowColumnHeadersVisible()
    {
        return $this->m_Worksheet->isRowColumnHeadersVisible();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.isSelected()]

      @return boolean
     */
    function isSelected()
    {
        return $this->m_Worksheet->isSelected();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.isVisible()]

      @return boolean
     */
    function isVisible()
    {
        return $this->m_Worksheet->isVisible();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.move(int)]

      @param pInt0  int
     */
    function move($pInt0)
    {
        $this->m_Worksheet->move($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.protect(int)]

      @param pInt0  int
     */
    function protect($pInt0)
    {
        $this->m_Worksheet->protect($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.protect(int, String, String)]

      @param pInt0  int
      @param oString1  String
      @param oString2  String
     */
    function protectISS($pInt0, $oString1, $oString2)
    {
        $this->m_Worksheet->protect($pInt0, $oString1, $oString2);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.removeAllDrawingObjects()]

     */
    function removeAllDrawingObjects()
    {
        $this->m_Worksheet->removeAllDrawingObjects();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.removeSplit()]

     */
    function removeSplit()
    {
        $this->m_Worksheet->removeSplit();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.replace(String, String)]

      @param oString0  String
      @param oString1  String
     */
    function replace($oString0, $oString1)
    {
        $this->m_Worksheet->replace($oString0, $oString1);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.setActiveCell(String)]

      @param oString0  String
     */
    function setActiveCell($oString0)
    {
        $this->m_Worksheet->setActiveCell($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.setBackground(byte[])]

      @param arrP1DByte0  byte[]
     */
    function setBackground($arrP1DByte0)
    {
        $this->m_Worksheet->setBackground($arrP1DByte0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.setDisplayRightToLeft(boolean)]

      @param pBoolean0  boolean
     */
    function setDisplayRightToLeft($pBoolean0)
    {
        $this->m_Worksheet->setDisplayRightToLeft($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.setDisplayZeros(boolean)]

      @param pBoolean0  boolean
     */
    function setDisplayZeros($pBoolean0)
    {
        $this->m_Worksheet->setDisplayZeros($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.setFirstVisibleColumn(int)]

      @param pInt0  int
     */
    function setFirstVisibleColumn($pInt0)
    {
        $this->m_Worksheet->setFirstVisibleColumn($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.setFirstVisibleRow(int)]

      @param pInt0  int
     */
    function setFirstVisibleRow($pInt0)
    {
        $this->m_Worksheet->setFirstVisibleRow($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.setGridlinesVisible(boolean)]

      @param pBoolean0  boolean
     */
    function setGridlinesVisible($pBoolean0)
    {
        $this->m_Worksheet->setGridlinesVisible($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.setName(String)]

      @param oString0  String
     */
    function setName($oString0)
    {
        $this->m_Worksheet->setName($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.setPageBreakPreview(boolean)]

      @param pBoolean0  boolean
     */
    function setPageBreakPreview($pBoolean0)
    {
        $this->m_Worksheet->setPageBreakPreview($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.setRowColumnHeadersVisible(boolean)]

      @param pBoolean0  boolean
     */
    function setRowColumnHeadersVisible($pBoolean0)
    {
        $this->m_Worksheet->setRowColumnHeadersVisible($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.setSelected(boolean)]

      @param pBoolean0  boolean
     */
    function setSelected($pBoolean0)
    {
        $this->m_Worksheet->setSelected($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.setTabColor(Color)]

      @param oColor0  com.aspose.cells.Color
     */
    function setTabColor($oColor0)
    {
        $this->m_Worksheet->setTabColor(ClassFactory::_t1($oColor0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.setType(int)]

      @param pInt0  int
     */
    function setType($pInt0)
    {
        $this->m_Worksheet->setType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.setViewType(int)]

      @param pInt0  int
     */
    function setViewType($pInt0)
    {
        $this->m_Worksheet->setViewType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.setVisibilityType(int)]

      @param pInt0  int
     */
    function setVisibilityType($pInt0)
    {
        $this->m_Worksheet->setVisibilityType($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.setVisible(boolean)]

      @param pBoolean0  boolean
     */
    function setVisible($pBoolean0)
    {
        $this->m_Worksheet->setVisible($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.setZoom(int)]

      @param pInt0  int
     */
    function setZoom($pInt0)
    {
        $this->m_Worksheet->setZoom($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.split()]

     */
    function split()
    {
        $this->m_Worksheet->split();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.unFreezePanes()]

     */
    function unFreezePanes()
    {
        $this->m_Worksheet->unFreezePanes();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.unprotect()]

     */
    function unprotect()
    {
        $this->m_Worksheet->unprotect();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheet.unprotect(String)]

      @param oString0  String
     */
    function unprotectS($oString0)
    {
        $this->m_Worksheet->unprotect($oString0);
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsWorksheetCollection]
  
 */
class WorksheetCollection extends CollectionBase
{
    public $m_WorksheetCollection;
    
    function __construct($worksheetCollection)
    {
    	$this->m_WorksheetCollection = $worksheetCollection;
    }
    
    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.add()]

      @return int
     */
    function add()
    {
        return $this->m_WorksheetCollection->add();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.add(String)]

      @param oString0  String
      @return com.aspose.cells.Worksheet
     */
    function addS($oString0)
    {
        return ClassFactory::_t2($this->m_WorksheetCollection->add($oString0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.add(int)]

      @param pInt0  int
      @return int
     */
    function addI($pInt0)
    {
        return $this->m_WorksheetCollection->add($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.addCopy(String)]

      @param oString0  String
      @return int
     */
    function addCopy($oString0)
    {
        return $this->m_WorksheetCollection->addCopy($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.addCopy(int)]

      @param pInt0  int
      @return int
     */
    function addCopyI($pInt0)
    {
        return $this->m_WorksheetCollection->addCopy($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.deleteName(String)]

      @param oString0  String
     */
    function deleteName($oString0)
    {
        $this->m_WorksheetCollection->deleteName($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.get(String)]

      @param oString0  String
      @return com.aspose.cells.Worksheet
     */
    function get($oString0)
    {
        return ClassFactory::_t2($this->m_WorksheetCollection->get($oString0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.get(int)]

      @param pInt0  int
      @return corresponding java type is {java.lang.Object}
     */
    function getI($pInt0)
    {
        return ClassFactory::_t2($this->m_WorksheetCollection->get($pInt0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.getActiveSheetIndex()]

      @return int
     */
    function getActiveSheetIndex()
    {
        return $this->m_WorksheetCollection->getActiveSheetIndex();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.getBuiltInDocumentProperties()]

      @return com.aspose.cells.BuiltInDocumentPropertyCollection
     */
    function getBuiltInDocumentProperties()
    {
        return ClassFactory::_t2($this->m_WorksheetCollection->getBuiltInDocumentProperties());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.getCustomDocumentProperties()]

      @return com.aspose.cells.CustomDocumentPropertyCollection
     */
    function getCustomDocumentProperties()
    {
        return ClassFactory::_t2($this->m_WorksheetCollection->getCustomDocumentProperties());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.getEnableHTTPCompression()]

      @return boolean
     */
    function getEnableHTTPCompression()
    {
        return $this->m_WorksheetCollection->getEnableHTTPCompression();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.getExternalLinks()]

      @return com.aspose.cells.ExternalLinkCollection
     */
    function getExternalLinks()
    {
        return ClassFactory::_t2($this->m_WorksheetCollection->getExternalLinks());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.getNamedRanges()]

      @return com.aspose.cells.Range[]
     */
    function getNamedRanges()
    {
        return ClassFactory::_t2($this->m_WorksheetCollection->getNamedRanges());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.getNamedRangesAndTables()]

      @return com.aspose.cells.Range[]
     */
    function getNamedRangesAndTables()
    {
        return ClassFactory::_t2($this->m_WorksheetCollection->getNamedRangesAndTables());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.getNames()]

      @return com.aspose.cells.NameCollection
     */
    function getNames()
    {
        return ClassFactory::_t2($this->m_WorksheetCollection->getNames());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.getOleSize()]

      @return corresponding java type is {java.lang.Object}
     */
    function getOleSize()
    {
        return ClassFactory::_t2($this->m_WorksheetCollection->getOleSize());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.getRangeByName(String)]

      @param oString0  String
      @return com.aspose.cells.Range
     */
    function getRangeByName($oString0)
    {
        return ClassFactory::_t2($this->m_WorksheetCollection->getRangeByName($oString0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.getSheetByCodeName(String)]

      @param oString0  String
      @return com.aspose.cells.Worksheet
     */
    function getSheetByCodeName($oString0)
    {
        return ClassFactory::_t2($this->m_WorksheetCollection->getSheetByCodeName($oString0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.getSheetTabBarWidth()]

      @return int
     */
    function getSheetTabBarWidth()
    {
        return $this->m_WorksheetCollection->getSheetTabBarWidth();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.getTableStyles()]

      @return com.aspose.cells.TableStyleCollection
     */
    function getTableStyles()
    {
        return ClassFactory::_t2($this->m_WorksheetCollection->getTableStyles());
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.getWindowHeightCM()]

      @return double
     */
    function getWindowHeightCM()
    {
        return $this->m_WorksheetCollection->getWindowHeightCM();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.getWindowHeightInch()]

      @return double
     */
    function getWindowHeightInch()
    {
        return $this->m_WorksheetCollection->getWindowHeightInch();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.getWindowLeftCM()]

      @return double
     */
    function getWindowLeftCM()
    {
        return $this->m_WorksheetCollection->getWindowLeftCM();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.getWindowLeftInch()]

      @return double
     */
    function getWindowLeftInch()
    {
        return $this->m_WorksheetCollection->getWindowLeftInch();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.getWindowTopCM()]

      @return double
     */
    function getWindowTopCM()
    {
        return $this->m_WorksheetCollection->getWindowTopCM();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.getWindowTopInch()]

      @return double
     */
    function getWindowTopInch()
    {
        return $this->m_WorksheetCollection->getWindowTopInch();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.getWindowWidthCM()]

      @return double
     */
    function getWindowWidthCM()
    {
        return $this->m_WorksheetCollection->getWindowWidthCM();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.getWindowWidthInch()]

      @return double
     */
    function getWindowWidthInch()
    {
        return $this->m_WorksheetCollection->getWindowWidthInch();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.insert(int, int)]

      @param pInt0  int
      @param pInt1  int
      @return com.aspose.cells.Worksheet
     */
    function insert($pInt0, $pInt1)
    {
        return ClassFactory::_t2($this->m_WorksheetCollection->insert($pInt0, $pInt1));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.insert(int, int, String)]

      @param pInt0  int
      @param pInt1  int
      @param oString2  String
      @return com.aspose.cells.Worksheet
     */
    function insertIIS($pInt0, $pInt1, $oString2)
    {
        return ClassFactory::_t2($this->m_WorksheetCollection->insert($pInt0, $pInt1, $oString2));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.isHidden()]

      @return boolean
     */
    function isHidden()
    {
        return $this->m_WorksheetCollection->isHidden();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.isMinimized()]

      @return boolean
     */
    function isMinimized()
    {
        return $this->m_WorksheetCollection->isMinimized();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.isRefreshAllConnections()]

      @return boolean
     */
    function isRefreshAllConnections()
    {
        return $this->m_WorksheetCollection->isRefreshAllConnections();
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.removeAt(String)]

      @param oString0  String
     */
    function removeAt($oString0)
    {
        $this->m_WorksheetCollection->removeAt($oString0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.removeAt(int)]

      @param pInt0  int
     */
    function removeAtI($pInt0)
    {
        $this->m_WorksheetCollection->removeAt($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.setActiveSheetIndex(int)]

      @param pInt0  int
     */
    function setActiveSheetIndex($pInt0)
    {
        $this->m_WorksheetCollection->setActiveSheetIndex($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.setEnableHTTPCompression(boolean)]

      @param pBoolean0  boolean
     */
    function setEnableHTTPCompression($pBoolean0)
    {
        $this->m_WorksheetCollection->setEnableHTTPCompression($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.setHidden(boolean)]

      @param pBoolean0  boolean
     */
    function setHidden($pBoolean0)
    {
        $this->m_WorksheetCollection->setHidden($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.setMinimized(boolean)]

      @param pBoolean0  boolean
     */
    function setMinimized($pBoolean0)
    {
        $this->m_WorksheetCollection->setMinimized($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.setOleSize(Object)]

      @param oObject0  corresponding java type is {java.lang.Object}
     */
    function setOleSize($oObject0)
    {
        $this->m_WorksheetCollection->setOleSize(ClassFactory::_t1($oObject0));
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.setOleSize(int, int, int, int)]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
     */
    function setOleSizeIIII($pInt0, $pInt1, $pInt2, $pInt3)
    {
        $this->m_WorksheetCollection->setOleSize($pInt0, $pInt1, $pInt2, $pInt3);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.setRefreshAllConnections(boolean)]

      @param pBoolean0  boolean
     */
    function setRefreshAllConnections($pBoolean0)
    {
        $this->m_WorksheetCollection->setRefreshAllConnections($pBoolean0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.setSheetTabBarWidth(int)]

      @param pInt0  int
     */
    function setSheetTabBarWidth($pInt0)
    {
        $this->m_WorksheetCollection->setSheetTabBarWidth($pInt0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.setWindowHeightCM(double)]

      @param pDouble0  double
     */
    function setWindowHeightCM($pDouble0)
    {
        $this->m_WorksheetCollection->setWindowHeightCM($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.setWindowHeightInch(double)]

      @param pDouble0  double
     */
    function setWindowHeightInch($pDouble0)
    {
        $this->m_WorksheetCollection->setWindowHeightInch($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.setWindowLeftCM(double)]

      @param pDouble0  double
     */
    function setWindowLeftCM($pDouble0)
    {
        $this->m_WorksheetCollection->setWindowLeftCM($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.setWindowLeftInch(double)]

      @param pDouble0  double
     */
    function setWindowLeftInch($pDouble0)
    {
        $this->m_WorksheetCollection->setWindowLeftInch($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.setWindowTopCM(double)]

      @param pDouble0  double
     */
    function setWindowTopCM($pDouble0)
    {
        $this->m_WorksheetCollection->setWindowTopCM($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.setWindowTopInch(double)]

      @param pDouble0  double
     */
    function setWindowTopInch($pDouble0)
    {
        $this->m_WorksheetCollection->setWindowTopInch($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.setWindowWidthCM(double)]

      @param pDouble0  double
     */
    function setWindowWidthCM($pDouble0)
    {
        $this->m_WorksheetCollection->setWindowWidthCM($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.setWindowWidthInch(double)]

      @param pDouble0  double
     */
    function setWindowWidthInch($pDouble0)
    {
        $this->m_WorksheetCollection->setWindowWidthInch($pDouble0);
    }

    /*
      Wrapper for java version method [com.aspose.cellsWorksheetCollection.sortNames()]

     */
    function sortNames()
    {
        $this->m_WorksheetCollection->sortNames();
    }
}

/*
  Wrapper for java version Class [com.aspose.cellsXlsbSaveOptions]
  
 */
class XlsbSaveOptions extends SaveOptions
{
    public $m_XlsbSaveOptions;
    
    function __construct($xlsbSaveOptions)
    {
    	$this->m_XlsbSaveOptions = $xlsbSaveOptions;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsXlsSaveOptions]
  
 */
class XlsSaveOptions extends SaveOptions
{
    public $m_XlsSaveOptions;
    
    function __construct($xlsSaveOptions)
    {
    	$this->m_XlsSaveOptions = $xlsSaveOptions;
    }
    }

/*
  Wrapper for java version Class [com.aspose.cellsXpsSaveOptions]
  
 */
class XpsSaveOptions extends SaveOptions
{
    public $m_XpsSaveOptions;
    
    function __construct($xpsSaveOptions)
    {
    	$this->m_XpsSaveOptions = $xpsSaveOptions;
    }
    }

class ClassFactory 
{
    static $_vv1 = array(
        );


    /*
      create new wrapped class [AboveAverage] for java version [com.aspose.cellsAboveAverage]

    */
    static function createAboveAverage()
    {
        $aboveAverage = new Java('com.aspose.cellsAboveAverage');
        return new AboveAverage($aboveAverage);
    }
    
    /*
      create new wrapped class [AutoFitterOptions] for java version [com.aspose.cellsAutoFitterOptions]

    */
    static function createAutoFitterOptions()
    {
        $autoFitterOptions = new Java('com.aspose.cellsAutoFitterOptions');
        return new AutoFitterOptions($autoFitterOptions);
    }
    
    /*
      create new wrapped class [CellArea] for java version [com.aspose.cellsCellArea]

    */
    static function createCellArea()
    {
        $cellArea = new Java('com.aspose.cellsCellArea');
        return new CellArea($cellArea);
    }
    
    /*
      create new wrapped class [CellsHelper] for java version [com.aspose.cellsCellsHelper]

    */
    static function createCellsHelper()
    {
        $cellsHelper = new Java('com.aspose.cellsCellsHelper');
        return new CellsHelper($cellsHelper);
    }
    
    /*
      create new wrapped class [CollectionBase] for java version [com.aspose.cellsCollectionBase]

    */
    static function createCollectionBase()
    {
        $collectionBase = new Java('com.aspose.cellsCollectionBase');
        return new CollectionBase($collectionBase);
    }
    
    /*
      create new wrapped class [CollectionBase] for java version [com.aspose.cellsCollectionBase]

      @param pInt0  int
    */
    static function create1CollectionBase($pInt0)
    {
        $collectionBase = new Java('com.aspose.cellsCollectionBase', $pInt0);
        return new CollectionBase($collectionBase);
    }
    
    /*
      create new wrapped class [Color] for java version [com.aspose.cellsColor]

    */
    static function createColor()
    {
        $color = new Java('com.aspose.cellsColor');
        return new Color($color);
    }
    
    /*
      create new wrapped class [CustomFilter] for java version [com.aspose.cellsCustomFilter]

    */
    static function createCustomFilter()
    {
        $customFilter = new Java('com.aspose.cellsCustomFilter');
        return new CustomFilter($customFilter);
    }
    
    /*
      create new wrapped class [CustomFilterCollection] for java version [com.aspose.cellsCustomFilterCollection]

    */
    static function createCustomFilterCollection()
    {
        $customFilterCollection = new Java('com.aspose.cellsCustomFilterCollection');
        return new CustomFilterCollection($customFilterCollection);
    }
    
    /*
      create new wrapped class [CustomProperty] for java version [com.aspose.cellsCustomProperty]

    */
    static function createCustomProperty()
    {
        $customProperty = new Java('com.aspose.cellsCustomProperty');
        return new CustomProperty($customProperty);
    }
    
    /*
      create new wrapped class [DateTime] for java version [com.aspose.cellsDateTime]
      WARNNING
        the parameter[oCalendar0] maybe has no Php-wrapper.

      @param oCalendar0  corresponding java type is {java.util.Calendar}
    */
    static function createDateTime($oCalendar0)
    {
        $dateTime = new Java('com.aspose.cellsDateTime', ClassFactory::_t1($oCalendar0));
        return new DateTime($dateTime);
    }
    
    /*
      create new wrapped class [DateTime] for java version [com.aspose.cellsDateTime]
      WARNNING
        the parameter[oDate0] maybe has no Php-wrapper.

      @param oDate0  corresponding java type is {java.util.Date}
    */
    static function create1DateTime($oDate0)
    {
        $dateTime = new Java('com.aspose.cellsDateTime', ClassFactory::_t1($oDate0));
        return new DateTime($dateTime);
    }
    
    /*
      create new wrapped class [DateTime] for java version [com.aspose.cellsDateTime]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
    */
    static function create2DateTime($pInt0, $pInt1, $pInt2)
    {
        $dateTime = new Java('com.aspose.cellsDateTime', $pInt0, $pInt1, $pInt2);
        return new DateTime($dateTime);
    }
    
    /*
      create new wrapped class [DateTime] for java version [com.aspose.cellsDateTime]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @param pInt4  int
      @param pInt5  int
    */
    static function create3DateTime($pInt0, $pInt1, $pInt2, $pInt3, $pInt4, $pInt5)
    {
        $dateTime = new Java('com.aspose.cellsDateTime', $pInt0, $pInt1, $pInt2, $pInt3, $pInt4, $pInt5);
        return new DateTime($dateTime);
    }
    
    /*
      create new wrapped class [DateTime] for java version [com.aspose.cellsDateTime]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @param pInt4  int
      @param pInt5  int
      @param pInt6  int
    */
    static function create4DateTime($pInt0, $pInt1, $pInt2, $pInt3, $pInt4, $pInt5, $pInt6)
    {
        $dateTime = new Java('com.aspose.cellsDateTime', $pInt0, $pInt1, $pInt2, $pInt3, $pInt4, $pInt5, $pInt6);
        return new DateTime($dateTime);
    }
    
    /*
      create new wrapped class [DateTimeGroupItem] for java version [com.aspose.cellsDateTimeGroupItem]

      @param pInt0  int
      @param pInt1  int
      @param pInt2  int
      @param pInt3  int
      @param pInt4  int
      @param pInt5  int
      @param pInt6  int
    */
    static function createDateTimeGroupItem($pInt0, $pInt1, $pInt2, $pInt3, $pInt4, $pInt5, $pInt6)
    {
        $dateTimeGroupItem = new Java('com.aspose.cellsDateTimeGroupItem', $pInt0, $pInt1, $pInt2, $pInt3, $pInt4, $pInt5, $pInt6);
        return new DateTimeGroupItem($dateTimeGroupItem);
    }
    
    /*
      create new wrapped class [ExportTableOptions] for java version [com.aspose.cellsExportTableOptions]

    */
    static function createExportTableOptions()
    {
        $exportTableOptions = new Java('com.aspose.cellsExportTableOptions');
        return new ExportTableOptions($exportTableOptions);
    }
    
    /*
      create new wrapped class [FileFormatUtil] for java version [com.aspose.cellsFileFormatUtil]

    */
    static function createFileFormatUtil()
    {
        $fileFormatUtil = new Java('com.aspose.cellsFileFormatUtil');
        return new FileFormatUtil($fileFormatUtil);
    }
    
    /*
      create new wrapped class [FindOptions] for java version [com.aspose.cellsFindOptions]

    */
    static function createFindOptions()
    {
        $findOptions = new Java('com.aspose.cellsFindOptions');
        return new FindOptions($findOptions);
    }
    
    /*
      create new wrapped class [HtmlSaveOptions] for java version [com.aspose.cellsHtmlSaveOptions]

    */
    static function createHtmlSaveOptions()
    {
        $htmlSaveOptions = new Java('com.aspose.cellsHtmlSaveOptions');
        return new HtmlSaveOptions($htmlSaveOptions);
    }
    
    /*
      create new wrapped class [HtmlSaveOptions] for java version [com.aspose.cellsHtmlSaveOptions]

      @param pInt0  int
    */
    static function create1HtmlSaveOptions($pInt0)
    {
        $htmlSaveOptions = new Java('com.aspose.cellsHtmlSaveOptions', $pInt0);
        return new HtmlSaveOptions($htmlSaveOptions);
    }
    
    /*
      create new wrapped class [ImageOrPrintOptions] for java version [com.aspose.cellsImageOrPrintOptions]

    */
    static function createImageOrPrintOptions()
    {
        $imageOrPrintOptions = new Java('com.aspose.cellsImageOrPrintOptions');
        return new ImageOrPrintOptions($imageOrPrintOptions);
    }
    
    /*
      create new wrapped class [InterruptMonitor] for java version [com.aspose.cellsInterruptMonitor]

    */
    static function createInterruptMonitor()
    {
        $interruptMonitor = new Java('com.aspose.cellsInterruptMonitor');
        return new InterruptMonitor($interruptMonitor);
    }
    
    /*
      create new wrapped class [License] for java version [com.aspose.cellsLicense]

    */
    static function createLicense()
    {
        $license = new Java('com.aspose.cellsLicense');
        return new License($license);
    }
    
    /*
      create new wrapped class [LoadDataOption] for java version [com.aspose.cellsLoadDataOption]

    */
    static function createLoadDataOption()
    {
        $loadDataOption = new Java('com.aspose.cellsLoadDataOption');
        return new LoadDataOption($loadDataOption);
    }
    
    /*
      create new wrapped class [LoadOptions] for java version [com.aspose.cellsLoadOptions]

    */
    static function createLoadOptions()
    {
        $loadOptions = new Java('com.aspose.cellsLoadOptions');
        return new LoadOptions($loadOptions);
    }
    
    /*
      create new wrapped class [LoadOptions] for java version [com.aspose.cellsLoadOptions]

      @param pInt0  int
    */
    static function create1LoadOptions($pInt0)
    {
        $loadOptions = new Java('com.aspose.cellsLoadOptions', $pInt0);
        return new LoadOptions($loadOptions);
    }
    
    /*
      create new wrapped class [MultipleFilterCollection] for java version [com.aspose.cellsMultipleFilterCollection]

    */
    static function createMultipleFilterCollection()
    {
        $multipleFilterCollection = new Java('com.aspose.cellsMultipleFilterCollection');
        return new MultipleFilterCollection($multipleFilterCollection);
    }
    
    /*
      create new wrapped class [OdsSaveOptions] for java version [com.aspose.cellsOdsSaveOptions]

    */
    static function createOdsSaveOptions()
    {
        $odsSaveOptions = new Java('com.aspose.cellsOdsSaveOptions');
        return new OdsSaveOptions($odsSaveOptions);
    }
    
    /*
      create new wrapped class [OdsSaveOptions] for java version [com.aspose.cellsOdsSaveOptions]

      @param pInt0  int
    */
    static function create1OdsSaveOptions($pInt0)
    {
        $odsSaveOptions = new Java('com.aspose.cellsOdsSaveOptions', $pInt0);
        return new OdsSaveOptions($odsSaveOptions);
    }
    
    /*
      create new wrapped class [OoxmlSaveOptions] for java version [com.aspose.cellsOoxmlSaveOptions]

    */
    static function createOoxmlSaveOptions()
    {
        $ooxmlSaveOptions = new Java('com.aspose.cellsOoxmlSaveOptions');
        return new OoxmlSaveOptions($ooxmlSaveOptions);
    }
    
    /*
      create new wrapped class [OoxmlSaveOptions] for java version [com.aspose.cellsOoxmlSaveOptions]

      @param pInt0  int
    */
    static function create1OoxmlSaveOptions($pInt0)
    {
        $ooxmlSaveOptions = new Java('com.aspose.cellsOoxmlSaveOptions', $pInt0);
        return new OoxmlSaveOptions($ooxmlSaveOptions);
    }
    
    /*
      create new wrapped class [PasteOptions] for java version [com.aspose.cellsPasteOptions]

    */
    static function createPasteOptions()
    {
        $pasteOptions = new Java('com.aspose.cellsPasteOptions');
        return new PasteOptions($pasteOptions);
    }
    
    /*
      create new wrapped class [PdfBookmarkEntry] for java version [com.aspose.cellsPdfBookmarkEntry]

    */
    static function createPdfBookmarkEntry()
    {
        $pdfBookmarkEntry = new Java('com.aspose.cellsPdfBookmarkEntry');
        return new PdfBookmarkEntry($pdfBookmarkEntry);
    }
    
    /*
      create new wrapped class [PdfSaveOptions] for java version [com.aspose.cellsPdfSaveOptions]

    */
    static function createPdfSaveOptions()
    {
        $pdfSaveOptions = new Java('com.aspose.cellsPdfSaveOptions');
        return new PdfSaveOptions($pdfSaveOptions);
    }
    
    /*
      create new wrapped class [PdfSaveOptions] for java version [com.aspose.cellsPdfSaveOptions]

      @param pInt0  int
    */
    static function create1PdfSaveOptions($pInt0)
    {
        $pdfSaveOptions = new Java('com.aspose.cellsPdfSaveOptions', $pInt0);
        return new PdfSaveOptions($pdfSaveOptions);
    }
    
    /*
      create new wrapped class [PdfSecurityOptions] for java version [com.aspose.cellsPdfSecurityOptions]

    */
    static function createPdfSecurityOptions()
    {
        $pdfSecurityOptions = new Java('com.aspose.cellsPdfSecurityOptions');
        return new PdfSecurityOptions($pdfSecurityOptions);
    }
    
    /*
      create new wrapped class [PivotPageFields] for java version [com.aspose.cellsPivotPageFields]

    */
    static function createPivotPageFields()
    {
        $pivotPageFields = new Java('com.aspose.cellsPivotPageFields');
        return new PivotPageFields($pivotPageFields);
    }
    
    /*
      create new wrapped class [ReferredAreaCollection] for java version [com.aspose.cellsReferredAreaCollection]

    */
    static function createReferredAreaCollection()
    {
        $referredAreaCollection = new Java('com.aspose.cellsReferredAreaCollection');
        return new ReferredAreaCollection($referredAreaCollection);
    }
    
    /*
      create new wrapped class [ReplaceOptions] for java version [com.aspose.cellsReplaceOptions]

    */
    static function createReplaceOptions()
    {
        $replaceOptions = new Java('com.aspose.cellsReplaceOptions');
        return new ReplaceOptions($replaceOptions);
    }
    
    /*
      create new wrapped class [SheetRender] for java version [com.aspose.cellsSheetRender]

      @param oWorksheet0  com.aspose.cells.Worksheet
      @param oImageOrPrintOptions1  com.aspose.cells.ImageOrPrintOptions
    */
    static function createSheetRender($oWorksheet0, $oImageOrPrintOptions1)
    {
        $sheetRender = new Java('com.aspose.cellsSheetRender', ClassFactory::_t1($oWorksheet0), ClassFactory::_t1($oImageOrPrintOptions1));
        return new SheetRender($sheetRender);
    }
    
    /*
      create new wrapped class [SmartTagOptions] for java version [com.aspose.cellsSmartTagOptions]

    */
    static function createSmartTagOptions()
    {
        $smartTagOptions = new Java('com.aspose.cellsSmartTagOptions');
        return new SmartTagOptions($smartTagOptions);
    }
    
    /*
      create new wrapped class [SmartTagPropertyCollection] for java version [com.aspose.cellsSmartTagPropertyCollection]

    */
    static function createSmartTagPropertyCollection()
    {
        $smartTagPropertyCollection = new Java('com.aspose.cellsSmartTagPropertyCollection');
        return new SmartTagPropertyCollection($smartTagPropertyCollection);
    }
    
    /*
      create new wrapped class [SpreadsheetML2003SaveOptions] for java version [com.aspose.cellsSpreadsheetML2003SaveOptions]

    */
    static function createSpreadsheetML2003SaveOptions()
    {
        $spreadsheetML2003SaveOptions = new Java('com.aspose.cellsSpreadsheetML2003SaveOptions');
        return new SpreadsheetML2003SaveOptions($spreadsheetML2003SaveOptions);
    }
    
    /*
      create new wrapped class [SpreadsheetML2003SaveOptions] for java version [com.aspose.cellsSpreadsheetML2003SaveOptions]

      @param pInt0  int
    */
    static function create1SpreadsheetML2003SaveOptions($pInt0)
    {
        $spreadsheetML2003SaveOptions = new Java('com.aspose.cellsSpreadsheetML2003SaveOptions', $pInt0);
        return new SpreadsheetML2003SaveOptions($spreadsheetML2003SaveOptions);
    }
    
    /*
      create new wrapped class [Style] for java version [com.aspose.cellsStyle]

    */
    static function createStyle()
    {
        $style = new Java('com.aspose.cellsStyle');
        return new Style($style);
    }
    
    /*
      create new wrapped class [StyleFlag] for java version [com.aspose.cellsStyleFlag]

    */
    static function createStyleFlag()
    {
        $styleFlag = new Java('com.aspose.cellsStyleFlag');
        return new StyleFlag($styleFlag);
    }
    
    /*
      create new wrapped class [ThemeColor] for java version [com.aspose.cellsThemeColor]

      @param pInt0  int
      @param pDouble1  double
    */
    static function createThemeColor($pInt0, $pDouble1)
    {
        $themeColor = new Java('com.aspose.cellsThemeColor', $pInt0, $pDouble1);
        return new ThemeColor($themeColor);
    }
    
    /*
      create new wrapped class [Top10] for java version [com.aspose.cellsTop10]

    */
    static function createTop10()
    {
        $top10 = new Java('com.aspose.cellsTop10');
        return new Top10($top10);
    }
    
    /*
      create new wrapped class [TxtLoadOptions] for java version [com.aspose.cellsTxtLoadOptions]

    */
    static function createTxtLoadOptions()
    {
        $txtLoadOptions = new Java('com.aspose.cellsTxtLoadOptions');
        return new TxtLoadOptions($txtLoadOptions);
    }
    
    /*
      create new wrapped class [TxtLoadOptions] for java version [com.aspose.cellsTxtLoadOptions]

      @param pInt0  int
    */
    static function create1TxtLoadOptions($pInt0)
    {
        $txtLoadOptions = new Java('com.aspose.cellsTxtLoadOptions', $pInt0);
        return new TxtLoadOptions($txtLoadOptions);
    }
    
    /*
      create new wrapped class [TxtSaveOptions] for java version [com.aspose.cellsTxtSaveOptions]

    */
    static function createTxtSaveOptions()
    {
        $txtSaveOptions = new Java('com.aspose.cellsTxtSaveOptions');
        return new TxtSaveOptions($txtSaveOptions);
    }
    
    /*
      create new wrapped class [TxtSaveOptions] for java version [com.aspose.cellsTxtSaveOptions]

      @param pInt0  int
    */
    static function create1TxtSaveOptions($pInt0)
    {
        $txtSaveOptions = new Java('com.aspose.cellsTxtSaveOptions', $pInt0);
        return new TxtSaveOptions($txtSaveOptions);
    }
    
    /*
      create new wrapped class [Workbook] for java version [com.aspose.cellsWorkbook]

    */
    static function createWorkbook()
    {
        $workbook = new Java('com.aspose.cellsWorkbook');
        return new Workbook($workbook);
    }
    
    /*
      create new wrapped class [Workbook] for java version [com.aspose.cellsWorkbook]
      WARNNING
        the parameter[oInputStream0] maybe has no Php-wrapper.

      @param oInputStream0  corresponding java type is {java.io.InputStream}
    */
    static function create1Workbook($oInputStream0)
    {
        $workbook = new Java('com.aspose.cellsWorkbook', ClassFactory::_t1($oInputStream0));
        return new Workbook($workbook);
    }
    
    /*
      create new wrapped class [Workbook] for java version [com.aspose.cellsWorkbook]

      @param oString0  String
    */
    static function create2Workbook($oString0)
    {
        $workbook = new Java('com.aspose.cellsWorkbook', $oString0);
        return new Workbook($workbook);
    }
    
    /*
      create new wrapped class [Workbook] for java version [com.aspose.cellsWorkbook]

      @param pInt0  int
    */
    static function create3Workbook($pInt0)
    {
        $workbook = new Java('com.aspose.cellsWorkbook', $pInt0);
        return new Workbook($workbook);
    }
    
    /*
      create new wrapped class [Workbook] for java version [com.aspose.cellsWorkbook]
      WARNNING
        the parameter[oInputStream0] maybe has no Php-wrapper.

      @param oInputStream0  corresponding java type is {java.io.InputStream}
      @param oLoadOptions1  com.aspose.cells.LoadOptions
    */
    static function create4Workbook($oInputStream0, $oLoadOptions1)
    {
        $workbook = new Java('com.aspose.cellsWorkbook', ClassFactory::_t1($oInputStream0), ClassFactory::_t1($oLoadOptions1));
        return new Workbook($workbook);
    }
    
    /*
      create new wrapped class [Workbook] for java version [com.aspose.cellsWorkbook]

      @param oString0  String
      @param oLoadOptions1  com.aspose.cells.LoadOptions
    */
    static function create5Workbook($oString0, $oLoadOptions1)
    {
        $workbook = new Java('com.aspose.cellsWorkbook', $oString0, ClassFactory::_t1($oLoadOptions1));
        return new Workbook($workbook);
    }
    
    /*
      create new wrapped class [WorkbookDesigner] for java version [com.aspose.cellsWorkbookDesigner]

    */
    static function createWorkbookDesigner()
    {
        $workbookDesigner = new Java('com.aspose.cellsWorkbookDesigner');
        return new WorkbookDesigner($workbookDesigner);
    }
    
    /*
      create new wrapped class [WorkbookRender] for java version [com.aspose.cellsWorkbookRender]

      @param oWorkbook0  com.aspose.cells.Workbook
      @param oImageOrPrintOptions1  com.aspose.cells.ImageOrPrintOptions
    */
    static function createWorkbookRender($oWorkbook0, $oImageOrPrintOptions1)
    {
        $workbookRender = new Java('com.aspose.cellsWorkbookRender', ClassFactory::_t1($oWorkbook0), ClassFactory::_t1($oImageOrPrintOptions1));
        return new WorkbookRender($workbookRender);
    }
    
    /*
      create new wrapped class [XlsbSaveOptions] for java version [com.aspose.cellsXlsbSaveOptions]

    */
    static function createXlsbSaveOptions()
    {
        $xlsbSaveOptions = new Java('com.aspose.cellsXlsbSaveOptions');
        return new XlsbSaveOptions($xlsbSaveOptions);
    }
    
    /*
      create new wrapped class [XlsbSaveOptions] for java version [com.aspose.cellsXlsbSaveOptions]

      @param pInt0  int
    */
    static function create1XlsbSaveOptions($pInt0)
    {
        $xlsbSaveOptions = new Java('com.aspose.cellsXlsbSaveOptions', $pInt0);
        return new XlsbSaveOptions($xlsbSaveOptions);
    }
    
    /*
      create new wrapped class [XlsSaveOptions] for java version [com.aspose.cellsXlsSaveOptions]

    */
    static function createXlsSaveOptions()
    {
        $xlsSaveOptions = new Java('com.aspose.cellsXlsSaveOptions');
        return new XlsSaveOptions($xlsSaveOptions);
    }
    
    /*
      create new wrapped class [XlsSaveOptions] for java version [com.aspose.cellsXlsSaveOptions]

      @param pInt0  int
    */
    static function create1XlsSaveOptions($pInt0)
    {
        $xlsSaveOptions = new Java('com.aspose.cellsXlsSaveOptions', $pInt0);
        return new XlsSaveOptions($xlsSaveOptions);
    }
    
    /*
      create new wrapped class [XpsSaveOptions] for java version [com.aspose.cellsXpsSaveOptions]

    */
    static function createXpsSaveOptions()
    {
        $xpsSaveOptions = new Java('com.aspose.cellsXpsSaveOptions');
        return new XpsSaveOptions($xpsSaveOptions);
    }
    
    /*
      create new wrapped class [XpsSaveOptions] for java version [com.aspose.cellsXpsSaveOptions]

      @param pInt0  int
    */
    static function create1XpsSaveOptions($pInt0)
    {
        $xpsSaveOptions = new Java('com.aspose.cellsXpsSaveOptions', $pInt0);
        return new XpsSaveOptions($xpsSaveOptions);
    }
    

    static function _t1($_v1)
    {
        if($_v1 instanceof Java)
        {
            return $_v1;
        }
        if(is_array($_v1))
        {
            foreach($_v1 as $_v2 => $_v3)
            {
                $_v4[$_v2] = ClassFactory::_t1($_v3);
            }
            return $_v4;
        }
        elseif (is_object($_v1))
        {
            $_v5 = get_class($_v1);
            if(!class_exists($_v5))
            {
                return $_v1;
            }
            $_v5 = "m_" . $_v5;
            if(array_key_exists($_v5, get_object_vars($_v1)))
            {
                return $_v1->$_v5;
            }
            else
            {
                return $_v1;
            }
        }
        else
        {
            return $_v1;
        }
    }
    
    static function _t2($_v1)
    {
        if($_v1 instanceof Java)
        {
            $_v1 = java_values($_v1);
        }
        if(is_array($_v1))
        {
            foreach($_v1 as $_v2 => $_v3)
            {
                $_v1[$_v2] = ClassFactory::_t2($_v3);
            }
            return $_v1;
        }
        else
        {
            return ClassFactory::_t3($_v1);
        }
    }
    
    static function _t3($_v1)
    {
        if($_v1 instanceof Java)
        {
            $_v2 = "" . $_v1->getClass();
            $_v3 = strpos($_v2, ":\"class ");
            if(!is_bool($_v3))
            {
                $_v2 = substr($_v2, $_v3+8, -2);
            }
            if(array_key_exists($_v2, ClassFactory::$_vv1))
            {
                return new ClassFactory::$_vv1[$_v2]($_v1);
            }
            else
            {
                $_v3 = strrpos($_v2, ".");
                if(!is_bool($_v3))
                {
                    $_v2 = substr($_v2, $_v3+1);
                }
                if(class_exists($_v2))
                {
                    return new $_v2($_v1);
                }
                else
                {
                    return $_v1;
                }
            }
        }
        else
        {
            return $_v1;
        }
    }
}

?>
